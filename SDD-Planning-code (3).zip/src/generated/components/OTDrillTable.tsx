// Session 1-06 Part B · 3. the 12-month table of the OT team card.
// Only the Plan OT column is editable, and only outside the locked past months (decision E).
import { useMemo } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@components/ui/table';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { ALLMI, MONTHS } from '@generated/config';
import { fmt, isPastMonth, n1 } from '@generated/engine';
import { headNames } from '@generated/engine/part-b';
import type { Tier2Row } from '@generated/engine/part-c';
import { TT } from '@generated/i18n';
import { EC } from '@generated/components/MPShared';
import type { Person, Span } from '@generated/model/types';

interface OTDrillTableProps {
  t: string;
  fy: number;
  plan: (number | null)[];
  hs: number[];
  hLo: number;
  hHi: number;
  L2: Tier2Row[];
  edit: boolean;
  back: boolean;
  setCell: (t: string, mi: number, v: number | null) => void;
  assign: Span[];
  peopleNow: Person[];
  fyCode?: Record<number, string[]>;
}

const TH = 'text-[11px] font-semibold text-[color:var(--t2)]';
const TD = 'py-[4px] text-[12px]';

export function OTDrillTable(props: OTDrillTableProps) {
  const byMi = useMemo(() => {
    const m = new Map<number, Tier2Row>();
    for (const r of props.L2) if (r.team === props.t) m.set(r.mi, r);
    return m;
  }, [props.L2, props.t]);

  return (
    <TooltipProvider>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className={TH}>{TT('เดือน')}</TableHead>
              <TableHead className={`${TH} text-right`}>{TT('คน')}</TableHead>
              <TableHead className={`${TH} text-right`}>{TT('เฉลี่ย/คน')}</TableHead>
              <TableHead className={`${TH} text-right`} style={{ width: 96 }}>
                Plan OT
              </TableHead>
              <TableHead className={`${TH} text-right`}>{TT('โควตา MP')}</TableHead>
              <TableHead className={`${TH} text-right`}>{TT('โควตา+OT')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {ALLMI.map((i) => {
              const v = props.plan[i] ?? null;
              const row = byMi.get(i);
              const hm = row ? row.head : props.hs[i] || 0;
              const avg = row ? row.otAvg : v != null && hm > 0 ? v / hm : null;
              const moved = props.hLo !== props.hHi && hm > 0 && hm !== props.hHi;
              const past = isPastMonth(props.fy, i, props.fyCode);
              const headTip =
                hm > 0
                  ? `${moved ? TT('เดือนนี้คนไม่เท่าเดือนอื่น · ') : ''}${TT('นับ')} ${hm} ${TT(
                      'คน',
                    )} — ${headNames(props.t, props.fy, i, props.assign, props.peopleNow, props.fyCode).join(' · ')}`
                  : TT('ไม่มีคนที่นับโควตาในเดือนนี้');

              return (
                <TableRow key={i}>
                  <TableCell className={`${TD} font-semibold`}>{MONTHS[i]}</TableCell>
                  <TableCell
                    className={`${TD} text-right ${
                      moved
                        ? 'font-bold text-[color:var(--or)]'
                        : 'text-[color:var(--t3)]'
                    } ${hm > 0 ? 'cursor-help' : ''}`}
                  >
                    {hm > 0 ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span>{hm}</span>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-[340px]">
                          <span style={{ whiteSpace: 'normal' }}>{headTip}</span>
                        </TooltipContent>
                      </Tooltip>
                    ) : (
                      '—'
                    )}
                  </TableCell>
                  <TableCell className={`${TD} text-right font-bold text-[color:var(--or)]`}>
                    {avg == null ? '—' : n1(avg)}
                  </TableCell>
                  <TableCell className={TD} style={{ width: 96 }}>
                    {!props.edit ? (
                      v == null ? (
                        <span className="block text-right font-semibold text-[color:var(--or)]">—</span>
                      ) : (
                        <span className="block text-right font-semibold">{fmt(v, 0, 'Hrs')}</span>
                      )
                    ) : past && !props.back ? (
                      <EC
                        v={v}
                        cap={0}
                        u="Hrs"
                        lock={{ k: 'time', why: TT('เดือนที่ผ่านมาแล้ว · ต้องเปิดโหมดย้อนหลังก่อนจึงจะแก้ไขได้') }}
                        lockWhy={TT('เดือนที่ผ่านมาแล้ว · ต้องเปิดโหมดย้อนหลังก่อนจึงจะแก้ไขได้')}
                      />
                    ) : (
                      <EC
                        v={v}
                        cap={0}
                        u="Hrs"
                        nullable
                        showZero
                        title={MONTHS[i]}
                        set={(x) => props.setCell(props.t, i, x)}
                      />
                    )}
                  </TableCell>
                  <TableCell className={`${TD} text-right`}>
                    {row ? fmt(row.quota, 0, 'Hrs') : '—'}
                  </TableCell>
                  <TableCell className={`${TD} text-right font-semibold`}>
                    {row ? fmt(row.allow, 0, 'Hrs') : '—'}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </TooltipProvider>
  );
}
