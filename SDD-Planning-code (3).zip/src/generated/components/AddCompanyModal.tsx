// Session 1-14 · แผนงาน ISUZU Group → "เพิ่มบริษัท". Creates TWELVE empty Company Plan rows
// (one per month of the selected FY) for a group + company pair that has none. Dropdowns only.
import { useMemo, useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@components/ui/select';
import { Button } from '@components/ui/button';
import { Loader2 } from 'lucide-react';
import { Modal, BoardTag } from '@generated/components/MPShared';
import { TT } from '@generated/i18n';
import { createCpCompanyRows, fyMonthYears, NoFyGroupError } from '@generated/lib/add-rows';
import { firstSeen } from '@generated/lib/cp';
import type { CpRow } from '@generated/lib/types';

export function noFyGroupText(e: NoFyGroupError): string {
  return `${TT('ยังไม่มีกลุ่ม FY')}${e.fy} ${TT('บนบอร์ด')} ${e.board} · ${TT('กรุณาสร้างกลุ่มนี้บนบอร์ดก่อนจึงจะเพิ่มแถวได้')}`;
}

export function AddCompanyModal(props: {
  fy: string | number;
  cp: CpRow[]; // the whole board, every FY
  close: () => void;
  done: () => Promise<void>;
  T: (msg: string) => void;
}) {
  const { fy, cp, close, done, T } = props;
  const FYK = String(fy);
  const groups = useMemo(() => firstSeen(cp.map((r) => r.grp)).filter(Boolean), [cp]);
  const [grp, setGrp] = useState(groups[0] ?? '');
  const [co, setCo] = useState('');
  const [busy, setBusy] = useState(false);
  const [n, setN] = useState(0);
  const [err, setErr] = useState('');

  // Every company on the board (any group, any FY) minus those already in this group for this FY.
  const companies = useMemo(() => {
    const taken = new Set(cp.filter((r) => String(r.fy) === FYK && r.grp === grp).map((r) => r.co));
    return firstSeen(cp.map((r) => r.co))
      .filter((c) => c && !taken.has(c))
      .sort((a, b) => a.localeCompare(b));
  }, [cp, FYK, grp]);

  const months = fyMonthYears(FYK);
  const ok = !!grp && !!co && companies.includes(co) && !busy;

  const submit = async () => {
    if (!ok) return;
    setBusy(true);
    setErr('');
    setN(0);
    try {
      const r = await createCpCompanyRows(grp, co, FYK, setN);
      await done();
      if (r.failed) {
        setErr(`${TT('สร้างได้')} ${r.created.length}/12 ${TT('แถว · ที่เหลือไม่สำเร็จ กรุณาตรวจบนบอร์ดก่อนลองใหม่')}`);
        return;
      }
      T(`${TT('เพิ่ม')} ${co} ${TT('ใน')} ${grp} ${TT('ปีงบ')} ${FYK} ${TT('ครบ 12 เดือน')}`);
      close();
    } catch (e) {
      console.error('Add company failed:', e);
      setErr(e instanceof NoFyGroupError ? noFyGroupText(e) : TT('ไม่สามารถเพิ่มแถวได้ กรุณาลองใหม่'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      show
      alertModal={busy}
      onClose={busy ? () => {} : close}
      pill={<BoardTag board="Company Plan" />}
      title={TT('เพิ่มบริษัท')}
      sub={`${TT('สร้างแถวเปล่าครบ 12 เดือน สำหรับปีงบ')} ${FYK}`}
      footer={
        <Button onClick={submit} disabled={!ok}>
          {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {busy ? `${n}/12` : TT('เพิ่มบริษัท')}
        </Button>
      }
    >
      <div className="space-y-4">
        <div className="space-y-1.5">
          <label className="block text-[13px] font-medium">{TT('กลุ่ม')}</label>
          <Select value={grp} onValueChange={(v) => { setGrp(v); setCo(''); }} disabled={busy}>
            <SelectTrigger aria-label={TT('กลุ่ม')}><SelectValue placeholder="—" /></SelectTrigger>
            <SelectContent>
              {groups.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <label className="block text-[13px] font-medium">{TT('บริษัท')}</label>
          <Select value={co} onValueChange={setCo} disabled={busy || companies.length === 0}>
            <SelectTrigger aria-label={TT('บริษัท')}><SelectValue placeholder="—" /></SelectTrigger>
            <SelectContent>
              {companies.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          <p className="text-[11.5px] text-muted-foreground">{TT('บริษัทใหม่ที่ยังไม่เคยมีบนบอร์ด ให้เพิ่มบนบอร์ดก่อน')}</p>
          {grp && companies.length === 0 && (
            <p className="text-[12px] font-semibold text-[#B54708]">{TT('กลุ่มนี้มีครบทุกบริษัทแล้วในปีงบนี้')}</p>
          )}
        </div>
        {ok && (
          <p className="text-[12.5px] font-semibold">
            {TT('จะสร้าง 12 แถว —')} {months[0]} {TT('ถึง')} {months[11]}
          </p>
        )}
        {err && <p className="text-[12px] font-semibold text-destructive">{err}</p>}
      </div>
    </Modal>
  );
}
