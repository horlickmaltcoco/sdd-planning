// A2 · Shared components for the MP Plan page (Session 1-03)
import { type ReactNode, useEffect, useRef, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@components/ui/dialog';
import { Button } from '@components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@components/ui/select';
import { Input } from '@components/ui/input';
import { Switch } from '@components/ui/switch';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { Search } from 'lucide-react';
import { TT } from '@generated/i18n';
import { HPD, hit, n0, n1, nn } from '@generated/engine';
import { cn } from '@lib/utils';

// Modal: full-screen overlay with header (pill+title+sub+close) + children + footer
interface ModalProps {
  show: boolean;
  onClose: () => void;
  pill?: ReactNode;
  title: ReactNode;
  sub?: string;
  children: ReactNode;
  closeTitle?: string;
  footer?: ReactNode;
  size?: 'medium' | 'large';
  /** While true the dialog is an alert: ESC, the backdrop and the X cannot close it. */
  alertModal?: boolean;
  /** Optional DOM id for the dialog surface (e.g. "val-team-drill"). */
  id?: string;
}

export function Modal(props: ModalProps) {
  const locked = !!props.alertModal;
  return (
    <Dialog open={props.show} onOpenChange={(open) => !open && !locked && props.onClose()}>
      <DialogContent
        id={props.id}
        showCloseButton={!locked}
        onEscapeKeyDown={locked ? (e) => e.preventDefault() : undefined}
        onPointerDownOutside={locked ? (e) => e.preventDefault() : undefined}
        onInteractOutside={locked ? (e) => e.preventDefault() : undefined}
        className={cn(
          // Session 1-24 · a fixed shape: at most 85% of the window, header and footer always in view,
          // only the middle scrolls (flex column; the middle takes what is left and never pushes the footer).
          'flex max-h-[85dvh] w-[96vw] flex-col sm:max-w-[640px]',
          props.size === 'large' && 'sm:max-w-[1680px]',
        )}
      >
        <DialogHeader className="shrink-0">
          <DialogTitle>
            {props.pill && <div className="mb-[5px]">{props.pill}</div>}
            {typeof props.title === 'string' ? TT(props.title) : props.title}
          </DialogTitle>
          {props.sub && <DialogDescription>{TT(props.sub)}</DialogDescription>}
        </DialogHeader>
        <div className="min-h-0 flex-1 overflow-y-auto">{props.children}</div>
        <div className="flex shrink-0 items-center justify-end gap-[8px] border-t pt-[16px]">
          <TooltipProvider>
            {props.closeTitle ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="secondary" onClick={props.onClose} disabled={locked}>
                    {TT('ปิด')}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{TT(props.closeTitle)}</TooltipContent>
              </Tooltip>
            ) : (
              <Button variant="secondary" onClick={props.onClose} disabled={locked}>
                {TT('ปิด')}
              </Button>
            )}
          </TooltipProvider>
          {props.footer}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// BoardTag: chip "บอร์ด {board}" with tooltip
export function BoardTag({ board }: { board: string }) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="inline-flex items-center gap-[4px] rounded-[4px] bg-muted px-[8px] py-[3px] text-[11px] text-muted-foreground">
            <b>{TT('บอร์ด')}</b> {board}
          </span>
        </TooltipTrigger>
        <TooltipContent>
          {TT('หน้านี้อ่านและเขียนลงบอร์ด ')}
          {board}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// ImportBtn: button "⇪ นำเข้าไฟล์"
interface ImportBtnProps {
  onClick: () => void;
  disabled?: boolean;
  title?: string;
}

export function ImportBtn(props: ImportBtnProps) {
  const button = (
    <Button variant="secondary" size="sm" disabled={!!props.disabled} onClick={props.onClick}>
      {TT('⇪ นำเข้าไฟล์')}
    </Button>
  );
  if (!props.title) return button;
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span>{button}</span>
        </TooltipTrigger>
        <TooltipContent>{TT(props.title)}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Filters: labelled selects + search + counter + clear
interface FilterItem {
  label: string;
  value: string;
  options: Array<{ v: string; t: string | React.ReactNode; title?: string }>;
  onChange: (v: string) => void;
  all?: string;
  minWidth?: string;
  maxMenuHeight?: string;
}

interface FiltersProps {
  items: FilterItem[];
  extra?: ReactNode;
  search?: {
    label?: string;
    placeholder: string;
    value: string;
    onChange: (v: string) => void;
  };
  /** Omit count/total to hide the "แสดง X จาก Y รายการ" badge (e.g. pages with no row list). */
  count?: number;
  total?: number;
  onClear: () => void;
}

/** Search box: types freely, reports to the page only after 200 ms of quiet (C2). */
function DebouncedSearch(props: {
  label?: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  const [draft, setDraft] = useState(props.value);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onChangeRef = useRef(props.onChange);
  onChangeRef.current = props.onChange;

  // An outside reset (✕ ล้างตัวกรอง, team change) must show in the box at once.
  useEffect(() => {
    setDraft(props.value);
  }, [props.value]);

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  const push = (v: string, now = false) => {
    setDraft(v);
    if (timer.current) clearTimeout(timer.current);
    if (now) {
      onChangeRef.current(v);
      return;
    }
    timer.current = setTimeout(() => onChangeRef.current(v), 200);
  };

  return (
    <div style={{ minWidth: '200px' }}>
      <label htmlFor="search-input" className="mb-[4px] block text-[11px] font-medium text-muted-foreground">
        {TT(props.label || 'ค้นหา')}
      </label>
      <div className="relative">
        <Search
          size={14}
          aria-hidden
          className="pointer-events-none absolute left-[10px] top-[50%] translate-y-[-50%] text-muted-foreground"
        />
        <Input
          id="search-input"
          type="text"
          value={draft}
          onChange={(e) => push(e.target.value)}
          placeholder={TT(props.placeholder)}
          aria-label={TT('ค้นหา')}
          className="h-[32px] pl-[30px] pr-[28px] text-[13px]"
        />
        {draft && (
          <button
            type="button"
            onClick={() => push('', true)}
            className="absolute right-[6px] top-[50%] translate-y-[-50%] text-[14px] text-muted-foreground hover:text-foreground"
            aria-label={TT('ล้างคำค้นหา')}
            title={TT('ล้างคำค้นหา')}
          >
            ✕
          </button>
        )}
      </div>
    </div>
  );
}

// UAT · a filter with MORE than this many options gets a type-to-filter box in its menu.
const FILTER_TYPE_MIN = 8;

/** Plain text of an option, for matching (only the ALL option is app text). */
function optText(opt: FilterItem['options'][number]): string {
  if (typeof opt.t === 'string') return opt.v === 'ALL' ? TT(opt.t) : opt.t;
  return String(opt.v);
}

/** One filter Select. Behaves exactly as before; long lists add a filter box at the top. */
export function FilterSelect({ item }: { item: FilterItem }) {
  const searchable = item.options.length > FILTER_TYPE_MIN;
  const [open, setOpen] = useState(false);
  const [fq, setFq] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  const matches = (opt: FilterItem['options'][number]) => !searchable || hit(fq, [optText(opt), opt.v]);
  const firstMatch = searchable && fq.trim() ? item.options.find(matches) : undefined;
  const anyMatch = !searchable || !fq.trim() || item.options.some(matches);

  // A stale query must never hide options: reset on every open AND close.
  const onOpenChange = (o: boolean) => {
    setFq('');
    setOpen(o);
  };

  return (
    <Select value={item.value} onValueChange={item.onChange} open={open} onOpenChange={onOpenChange}>
      <SelectTrigger id={`filter-${item.label}`} className="h-[32px] text-[13px]" style={{ minWidth: item.minWidth || '160px' }}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent 
        position="popper"
        side="bottom"
        align="start"
        sideOffset={4}
        className="max-w-[500px]"
        style={{ maxHeight: item.maxMenuHeight || '640px' }}
        onKeyDownCapture={
          searchable
            ? (e) => {
                // A printable key pressed while an option has focus goes to the filter box
                // instead of Select's own typeahead (which would jump the highlight).
                const printable = e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey;
                if (printable && e.target !== inputRef.current && inputRef.current) {
                  e.stopPropagation();
                  inputRef.current.focus();
                }
              }
            : undefined
        }
      >
        {searchable && (
          <div className="sticky top-0 z-10 -mx-1 -mt-1 mb-1 border-b border-border bg-popover p-[6px]">
            <Input
              ref={inputRef}
              type="text"
              value={fq}
              onChange={(e) => setFq(e.target.value)}
              placeholder={TT('พิมพ์เพื่อค้นหา')}
              aria-label={TT('พิมพ์เพื่อค้นหา')}
              className="h-[28px] text-[12.5px]"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => e.stopPropagation()}
              onKeyDown={(e) => {
                // Escape → let it through: Select closes (its listener is on the document).
                if (e.key === 'Escape') return;
                // Arrow Up/Down → let it through: Select moves focus into the (filtered) options.
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') return;
                // Enter → pick the first matching option, exactly as clicking it would.
                if (e.key === 'Enter') {
                  e.preventDefault();
                  e.stopPropagation();
                  if (firstMatch) {
                    item.onChange(firstMatch.v);
                    onOpenChange(false);
                  }
                  return;
                }
                // Every other key (letters, Space, Backspace, Home/End, …) stays in the box.
                e.stopPropagation();
              }}
            />
          </div>
        )}
        {!anyMatch && (
          <div className="px-[8px] py-[6px] text-[12.5px] text-muted-foreground">{TT('ไม่พบตัวเลือก')}</div>
        )}
        {item.options.map((opt) => {
          // Non-matching options stay mounted (so the trigger keeps showing the selected value)
          // but are hidden AND disabled, which also takes them out of arrow-key navigation.
          const off = !matches(opt);
          return (
            <SelectItem 
              key={opt.v} 
              value={opt.v} 
              disabled={off}
              className={cn('items-start whitespace-normal py-[6px] leading-[1.4]', off && 'hidden')}
            >
              <span className="inline">
                {/* Only the ALL option is app text; every other option is a data value. */}
                {opt.v === 'ALL' && typeof opt.t === 'string' ? TT(opt.t) : opt.t}
              </span>
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );
}

export function Filters(props: FiltersProps) {
  const anyDirty =
    props.items.some((item) => item.value !== (item.all || 'ALL')) || (props.search && props.search.value !== '');

  return (
    <div className="mb-[16px] flex flex-wrap items-end gap-[8px]">
      {props.items.map((item) => (
        <div key={item.label} style={{ minWidth: item.minWidth || '160px' }}>
          <label htmlFor={`filter-${item.label}`} className="mb-[4px] block text-[11px] font-medium text-muted-foreground">
            {TT(item.label)}
          </label>
          <FilterSelect item={item} />
        </div>
      ))}
      {props.extra}
      {props.search && (
        <DebouncedSearch
          label={props.search.label}
          placeholder={props.search.placeholder}
          value={props.search.value}
          onChange={props.search.onChange}
        />
      )}
      {props.count != null && props.total != null && (
        <span className="text-[13px] text-muted-foreground">
          {TT('แสดง ')}
          <b>{n0(props.count)}</b>
          {TT(' จาก ')}
          {n0(props.total)}
          {TT(' รายการ')}
        </span>
      )}
      {anyDirty && (
        <button
          type="button"
          onClick={props.onClear}
          className="text-[13px] font-medium text-destructive hover:underline"
        >
          {TT('✕ ล้างตัวกรอง')}
        </button>
      )}
    </div>
  );
}

// K: KPI card (label · value · sub). Custom by design — Vibe has no KPI card and
// FormattedNumber would compact "2,294.5h" into "2.3K".
interface KProps {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: 'or' | 'gn' | 'rd';
  /** Optional: turns the card into a clickable (and keyboard-reachable) nav shortcut. */
  onClick?: () => void;
  /** Optional colour override for the value, e.g. "var(--gn)" — wins over tone. */
  color?: string;
  /** Optional tooltip shown on hover. */
  title?: string;
}

export function K(props: KProps) {
  const color = props.color ?? (props.tone ? `var(--${props.tone})` : 'var(--tx)');
  const clickable = !!props.onClick;
  const card = (
    <div
      className={cn(
        'rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[14px]',
        clickable &&
          'cursor-pointer transition-all hover:-translate-y-[1px] hover:border-[color:var(--yl)] hover:shadow-[0_4px_14px_rgba(217,45,32,0.12)]',
      )}
      onClick={props.onClick}
      onKeyDown={
        clickable
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                props.onClick!();
              }
            }
          : undefined
      }
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
    >
      <div className="text-[11.5px] font-medium leading-[1.35] text-[color:var(--t2)]">
        {TT(props.label)}
      </div>
      <div className="mt-[6px] text-[24px] font-bold leading-[1.15]" style={{ color }}>
        {props.value}
      </div>
      {props.sub != null && (
        <div className="mt-[3px] text-[11px] leading-[1.35] text-[color:var(--t3)]">{props.sub}</div>
      )}
    </div>
  );
  if (!props.title) return card;
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{card}</TooltipTrigger>
        <TooltipContent>{TT(props.title)}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Sw: the app's on/off switch. Always CONTROLLED — an uncontrolled switch would start
// ON for every team regardless of what the board says.
interface SwProps {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}

export function Sw(props: SwProps) {
  return (
    <Switch
      checked={props.on}
      onCheckedChange={props.onChange}
      aria-label={props.label}
      className="h-[18px] w-[32px]"
    />
  );
}

// Part S · label of a segmented switch (unit, มุมมอง, chart view): its own full-width line ABOVE
// the buttons — block · 11px · letter-spacing .1px · #475467 · 600 · margin-bottom 5px · nowrap.
export const SEG_LABEL =
  'mb-[5px] block whitespace-nowrap text-[11px] font-semibold tracking-[.1px] text-[color:var(--t2)]';

// UnitSeg: label line (หน่วย [· hint]) above the Hrs/MD/% buttons
interface UnitSegProps {
  value: 'Hrs' | 'MD' | '%';
  onChange: (v: 'Hrs' | 'MD' | '%') => void;
  hint?: string;
}

export function UnitSeg(props: UnitSegProps) {
  const options = [
    { value: 'Hrs' as const, text: 'Hrs', tooltip: TT('ชั่วโมง (ค่าดิบในไฟล์)') },
    { value: 'MD' as const, text: 'MD', tooltip: `${TT('MD = ชั่วโมง ÷ ชม./วัน ของปีงบ')} (${HPD})` },
    { value: '%' as const, text: '%', tooltip: TT('% เทียบโควตา+OT หรือ capacity') },
  ];

  // One string; the hint arrives already translated. Nothing renders beside or below the buttons.
  const label = TT('หน่วย') + (props.hint ? ' · ' + props.hint : '');

  return (
    <div className="unitseg" style={{ minWidth: '160px' }}>
      <span className={SEG_LABEL}>{label}</span>
      <div className="flex gap-[4px]" role="group" aria-label={TT('เลือกหน่วยที่แสดง')}>
        <TooltipProvider>
          {options.map((opt) => (
            <Tooltip key={opt.value}>
              <TooltipTrigger asChild>
                <Button
                  variant={props.value === opt.value ? 'default' : 'secondary'}
                  size="sm"
                  onClick={() => props.onChange(opt.value)}
                >
                  {opt.text}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{opt.tooltip}</TooltipContent>
            </Tooltip>
          ))}
        </TooltipProvider>
      </div>
    </div>
  );
}

// EC: the ONE cell component for every number cell
interface ECProps {
  v: number | null;
  cap: number;
  u: 'Hrs' | 'MD' | '%';
  lock?: { k: 'team' | 'time'; t?: string; why: string };
  lockTeam?: string;
  lockWhy?: string;
  ro?: boolean;
  onClick?: () => void;
  set?: (v: number | null) => void;
  nullable?: boolean;
  title?: string;
  /** OT only: 0 is a real value there ("filled with zero"), so it must not look empty. */
  showZero?: boolean;
}

export function EC(props: ECProps) {
  const [inputVal, setInputVal] = useState('');

  // Helper to format value
  const fmtVal = (v: number | null): string => {
    if (v === null) return '–';
    if (v === 0) return props.u === 'Hrs' ? n1(0) : '–';
    const val = props.u === 'MD' ? v / HPD : props.u === '%' ? (v / props.cap) * 100 : v;
    if (props.u === '%') return `${nn(val)}%`;
    if (props.u === 'MD') return n1(val);
    return n1(val); // Hours: always use n1 (one decimal)
  };

  // Branch 1: locked
  if (props.lock) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span
              className={cn(
                'eclk inline-flex min-h-[28px] w-full cursor-not-allowed items-center justify-end bg-[repeating-linear-gradient(45deg,_#F9FAFB,_#F9FAFB_10px,_transparent_10px,_transparent_20px)] px-[8px] py-[4px] text-[11px] text-muted-foreground opacity-75 font-mono',
                props.lockTeam && 'relative pt-[16px]',
              )}
            >
              {props.lockTeam && (
                <span className="absolute left-0 top-0 w-full bg-[#7A5AF8] px-[4px] py-[1px] text-center text-[9px] font-bold text-white">
                  {props.lockTeam}
                </span>
              )}
              <span>{fmtVal(props.v)}</span>
              {!props.lockTeam && <span className="ml-[4px]">🔒</span>}
            </span>
          </TooltipTrigger>
          <TooltipContent>{props.lockWhy || TT('ช่องนี้แก้ที่นี่ไม่ได้')}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Branch 2: read-only
  if (props.ro) {
    const content = (
      <span
        className={cn(
          'ecro inline-flex min-h-[28px] w-full items-center justify-end px-[8px] py-[4px] text-[11px] font-mono',
          props.onClick && 'ck cursor-pointer hover:bg-[#F7D3D9]',
        )}
        onClick={props.onClick}
        onKeyDown={(e) => {
          if (props.onClick && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault();
            props.onClick();
          }
        }}
        role={props.onClick ? 'button' : undefined}
        tabIndex={props.onClick ? 0 : undefined}
      >
        {fmtVal(props.v)}
      </span>
    );
    if (!props.onClick) return content;
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>{content}</TooltipTrigger>
          <TooltipContent>{TT('คลิกเพื่อเปิดการ์ดแล้วกดแก้ไข')}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Branch 3: % (not editable)
  if (props.u === '%') {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="inline-flex min-h-[28px] w-full items-center justify-end px-[8px] py-[4px] text-[11px] font-mono">
              {fmtVal(props.v)}
            </span>
          </TooltipTrigger>
          <TooltipContent>
            {n1(props.v ?? 0)}
            {TT(' ชม.')}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Branch 4: editable input. Hours keep their decimals and carry NO thousands separator —
  // an input must hold exactly what parseFloat reads back ("12.5", "1000", never "1,000").
  const displayVal =
    props.v === null || (props.v === 0 && !props.showZero)
      ? ''
      : props.u === 'MD'
        ? n1(props.v / HPD)
        : String(nn(props.v));
  const tooltipText =
    `${props.title ? `${TT(props.title)} · ` : ''}${TT('กรอกเป็น')}${props.u === 'MD' ? ' MD' : TT(' ชั่วโมง')}` +
    `${TT(' · ปัจจุบัน ')}${props.v === null ? TT('ยังไม่กรอก') : `${n1(props.v)}${TT(' ชม.')}`}`;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const stripped = e.target.value.replace(/[^0-9.]/g, '');
    setInputVal(stripped);
    if (!props.set) return;

    if (props.nullable && stripped === '') {
      props.set(null);
      return;
    }

    const x = parseFloat(stripped);
    if (Number.isNaN(x)) {
      props.set(props.nullable ? null : 0);
    } else {
      const hours = props.u === 'MD' ? x * HPD : x;
      props.set(nn(hours));
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Input
            type="text"
            value={inputVal || displayVal}
            onChange={handleChange}
            onFocus={(e) => setInputVal(e.target.value)}
            onBlur={() => setInputVal('')}
            placeholder="–"
            className={cn(
              'ec h-[28px] w-full px-[8px] py-[4px] text-right text-[11px] font-mono',
              (!props.v || props.v === 0) && 'z text-muted-foreground',
            )}
          />
        </TooltipTrigger>
        <TooltipContent>{tooltipText}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
