// C3 · shown while a board the current page needs is loading. A plain white card: spinner +
// one line per board (all five, so the user can see what is still coming). CHANGE 4 · each
// line shows the live item count reported by the loader. No skeleton of numbers.
import { Check, Loader2, TriangleAlert } from 'lucide-react';
import type { BoardKey } from '@generated/config';
import { TT } from '@generated/i18n';
import type { BoardState } from '@generated/lib/types';

const fmtN = (n: number) => n.toLocaleString('en-US');

export default function LoadingCard(props: {
  bs: Record<BoardKey, BoardState>;
  order: BoardKey[];
  prog: Record<BoardKey, number | null>;
}) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="mb-[14px] rounded-[var(--r)] border border-[color:var(--bd)] bg-[var(--cd)] px-[20px] py-[18px] shadow-[var(--sd)]"
    >
      <div className="flex items-center gap-[10px] text-[13.5px] font-semibold text-[color:var(--tx)]">
        <Loader2 size={16} className="animate-spin text-[color:var(--yl)]" aria-hidden />
        {TT('กำลังโหลดข้อมูลจากบอร์ด…')}
      </div>
      <ul className="mt-[10px] flex flex-col gap-[5px] pl-[26px]">
        {props.order.map((b) => {
          const s = props.bs[b]?.status ?? 'loading';
          const n = props.prog[b];
          const tail =
            s === 'loading'
              ? n == null
                ? '…'
                : `${fmtN(n)} ${TT('รายการ')}…`
              : s === 'ok'
                ? `${fmtN(n ?? 0)} ${TT('รายการ')}`
                : '✕';
          return (
            <li key={b} className="flex items-center gap-[8px] text-[12.5px] text-[color:var(--t2)]">
              {s === 'loading' ? (
                <Loader2 size={12} className="animate-spin text-[color:var(--t3)]" aria-hidden />
              ) : s === 'ok' ? (
                <Check size={12} className="text-[color:var(--gn)]" aria-hidden />
              ) : (
                <TriangleAlert size={12} className="text-[color:var(--rd)]" aria-hidden />
              )}
              <span className="font-medium text-[color:var(--tx)]">{b}</span>
              <span className="tabular-nums text-[color:var(--t3)]">· {tail}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
