// C1 · amber banner: the selected FY has no annual rule row and/or no working days on board 03,
// so the engine is running on its documented defaults. Never fall back silently.
import { BAND_DEFAULT } from '@generated/config';
import { TT } from '@generated/i18n';

interface RuleFallbackNoteProps {
  fy: string | number;
  hasRule: boolean;
  hasWd: boolean;
  /** Hours per Day the engine is using for this FY (computed, else HPD_FALLBACK). */
  hpd: number;
}

export function RuleFallbackNote({ fy, hasRule, hasWd, hpd }: RuleFallbackNoteProps) {
  if (hasRule && hasWd) return null;
  return (
    <div className="mb-[13px] rounded-[8px] border border-[color:var(--or)] bg-[var(--orl)] p-[14px]">
      <p className="mb-[6px] text-[13px] font-bold text-[color:var(--or)]">
        ⚠ {TT('ใช้ค่าตั้งต้นแทนข้อมูลบอร์ด SDD · Working Day Master')} · FY {String(fy)}
      </p>
      {!hasRule && (
        <p className="text-[12px] leading-[1.6] text-[color:var(--or)]">
          {TT('ไม่พบแถวกติกาประจำปีของปีงบนี้ · ระบบใช้ค่าตั้งต้น')}: Team Tolerance 0 · Block Person Below
          Capacity Yes · Block Person Above Capacity No · Red Frame Below 100% · Color Bands{' '}
          {BAND_DEFAULT.join(',')} · Hours per Day {hpd}
        </p>
      )}
      {!hasWd && (
        <p className="mt-[4px] text-[12px] leading-[1.6] text-[color:var(--or)]">
          {TT('ไม่พบวันทำงานของปีงบนี้ · ทุกเดือนนับเป็น 0 วัน')}
        </p>
      )}
    </div>
  );
}
