// Session 1-06 Part B · 1. the chart card "OT Plan รายเดือน". Two views, รายทีม (default) and
// ราย Group. There is no combined all-teams chart (customer, 2026-09-25) — the table total row
// carries that number. Every chart of one view shares one scale, and the scale is printed.
import { useMemo } from 'react';
import { ALLMI } from '@generated/config';
import { fmt } from '@generated/engine';
import { TT } from '@generated/i18n';
import { Button } from '@components/ui/button';
import { OTBar } from '@generated/components/OTBar';
import { SEG_LABEL } from '@generated/components/MPShared';
import { buildGroups, maxOf, totOf, type OtView } from '@generated/lib/ot-chart';
import type { OtCellView } from '@generated/lib/ot-derive';

interface OTChartProps {
  /** onTeams that have at least one filled month in view. Never a closed team. */
  shown: string[];
  MI: number[];
  fg: string;
  cv: OtView;
  setCv: (v: OtView) => void;
  otAt: (t: string, i: number) => OtCellView;
  grpAt: (t: string, i: number) => string;
  hcText: (t: string) => string;
  onDrill: (t: string) => void;
}

const GRID = 'grid grid-cols-[repeat(auto-fill,minmax(290px,1fr))] gap-[14px]';

export function OTChart(props: OTChartProps) {
  const teamCells = useMemo(
    () => props.shown.map((t) => ALLMI.map((i) => props.otAt(t, i))),
    [props.shown, props.otAt],
  );
  const maxT = useMemo(() => maxOf(teamCells, props.MI), [teamCells, props.MI]);

  const groups = useMemo(
    () => buildGroups(props.shown, props.MI, props.grpAt, props.otAt, props.fg),
    [props.shown, props.MI, props.grpAt, props.otAt, props.fg],
  );
  const maxG = useMemo(() => maxOf(groups.map((g) => g.cells), props.MI), [groups, props.MI]);

  const note =
    props.cv === 'team'
      ? `${TT('กราฟรายทีมใช้สเกลเดียวกันทุกใบ')} 0–${fmt(maxT, 0, 'Hrs')} ${TT('ชม. · เทียบความสูงข้ามทีมได้')}`
      : `${TT('กราฟราย Group ใช้สเกลเดียวกันทุกใบ')} 0–${fmt(maxG, 0, 'Hrs')} ${TT(
          'ชม. · รวมจากทีมที่เปิดไว้ตามตัวกรอง · Group ของแต่ละเดือนอ่านจากช่วงสังกัด',
        )}`;

  return (
    <div className="otchart mt-[16px] rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[16px]">
      <div className="mb-[10px] flex flex-wrap items-start justify-between gap-[12px]">
        <div className="min-w-0">
          <h2 className="text-[16px] font-bold leading-[1.3]">OT Plan {TT('รายเดือน')}</h2>
          <p className="mt-[3px] text-[12px] leading-[1.45] text-[color:var(--t2)]">
            {TT('ก้อนชั่วโมง OT ที่ทีมวางไว้แต่ละเดือน · เม.ย. → มี.ค. · ชี้ที่แท่งเพื่อดูชั่วโมงและเ��ลี่ย/คน')}
          </p>
        </div>
        <div className="seg otview">
          <span className={SEG_LABEL}>{TT('มุมมอง')}</span>
          <fieldset className="flex min-w-0 gap-[4px] border-0 p-0">
            <legend className="sr-only">{TT('มุมมอง')}</legend>
            <Button
              variant={props.cv === 'team' ? 'default' : 'secondary'}
              size="sm"
              onClick={() => props.setCv('team')}
            >
              {TT('รายทีม')}
            </Button>
            <Button
              variant={props.cv === 'grp' ? 'default' : 'secondary'}
              size="sm"
              onClick={() => props.setCv('grp')}
            >
              {TT('ราย Group')}
            </Button>
          </fieldset>
        </div>
      </div>

      <p className="mb-[8px] text-[11px] leading-[1.45] text-[color:var(--t3)]">{note}</p>

      {props.cv === 'team' ? (
        <div className={GRID}>
          {props.shown.map((t, n) => {
            const cells = teamCells[n] ?? [];
            return (
              <button
                key={t}
                type="button"
                onClick={() => props.onDrill(t)}
                className="otteam cursor-pointer rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[10px] text-left hover:border-[color:var(--t3)]"
              >
                <div className="mb-[4px] flex flex-wrap items-baseline">
                  <span className="text-[13px] font-bold">{t}</span>
                  <span className="ml-[6px] text-[11px] font-normal text-[color:var(--t3)]">
                    {TT('รวม')} {fmt(totOf(cells, props.MI), 0, 'Hrs')}h · {props.hcText(t)} {TT('คน')}
                  </span>
                </div>
                <OTBar cells={cells} MI={props.MI} max={maxT} name={t} />
              </button>
            );
          })}
        </div>
      ) : (
        <div className={GRID}>
          {groups.map((d) => (
            <div
              key={d.g}
              className="otgrp rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[10px]"
            >
              <div className="mb-[4px] flex flex-wrap items-baseline">
                <span className="text-[13px] font-bold">{d.g}</span>
                <span className="ml-[6px] text-[11px] font-normal text-[color:var(--t3)]">
                  {TT('รวม')} {fmt(d.tot, 0, 'Hrs')}h · {d.hc} {TT('คน')} · {d.teams.join(' ')}
                </span>
              </div>
              <OTBar cells={d.cells} MI={props.MI} max={maxG} name={d.g} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
