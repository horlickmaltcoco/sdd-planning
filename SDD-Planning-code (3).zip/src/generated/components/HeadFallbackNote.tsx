// Session 1-09 · shared banner: months where the engine had to fall back to the plan's own
// head-count instead of the Employee Master register (Tier2Row.headFb). Reused by Overview and
// by MP Plan pages — build it once here, never a second copy.
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';

interface HeadFbRow {
  team: string;
  mi: number;
  headFb: boolean;
}

interface HeadFallbackNoteProps {
  rows: HeadFbRow[];
}

export function HeadFallbackNote(props: HeadFallbackNoteProps) {
  const bad = props.rows.filter((r) => r.headFb);
  if (bad.length === 0) return null;

  // Group by team in order of first appearance.
  const order: string[] = [];
  const byTeam = new Map<string, number[]>();
  for (const r of bad) {
    if (!byTeam.has(r.team)) {
      byTeam.set(r.team, []);
      order.push(r.team);
    }
    byTeam.get(r.team)!.push(r.mi);
  }

  const teamsTxt = order
    .map((team) => {
      const mis = Array.from(new Set(byTeam.get(team) ?? [])).sort((a, b) => a - b);
      const label = mis.length === 12 ? TT('ทั้งปี') : mis.map((i) => MONTHS[i]).join(', ');
      return `${team} (${label})`;
    })
    .join(' · ');

  return (
    <div className="mb-[13px] rounded-[8px] border border-[#FDA29B] bg-[#FFFBFA] p-[14px]">
      <p className="mb-[8px] text-[13px] font-bold text-[#B42318]">
        ⚠ {TT('ไม่พบข้อมูลพนักงานของทีมในทะเบียนบุคคล')} {bad.length} {TT('ทีม × เดือน')}
      </p>
      <p className="text-[12px] leading-[1.6] text-[#7A271A]">
        {TT(
          'ช่วงเวลาเหล่านี้ระบบใช้จำนวนคนจากแผนแทนทะเบียน โควตาของช่วงนั้นจึงยังไม่ได้มาจากทะเบียนบุคคล · แก้ได้โดยเพิ่มพนักงานและช่วงสังกัดของทีมนั้นที่บอร์ด SDD · Employee Master',
        )}
      </p>
      <p className="mt-[6px] text-[11.5px] leading-[1.6] text-[#7A271A]">{teamsTxt}</p>
    </div>
  );
}
