// B1 · MP Plan row view table
import React, { useEffect, useMemo, useState } from 'react';
import { Card } from '@components/ui/card';
import { Button } from '@components/ui/button';
import { TT } from '@generated/i18n';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import type { Settings } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import type { MaskedRow } from '@generated/engine/part-b';
import { ALLMI, MONTHS, SRC_APP } from '@generated/config';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { EC } from '@generated/components/MPShared';
import { cn } from '@lib/utils';
import { systemMissing } from '@generated/lib/mp-fields';

interface RowViewProps {
  rows: MaskedRow[];
  MI: number[];
  S: Settings;
  P: Plan;
  u: 'Hrs' | 'MD' | '%';
  capY: number;
  headSel: number;
  lockOf: (r: MaskedRow, mi: number) => { k: 'team' | 'time'; t?: string; why: string } | null;
  onDrill: (r: MaskedRow) => void;
  capPerOf: (fy: string | number, mi: number) => number;
  peopleByEmp: Record<string, any>;
  peopleByName: Record<string, any>;
  types: string[];
}

const PAGE_ROWS = 300;

export function MPRowView(props: RowViewProps) {
  const { rows, MI, S, P, u, capY, headSel, lockOf, onDrill, capPerOf, peopleByEmp, peopleByName, types } = props;

  // Column totals
  const colTotals = useMemo(() => {
    return MI.map((mi) => rows.reduce((sum, r) => sum + (r.m[mi] || 0), 0));
  }, [rows, MI]);

  const grand = useMemo(() => {
    return rows.reduce((sum, r) => MI.reduce((s, mi) => s + (r.m[mi] || 0), 0) + sum, 0);
  }, [rows, MI]);

  // C2 · more than 300 rows: render the first 300 and append 300 per "แสดงเพิ่ม".
  // Totals and the counter always use ALL filtered rows, never the rendered window.
  const [limit, setLimit] = useState(PAGE_ROWS);
  useEffect(() => setLimit(PAGE_ROWS), [rows]);
  const shownRows = rows.length > PAGE_ROWS ? rows.slice(0, limit) : rows;

  if (rows.length === 0) {
    return (
      <Card className="p-8 text-center">
        <div className="text-[13px] text-muted-foreground">{TT('ไม่มีแถวตามตัวกรองที่เลือก')}</div>
      </Card>
    );
  }

  return (
    <Card className="p-0 overflow-hidden">
      <div className="overflow-x-auto overflow-y-auto max-h-[520px]">
        <table className="w-max min-w-full border-collapse text-[13px]">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-left font-medium text-muted-foreground w-[36px]">
                #
              </th>
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-left font-medium text-muted-foreground">
                Type
              </th>
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-left font-medium text-muted-foreground min-w-[200px]">
                Task1 / Detail
              </th>
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-left font-medium text-muted-foreground">
                Role
              </th>
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-left font-medium text-muted-foreground min-w-[140px]">
                Name
              </th>
              {MI.map((mi) => (
                <th
                  key={mi}
                  className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-center font-medium text-muted-foreground min-w-[90px]"
                >
                  <div>{MONTHS[mi]}</div>
                  <div className="text-[10px] font-normal text-muted-foreground">{P.WD[mi]}d</div>
                </th>
              ))}
              <th className="sticky top-0 z-10 bg-[var(--cd2)] px-3 py-2.5 text-right font-medium text-muted-foreground min-w-[90px]">
                {TT('รวม')}
              </th>
            </tr>
          </thead>
          <tbody>
            {shownRows.map((r, ri) => {
              const rowSum = MI.reduce((s, mi) => s + (r.m[mi] || 0), 0);
              const person = EB.personOfRow(r, peopleByEmp, peopleByName);
              const disp = person ? (person.mpname || person.name) : r.name;
              const namesDiffer = disp !== r.name;

              return (
                <tr key={r.id} data-id={r.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                  {/* # */}
                  <td className="px-3 py-2 text-muted-foreground">{ri + 1}</td>

                  {/* Type */}
                  <td className="px-3 py-2">
                    <span
                      className="inline-block rounded px-2 py-0.5 text-[11px] font-medium"
                      style={{
                        color: E.typeColor(r.type, types),
                        backgroundColor: E.typeColor(r.type, types) + '22',
                      }}
                    >
                      {r.type}
                    </span>
                  </td>

                  {/* Task1 / Detail - clickable */}
                  <td
                    className="px-3 py-2 cursor-pointer hover:bg-accent"
                    onClick={() => onDrill(r)}
                  >
                    <div className="font-medium">{r.t1 || '—'}</div>
                    {r.system && (
                      <div className="mt-0.5 text-[11px] text-muted-foreground">
                        System: {r.system}
                      </div>
                    )}
                    {r.task2 && (
                      <div className="mt-0.5 text-[11px] text-muted-foreground">Task2: {r.task2}</div>
                    )}
                    {systemMissing(r) && (
                      <div className="mt-0.5 text-[11px] font-medium text-[color:var(--negative-color,var(--rd))]">
                        {TT('ยังไม่ระบุ System')}
                      </div>
                    )}
                    {r.detail && (
                      <div className="mt-0.5 text-[11px] text-muted-foreground line-clamp-1">
                        {r.detail}
                      </div>
                    )}
                  </td>

                  {/* Role */}
                  <td className="px-3 py-2">
                    {r.role && (
                      <span className="inline-block rounded border border-border px-2 py-0.5 text-[11px]">
                        {r.role}
                      </span>
                    )}
                  </td>

                  {/* Name */}
                  <td className="px-3 py-2">
                    <TooltipProvider delayDuration={300}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button type="button" className="text-left w-full" aria-label={disp}>
                            <div className={cn('font-medium', namesDiffer && 'text-muted-foreground line-through')}>
                              {r.name}
                            </div>
                            {namesDiffer && <div className="mt-0.5 text-[11px]">{disp}</div>}
                          </button>
                        </TooltipTrigger>
                        <TooltipContent side="right">
                          <div className="text-[11px]">
                            {namesDiffer && (
                              <div className="mb-1">
                                <span className="text-muted-foreground">{TT('ระบบหา')}:</span> {disp}
                              </div>
                            )}
                            <div>
                              <span className="text-muted-foreground">EMP:</span> {r.empid || '—'}
                            </div>
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </td>

                  {/* Month cells */}
                  {MI.map((mi) => {
                    const lk = lockOf(r, mi);
                    const cap = capPerOf(S.fy, mi);
                    const v = lk && lk.k === 'team' ? ((r.mo && r.mo[mi]) || r.m[mi]) : r.m[mi];
                    return (
                      <td key={mi} className="px-1 py-1">
                        <EC
                          v={v}
                          u={u}
                          cap={cap}
                          ro
                          lock={lk || undefined}
                          lockTeam={lk && lk.k === 'team' ? lk.t : undefined}
                          lockWhy={lk ? `${lk.why} · ${r.name} · ${MONTHS[mi]}` : undefined}
                          onClick={() => !lk && onDrill(r)}
                        />
                      </td>
                    );
                  })}

                  {/* Row total */}
                  <td className="px-3 py-2 bg-[#F9FAFB] text-right font-mono font-bold">
                    {E.fmt(rowSum, capY, u)}
                  </td>
                </tr>
              );
            })}

            {/* Totals row */}
            <tr className="bg-[#F9FAFB] font-bold border-t-2 border-border">
              <td colSpan={5} className="px-3 py-2.5">
                {TT('รวม ')}
                {rows.length}
                {TT(' แถว')}
              </td>
              {MI.map((mi, idx) => (
                <td key={mi} className="px-3 py-2.5 text-center font-mono">
                  {E.fmt(colTotals[idx], capPerOf(S.fy, mi) * (headSel || 1), u)}
                </td>
              ))}
              <td className="px-3 py-2.5 text-right font-mono text-[#A30A23]">
                {E.fmt(grand, capY, u)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      {rows.length > shownRows.length && (
        <div className="flex items-center justify-center gap-[10px] border-t border-border py-[10px] text-[12px] text-muted-foreground">
          <span>
            {TT('แสดง ')}
            {E.n0(shownRows.length)}
            {TT(' จาก ')}
            {E.n0(rows.length)}
            {TT(' แถว')}
          </span>
          <Button variant="secondary" size="sm" onClick={() => setLimit((n) => n + PAGE_ROWS)}>
            {TT('แสดงเพิ่ม')}
          </Button>
        </div>
      )}
    </Card>
  );
}
