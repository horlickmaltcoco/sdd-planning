// C3 · one banner per failed board: title + board key + the monday error message + retry.
// Pinned above every page until a reload succeeds. No close button.
import { TT } from '@generated/i18n';

export default function LoadError(props: {
  boards: { key: string; msg: string }[];
  onRetry: () => void;
  busy: boolean;
}) {
  return (
    <div className="mb-[14px] flex flex-col gap-[10px]" role="alert">
      {props.boards.map((b) => (
        <div
          key={b.key}
          className="rounded-[var(--r)] border px-[18px] py-[14px]"
          style={{ borderColor: '#FDA29B', background: '#FFFBFA' }}
        >
          <div className="text-[13px] font-semibold" style={{ color: '#B42318' }}>
            ⚠ {TT('โหลดข้อมูลจากบอร์ดไม่สำเร็จ')}
          </div>
          <p className="mt-[4px] whitespace-normal break-words text-[12px] leading-[1.7] text-[color:var(--t2)]">
            <b>{b.key}</b> · {b.msg}
          </p>
          <button
            type="button"
            onClick={props.onRetry}
            disabled={props.busy}
            className="mt-[10px] rounded-[var(--rs)] border bg-[var(--cd)] px-[12px] py-[7px] text-[12px] font-semibold outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--yl)] disabled:opacity-60"
            style={{ borderColor: '#FDA29B', color: '#B42318' }}
          >
            {TT('ลองอีกครั้ง')}
          </button>
        </div>
      ))}
    </div>
  );
}
