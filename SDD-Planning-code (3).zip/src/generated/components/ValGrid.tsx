// Session 1-11 · "val" = Validation. READ-ONLY — never writes to any board. Opens on tier 2
// per spec (never the first tab). Reuses the Session 1-02 engine (tier1Judge/pillOf/statusOf)
// and the shared Filters/UnitSeg — no tier logic is recomputed here.
import { useCallback, useMemo, useState } from 'react';
import { fyOptions } from '@generated/components/FyOptions';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { Settings } from '@generated/model/types';
import type { Plan, Tier1Row, Tier2Row, Tier3Row } from '@generated/engine/part-c';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { Filters, UnitSeg } from '@generated/components/MPShared';
import { ValBanners } from '@generated/components/ValBanners';
import { ValL1Table } from '@generated/components/ValL1Table';
import { ValL2Table } from '@generated/components/ValL2Table';
import { ValL3Table } from '@generated/components/ValL3Table';
import { MonthDrill } from '@generated/components/MonthDrill';
import { PersonDrill } from '@generated/components/PersonDrill';
import { TeamDrill } from '@generated/components/TeamDrill';
import { cn } from '@lib/utils';

type Tab = 'l1' | 'l2' | 'l3';
type Drill = { k: 'person'; v: Tier1Row } | { k: 'team'; v: Tier2Row } | { k: 'month'; v: Tier3Row };

interface ValGridProps {
  S: Settings;
  setS: (fn: (prev: Settings) => Settings) => void;
  P: Plan;
  model: Model;
  go?: (p: string) => void;
  /** Session 1-15 · badge for years that are not prepared (display only). */
  fyUnprep?: (fy: string) => boolean;
}

function CountBadge({ n, active }: { n: number; active: boolean }) {
  const bad = n > 0;
  const cls = active
    ? bad
      ? 'bg-[var(--rd)] text-white'
      : 'bg-[var(--yl)] text-white'
    : bad
      ? 'bg-[var(--rdl)] text-[color:var(--rd)]'
      : 'bg-[var(--cd2)] text-[color:var(--t2)]';
  return (
    <span className={cn('ml-[7px] inline-flex min-w-[24px] items-center justify-center rounded-full px-[6px] py-[1px] text-[11px] font-semibold', cls)}>
      {n}
    </span>
  );
}

export default function ValGrid({ S, setS, P, model, go, fyUnprep }: ValGridProps) {
  const [tab, setTab] = useState<Tab>('l2');
  const [fg, setFg] = useState('ALL');
  const [ft, setFt] = useState('ALL');
  const [fm, setFm] = useState('ALL');
  const [fs, setFs] = useState('ALL');
  const [u, setU] = useState<'Hrs' | 'MD' | '%'>('Hrs');
  const [q, setQ] = useState('');
  const [drill, setDrill] = useState<Drill | null>(null);
  const closeDrill = useCallback(() => setDrill(null), []);

  const A = model.ASSIGN;
  const FC = model.FYCODE;
  const grpOfMap = model.grpOf;

  const cntL1 = useMemo(() => P.L1.filter((r) => r.bad).length, [P.L1]);
  const cntL2 = useMemo(() => P.L2.filter((r) => E.statusOf(r.dif, S.teamTolerance ?? 0) !== 'ok').length, [P.L2, S.teamTolerance]);
  const cntL3 = useMemo(() => P.L3.filter((r) => r.st === 'over').length, [P.L3]);

  const teamOpts = useMemo(() => {
    const codes = P.teams.map((t) => t.team).filter((t) => EB.inGrpFy(t, fg, S.fy, A, grpOfMap, FC));
    return [{ v: 'ALL', t: TT('ทุกทีม') }, ...codes.map((t) => ({ v: t, t }))];
  }, [P.teams, fg, S.fy, A, grpOfMap, FC]);

  const l1Filtered = useMemo(
    () =>
      P.L1.filter((r) => {
        if (fg !== 'ALL' && EB.grpOfM(r.team, S.fy, r.mi, A, grpOfMap, FC) !== fg) return false;
        if (ft !== 'ALL' && r.team !== ft) return false;
        if (fm !== 'ALL' && r.mi !== Number.parseInt(fm, 10)) return false;
        if (fs === 'under' && r.kind !== 'under') return false;
        if (fs === 'over' && r.kind !== 'over') return false;
        if (fs === 'bad' && !r.bad) return false;
        if (!E.hit(q, [r.team, r.name, r.role, MONTHS[r.mi]])) return false;
        return true;
      }),
    [P.L1, fg, ft, fm, fs, q, S.fy, A, grpOfMap, FC],
  );

  const l2Filtered = useMemo(
    () =>
      P.L2.filter((r) => {
        if (fg !== 'ALL' && r.grp !== fg) return false;
        if (ft !== 'ALL' && r.team !== ft) return false;
        if (fm !== 'ALL' && r.mi !== Number.parseInt(fm, 10)) return false;
        if (fs !== 'ALL' && E.statusOf(r.dif, S.teamTolerance ?? 0) !== fs) return false;
        if (!E.hit(q, [r.team, r.grp, MONTHS[r.mi]])) return false;
        return true;
      }),
    [P.L2, fg, ft, fm, fs, q, S.teamTolerance],
  );

  const l3Filtered = useMemo(
    () =>
      P.L3.filter((r) => {
        if (fg !== 'ALL' && r.grp !== fg) return false;
        if (fm !== 'ALL' && r.mi !== Number.parseInt(fm, 10)) return false;
        if (fs === 'over' && r.st !== 'over') return false;
        if (fs === 'under' && r.st !== 'under') return false;
        if (!E.hit(q, [r.grp, MONTHS[r.mi], r.teams.join(' ')])) return false;
        return true;
      }),
    [P.L3, fg, fm, fs, q],
  );

  const count = tab === 'l1' ? l1Filtered.length : tab === 'l2' ? l2Filtered.length : l3Filtered.length;
  const total = tab === 'l1' ? P.L1.length : tab === 'l2' ? P.L2.length : P.L3.length;

  const clear = useCallback(() => {
    setFg('ALL');
    setFt('ALL');
    setFm('ALL');
    setFs('ALL');
    setQ('');
  }, []);

  const changeTab = (t: Tab) => {
    setTab(t);
    setFs('ALL');
  };

  const fsItems =
    tab === 'l1'
      ? [
          { v: 'ALL', t: TT('ทุกประเภท') },
          { v: 'under', t: TT('ต่ำกว่า capacity') },
          { v: 'over', t: TT('เกิน capacity') },
          { v: 'bad', t: TT('เฉพาะที่ผิดเกณฑ์') },
        ]
      : [
          { v: 'ALL', t: TT('ทุกสถานะ') },
          { v: 'over', t: TT('เกิน') },
          { v: 'under', t: TT('ขาด') },
          { v: 'ok', t: TT('พอดี') },
        ];

  const unitHint = u === '%' ? (tab === 'l1' ? TT('เทียบ capacity') : TT('เทียบโควตา+OT')) : undefined;

  return (
    <div className="mx-auto w-full max-w-[1600px]">
      <div className="mb-[14px]">
        <h1 className="text-[22px] font-bold leading-[1.3]">
          {TT('Validation')} · {TT('ปีงบ')} {S.fy}
        </h1>
        <p className="mt-[4px] text-[13px] text-[color:var(--t2)]">{TT('ตรวจ 3 ชั้น · คลิกเพื่อดูรายละเอียดของตัวเลข')}</p>
      </div>

      <div className="mb-[14px] flex gap-[4px] border-b border-[color:var(--bd)]">
        {(
          [
            ['l1', 'ชั้น 1 · รายคน', cntL1],
            ['l2', 'ชั้น 2 · รายทีม', cntL2],
            ['l3', 'ชั้น 3 · Group', cntL3],
          ] as [Tab, string, number][]
        ).map(([id, label, n]) => {
          const on = tab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => changeTab(id)}
              className={cn(
                'flex items-center px-[14px] py-[10px] text-[13px]',
                on
                  ? 'border-b-2 border-[color:var(--yl)] font-semibold text-[color:var(--tx)]'
                  : 'font-medium text-[color:var(--t2)] hover:text-[color:var(--tx)]',
              )}
            >
              {TT(label)}
              <CountBadge n={n} active={on} />
            </button>
          );
        })}
      </div>

      <Filters
        items={[
          {
            label: TT('ปีงบ'),
            value: String(S.fy),
            all: String(S.fy),
            onChange: (v) => setS((prev) => ({ ...prev, fy: Number.parseInt(v, 10) })),
            options: fyOptions(model.fyList(), fyUnprep),
          },
          {
            label: 'Group',
            value: fg,
            onChange: (v) => {
              setFg(v);
              setFt('ALL');
            },
            options: E.optGroups(model.GROUPS).map((o) => ({ v: o.v, t: TT(o.t) })),
          },
          ...(tab !== 'l3' ? [{ label: TT('ทีม'), value: ft, onChange: setFt, options: teamOpts }] : []),
          { label: TT('เดือน'), value: fm, onChange: setFm, options: E.optMonths() },
          { label: tab === 'l1' ? TT('ประเภท') : TT('สถานะ'), value: fs, onChange: setFs, options: fsItems },
        ]}
        extra={<UnitSeg value={u} onChange={setU} hint={unitHint} />}
        search={{
          label: TT('ค้นหา'),
          placeholder: tab === 'l1' ? TT('ชื่อพนักงาน · ทีม · role · เดือน') : TT('ทีม · group · เดือน'),
          value: q,
          onChange: setQ,
        }}
        count={count}
        total={total}
        onClear={clear}
      />

      <ValBanners S={S} model={model} P={P} fg={fg} ft={ft} />

      {tab === 'l1' && <ValL1Table rows={l1Filtered} S={S} u={u} pick={(r) => setDrill({ k: 'person', v: r })} />}
      {tab === 'l2' && <ValL2Table rows={l2Filtered} S={S} u={u} WD={P.WD} pick={(r) => setDrill({ k: 'team', v: r })} />}
      {tab === 'l3' && <ValL3Table rows={l3Filtered} S={S} u={u} pick={(r) => setDrill({ k: 'month', v: r })} />}

      {/* C1 · drills — each uses the clicked row's scope and the current unit */}
      {drill?.k === 'person' && (
        <PersonDrill id="val-person-drill" S={S} P={P} row={drill.v} u={u} close={closeDrill} model={model} />
      )}
      {drill?.k === 'team' && (
        <TeamDrill id="val-team-drill" S={S} P={P} row={drill.v} u={u} close={closeDrill} model={model} />
      )}
      {drill?.k === 'month' && (
        <MonthDrill
          id="val-month-drill"
          S={S}
          P={P}
          mi={drill.v.mi}
          fg={drill.v.grp}
          u={u}
          go={go ?? (() => undefined)}
          close={closeDrill}
          fromVal
        />
      )}
    </div>
  );
}
