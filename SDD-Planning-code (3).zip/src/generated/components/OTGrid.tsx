// Session 1-06 Part A · the "OT Plan" page (board 05). One item = one team × one FY.
// Reads and writes ONLY the bucket of the selected FY — no data is ever borrowed from another FY.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Button } from '@components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { ALLMI, BOARD_ID, OT_LABEL_OFF, OT_LABEL_ON, SRC_APP } from '@generated/config';
import { OT_C } from '@generated/lib/cols';
import { TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { OtCell, OtMap, Settings } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { isOff, statusOfTeam, type OtCellView } from '@generated/lib/ot-derive';
import type { OtView } from '@generated/lib/ot-chart';
import type { OtRow } from '@generated/lib/types';
import { doExportOT } from '@generated/lib/file-export';
import { BoardTag, Filters, ImportBtn } from '@generated/components/MPShared';
import { OTBanners } from '@generated/components/OTBanners';
import { OTCards } from '@generated/components/OTCards';
import { OTChart } from '@generated/components/OTChart';
import { OTDrill } from '@generated/components/OTDrill';
import { OTTable } from '@generated/components/OTTable';
import { ImportModal } from '@generated/components/ImportModal';
import { AddTeamModal } from '@generated/components/AddTeamModal';
import { useOtWrite } from '@generated/hooks/use-ot-write';
import { writeItem, readItem } from '@generated/server/write';

interface OTGridProps {
  S: Settings;
  P: Plan;
  model: Model;
  otAll: OtMap;
  setOtAll: (fn: (prev: OtMap) => OtMap) => void;
  T: (msg: string) => void;
  loading: boolean;
  /** Re-reads board 05 into page state (used after an import or a failed write). */
  reloadOt: () => Promise<void>;
}

export default function OTGrid({ S, P, model, otAll, setOtAll, T, loading, reloadOt }: OTGridProps) {
  const [drill, setDrill] = useState<string | null>(null);
  const [imp, setImp] = useState(false);
  const [addTeam, setAddTeam] = useState(false);
  const [cv, setCv] = useState<OtView>('team');
  const [fg, setFg] = useState('ALL');
  const [fs, setFs] = useState('ALL');
  const [fM, setFM] = useState('ALL');
  const [back, setBack] = useState(false);

  const FYK = String(S.fy);
  const ot = useMemo<Record<string, OtCell>>(() => E.otOfFy(otAll, S.fy), [otAll, S.fy]);
  const MI = useMemo(() => E.miOf(fM), [fM]);
  const A = model.ASSIGN;
  const FC = model.FYCODE;

  // back-dated mode is session only, never written to any board, and resets with the fiscal year.
  useEffect(() => {
    setBack(false);
  }, [S.fy]);

  const allTeams = useMemo(() => Object.keys(ot), [ot]);
  // Session 1-14 · the team list (the register the MP Plan team filter is built from) minus the
  // teams that already have a row for this FY. The only teams "เพิ่มทีม" may offer.
  const teamList = useMemo(() => model.SECTIONS.map((s) => s.c).filter(Boolean), [model.SECTIONS]);
  const freeTeams = useMemo(() => teamList.filter((t) => !ot[t]), [teamList, ot]);
  const isOffOf = useCallback((t: string) => isOff(ot[t]), [ot]);
  const grpOfTeam = useCallback((t: string) => EB.grpLabel(t, S.fy, A, model.grpOf, FC), [S.fy, A, model.grpOf, FC]);

  const teams = useMemo(
    () =>
      allTeams.filter(
        (t) =>
          EB.inGrpFy(t, fg, S.fy, A, model.grpOf, FC) &&
          (fs === 'ALL' || statusOfTeam(ot[t], MI) === fs),
      ),
    [allTeams, fg, fs, MI, ot, S.fy, A, model.grpOf, FC],
  );

  const onTeams = useMemo(() => teams.filter((t) => !isOffOf(t)), [teams, isOffOf]);

  // Cards follow the SAME filters as the table. Empty (null) is counted as missing, 0 is not.
  const { totPlan, missing } = useMemo(() => {
    let tot = 0;
    let miss = 0;
    for (const t of onTeams) {
      for (const i of MI) {
        const v = ot[t]?.plan?.[i] ?? null;
        if (v == null) miss += 1;
        else tot += v;
      }
    }
    return { totPlan: tot, missing: miss };
  }, [onTeams, MI, ot]);

  const clash = useMemo(() => EB.assignClash(S.fy, A, model.PEOPLE_NOW, FC), [S.fy, A, model.PEOPLE_NOW, FC]);

  // Live, so the banner clears the moment the switch writes a valid label.
  const labelBad = useMemo(
    () => E.otLabelBad(Object.entries(ot).map(([t, c]) => ({ fy: FYK, t, pl: c.pl })), S.fy),
    [ot, FYK, S.fy],
  );

  const noRow = useMemo(() => P.teams.map((x) => x.team).filter((t) => !ot[t]), [P.teams, ot]);

  const headsOf = useCallback(
    (t: string) => ALLMI.map((i) => EB.headOf(t, S.fy, i, A, FC)),
    [S.fy, A, FC],
  );

  const hcText = useCallback(
    (t: string) =>
      !EB.teamInRegister(t, A) ? TT('ไม่มีในทะเบียน') : EB.headRangeTxt([t], S.fy, MI, A, FC),
    [A, S.fy, MI, FC],
  );

  const headMoved = useMemo(
    () => onTeams.filter((t) => hcText(t).includes('–')).length,
    [onTeams, hcText],
  );

  // head comes from the engine row when it exists, else straight from the register spans
  // (P.L2 has no row for a team without an MP plan).
  const headByKey = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of P.L2) m.set(`${r.team}|${r.mi}`, r.head);
    return m;
  }, [P.L2]);

  const otAt = useCallback(
    (t: string, i: number): OtCellView => {
      const v = ot[t]?.plan?.[i] ?? null;
      const h = headByKey.get(`${t}|${i}`) ?? EB.headOf(t, S.fy, i, A, FC);
      return { v, head: h, avg: v != null && h > 0 ? v / h : null };
    },
    [ot, headByKey, S.fy, A, FC],
  );

  const totM = useMemo(
    () =>
      ALLMI.map((i) => {
        let s = 0;
        let h = 0;
        let any = false;
        for (const t of onTeams) {
          const c = otAt(t, i);
          if (c.v != null) {
            any = true;
            s += c.v;
          }
          h += c.head || 0;
        }
        return { v: any ? s : null, head: h, avg: any && h > 0 ? s / h : null };
      }),
    [onTeams, otAt],
  );

  const pastN = useMemo(() => E.pastCount(S.fy, ALLMI, FC), [S.fy, FC]);

  // Charts: only teams that are open AND have at least one filled month in view (R14).
  const shown = useMemo(
    () => onTeams.filter((t) => MI.some((i) => (ot[t]?.plan?.[i] ?? null) != null)),
    [onTeams, MI, ot],
  );

  const grpAt = useCallback(
    (t: string, i: number) => EB.grpOfM(t, S.fy, i, A, model.grpOf, FC),
    [S.fy, A, model.grpOf, FC],
  );

  // Every team of the FY, ignoring the filters and the switch — the file is the whole FY (R20).
  const otRows = useCallback(
    (): OtRow[] =>
      Object.keys(ot).map((t) => {
        const rec = ot[t];
        return {
          id: String(rec?.id ?? ''),
          name: t,
          t,
          fy: FYK,
          pl: String(rec?.pl ?? ''),
          m: ALLMI.map((i) => rec?.plan?.[i] ?? null),
          batch: '',
          src: String(rec?.src ?? ''),
          editedAt: String(rec?.editedAt ?? ''),
        };
      }),
    [ot, FYK],
  );

  const { setCell, applyImport } = useOtWrite({
    fy: S.fy,
    fyKey: FYK,
    ot,
    setOtAll,
    T,
    back,
    fyCode: FC,
    reloadOt,
  });

  // W-A · the OT switch. Writes OT Planned immediately; never touches the month numbers.
  const setNoOt = useCallback(
    async (t: string, off: boolean) => {
      const rec = ot[t];
      if (!rec?.id) return;
      const prev = rec.pl;
      const label = off ? OT_LABEL_OFF : OT_LABEL_ON;

      setOtAll((p) => ({ ...p, [FYK]: { ...(p[FYK] ?? {}), [t]: { ...rec, pl: label, src: SRC_APP } } }));

      try {
        await writeItem({
          data: {
            boardId: BOARD_ID['OT Plan'],
            itemId: rec.id,
            colValues: { [OT_C.pl]: { label }, [OT_C.src]: { label: SRC_APP } },
          },
        });
      } catch (err) {
        console.error('setNoOt failed', err);
        let restored = prev;
        try {
          const item = await readItem({ data: { itemId: rec.id, colIds: [OT_C.pl] } });
          const cv = (item.column_values ?? []).find((c) => c?.id === OT_C.pl);
          restored = String(cv?.text ?? prev);
        } catch (e2) {
          console.error('setNoOt re-read failed', e2);
        }
        setOtAll((p) => ({ ...p, [FYK]: { ...(p[FYK] ?? {}), [t]: { ...rec, pl: restored } } }));
        T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
      }
    },
    [ot, FYK, setOtAll, T],
  );

  const clear = () => {
    setFg('ALL');
    setFs('ALL');
    setFM('ALL');
  };

  return (
    <div className="mx-auto w-full max-w-[1600px]">
      <div className="mb-[16px] flex flex-wrap items-start justify-between gap-[10px]">
        <div>
          <h1 className="flex items-center gap-[8px] text-[22px] font-bold leading-[1.3]">
            OT Plan · {TT('ปีงบ')} {S.fy}
            <BoardTag board="OT Plan" />
          </h1>
          <p className="mt-[4px] text-[13px] text-[color:var(--t2)]">
            <b>{TT('หน่วยเป็นชั่วโมงเสมอ')}</b> · <b>{TT('บันทึกทันทีเมื่อแก้')}</b> ·{' '}
            {TT('ตัวเลขเป็นของปีงบที่เลือกเท่านั้น')}
          </p>
        </div>
        <div className="flex flex-wrap gap-[8px]">
          <TooltipProvider>
            {pastN > 0 && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant={back ? 'default' : 'secondary'} size="sm" onClick={() => setBack(!back)}>
                    {back
                      ? `🔓 ${TT('โหมดย้อนหลัง เปิดอยู่')} (${pastN})`
                      : `🔒 ${TT('เดือนที่ผ่านมา ล็อกอยู่')} (${pastN})`}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {TT('ปีงบนี้มีเดือนที่ผ่านมาแล้ว')} {pastN}{' '}
                  {TT('เดือน · ล็อกไว้เพื่อป้องกันการแก้ไขย้อนหลังโดยไม่ตั้งใจ')}
                </TooltipContent>
              </Tooltip>
            )}
            <ImportBtn onClick={() => setImp(true)} />
            <Button
              variant="secondary"
              size="sm"
              disabled={freeTeams.length === 0}
              onClick={() => setAddTeam(true)}
            >
              + {TT('เพิ่มทีม')}
            </Button>
            {freeTeams.length === 0 && (
              <span className="self-center text-[11.5px] text-muted-foreground">{TT('ทุกทีมมีแถวของปีงบนี้แล้ว')}</span>
            )}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="secondary" size="sm" onClick={() => doExportOT(S.fy, otRows(), T)}>
                  ⤓ Export
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {TT('ได้ไฟล์ที่ติด Item ID มาให้ทุกแถว · ใช้ไฟล์นี้ไปแก้แล้วอัปโหลดกลับ')}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <Filters
        items={[
          {
            label: 'Group',
            value: fg,
            onChange: setFg,
            options: E.optGroups(model.GROUPS).map((o) => ({ v: o.v, t: TT(o.t) })),
          },
          {
            label: TT('เดือน'),
            value: fM,
            onChange: setFM,
            options: E.optMonths().map((o) => ({ v: o.v, t: TT(o.t) })),
          },
          {
            label: TT('สถานะ'),
            value: fs,
            onChange: setFs,
            options: [
              { v: 'ALL', t: TT('ทุกสถานะ') },
              { v: 'partial', t: TT('กรอกไม่ครบ') },
              { v: 'empty', t: TT('ยังไม่กรอกเลย') },
              { v: 'ok', t: TT('กรอกครบ') },
              { v: 'off', t: TT('ปิดไว้') },
            ],
          },
        ]}
        count={teams.length}
        total={allTeams.length}
        onClear={clear}
      />

      <OTCards
        fM={fM}
        totPlan={totPlan}
        headMoved={headMoved}
        missing={missing}
        offN={teams.filter((t) => isOffOf(t)).length}
        teamN={teams.length}
      />

      <OTBanners noRow={noRow} labelBad={labelBad} clash={clash} />

      <OTTable
        teams={teams}
        MI={MI}
        fM={fM}
        ot={ot}
        isOffOf={isOffOf}
        otAt={otAt}
        grpOfTeam={grpOfTeam}
        hcText={hcText}
        headsOf={headsOf}
        onTeams={onTeams}
        totM={totM}
        totPlan={totPlan}
        totHc={EB.headRangeTxt(onTeams, S.fy, MI, A, FC)}
        onDrill={setDrill}
        setNoOt={setNoOt}
        loading={loading}
      />

      {/* One month selected → no charts: there would be a single bar per card and the table
          already carries that number. */}
      {fM === 'ALL' && shown.length > 0 && (
        <OTChart
          shown={shown}
          MI={MI}
          fg={fg}
          cv={cv}
          setCv={setCv}
          otAt={otAt}
          grpAt={grpAt}
          hcText={hcText}
          onDrill={setDrill}
        />
      )}

      {drill && ot[drill] && (
        <OTDrill
          S={S}
          P={P}
          ot={ot}
          t={drill}
          setCell={setCell}
          close={() => setDrill(null)}
          back={back}
          setBack={setBack}
          pastN={pastN}
          assign={A}
          peopleNow={model.PEOPLE_NOW}
          grpOfMap={model.grpOf}
          fyCode={FC}
        />
      )}

      {imp && (
        <ImportModal
          which="ot"
          scope={otRows()}
          teamList={teamList}
          scopeFy={S.fy}
          apply={applyImport}
          S={S}
          T={T}
          close={() => setImp(false)}
          onExport={() => doExportOT(S.fy, otRows(), T)}
          model={{
            TYPES: model.TYPES,
            ROLES: model.ROLES,
            GROUPS: model.GROUPS,
            COMPANIES: model.COMPANIES,
            PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
            ASSIGN: A,
            EMPWIN: model.EMPWIN,
            FYCODE: FC,
          }}
        />
      )}

      {addTeam && (
        <AddTeamModal fy={S.fy} free={freeTeams} close={() => setAddTeam(false)} done={reloadOt} T={T} />
      )}
    </div>
  );
}
