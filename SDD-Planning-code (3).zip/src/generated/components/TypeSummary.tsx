// Session 1-09 Part B · B3. Group → Section → Type × 12 months. Custom HTML table: it has far
// more columns than the Vibe Table can render with colSpan + expand/collapse, and the row
// count is small (no virtualization needed). Read-only: no edits ever land on a board here.
import { Fragment, useMemo, useState } from 'react';
import { fmt, typeColor, z12 } from '@generated/engine';
import { grpOfM } from '@generated/engine/part-b';
import { capBySec, capByGrp, type ScopedMpRow } from '@generated/engine/part-d';
import type { Plan } from '@generated/engine/part-c';
import type { Span } from '@generated/model/types';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';

interface TypeNode {
  m: number[];
}
interface SecNode {
  m: number[];
  ty: Record<string, TypeNode>;
  order: string[];
}
interface GrpNode {
  m: number[];
  sec: Record<string, SecNode>;
  order: string[];
}

interface TypeSummaryProps {
  rows: ScopedMpRow[];
  P: Plan;
  u: 'Hrs' | 'MD' | '%';
  totPlan: number;
  TYPES: string[];
  grpOfMap: Record<string, string>;
  ASSIGN: Span[];
  FYCODE?: Record<number, string[]>;
  /** Session 1-28 · the Type dropdown above this table ('ALL' = every Type). Hides rows only — never
   *  changes a number, exactly as the search it replaces did. */
  ty?: string;
}

export function TypeSummary({ rows, P, u, totPlan, TYPES, grpOfMap, ASSIGN, FYCODE, ty }: TypeSummaryProps) {
  const [shut, setShut] = useState<Record<string, boolean>>({});
  const isOpen = (k: string) => !shut[k];
  const tog = (k: string) => setShut((prev) => ({ ...prev, [k]: !prev[k] }));

  const secCap = useMemo(() => capBySec(P), [P]);
  const grpCap = useMemo(() => capByGrp(P), [P]);

  const { G, groups } = useMemo(() => {
    const g: Record<string, GrpNode> = {};
    for (const r of rows) {
      for (let i = 0; i < 12; i += 1) {
        const v = r.m[i] ?? 0;
        if (v === 0) continue;
        const t = r.mteam[i] || r.team;
        if (!t) continue;
        const grp = grpOfM(t, r.fy, i, ASSIGN, grpOfMap, FYCODE);
        if (!g[grp]) g[grp] = { m: z12(), sec: {}, order: [] };
        const gn = g[grp] as GrpNode;
        gn.m[i] = (gn.m[i] ?? 0) + v;
        if (!gn.sec[t]) {
          gn.sec[t] = { m: z12(), ty: {}, order: [] };
          gn.order.push(t);
        }
        const sn = gn.sec[t] as SecNode;
        sn.m[i] = (sn.m[i] ?? 0) + v;
        if (!sn.ty[r.type]) {
          sn.ty[r.type] = { m: z12() };
          sn.order.push(r.type);
        }
        const tn = sn.ty[r.type] as TypeNode;
        tn.m[i] = (tn.m[i] ?? 0) + v;
      }
    }
    const groupNames = Object.keys(g).sort();
    for (const gname of groupNames) {
      (g[gname] as GrpNode).order.sort();
      for (const t of (g[gname] as GrpNode).order) {
        (g[gname] as GrpNode).sec[t]!.order.sort();
      }
    }
    return { G: g, groups: groupNames };
  }, [rows, ASSIGN, grpOfMap, FYCODE]);

  // ---- search: decide visibility only. G, grand, grandCap and totPlan are untouched, so every
  // number (and the bottom total, which must equal the "แผนที่กรอกมา" card) stays the real total.
  const sel = ty && ty !== 'ALL' ? ty : '';
  const searching = sel !== '';
  const vis = useMemo(() => {
    const showG = new Set<string>();
    const showS = new Set<string>(); // key `${gname}|${t}`
    const showT = new Set<string>(); // key `${gname}|${t}|${ty}`
    const openG = new Set<string>(); // groups with a matching child → forced open
    const openS = new Set<string>(); // sections with a matching type → forced open
    if (!searching) return { showG, showS, showT, openG, openS };
    for (const gname of groups) {
      const gg = G[gname] as GrpNode;
      const mG = false; // a Type choice never matches a Group or Section name
      let gChild = false;
      for (const t of gg.order) {
        const ss = gg.sec[t] as SecNode;
        const mS = false;
        let sChild = false;
        for (const ty of ss.order) {
          const mT = ty === sel;
          if (mT) sChild = true;
          if (mT || mS || mG) showT.add(`${gname}|${t}|${ty}`);
        }
        if (mS || mG || sChild) showS.add(`${gname}|${t}`);
        if (sChild) openS.add(`${gname}|${t}`);
        if (mS || sChild) gChild = true;
      }
      if (mG || gChild) showG.add(gname);
      if (gChild) openG.add(gname);
    }
    return { showG, showS, showT, openG, openS };
  }, [searching, sel, groups, G]);

  const grand = z12();
  for (const gname of groups) for (let i = 0; i < 12; i += 1) grand[i] += (G[gname] as GrpNode).m[i] ?? 0;
  const grandCap = z12();
  for (const r of P.L2) {
    if (G[r.grp]) grandCap[r.mi] += r.allow;
  }

  function cellsRow(m: number[], cap: number[], total?: number) {
    const sumM = m.reduce((a, b) => a + b, 0);
    const sumCap = cap.reduce((a, b) => a + b, 0);
    return (
      <>
        {m.map((v, i) => (
          <td
            key={MONTHS[i] ?? i}
            className="whitespace-nowrap px-[6px] py-[5px] text-right font-mono text-[11.5px]"
          >
            {v ? fmt(v, cap[i] ?? 0, u) : '–'}
          </td>
        ))}
        <td className="whitespace-nowrap bg-[var(--cd2)] px-[6px] py-[5px] text-right font-mono text-[11.5px] font-bold">
          {fmt(total ?? sumM, sumCap, u)}
        </td>
      </>
    );
  }

  if (groups.length === 0) {
    return (
      <div className="mb-[16px] rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
        <h2 className="text-[15px] font-bold leading-[1.3]">{TT('สรุปแผนตาม Type')}</h2>
        <p className="mt-[10px] text-[13px] text-[color:var(--t3)]">{TT('ไม่มีแผนตามตัวกรองที่เลือก')}</p>
      </div>
    );
  }

  return (
    <div className="mb-[16px] rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
      <h2 className="text-[15px] font-bold leading-[1.3]">{TT('สรุปแผนตาม Type')}</h2>
      <p className="mt-[3px] text-[12px] text-[color:var(--t3)]">
        {TT('Group → Section → Type × 12 เดือน · คลิกชื่อ Group หรือ Section เพื่อย่อ/ขยาย')}
      </p>
      {searching && (
        <p className="mt-[3px] text-[12px] text-[color:var(--t3)]">
          {TT('กำลังค้นหา · ยอดรวมด้านล่างยังเป็นยอดรวมทั้งหมด')}
        </p>
      )}

      <div className="mt-[10px] max-h-[520px] overflow-auto rounded-[8px] border border-[color:var(--bd)]">
        <table className="w-full min-w-[1100px] border-collapse text-[11.5px]">
          <thead className="sticky top-0 z-10 bg-[var(--cd2)]">
            <tr>
              <th className="min-w-[64px] px-[6px] py-[6px] text-left font-semibold text-[color:var(--t2)]">
                {TT('Group')}
              </th>
              <th className="min-w-[64px] px-[6px] py-[6px] text-left font-semibold text-[color:var(--t2)]">
                {TT('Section')}
              </th>
              <th className="min-w-[150px] px-[6px] py-[6px] text-left font-semibold text-[color:var(--t2)]">
                {TT('Type')}
              </th>
              {MONTHS.map((mo, i) => (
                <th key={mo} className="px-[6px] py-[6px] text-right font-semibold text-[color:var(--t2)]">
                  <div>{mo}</div>
                  <div className="text-[9px] font-normal text-[color:var(--t3)]">{(P.WD[i] ?? '–') + 'd'}</div>
                </th>
              ))}
              <th className="px-[6px] py-[6px] text-right font-semibold text-[color:var(--t2)]">{TT('รวม')}</th>
            </tr>
          </thead>
          <tbody>
            {searching && vis.showG.size === 0 && (
              <tr className="border-t border-[color:var(--bd)]">
                <td colSpan={16} className="px-[6px] py-[10px] text-[13px] text-[color:var(--t3)]">
                  {TT('ไม่พบรายการที่ตรงกับคำค้น')}
                </td>
              </tr>
            )}
            {groups.map((gname) => {
              const gg = G[gname] as GrpNode;
              if (searching && !vis.showG.has(gname)) return null;
              const gOpen = (searching && vis.openG.has(gname)) || isOpen(`g|${gname}`);
              return (
                <Fragment key={`g-${gname}`}>
                  <tr className="border-t border-[color:var(--bd)]">
                    <td colSpan={3} className="px-[6px] py-[6px]">
                      <button
                        type="button"
                        onClick={() => tog(`g|${gname}`)}
                        aria-label={`${gOpen ? TT('ย่อ') : TT('ขยาย')} ${gname}`}
                        className="flex items-center gap-[6px] text-left font-bold"
                      >
                        <span>{gOpen ? '⊟' : '⊞'}</span>
                        <span>{gname}</span>
                        <span className="font-normal text-[color:var(--t3)]">
                          {gg.order.length} {TT('section')}
                        </span>
                      </button>
                    </td>
                    {cellsRow(gg.m, (grpCap[gname] as number[] | undefined) || z12())}
                  </tr>
                  {gOpen &&
                    gg.order.map((t) => {
                      const ss = gg.sec[t] as SecNode;
                      if (searching && !vis.showS.has(`${gname}|${t}`)) return null;
                      const sOpen = (searching && vis.openS.has(`${gname}|${t}`)) || isOpen(`s|${t}`);
                      return (
                        <Fragment key={`s-${t}`}>
                          <tr className="border-t border-[color:var(--bd)] bg-[var(--cd2)]">
                            <td className="px-[6px] py-[5px]" />
                            <td colSpan={2} className="px-[6px] py-[5px]">
                              <button
                                type="button"
                                onClick={() => tog(`s|${t}`)}
                                aria-label={`${sOpen ? TT('ย่อ') : TT('ขยาย')} ${t}`}
                                className="flex items-center gap-[6px] text-left font-bold"
                              >
                                <span>{sOpen ? '⊟' : '⊞'}</span>
                                <span>{t}</span>
                                <span className="font-normal text-[color:var(--t3)]">
                                  {ss.order.length} {TT('Type')}
                                </span>
                              </button>
                            </td>
                            {cellsRow(ss.m, (secCap[t] as number[] | undefined) || z12())}
                          </tr>
                          {sOpen &&
                            ss.order.map((ty) => {
                              const tn = ss.ty[ty] as TypeNode;
                              if (searching && !vis.showT.has(`${gname}|${t}|${ty}`)) return null;
                              const color = typeColor(ty, TYPES);
                              return (
                                <tr key={`t-${t}-${ty}`} className="border-t border-[color:var(--bd)]">
                                  <td className="px-[6px] py-[5px]" />
                                  <td className="px-[6px] py-[5px]" />
                                  <td className="px-[6px] py-[5px]">
                                    <span
                                      className="inline-block rounded-[4px] px-[6px] py-[2px] text-[10.5px] font-medium"
                                      style={{ background: `${color}22`, color }}
                                    >
                                      {ty}
                                    </span>
                                  </td>
                                  {cellsRow(tn.m, (secCap[t] as number[] | undefined) || z12())}
                                </tr>
                              );
                            })}
                        </Fragment>
                      );
                    })}
                </Fragment>
              );
            })}
            <tr className="border-t-2 border-[color:var(--bd2)] font-bold">
              <td colSpan={3} className="px-[6px] py-[6px]">
                {TT('รวมทุก Group')}
              </td>
              {cellsRow(grand, grandCap, totPlan)}
            </tr>
          </tbody>
        </table>
      </div>

      <p className="mt-[8px] text-[11px] text-[color:var(--t3)]">
        {TT('หน่วยปัจจุบัน: ')}
        <b>{u === '%' ? TT('% ของโควตา+OT ของชั้นนั้น') : u}</b>
        {u === '%' && TT(' · แถว Type และ Section หารด้วยโควตา+OT ของ section · แถว Group หารด้วยของ group')}
      </p>
    </div>
  );
}
