// B4 · Add Row Modal for MP Plan
import React, { useState, useMemo } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@components/ui/select';
import { Input } from '@components/ui/input';
import { Button } from '@components/ui/button';
import { Loader2 } from 'lucide-react';
import { Modal, BoardTag, FilterSelect } from '@generated/components/MPShared';
import { MP_C } from '@generated/lib/cols';
import { NONE, SYSTEM_HELP, SYSTEM_RULE_MSG, systemMissing } from '@generated/lib/mp-fields';
import type { MpDerived, Person, Settings } from '@generated/model/types';
import { SRC_APP, BOARD_ID } from '@generated/config';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { createItem } from '@generated/server/write';
import { TT } from '@generated/i18n';
import { findFyGroupId } from '@generated/lib/import-run';

interface AddRowModalProps {
  S: Settings;
  team: string; // fTeam (never 'ALL')
  rows: MpDerived[]; // WHOLE board (all teams, all FYs)
  peopleNow: Person[];
  assign: any[];
  fyCode: Record<number, string[]> | undefined;
  empWin: Record<string, any>;
  roles: string[]; // ACTIVE Role labels from the board's column settings
  systems: string[]; // ACTIVE System labels from the board's column settings
  task2s: string[]; // ACTIVE Task2 labels from the board's column settings (optional field)
  close: () => void;
  add: (row: MpDerived) => void;
  /** The app toast (A6). */
  T: (msg: string) => void;
}

export function AddRowModal(props: AddRowModalProps) {
  const { S, team, rows, peopleNow, assign, fyCode, empWin, roles, systems, task2s, close, add, T } = props;

  // Options
  const tyOpts = useMemo(() => {
    const types = new Set<string>();
    for (const r of rows) {
      if (r.type) types.add(r.type);
    }
    return Array.from(types).sort();
  }, [rows]);

  const [ty, setTy] = useState(tyOpts[0] || '');
  const [t1, setT1] = useState('');
  const [ro, setRo] = useState('');
  const [sys, setSys] = useState('');
  const [t2, setT2] = useState('');
  const [nm, setNm] = useState('');
  const [de, setDe] = useState('');
  const [loading, setLoading] = useState(false);

  const t1opts = useMemo(() => {
    if (!ty) return [];
    const tasks = new Set<string>();
    for (const r of rows) {
      if (r.type === ty && r.t1) tasks.add(r.t1);
    }
    return Array.from(tasks).sort();
  }, [rows, ty]);

  // Staff in team for this FY
  const staff = useMemo(() => {
    return peopleNow.filter((p) => {
      if (!p.emp) return false;
      for (let i = 0; i < 12; i++) {
        const tm = EB.teamOfMonth(p.emp, S.fy, i, assign, fyCode);
        const ym = E.ymOfFy(S.fy, i);
        if (tm === team && EB.inEmployment(p.emp, ym, empWin)) {
          return true;
        }
      }
      return false;
    });
  }, [peopleNow, S.fy, team, assign, fyCode, empWin]);

  const sysMiss = systemMissing({ type: ty, system: sys });
  const ok = Boolean(ty && t1 && nm && ro) && !sysMiss;

  const handleSubmit = async () => {
    if (!ok) return;
    setLoading(true);

    try {
      const who = staff.find((x) => x.emp === nm);
      const disp = who ? (who.mpname || who.name) : nm;

      // Find group by title
      // We'll need to query the board groups - for now omit group_id if we can't find it
      // In production this would query the board, but we'll use the known group IDs from schema
      const groupId = await findFyGroupId(BOARD_ID['MP Plan'], S.fy);

      // No "FY<year>" group on the board → do NOT create the row. Without a group monday would
      // drop it into the top group ("Unmatched · รอยืนยัน"), which silently mislabels the data.
      // The modal stays open; loading is turned off by the finally block below.
      if (!groupId) {
        T(
          TT('ยังไม่มีกลุ่ม FY') +
            String(S.fy) +
            TT(' บนบอร์ด MP Plan · กรุณาสร้างกลุ่มนี้บนบอร์ดก่อนจึงจะเพิ่มแถวได้'),
        );
        setLoading(false);
        return;
      }

      // Month columns are intentionally omitted so a new row starts with EMPTY month cells.
      // Empty means "not planned yet" while 0 means "planned zero".
      // Never add numVal(0) or '0' (or any month key) here.
      const columnValues: Record<string, any> = {
        dropdown_mm7gemym: { labels: [team] },
        dropdown_mm7gh9b9: { labels: [String(S.fy)] },
        dropdown_mm71y3ex: { labels: [ty] },
        text_mm712g3d: t1,
        color_mm71hgnd: { label: ro },
        ...(sys ? { [MP_C.system]: { labels: [sys] } } : {}),
        ...(t2 ? { [MP_C.task2]: { labels: [t2] } } : {}),
        text_mm716jca: disp,
        text_mm71sj5r: nm,
        text_mm7121my: who?.sec ?? '', // Section Resolved = registered section, not the page's team
        color_mm71ee3q: { label: 'Matched' },
        color_mm728ges: { label: 'Vibe App' },
      };

      if (de) {
        columnValues.long_text_mm71bkm0 = { text: de };
      }

      const result = await createItem({
        data: {
          boardId: BOARD_ID['MP Plan'],
          itemName: t1,
          groupId: groupId || undefined,
          colValues: columnValues,
        },
      });

      if (result?.id) {
        const isLeave = ty.includes('11.Leave');
        const kind = ty.includes('01.Project') ? 'PJ' : 'MP';
        const newRow: MpDerived = {
          id: result.id,
          title: t1,
          team,
          fy: String(S.fy),
          type: ty,
          t1,
          role: ro,
          detail: de,
          system: sys,
          task2: t2,
          name: disp,
          empid: nm,
          sec: team,
          ms: 'Matched',
          m: E.z12(),
          kind,
          isLeave,
          src: SRC_APP,
          editedAt: E.NOW(),
          batch: '',
        };
        add(newRow);
        T(`${TT('เพิ่มแถวใหม่ในทีม')} ${team} · ${TT('บันทึกลงบอร์ด MP Plan ทันที')}`);
        close();
      }
    } catch (err) {
      console.error('Failed to create row:', err);
      T(TT('ไม่สามารถเพิ่มแถวได้ กรุณาลองใหม่'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      show
      onClose={close}
      title={`${TT('เพิ่มแถวแผน · ทีม')} ${team}`}
      sub="ตัวเลือกดึงจากแผนที่มีอยู่บนบอร์ด MP Plan · Type ใหม่ต้องเพิ่มผ่านไฟล์ Excel"
      pill={<BoardTag board="MP Plan" />}
      footer={
        <Button onClick={handleSubmit} disabled={!ok || loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              {TT('กำลังบันทึก')}…
            </>
          ) : (
            TT('เพิ่มแถว →')
          )}
        </Button>
      }
    >
      <div className="space-y-4">
        {/* Type */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium">
            Type · {tyOpts.length} {TT('ตัวเลือกจากแผนที่มีอยู่')}
          </label>
          <Select
            value={ty}
            onValueChange={(v) => {
              setTy(v);
              setT1('');
            }}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {tyOpts.map((opt) => (
                <SelectItem key={opt} value={opt}>
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Task1 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium">
            Task1 · {t1opts.length} {TT('ตัวเลือก')}
          </label>
          {t1opts.length === 0 ? (
            <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] p-3 text-[12px] text-[#B54708]">
              {TT('Type นี้ยังไม่มีงานในแผน — เพิ่มงานใหม่ผ่านไฟล์ Excel')}
            </div>
          ) : (
            <Select value={t1} onValueChange={setT1}>
              <SelectTrigger>
                <SelectValue placeholder={TT('— เลือก —')} />
              </SelectTrigger>
              <SelectContent>
                {t1opts.map((opt) => (
                  <SelectItem key={opt} value={opt}>
                    {opt}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* System — searchable, ACTIVE labels from the board */}
        <div>
          <label htmlFor="filter-System" className="mb-1.5 block text-[13px] font-medium">
            System
          </label>
          <FilterSelect
            item={{
              label: 'System',
              value: sys || NONE,
              onChange: (v) => setSys(v === NONE ? '' : v),
              minWidth: '100%',
              maxMenuHeight: '360px',
              options: [{ v: NONE, t: TT('— ไม่ระบุ —') }, ...systems.map((s) => ({ v: s, t: s }))],
            }}
          />
          {sysMiss && <div className="mt-1 text-[12px] text-[color:var(--negative-color,var(--rd))]">{TT(SYSTEM_RULE_MSG)}</div>}
          <div className="mt-1 text-[11px] text-muted-foreground">{TT(SYSTEM_HELP)}</div>
        </div>

        {/* Task2 — optional, searchable, ACTIVE labels from the board */}
        <div>
          <label htmlFor="filter-Task2" className="mb-1.5 block text-[13px] font-medium">
            Task2 <span className="font-normal text-muted-foreground">({TT('ไม่บังคับ')})</span>
          </label>
          <FilterSelect
            item={{
              label: 'Task2',
              value: t2 || NONE,
              onChange: (v) => setT2(v === NONE ? '' : v),
              minWidth: '100%',
              maxMenuHeight: '360px',
              options: [{ v: NONE, t: TT('— ไม่ระบุ —') }, ...task2s.map((s) => ({ v: s, t: s }))],
            }}
          />
        </div>

        {/* Role */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium">Role</label>
          <Select value={ro} onValueChange={setRo}>
            <SelectTrigger>
              <SelectValue placeholder={TT('— เลือก —')} />
            </SelectTrigger>
            <SelectContent>
              {roles.map((r) => (
                <SelectItem key={r} value={r}>
                  {r}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Staff */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium">
            {TT('พนักงาน')} · {staff.length} {TT('คนในทีม')} {team}
          </label>
          {staff.length === 0 ? (
            <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] p-3 text-[12px] text-[#B54708]">
              {TT('ไม่มีพนักงานที่มีช่วงสังกัดในทีมนี้ในปีงบนี้บน Employee Master')}
            </div>
          ) : (
            <Select value={nm} onValueChange={setNm}>
              <SelectTrigger>
                <SelectValue placeholder={TT('— เลือก —')} />
              </SelectTrigger>
              <SelectContent>
                {staff.map((p) => (
                  <SelectItem key={p.emp} value={p.emp || ''}>
                    {p.mpname || p.name} · {p.pos} · {p.emp}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Detail */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium">{TT('Detail (ไม่บังคับ)')}</label>
          <Input
            value={de}
            onChange={(e) => setDe(e.target.value)}
            placeholder={TT('คำอธิบายงาน')}
          />
        </div>

      </div>
    </Modal>
  );
}
