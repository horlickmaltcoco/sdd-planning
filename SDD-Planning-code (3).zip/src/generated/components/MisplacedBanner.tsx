// Session 1-17i · rows of the selected year that sit in another year's group on the board. They are
// NOT read into any calculation; this banner only tells the person so they can move them back.
import type { ReactNode } from 'react';
import { TT } from '@generated/i18n';
import { PERF_CODE } from '@generated/lib/load-perf';
import type { BoardKey } from '@generated/config';

export interface MisplacedRow {
  id: string;
  name: string;
  group: string;
}

function Row({ label, value, hi }: { label: string; value: ReactNode; hi?: boolean }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-[12px] gap-y-[2px] border-b border-[color:var(--bd2)] py-[5px] last:border-b-0">
      <span className={`text-[12px] ${hi ? 'font-bold' : ''} text-[color:var(--t2)]`}>{label}</span>
      <span
        className={`min-w-0 text-[12px] ${hi ? 'font-bold' : ''}`}
        style={{ color: hi ? 'var(--rd)' : 'var(--tx)', whiteSpace: 'normal' }}
      >
        {value}
      </span>
    </div>
  );
}

export function MisplacedBanner({ fy, found }: { fy: string | number; found: { board: BoardKey; rows: MisplacedRow[] }[] }) {
  const list = found.filter((f) => f.rows.length > 0);
  if (list.length === 0) return null;
  const n = list.reduce((s, f) => s + f.rows.length, 0);
  return (
    <div className="misplaced mb-[13px] rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[14px]">
      <div className="rounded-[6px] bg-[var(--cd2)] p-[10px]">
        <Row hi label={TT('มีแถวของปีงบนี้อยู่ผิดกลุ่มบนบอร์ด')} value={`${n} ${TT('แถวมีปีงบ')} ${fy} ${TT('แต่ไม่ได้อยู่ในกลุ่ม')} FY${fy} ${TT('จึงไม่ถูกนำมาคำนวณ')}`} />
        <Row label={TT('ต้องทำอะไร')} value={`${TT('ย้ายแถวเหล่านี้เข้ากลุ่ม')} FY${fy} ${TT('บนบอร์ด แล้วกด โหลดข้อมูลใหม่')}`} />
        {list.flatMap((f) =>
          f.rows.map((r) => (
            <Row key={`${f.board}|${r.id}`} label={`${PERF_CODE[f.board]} ${f.board} · ${r.name || r.id}`} value={`${r.group} · Item ID ${r.id}`} />
          )),
        )}
      </div>
    </div>
  );
}
