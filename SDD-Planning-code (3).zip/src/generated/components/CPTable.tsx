// 07 Company Plan · B3 table. One row per Group × Company, columns Apr…Mar + รวมปี, a dark header
// row before each Group, a subtotal after it, and "รวมที่แสดง" at the end. Unit MD only.
import { Fragment, type MouseEvent } from 'react';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import { md2, type CpBlock } from '@generated/lib/cp';
import type { CpRow } from '@generated/lib/types';

interface CPTableProps {
  blocks: CpBlock[];
  onOpen: (row: CpRow, el: HTMLElement) => void;
}

const TH = 'border-b border-[color:var(--bd2)] bg-[var(--cd2)] px-[8px] py-[7px] text-[11px] font-semibold text-[color:var(--t2)]';
const TD = 'border-b border-[color:var(--bd2)] px-[8px] py-[5px] text-[12px]';
const NUM = 'text-right font-mono tabular-nums';
const COLS = 3 + MONTHS.length; // Group · Company · 12 months · รวมปี

function Spacer() {
  return (
    <tr aria-hidden="true">
      <td colSpan={COLS} className="h-[14px] border-0 bg-[var(--bg)] p-0" />
    </tr>
  );
}

function SumRow(props: { label: string; months: number[]; year: number; grp?: boolean }) {
  const tone = props.grp
    ? 'border-t-2 border-t-[color:var(--acv)] bg-[#E8EDF5] font-bold text-[color:var(--acv)]'
    : 'bg-[var(--cd2)] font-bold';
  return (
    <tr className={tone}>
      <td className={`${TD} whitespace-nowrap text-left`} colSpan={2}>
        {props.label}
      </td>
      {props.months.map((v, i) => (
        <td key={MONTHS[i]} className={`${TD} ${NUM}`}>
          {md2(v)}
        </td>
      ))}
      <td className={`${TD} ${NUM}`}>{md2(props.year)}</td>
    </tr>
  );
}

export function CPTable(props: CPTableProps) {
  if (props.blocks.length === 0) {
    return (
      <div className="rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[16px]">
        <p className="text-[13px] text-[color:var(--t3)]">{TT('ไม่มีแถวตามตัวกรองที่เลือก')}</p>
      </div>
    );
  }

  const allMonths = MONTHS.map((_, i) => props.blocks.reduce((s, b) => s + (b.months[i] ?? 0), 0));
  const allYear = props.blocks.reduce((s, b) => s + b.year, 0);

  const open = (row: CpRow) => (e: MouseEvent<HTMLButtonElement>) => props.onOpen(row, e.currentTarget);

  return (
    <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)]">
      <table className="w-full min-w-[1100px] border-collapse">
        <thead>
          <tr>
            <th className={`${TH} text-left`}>Group</th>
            <th className={`${TH} text-left`}>Company</th>
            {MONTHS.map((m) => (
              <th key={m} className={`${TH} text-right`}>
                {m}
              </th>
            ))}
            <th className={`${TH} text-right`}>{TT('รวมปี')}</th>
          </tr>
        </thead>
        <tbody>
          {props.blocks.map((b, bi) => (
            <Fragment key={b.grp || `blank-${bi}`}>
              {bi > 0 && <Spacer />}
              <tr>
                <td
                  colSpan={COLS}
                  className="bg-[var(--acv)] px-[10px] py-[7px] text-[12.5px] font-bold text-[color:var(--cd)]"
                >
                  {b.grp || TT('ว่าง')} · {b.lines.length} {TT('บริษัท')}
                </td>
              </tr>
              {b.lines.map((l) => (
                <tr key={`${l.grp}|${l.co}`}>
                  <td className={`${TD} text-left font-medium`}>{l.grp}</td>
                  <td className={`${TD} text-left`}>
                    <span className="tg sy inline-block rounded-[4px] bg-[var(--cd2)] px-[7px] py-[2px] text-[11px]">
                      {l.co}
                    </span>
                  </td>
                  {l.cells.map((c, i) => {
                    const mo = MONTHS[i]!;
                    if (!c) {
                      return (
                        <td
                          key={mo}
                          className={`${TD} ${NUM} bg-[var(--orl)] text-[color:var(--t3)]`}
                          title={TT('ไม่มีแถวของเดือนนี้บนบอร์ด')}
                        >
                          —
                        </td>
                      );
                    }
                    const empty = c.md == null;
                    return (
                      <td key={mo} className={`${TD} p-0 ${empty ? 'bg-[var(--orl)]' : ''}`}>
                        <button
                          type="button"
                          onClick={open(c)}
                          title={empty ? `${c.my} · ${TT('ยังไม่กรอก')}` : `${c.my} · ${String(c.md)} MD`}
                          className={`${NUM} block min-h-[30px] w-full px-[8px] py-[5px] text-[12px] outline-none hover:bg-[#F7D3D9] focus-visible:ring-2 focus-visible:ring-[color:var(--yl)]`}
                        >
                          {md2(c.md)}
                        </button>
                      </td>
                    );
                  })}
                  <td className={`${TD} ${NUM} bg-[var(--cd2)] font-bold`}>{md2(l.year)}</td>
                </tr>
              ))}
              <SumRow grp label={`${TT('รวม')} ${b.grp || TT('ว่าง')}`} months={b.months} year={b.year} />
            </Fragment>
          ))}
          <Spacer />
          <SumRow label={TT('รวมที่แสดง')} months={allMonths} year={allYear} />
        </tbody>
      </table>
    </div>
  );
}
