// Session 1-06 Part B · 3. the OT team card. Reads the LIVE page state, so a number typed here
// updates the card, the table, the KPI cards and the charts at once. No save button: every
// keystroke is written (W-B), "เสร็จ" only leaves edit mode.
import { type ReactNode, useMemo, useState } from 'react';
import { Button } from '@components/ui/button';
import { ALLMI } from '@generated/config';
import { fmt, n1, sum } from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import type { Plan } from '@generated/engine/part-c';
import { TT } from '@generated/i18n';
import { Modal } from '@generated/components/MPShared';
import { OTDrillTable } from '@generated/components/OTDrillTable';
import { isOff } from '@generated/lib/ot-derive';
import type { OtCell, Person, Settings, Span } from '@generated/model/types';

interface OTDrillProps {
  S: Settings;
  P: Plan;
  ot: Record<string, OtCell>;
  t: string;
  setCell: (t: string, mi: number, v: number | null) => void;
  close: () => void;
  back: boolean;
  setBack: (v: boolean) => void;
  pastN: number;
  assign: Span[];
  peopleNow: Person[];
  grpOfMap: Record<string, string>;
  fyCode?: Record<number, string[]>;
}

function Row(props: { label: string; value: ReactNode; hi?: boolean }) {
  return (
    <div
      className={`flex items-start justify-between gap-[16px] py-[4px] text-[13px] ${
        props.hi ? 'border-t border-[color:var(--bd)] bg-[var(--bll)] px-[6px]' : ''
      }`}
    >
      <span className="shrink-0 font-medium text-[color:var(--t2)]">{props.label}</span>
      <span className="text-right leading-[1.45]">{props.value}</span>
    </div>
  );
}

export function OTDrill(props: OTDrillProps) {
  const [edit, setEdit] = useState(false);
  const { S, P, ot, t } = props;

  const o = ot[t];
  const plan = useMemo(() => ALLMI.map((i) => o?.plan?.[i] ?? null), [o]);
  const hs = useMemo(
    () => ALLMI.map((i) => EB.headOf(t, S.fy, i, props.assign, props.fyCode)),
    [t, S.fy, props.assign, props.fyCode],
  );

  const inReg = EB.teamInRegister(t, props.assign);
  const hcTxt = !inReg
    ? TT('ไม่มีชื่อในทะเบียน')
    : EB.headRangeTxt([t], S.fy, null, props.assign, props.fyCode);
  const hLo = Math.min(...hs);
  const hHi = Math.max(...hs);

  const noOt = isOff(o);
  const miss = plan.filter((v) => v == null).length;
  const totY = sum(plan);

  // R15 · year average per person = SUM OF MONTHLY AVERAGES, never totY ÷ headcount.
  let avgY = 0;
  let avgIncomplete = false;
  for (const i of ALLMI) {
    const v = plan[i] ?? null;
    if (v == null) continue;
    const h = hs[i] ?? 0;
    if (h > 0) avgY += v / h;
    else avgIncomplete = true;
  }

  const pill = noOt ? (
    <span className="inline-block rounded-[4px] bg-[var(--bll)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--t2)]">
      {TT('ปิดไว้')}
    </span>
  ) : miss > 0 ? (
    <span className="inline-block rounded-[4px] bg-[var(--orl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--or)]">
      ⚠ {TT('ยังไม่กรอก')} {miss} {TT('เดือน')}
    </span>
  ) : (
    <span className="inline-block rounded-[4px] bg-[var(--gnl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--gn)]">
      {TT('กรอกครบ')}
    </span>
  );

  return (
    <Modal
      show
      onClose={props.close}
      size="large"
      pill={pill}
      title={`OT Plan · ${TT('ทีม')} ${t}`}
      sub={`${EB.grpLabel(t, S.fy, props.assign, props.grpOfMap, props.fyCode)} · ${hcTxt} ${TT(
        'คนที่นับโควตา · แผนกรอกเป็นก้อนรวมของทีม',
      )}`}
      footer={
        <Button
          variant={edit ? 'default' : 'secondary'}
          size="sm"
          onClick={() => setEdit(!edit)}
        >
          {edit ? TT('เสร็จ') : TT('แก้ไข')}
        </Button>
      }
    >
      <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <Row label={TT('Plan OT รวมปี')} value={<b>{fmt(totY, 0, 'Hrs')} {TT('ชม.')}</b>} />
        <Row
          hi
          label={TT('เฉลี่ย/คน รวมปี')}
          value={
            <b className="text-[color:var(--or)]">
              {n1(avgY)} {TT('ชม.')}
              {avgIncomplete ? ' *' : ''}
            </b>
          }
        />
        {hLo !== hHi && (
          <Row
            label={TT('จำนวนคนระหว่างปี')}
            value={
              <span className="font-medium text-[color:var(--or)]">
                {TT('ไม่คงที่')} {hLo}–{hHi} {TT('คน → เฉลี่ย/คน เปลี่ยนตามเดือน')}
              </span>
            }
          />
        )}
        {avgIncomplete && (
          <Row
            label={`* ${TT('หมายเหตุ')}`}
            value={
              <span className="font-normal text-[color:var(--or)]">
                {TT(
                  'มีเดือนที่กรอก OT ไว้แต่ไม่มีคนที่นับโควตา — เดือนนั้นหารไม่ได้ ไม่ถูกรวมในค่าเฉลี่ย',
                )}
              </span>
            }
          />
        )}
        {!inReg && (
          <Row
            label={TT('ยังหารไม่ได้')}
            value={
              <span className="font-normal text-[color:var(--or)]">
                {TT(
                  'ทีมนี้ไม่มีชื่อพนักงานในทะเบียน — ต้องได้ Employee Profile ของกลุ่มนี้ก่อน จึงจะคิดเฉลี่ย/คน ได้',
                )}
              </span>
            }
          />
        )}
      </div>

      <h3 className="mb-[8px] text-[14px] font-semibold">
        {TT('รายเดือน · ก้อน OT ของทีม หารด้วยคนที่นับโควตาของเดือนนั้น')}
      </h3>

      {edit && !props.back && props.pastN > 0 && (
        <div className="mb-[10px] flex flex-wrap items-center gap-[10px] rounded-[6px] border border-[#FDA29B] bg-[#FFFBFA] p-[10px] text-[12px] text-[color:var(--or)]">
          <span>
            🔒 {TT('เดือนที่ผ่านไปแล้ว')} {props.pastN}{' '}
            {TT('เดือน ถูกล็อกเพื่อป้องกันการแก้ไขย้อนหลังโดยไม่ตั้งใจ')}
          </span>
          <Button variant="secondary" size="sm" onClick={() => props.setBack(true)}>
            {TT('ปลดล็อกเพื่อแก้ไขย้อนหลัง')}
          </Button>
        </div>
      )}

      <OTDrillTable
        t={t}
        fy={S.fy}
        plan={plan}
        hs={hs}
        hLo={hLo}
        hHi={hHi}
        L2={P.L2}
        edit={edit}
        back={props.back}
        setCell={props.setCell}
        assign={props.assign}
        peopleNow={props.peopleNow}
        fyCode={props.fyCode}
      />
    </Modal>
  );
}
