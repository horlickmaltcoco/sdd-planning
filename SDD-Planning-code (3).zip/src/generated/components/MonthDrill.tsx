// Session 1-09 Part C · C3. One fiscal month split by team. Shared component — Validation
// can reuse it later with fromVal=true (hides the "ไปหน้า Validation →" shortcut). Read-only.
import { type ReactNode, useMemo } from 'react';
import { Button } from '@components/ui/button';
import { fmt, fyMonthLabel, n1, statusOf, uSuf } from '@generated/engine';
import { pillOf } from '@generated/engine/part-c';
import type { Plan } from '@generated/engine/part-c';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import { Modal } from '@generated/components/MPShared';
import type { Settings } from '@generated/model/types';

interface MonthDrillProps {
  S: Settings;
  P: Plan;
  mi: number;
  fg: string;
  /** Omit to show every team of group fg (Validation tier 3). */
  ft?: string;
  u: 'Hrs' | 'MD' | '%';
  go: (p: string) => void;
  close: () => void;
  fromVal?: boolean;
  id?: string;
}

const PILL_TONE: Record<string, string> = {
  ov: 'bg-[var(--rdl)] text-[color:var(--rd)]',
  un: 'bg-[var(--orl)] text-[color:var(--or)]',
  ok: 'bg-[var(--gnl)] text-[color:var(--gn)]',
};

function PillSpan({ cls, txt }: { cls: string; txt: string }) {
  const key = cls.split(' ')[1] ?? cls;
  return (
    <span className={`inline-block rounded-[4px] px-[7px] py-[2px] text-[10.5px] font-medium ${PILL_TONE[key] ?? ''}`}>
      {TT(txt)}
    </span>
  );
}

function Row({ label, value, hi }: { label: string; value: ReactNode; hi?: boolean }) {
  return (
    <div
      className={`flex items-start justify-between gap-[16px] py-[4px] text-[13px] ${
        hi ? 'border-t border-[color:var(--bd)] bg-[var(--ylb)] px-[6px]' : ''
      }`}
    >
      <span className="shrink-0 font-medium text-[color:var(--t2)]">{label}</span>
      <span className="text-right leading-[1.45]">{value}</span>
    </div>
  );
}

export function MonthDrill({ S, P, mi, fg, ft, u, go, close, fromVal, id }: MonthDrillProps) {
  const rows = useMemo(
    () =>
      P.L2.filter(
        (r) => r.mi === mi && (ft && ft !== 'ALL' ? r.team === ft : !fg || fg === 'ALL' || r.grp === fg),
      ),
    [P.L2, mi, fg, ft],
  );
  const q = rows.reduce((sum, r) => sum + r.quota, 0);
  const a = rows.reduce((sum, r) => sum + r.allow, 0);
  const s = rows.reduce((sum, r) => sum + r.planSum, 0);
  const nOver = rows.filter((r) => statusOf(r.dif, S.teamTolerance ?? 0) === 'over').length;
  const capPer = rows[0]?.capPer ?? 0;

  const pill =
    nOver > 0 ? (
      <span className="inline-block rounded-[4px] bg-[var(--rdl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--rd)]">
        {TT('มีทีมที่เกินโควตา+OT')} {nOver} {TT('ทีม')}
      </span>
    ) : (
      <span className="inline-block rounded-[4px] bg-[var(--gnl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--gn)]">
        {TT('ทุกทีมอยู่ในโควตา+OT')}
      </span>
    );

  return (
    <Modal
      id={id}
      show
      onClose={close}
      size="large"
      pill={pill}
      title={`${TT('เดือน')} ${MONTHS[mi]} · ${TT('แยกรายทีม')}`}
      sub={`${fyMonthLabel(S.fy, mi)} · ${TT('วันทำงาน')} ${P.WD[mi] ?? '–'} ${TT('วัน')} = ${n1(capPer)} ${TT('ชม./คน')}`}
      footer={
        !fromVal ? (
          <Button
            size="sm"
            className="bg-[var(--yl)] text-white hover:bg-[var(--yld)]"
            onClick={() => {
              close();
              go('val');
            }}
          >
            {TT('ไปหน้า Validation →')}
          </Button>
        ) : undefined
      }
    >
      <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <Row label={TT('โควตา MP รวม')} value={`${fmt(q, a, u)} ${uSuf(u)}`.trim()} />
        <Row
          label={TT('+ OT Plan')}
          value={
            <span className="text-[color:var(--or)]">
              {fmt(a - q, a, u)} {uSuf(u)}
            </span>
          }
        />
        <Row label={TT('= โควตา+OT')} value={`${fmt(a, a, u)} ${uSuf(u)}`.trim()} />
        <Row
          hi
          label={TT('แผนที่กรอกมา')}
          value={
            <b>
              {fmt(s, a, u)} {uSuf(u)} · {fmt(s - a, a, u, { sign: true })}
            </b>
          }
        />
      </div>

      <h3 className="mb-[8px] text-[14px] font-semibold">{TT('รายทีม')}</h3>
      <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd)]">
        <table className="w-full min-w-[720px] border-collapse text-[12px]">
          <thead className="bg-[var(--cd2)]">
            <tr>
              {[TT('ทีม'), TT('คน'), TT('โควตา'), TT('OT'), TT('โควตา+OT'), TT('แผน'), TT('ส่วนต่าง'), TT('สถานะ')].map(
                (h) => (
                  <th key={h} className="px-[8px] py-[6px] text-right font-semibold text-[color:var(--t2)] first:text-left">
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const st = statusOf(r.dif, S.teamTolerance ?? 0);
              const pl = pillOf(st);
              const difColor = st === 'over' ? 'var(--rd)' : st === 'under' ? '#0369A1' : 'var(--t2)';
              return (
                <tr key={r.team} className="border-t border-[color:var(--bd)]">
                  <td className="px-[8px] py-[6px] text-left font-bold">{r.team}</td>
                  <td className="px-[8px] py-[6px] text-right">{r.head}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono">{fmt(r.quota, r.allow, u)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono">
                    {r.otMiss ? <span className="text-[color:var(--t3)]">—</span> : fmt(r.otPlan ?? 0, r.allow, u)}
                  </td>
                  <td className="px-[8px] py-[6px] text-right font-mono">{fmt(r.allow, r.allow, u)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono font-bold">{fmt(r.planSum, r.allow, u)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono font-bold" style={{ color: difColor }}>
                    {fmt(r.dif, r.allow, u, { sign: true })}
                  </td>
                  <td className="px-[8px] py-[6px] text-right">
                    <PillSpan cls={pl.cls} txt={pl.txt} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}
