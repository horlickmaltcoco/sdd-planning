// Session 1-15 · "เตรียมข้อมูลปีงบ {fy}". Target year = the page's year (fixed). One control: the
// source year. Every number is counted from a fresh read of the boards.
import { useEffect, useMemo, useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@components/ui/select';
import { Button } from '@components/ui/button';
import { Loader2 } from 'lucide-react';
import { Modal } from '@generated/components/MPShared';
import { TT } from '@generated/i18n';
import { planPrepare, sourceYears, type PrepSnapshot } from '@generated/lib/prepare-plan';
import { runPrepare } from '@generated/lib/prepare-run';
import { readPrepareSnapshot } from '@generated/server/prepare-fy';

export function PrepareFyDialog(props: {
  fy: string;
  fyList: string[];
  close: () => void;
  /** Reload the page data + the prepared-years list after a successful run. */
  done: () => Promise<void>;
  T: (msg: string) => void;
}) {
  const { fy, fyList, close, done, T } = props;
  const [snap, setSnap] = useState<PrepSnapshot | null>(null);
  const [loadErr, setLoadErr] = useState('');
  const [src, setSrc] = useState('');
  const [busy, setBusy] = useState(false);
  const [prog, setProg] = useState<{ done: number; total: number } | null>(null);
  const [fail, setFail] = useState<{ done: number; total: number } | null>(null);

  const load = async () => {
    setLoadErr('');
    try {
      const s = await readPrepareSnapshot({ data: {} });
      setSnap(s);
      setSrc((cur) => cur || sourceYears(s, fyList, fy)[0] || '');
    } catch (e) {
      console.error('readPrepareSnapshot failed', e);
      setLoadErr(TT('อ่านข้อมูลบอร์ดไม่สำเร็จ กรุณาลองใหม่'));
    }
  };
  useEffect(() => {
    void load();
  }, []);

  const srcOpts = useMemo(() => (snap ? sourceYears(snap, fyList, fy) : []), [snap, fyList, fy]);
  const plan = useMemo(() => (snap && src ? planPrepare(snap, fy, src) : null), [snap, fy, src]);
  const nothing = !!plan && plan.total === 0 && plan.groupsMissing.length === 0;
  const noLabel = !!plan && plan.labelMissing.length > 0;

  const submit = async () => {
    if (!plan || busy || nothing || noLabel) return;
    setBusy(true);
    setFail(null);
    try {
      const r = await runPrepare(fy, src, (d, t) => setProg({ done: d, total: t }));
      if (r.failed) {
        setFail({ done: r.done, total: r.total });
        await load(); // the table now shows what is STILL missing
        return;
      }
      await done();
      T(`${TT('เตรียมข้อมูลปีงบ')} ${fy} ${TT('แล้ว · สร้าง')} ${r.done} ${TT('แถว')}`);
      close();
    } catch (e) {
      console.error('prepare failed', e);
      setFail({ done: prog?.done ?? 0, total: prog?.total ?? plan.total });
    } finally {
      setBusy(false);
      setProg(null);
    }
  };

  const row = (label: string, value: string) => (
    <tr className="border-b border-border/50 last:border-0">
      <td className="py-1.5 pr-3 text-[12.5px]">{label}</td>
      <td className="py-1.5 text-right font-mono text-[12.5px] font-semibold">{value}</td>
    </tr>
  );

  return (
    <Modal
      show
      alertModal={busy}
      onClose={busy ? () => {} : close}
      title={`${TT('เตรียมข้อมูลปีงบ')} ${fy}`}
      sub={TT('สร้างโครงของปีงบนี้ ไม่ลอกตัวเลขจากปีเก่า')}
      footer={
        <div className="flex flex-col items-end gap-1">
          {nothing && <p className="text-[12px] font-semibold text-muted-foreground">{TT('ปีงบนี้มีโครงครบแล้ว')}</p>}
          <Button onClick={submit} disabled={!plan || busy || nothing || noLabel}>
            {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {TT('สร้าง')} {plan?.total ?? 0} {TT('แถว')}
          </Button>
        </div>
      }
    >
      <div className="space-y-4">
        {loadErr && <p className="text-[12.5px] font-semibold text-destructive">{loadErr}</p>}
        {!snap && !loadErr && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
        {snap && (
          <>
            <div className="space-y-1.5">
              <label className="block text-[13px] font-medium">{TT('ลอกโครงจาก')}</label>
              <Select value={src} onValueChange={setSrc} disabled={busy || srcOpts.length === 0}>
                <SelectTrigger aria-label={TT('ลอกโครงจาก')}><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  {srcOpts.map((y) => <SelectItem key={y} value={y}>{`${TT('ปีงบ')} ${y}`}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {plan && (
              <table className="w-full">
                <tbody>
                  {row(`${TT('กลุ่ม FY')}${fy} ${TT('บนบอร์ด')}`, `${plan.groupsMissing.length} / 3`)}
                  {row(TT('แผน OT · รายชื่อทีม'), `${plan.otTeams.length} ${TT('แถว')}`)}
                  {row(`${TT('แผนงาน ISUZU Group ·')} ${plan.pairs} ${TT('คู่ × 12 เดือน')}`, `${plan.cpRows.length} ${TT('แถว')}`)}
                  {row('MP Plan', TT('ไม่สร้าง · แต่ละทีมนำเข้าไฟล์เอง'))}
                </tbody>
              </table>
            )}
            <div className="space-y-1 text-[12px] text-muted-foreground">
              <p>{`${TT('ทุกช่องตัวเลขเว้นว่าง ไม่ลอกค่าจากปีงบ')} ${src || '—'} ${TT('· ข้อมูลปีงบเดิมไม่ถูกแตะแม้แต่ช่องเดียว')}`}</p>
              <p>{TT('กดซ้ำได้ ระบบจะสร้างเฉพาะส่วนที่ยังขาด')}</p>
            </div>
            {noLabel && plan && (
              <div className="rounded border border-destructive/40 px-3 py-2 text-[12.5px]">
                <p className="font-semibold text-destructive">
                  {TT('คอลัมน์ FY บนบอร์ด')} {plan.labelMissing.join(' · ')} {TT('ยังไม่มีตัวเลือก')} {fy}
                </p>
                <p>
                  {TT('เปิดตั้งค่าคอลัมน์ FY บนบอร์ดเหล่านี้ เพิ่มตัวเลือก')} {fy} {TT('แล้วเปิดหน้านี้ใหม่')}
                </p>
              </div>
            )}
            {busy && prog && (
              <p className="text-[12.5px] font-semibold">
                {TT('กำลังสร้าง')} {prog.done} {TT('จาก')} {prog.total} {TT('แถว')}
              </p>
            )}
            {fail && (
              <div className="rounded border border-destructive/40 px-3 py-2 text-[12.5px]">
                <p className="font-semibold text-destructive">
                  {TT('สร้างได้')} {fail.done} {TT('จาก')} {fail.total} {TT('แถว')}
                </p>
                <p>{TT('กดเตรียมข้อมูลอีกครั้ง ระบบจะสร้างเฉพาะส่วนที่ยังขาด')}</p>
              </div>
            )}
          </>
        )}
      </div>
    </Modal>
  );
}
