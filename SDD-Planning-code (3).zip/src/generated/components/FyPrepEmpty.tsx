// Session 1-15 · the shared empty state for a fiscal year that is not prepared yet (ภาพรวม, แผน OT,
// แผนงาน ISUZU Group — never MP Plan). Explains the zeros and offers the one action.
import { useState } from 'react';
import { Button } from '@components/ui/button';
import { CalendarPlus } from 'lucide-react';
import { TT } from '@generated/i18n';
import { PrepareFyDialog } from '@generated/components/PrepareFyDialog';

export function FyPrepEmpty(props: {
  fy: string;
  fyList: string[];
  done: () => Promise<void>;
  T: (msg: string) => void;
}) {
  const { fy } = props;
  const [open, setOpen] = useState(false);
  return (
    <div className="mx-auto mt-[24px] max-w-[620px] rounded-[10px] border border-dashed border-[color:var(--bd)] bg-[var(--cd)] px-[24px] py-[28px] text-center">
      <CalendarPlus className="mx-auto mb-[10px] h-[28px] w-[28px] text-[color:var(--t3)]" aria-hidden />
      <h2 className="text-[17px] font-bold leading-[1.35]">
        {TT('ปีงบ')} {fy} {TT('ยังไม่มีข้อมูลฝั่งการวางแผน')}
      </h2>
      <p className="mt-[8px] text-[13px] text-[color:var(--t2)]">{TT('ปีงบนี้ยังไม่มีโครงข้อมูลบนบอร์ด ตัวเลขทุกหน้าจึงว่างเปล่า')}</p>
      <p className="text-[13px] text-[color:var(--t2)]">{TT('เตรียมข้อมูลเพื่อสร้างรายชื่อทีมและคู่กลุ่ม-บริษัทไว้รองรับ')}</p>
      <Button className="mt-[16px]" onClick={() => setOpen(true)}>
        {TT('เตรียมข้อมูลปีงบ')} {fy}
      </Button>
      <p className="mt-[10px] text-[11.5px] text-[color:var(--t3)]">{TT('ไม่ลอกตัวเลขจากปีเก่า · ข้อมูลปีงบเดิมไม่ถูกแตะ')}</p>
      <p className="mt-[2px] text-[11.5px] text-[color:var(--t3)]">
        {TT('ถ้าวันทำงานปีงบ')} {fy} {TT('จาก SDD Master ยังไม่เข้า ตัวเลขโควตาจะยังเป็นศูนย์แม้เตรียมข���อมูลแล้ว')}
      </p>
      {open && <PrepareFyDialog fy={fy} fyList={props.fyList} close={() => setOpen(false)} done={props.done} T={props.T} />}
    </div>
  );
}
