// Session 1-11 · Validation "val" · A5 Tier-3 table (Group x month vs quota+OT summed over
// its teams). 36 rows in FY2026 — plain table. Read-only.
//
// Session 1-09 Part A/B fix: columns previously auto-sized to the longest value on screen, so
// switching FY / unit moved every column, and the table stopped short of the card's right
// edge. All 9 columns (including "ทีมที่เกิน") now come from one fixed-width list (L3_COLS)
// rendered via a <colgroup> under table-layout: fixed + width: 100% — the browser distributes
// any leftover space across columns in proportion to their declared widths (so the table
// fills the card) while content can never change a column's width (so nothing moves between
// FY/unit). min-width keeps it scrollable on a narrow window instead of squeezing.
import { fmt, uLabel } from '@generated/engine';
import type { Tier3Row } from '@generated/engine/part-c';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import type { Settings } from '@generated/model/types';

type ColAlign = 'left' | 'right' | 'center';
interface Col {
  id: string;
  title: string;
  width: number;
  align: ColAlign;
}

const L3_COLS: Col[] = [
  { id: 'grp', title: 'Group', width: 80, align: 'left' },
  { id: 'month', title: 'เดือน', width: 70, align: 'left' },
  { id: 'teams', title: 'ทีมในกลุ่ม', width: 190, align: 'left' },
  { id: 'allow', title: 'โควตา+OT รวม', width: 130, align: 'right' },
  { id: 'plan', title: 'แผนรวม', width: 110, align: 'right' },
  { id: 'dif', title: 'ส่วนต่าง', width: 110, align: 'right' },
  { id: 'st', title: 'สถานะ', width: 120, align: 'center' },
  { id: 'over', title: 'ทีมที่เกิน', width: 220, align: 'left' },
  { id: 'go', title: '', width: 40, align: 'right' },
];
const L3_TOTAL_W = L3_COLS.reduce((s, c) => s + c.width, 0);

function alignCls(a: ColAlign): string {
  return a === 'left' ? 'text-left' : a === 'center' ? 'text-center' : 'text-right';
}

interface ValL3TableProps {
  rows: Tier3Row[];
  S: Settings;
  u: 'Hrs' | 'MD' | '%';
  pick: (r: Tier3Row) => void;
}

export function ValL3Table({ rows, S, u, pick }: ValL3TableProps) {
  return (
    <div className="overflow-hidden rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
      <h3 className="text-[15px] font-bold leading-[1.3]">{TT('ยอดรวมระดับ Group')}</h3>
      <p className="mt-[5px] text-[12.5px] leading-[1.55] text-[color:var(--t2)]">
        {TT('แผนรวมของทุกทีมใน group เทียบกับโควตา+OT รวมของ group · ผ่อนผัน ±')}
        {S.teamTolerance ?? 0}
        {TT(' ชม. ต่อทีม · หน่วยที่แสดง ')}
        <b>{uLabel(u, TT('โควตา+OT รวมของ group ในเดือนนั้น'))}</b>
      </p>

      {rows.length === 0 ? (
        <p className="px-[22px] py-[18px] text-[13px] text-[color:var(--t3)]">{TT('ไม่มีรายการตามตัวกรองที่เลือก')}</p>
      ) : (
        <div className="mt-[10px] overflow-auto rounded-[8px] border border-[color:var(--bd)]" style={{ height: 520 }}>
          <table className="border-collapse text-[12px]" style={{ tableLayout: 'fixed', width: '100%', minWidth: L3_TOTAL_W }}>
            <colgroup>
              {L3_COLS.map((c) => (
                <col key={c.id} style={{ width: c.width }} />
              ))}
            </colgroup>
            <thead className="sticky top-0 z-10 bg-[var(--cd2)]">
              <tr>
                {L3_COLS.map((c) => (
                  <th
                    key={c.id}
                    className={`overflow-hidden whitespace-nowrap px-[8px] py-[7px] font-semibold text-[color:var(--t2)] ${alignCls(c.align)}`}
                  >
                    {TT(c.title)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const difColor = r.st === 'over' ? 'var(--rd)' : r.st === 'under' ? '#0369A1' : 'var(--t2)';
                const overTxt = r.over.length ? r.over.map((z) => `${z.t} +${fmt(z.h, r.allow, u)}`).join(', ') : '—';
                return (
                  <tr
                    key={`${r.grp}|${r.mi}`}
                    onClick={() => pick(r)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        pick(r);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-label={`${r.grp} · ${MONTHS[r.mi]} · ${r.st === 'over' ? TT('เกินทั้ง group') : TT('ยังพอ')}`}
                    className="cursor-pointer border-t border-[color:var(--bd)] hover:bg-[var(--cd2)]"
                  >
                    <td className={`overflow-hidden px-[8px] py-[6px] font-bold ${alignCls(L3_COLS[0].align)}`}>{r.grp}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L3_COLS[1].align)}`}>{MONTHS[r.mi]}</td>
                    <td className={`whitespace-normal px-[8px] py-[6px] text-[11.5px] leading-[1.45] text-[color:var(--t2)] ${alignCls(L3_COLS[2].align)}`}>
                      {r.teams.join(' · ')}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono text-[color:var(--t2)] ${alignCls(L3_COLS[3].align)}`}>
                      {fmt(r.allow, r.allow, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono font-bold ${alignCls(L3_COLS[4].align)}`}>
                      {fmt(r.planSum, r.allow, u)}
                    </td>
                    <td
                      className={`overflow-hidden px-[8px] py-[6px] font-mono font-bold ${alignCls(L3_COLS[5].align)}`}
                      style={{ color: difColor }}
                    >
                      {fmt(r.dif, r.allow, u, { sign: true })}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L3_COLS[6].align)}`}>
                      {r.st === 'over' ? (
                        <span className="inline-block rounded-[4px] bg-[var(--rdl)] px-[7px] py-[2px] text-[10.5px] font-medium text-[color:var(--rd)]">
                          {TT('เกินทั้ง group')}
                        </span>
                      ) : (
                        <span className="inline-block rounded-[4px] bg-[var(--gnl)] px-[7px] py-[2px] text-[10.5px] font-medium text-[color:var(--gn)]">
                          {TT('ยังพอ')}
                        </span>
                      )}
                    </td>
                    <td className={`whitespace-normal px-[8px] py-[6px] leading-[1.45] text-[color:var(--t2)] ${alignCls(L3_COLS[7].align)}`}>
                      {r.over.length ? overTxt : <span className="text-[color:var(--t3)]">{overTxt}</span>}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] text-[color:var(--t3)] ${alignCls(L3_COLS[8].align)}`}>{'→'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
