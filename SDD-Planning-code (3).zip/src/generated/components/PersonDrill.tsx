// Session 1-04 B3 (shared) · PersonDrill — one person in one team for the whole FY.
// ONE copy for the whole app (Validation tier 1 and the MP person view). Read-only.
import { useMemo } from 'react';
import { ALLMI, MONTHS } from '@generated/config';
import { fmt, fyYearOf, pct, uLabel, uSuf } from '@generated/engine';
import { inQuotaOf } from '@generated/engine/part-b';
import { tier1State, type Plan } from '@generated/engine/part-c';
import { TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { Settings } from '@generated/model/types';
import { Modal } from '@generated/components/MPShared';
import { BandCell, KVRow, PillSpan, Tier1Pill } from '@generated/components/Tier1Pill';

interface PersonDrillProps {
  S: Settings;
  P: Plan;
  /** The clicked row: team + EMP ID key (name only as fallback). */
  row: { team: string; key?: string; name: string };
  u: 'Hrs' | 'MD' | '%';
  close: () => void;
  model: Model;
  id?: string;
}

function withSuf(txt: string, u: string): string {
  const s = uSuf(u);
  return s ? `${txt} ${TT(s)}` : txt;
}

export function PersonDrill({ S, P, row, u, close, model, id }: PersonDrillProps) {
  const tm = P.teams.find((t) => t.team === row.team);
  const pp = tm?.people.find((x) => (row.key ? x.key === row.key : x.n === row.name));

  const deps = useMemo(
    () => ({
      EMPWIN: model.EMPWIN,
      ASSIGN: model.ASSIGN,
      FYCODE: model.FYCODE,
      PEOPLE_BY_EMP: model.PEOPLE_BY_EMP,
      PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
    }),
    [model],
  );

  if (!pp) {
    return (
      <Modal id={id} show onClose={close} title={row.name} sub={`${row.team} · ${TT('ปีงบ')} ${S.fy}`}>
        <p className="text-[13px] text-[color:var(--t3)]">{TT('ไม่พบข้อมูลของพนักงานคนนี้ในทีมนี้')}</p>
      </Modal>
    );
  }

  const myMI = pp.emp ? ALLMI.filter((i) => inQuotaOf(row.team, pp.emp, S.fy, i, model.ASSIGN, model.FYCODE)) : ALLMI;
  const capY = model.capSumOf(S.fy, myMI);
  const tot = ALLMI.reduce((s, i) => s + (pp.m[i] ?? 0), 0);
  const wdY = myMI.reduce((s, i) => s + (P.WD[i] ?? 0), 0);
  const n = P.L1.filter((r) => r.team === row.team && r.key === pp.key && r.bad).length;

  const pill =
    n > 0 ? (
      <PillSpan tone="un">
        {TT('ไม่ผ่านเกณฑ์ชั้น 1 · ')}{n} {TT('เดือน')}
      </PillSpan>
    ) : (
      <PillSpan tone="ok">{TT('ผ่านเกณฑ์ชั้น 1')}</PillSpan>
    );

  const HEAD = ['เดือน', 'วันทำงาน', 'capacity', 'แผน', '%', 'เกณฑ์ชั้น 1'];

  return (
    <Modal
      id={id}
      show
      onClose={close}
      size="large"
      pill={pill}
      title={pp.n}
      sub={`${row.team} · ${pp.role} · ${TT('ปีงบ')} ${S.fy}`}
    >
      <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <KVRow
          label={TT('capacity ทั้งปี')}
          value={`${withSuf(fmt(capY, capY, u), u)} (${wdY} ${TT('วัน')} × ${S.hoursPerDay})`}
        />
        {myMI.length < 12 && (
          <KVRow label={TT('นับเฉพาะเดือนที่อยู่ในโควตาของทีมนี้')} value={`${myMI.length} ${TT('จาก 12 เดือน')}`} />
        )}
        <KVRow hi label={TT('แผนทั้งปี')} value={`${withSuf(fmt(tot, capY, u), u)} · ${pct(tot, capY)}%`} />
      </div>

      <p className="mb-[8px] text-[14px] font-bold leading-[1.4]">
        {TT('รายเดือน · แสดงเป็น')} {TT(uLabel(u, TT('capacity รายคน')))}
      </p>
      <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd)]">
        <table className="w-full min-w-[640px] border-collapse text-[12px]">
          <thead className="bg-[var(--cd2)]">
            <tr>
              {HEAD.map((h, i) => (
                <th
                  key={h}
                  className={`whitespace-nowrap px-[8px] py-[6px] font-semibold text-[color:var(--t2)] ${i === 0 || i === 5 ? 'text-left' : 'text-right'}`}
                >
                  {TT(h)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ALLMI.map((i) => {
              const cap = model.capPerOf(S.fy, i);
              const v = pp.m[i] ?? 0;
              const st1 = tier1State(row.team, pp, S.fy, i, cap, S, deps);
              return (
                <tr
                  key={i}
                  className="border-t border-[color:var(--bd)]"
                  style={st1.k === 'under' ? { background: '#F0F9FF' } : undefined}
                >
                  <td className="px-[8px] py-[6px] text-left">
                    <b>{MONTHS[i]}</b> <span className="font-mono text-[color:var(--t3)]">{fyYearOf(S.fy, i)}</span>
                  </td>
                  <td className="px-[8px] py-[6px] text-right">{P.WD[i] ?? '–'}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono text-[color:var(--t2)]">{fmt(cap, cap, u)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono font-bold">{v ? fmt(v, cap, u) : '–'}</td>
                  <td className="px-[8px] py-[6px] text-right">
                    <BandCell v={v} cap={cap} bands={S.bands} />
                  </td>
                  <td className="px-[8px] py-[6px] text-left">
                    <Tier1Pill s={st1} cap={cap} u={u} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Modal>
  );
}
