// Session 1-11 · Validation "val" · A5 Tier-1 table (person x month vs capacity).
// Manually windowed (no virtualization lib in this project): only rows near the visible
// viewport are mounted, header stays sticky while scrolling. Read-only.
//
// Session 1-09 Part A fix: header and body rows previously sized their columns
// independently (header used the raw title strings, rows used their own td widths),
// so "พนักงาน" drifted from the names below it. Both are now driven by one shared
// column list (L1_COLS) with fixed pixel widths + a <colgroup>, under table-layout:
// fixed + width: 100%, so content can never influence a column's width (header can
// never drift from the rows while scrolling) while the table still stretches to
// fill its card — min-width keeps it scrollable on a narrow window.
import { useState } from 'react';
import { fmt, fyYearOf, uLabel } from '@generated/engine';
import type { Tier1Row } from '@generated/engine/part-c';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import type { Settings } from '@generated/model/types';

const ROW_H = 34;
const VIEWPORT_H = 520;
const OVERSCAN = 10;

type ColAlign = 'left' | 'right' | 'center';
interface Col {
  id: string;
  title: string;
  width: number;
  align: ColAlign;
}

const L1_COLS: Col[] = [
  { id: 'team', title: 'ทีม', width: 70, align: 'left' },
  { id: 'name', title: 'พนักงาน', width: 200, align: 'left' },
  { id: 'role', title: 'Role', width: 90, align: 'left' },
  { id: 'month', title: 'เดือน', width: 110, align: 'left' },
  { id: 'plan', title: 'แผน', width: 100, align: 'right' },
  { id: 'cap', title: 'capacity', width: 100, align: 'right' },
  { id: 'gap', title: 'ส่วนต่าง', width: 110, align: 'right' },
  { id: 'type', title: 'ประเภท', width: 190, align: 'left' },
  { id: 'go', title: '', width: 40, align: 'right' },
];
const L1_TOTAL_W = L1_COLS.reduce((s, c) => s + c.width, 0);
const COLS = L1_COLS.length;

function alignCls(a: ColAlign): string {
  return a === 'left' ? 'text-left' : a === 'center' ? 'text-center' : 'text-right';
}

interface ValL1TableProps {
  rows: Tier1Row[];
  S: Settings;
  u: 'Hrs' | 'MD' | '%';
  pick: (r: Tier1Row) => void;
}

export function ValL1Table({ rows, S, u, pick }: ValL1TableProps) {
  const [scrollTop, setScrollTop] = useState(0);

  if (!S.minPerPerson && !S.maxPerPerson) {
    return (
      <div className="rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
        <h3 className="text-[15px] font-bold leading-[1.3]">{TT('ปิดการตรวจชั้น 1 ไว้')}</h3>
        <p className="mt-[6px] text-[13px] leading-[1.5] text-[color:var(--t3)]">
          {TT('เปิดได้ที่บอร์ด Working Day Master แถวรวมทั้งปี คอลัมน์ Block Person Below Capacity')}
        </p>
      </div>
    );
  }

  const total = rows.length;
  const visibleCount = Math.ceil(VIEWPORT_H / ROW_H) + OVERSCAN * 2;
  const start = Math.max(0, Math.floor(scrollTop / ROW_H) - OVERSCAN);
  const end = Math.min(total, start + visibleCount);
  const visRows = rows.slice(start, end);

  return (
    <div className="overflow-hidden rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
      <h3 className="text-[15px] font-bold leading-[1.3]">{TT('แผนรายคนเทียบ capacity')}</h3>
      <p className="mt-[5px] text-[12.5px] leading-[1.55] text-[color:var(--t2)]">
        {TT('เกณฑ์: แผนของแต่ละคนในเดือนนั้น ต้องไม่น้อยกว่า วันทำงาน × ')}
        {S.hoursPerDay}
        {TT(' ชม. · หน่วยที่แสดง ')}
        <b>{uLabel(u, TT('capacity ของคนในเดือนนั้น'))}</b>
      </p>
      <p className="mt-[4px] text-[11.5px] leading-[1.55] text-[color:var(--t3)]">
        {TT('รายการนี้แสดงทุกเดือนที่ไม่เท่ากับ capacity · ป้ายสีแดงคือผิดเกณฑ์ตามกติกาบนบอร์ด ป้ายสีเทาคือแสดงให้ทราบ ไม่ถือว่าผิด')}
        {' · '}
        {TT('กติกาตอนนี้')}: {TT('ต่ำกว่า capacity')} {S.minPerPerson ? TT('ผิด') : TT('ไม่ผิด')} ·{' '}
        {TT('เกิน capacity')} {S.maxPerPerson ? TT('ผิด') : TT('ไม่ผิด')} · {TT('แก้ได้ที่บอร์ด Working Day Master แถวรวมทั้งปี')}
      </p>

      {total === 0 ? (
        <p className="px-[22px] py-[18px] text-[13px] text-[color:var(--t3)]">{TT('ไม่มีรายการตามตัวกรองที่เลือก')}</p>
      ) : (
        <div
          className="mt-[10px] overflow-auto rounded-[8px] border border-[color:var(--bd)]"
          style={{ height: VIEWPORT_H }}
          onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
        >
          <table className="border-collapse text-[12px]" style={{ tableLayout: 'fixed', width: '100%', minWidth: L1_TOTAL_W }}>
            <colgroup>
              {L1_COLS.map((c) => (
                <col key={c.id} style={{ width: c.width }} />
              ))}
            </colgroup>
            <thead className="sticky top-0 z-10 bg-[var(--cd2)]">
              <tr>
                {L1_COLS.map((c) => (
                  <th
                    key={c.id}
                    className={`overflow-hidden whitespace-nowrap px-[8px] py-[7px] font-semibold text-[color:var(--t2)] ${alignCls(c.align)}`}
                  >
                    {TT(c.title)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr style={{ height: start * ROW_H }}>
                <td colSpan={COLS} className="p-0" />
              </tr>
              {visRows.map((r) => {
                const diffColor = r.kind === 'under' ? '#0369A1' : 'var(--rd)';
                const sign = r.kind === 'under' ? '−' : '+';
                const badTxt = r.kind === 'under' ? TT('ต่ำกว่า capacity') : TT('เกิน capacity');
                return (
                  <tr
                    key={`${r.team}|${r.key}|${r.mi}`}
                    onClick={() => pick(r)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        pick(r);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-label={`${r.name} · ${MONTHS[r.mi]} · ${badTxt}`}
                    style={{ height: ROW_H }}
                    className="cursor-pointer border-t border-[color:var(--bd)] hover:bg-[var(--cd2)]"
                  >
                    <td className={`overflow-hidden px-[8px] font-bold ${alignCls(L1_COLS[0].align)}`}>{r.team}</td>
                    <td className={`overflow-hidden px-[8px] ${alignCls(L1_COLS[1].align)}`}>{r.name}</td>
                    <td className={`overflow-hidden px-[8px] text-[color:var(--t2)] ${alignCls(L1_COLS[2].align)}`}>{r.role}</td>
                    <td className={`overflow-hidden px-[8px] ${alignCls(L1_COLS[3].align)}`}>
                      {MONTHS[r.mi]} <span className="font-mono text-[color:var(--t3)]">{fyYearOf(S.fy, r.mi)}</span>
                    </td>
                    <td className={`overflow-hidden px-[8px] font-mono font-bold ${alignCls(L1_COLS[4].align)}`}>{fmt(r.v, r.cap, u)}</td>
                    <td className={`overflow-hidden px-[8px] font-mono text-[color:var(--t2)] ${alignCls(L1_COLS[5].align)}`}>
                      {fmt(r.cap, r.cap, u)}
                    </td>
                    <td
                      className={`overflow-hidden px-[8px] font-mono font-bold ${alignCls(L1_COLS[6].align)}`}
                      style={{ color: diffColor }}
                    >
                      {sign}
                      {fmt(r.gap, r.cap, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] ${alignCls(L1_COLS[7].align)}`}>
                      {r.bad ? (
                        <span className="inline-block rounded-[4px] bg-[var(--rdl)] px-[7px] py-[2px] text-[10.5px] font-medium text-[color:var(--rd)]">
                          {badTxt} · {TT('ผิดเกณฑ์')}
                        </span>
                      ) : (
                        <span
                          className="inline-block cursor-help rounded-[4px] bg-[var(--cd2)] px-[7px] py-[2px] text-[10.5px] font-medium text-[color:var(--t3)]"
                          title={TT('กติกาบนบอร์ดไม่ถือว่าผิด · แสดงไว้ให้ทราบ')}
                        >
                          {badTxt}
                        </span>
                      )}
                    </td>
                    <td className={`overflow-hidden px-[8px] text-[color:var(--t3)] ${alignCls(L1_COLS[8].align)}`}>{'→'}</td>
                  </tr>
                );
              })}
              <tr style={{ height: (total - end) * ROW_H }}>
                <td colSpan={COLS} className="p-0" />
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
