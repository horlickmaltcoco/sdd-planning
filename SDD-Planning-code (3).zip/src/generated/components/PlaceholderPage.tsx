// Page switcher. Loading and load-error states are handled once in App (C3), so every page
// here renders only with complete data.
import type { PageId } from '@generated/config';
import type { SddData } from '@generated/hooks/use-sdd-data';
import type { CpRow } from '@generated/lib/types';
import CPGrid from '@generated/components/CPGrid';
import type { Model } from '@generated/model';
import type { Settings, MpDerived, OtMap } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import MPGrid from '@generated/components/MPGrid';
import OTGrid from '@generated/components/OTGrid';
import OvGrid from '@generated/components/OvGrid';
import ValGrid from '@generated/components/ValGrid';
import { FyPrepEmpty } from '@generated/components/FyPrepEmpty';
import { PrepareFyButton } from '@generated/components/PrepareFyButton';
import type { Prepared } from '@generated/hooks/use-prepared';
import { TT } from '@generated/i18n';

export default function PlaceholderPage(props: {
  id: PageId;
  label: string;
  go: (p: string) => void;
  T: (msg: string) => void;
  data: SddData;
  model: Model;
  S: Settings;
  P: Plan;
  setS: (fn: (prev: Settings) => Settings) => void;
  mp: MpDerived[];
  setMp: (fn: (prev: MpDerived[]) => MpDerived[]) => void;
  otAll: OtMap;
  setOtAll: (fn: (prev: OtMap) => OtMap) => void;
  cp: CpRow[];
  setCp: (fn: (prev: CpRow[]) => CpRow[]) => void;
  saveBands: (fy: string | number, bands: number[], redAt: number | string | null) => void;
  clearBands: (fy: string | number) => void;
  prep: Prepared;
}) {
  const bs = props.data.bs;

  // Session 1-15 · a year without its FY group on boards 04, 05 AND 07 is "not prepared". Only
  // judged once the groups are known; MP Plan never gets this empty state.
  const FYS = String(props.S.fy);
  const unprep = (fy: string) => props.prep.known && !props.prep.isPrepared(fy);
  const afterPrepare = async () => {
    await props.prep.refresh();
    await props.data.reload('OT Plan');
    await props.data.reload('Company Plan');
  };
  const prepEmpty = unprep(FYS) ? (
    <FyPrepEmpty fy={FYS} fyList={props.model.fyList()} done={afterPrepare} T={props.T} />
  ) : null;
  const prepPage = (title: string) => (
    <div className="mx-auto w-full max-w-[1600px]">
      <h1 className="text-[22px] font-bold leading-[1.3]">
        {TT(title)} {TT('ปีงบ')} {FYS}
      </h1>
      {prepEmpty}
    </div>
  );

  if (props.id === 'val') {
    return <ValGrid S={props.S} setS={props.setS} P={props.P} model={props.model} go={props.go} fyUnprep={unprep} />;
  }

  if (props.id === 'ot') {
    if (prepEmpty) return prepPage('OT Plan ·');
    return (
      <OTGrid
        S={props.S}
        P={props.P}
        model={props.model}
        otAll={props.otAll}
        setOtAll={props.setOtAll}
        T={props.T}
        loading={bs['OT Plan'].status === 'loading'}
        reloadOt={() => props.data.reload('OT Plan')}
      />
    );
  }

  if (props.id === 'cp') {
    if (prepEmpty) return prepPage('แผนงาน ISUZU Group');
    return (
      <CPGrid
        S={props.S}
        model={props.model}
        cp={props.cp}
        setCp={props.setCp}
        T={props.T}
        reloadCp={() => props.data.reload('Company Plan')}
      />
    );
  }

  if (props.id === 'mp') {
    return (
      <MPGrid
        S={props.S}
        P={props.P}
        mp={props.mp}
        model={props.model}
        setMp={props.setMp}
        T={props.T}
        setS={props.setS}
        saveBands={props.saveBands}
        clearBands={props.clearBands}
        reloadMp={() => props.data.reload('MP Plan')}
      />
    );
  }

  // 'ov' and any unknown id → Overview
  return (
    <OvGrid
      S={props.S}
      setS={props.setS}
      P={props.P}
      model={props.model}
      mp={props.mp}
      cp={props.cp}
      go={props.go}
      fyUnprep={unprep}
      prepBody={prepEmpty}
      prepAction={<PrepareFyButton fy={FYS} fyList={props.model.fyList()} done={afterPrepare} T={props.T} />}
    />
  );
}
