import { type PageId } from '@generated/config';
import { TT, U, type Lang } from '@generated/i18n';
import SidebarNav from '@generated/components/SidebarNav';
import { cn } from '@lib/utils';

export default function Sidebar(props: {
  page: PageId;
  go: (p: string) => void;
  lang: Lang;
  setLang: (l: Lang) => void;
  dot: boolean;
  /** C3 · time of the last fully successful load (null until the first one). */
  loadedAt: Date | null;
  busy: boolean;
  reload: () => void;
}) {
  const hhmm = props.loadedAt
    ? `${String(props.loadedAt.getHours()).padStart(2, '0')}:${String(props.loadedAt.getMinutes()).padStart(2, '0')}`
    : '–';
  // Each button reads U('lang') when it IS the active language, U('other') when it is not —
  // this is why the English-mode pair reads "EN" / "ไทย" rather than "English" / "ไทย".
  const langs: [Lang][] = [['th'], ['en']];
  return (
    <div className="flex h-full w-full flex-col bg-[var(--sb)] text-white">
      <button
        type="button"
        onClick={() => props.go('ov')}
        className="flex w-full items-center gap-[10px] border-b border-[color:var(--sb-bd)] px-[18px] py-[17px] text-left outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--yl)]"
      >
        <span className="flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-[7px] bg-[var(--yl)] text-[12px] font-bold text-white">
          IZ
        </span>
        <span className="min-w-0">
          <h2 className="truncate text-[14px] font-bold leading-[1.2]">SDD Planning</h2>
          <small className="mt-[2px] block truncate text-[9px] uppercase tracking-[.5px] text-[color:var(--sb-t4)]">
            {TT('ISUZU')}
          </small>
        </span>
      </button>

      <SidebarNav page={props.page} go={props.go} dot={props.dot} />

      {/* C3 · the only new sidebar element: "ข้อมูล ณ HH:MM" + reload link */}
      <div className="mx-[18px] mb-[8px] flex flex-wrap items-center gap-x-[6px] text-[10.5px] text-[color:var(--sb-t4)]">
        <span>
          {TT('ข้อมูล ณ')} {hhmm}
        </span>
        <span aria-hidden>·</span>
        <button
          type="button"
          onClick={props.reload}
          disabled={props.busy}
          className="rounded-[3px] font-semibold text-[color:var(--sb-t1)] underline-offset-2 outline-none hover:text-white hover:underline focus-visible:ring-2 focus-visible:ring-[color:var(--yl)] disabled:opacity-50"
        >
          {TT('โหลดข้อมูลใหม่')}
        </button>
      </div>

      <div
        role="group"
        aria-label={TT('เลือกภาษา')}
        className="mx-[9px] mb-[10px] flex overflow-hidden rounded-[7px] border border-[color:var(--sb-bd2)]"
      >
        {langs.map(([code]) => {
          const active = props.lang === code;
          return (
            <button
              key={code}
              type="button"
              onClick={() => props.setLang(code)}
              aria-pressed={active}
              className={cn(
                'flex-1 py-[7px] text-[12.1px] font-semibold shadow-none outline-none transition-colors focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[color:var(--yl)]',
                active
                  ? 'bg-[var(--yl)] text-white'
                  : 'bg-transparent text-[color:var(--sb-t3)] hover:text-white',
              )}
            >
              {active ? U('lang') : U('other')}
            </button>
          );
        })}
      </div>

    </div>
  );
}
