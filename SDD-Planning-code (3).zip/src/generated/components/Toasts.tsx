import type { Toast } from '@generated/hooks/use-toasts';
import { TT } from '@generated/i18n';

export default function Toasts(props: { toasts: Toast[]; drop: (id: number) => void }) {
  return (
    <div
      className="pointer-events-none fixed bottom-[20px] right-[20px] z-[200] flex flex-col gap-[8px]"
      aria-live="polite"
    >
      {props.toasts.map((t) => (
        <div
          key={t.id}
          className="sdd-rise pointer-events-auto flex max-w-[420px] items-start gap-[10px] rounded-[9px] bg-[var(--sb)] px-[16px] py-[11px] text-[12.5px] text-white shadow-[var(--toast-sd)]"
        >
          <span className="min-w-0 flex-1">{TT(t.msg)}</span>
          <button
            type="button"
            aria-label={TT('ปิด')}
            onClick={() => props.drop(t.id)}
            className="shrink-0 opacity-50 outline-none transition-opacity hover:opacity-100 focus-visible:opacity-100"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
