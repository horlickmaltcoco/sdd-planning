// Session 1-14 · แผน OT → "เพิ่มทีม". Creates ONE empty OT Plan row for a team that has none in
// the selected FY. Dropdown only — no typed team names.
import { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@components/ui/select';
import { Button } from '@components/ui/button';
import { Loader2 } from 'lucide-react';
import { Modal, BoardTag } from '@generated/components/MPShared';
import { TT } from '@generated/i18n';
import { createOtTeamRow, NoFyGroupError } from '@generated/lib/add-rows';
import { noFyGroupText } from '@generated/components/AddCompanyModal';

export function AddTeamModal(props: {
  fy: string | number;
  free: string[]; // teams with NO row for this FY
  close: () => void;
  done: () => Promise<void>;
  T: (msg: string) => void;
}) {
  const { fy, free, close, done, T } = props;
  const [team, setTeam] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async () => {
    if (!team || busy) return;
    setBusy(true);
    setErr('');
    try {
      await createOtTeamRow(team, fy);
      await done();
      T(`${TT('เพิ่มทีม')} ${team} ${TT('ปีงบ')} ${fy} ${TT('แล้ว')}`);
      close();
    } catch (e) {
      console.error('Add team failed:', e);
      setErr(e instanceof NoFyGroupError ? noFyGroupText(e) : TT('ไม่สามารถเพิ่มแถวได้ กรุณาลองใหม่'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      show
      alertModal={busy}
      onClose={busy ? () => {} : close}
      pill={<BoardTag board="OT Plan" />}
      title={TT('เพิ่มทีม')}
      sub={`${TT('สร้างแถวเปล่าของทีมนี้ สำหรับปีงบ')} ${fy}`}
      footer={
        <Button onClick={submit} disabled={!team || busy}>
          {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {TT('เพิ่มทีม')}
        </Button>
      }
    >
      <div className="space-y-2">
        <label className="block text-[13px] font-medium">{TT('ทีม')}</label>
        <Select value={team} onValueChange={setTeam} disabled={busy}>
          <SelectTrigger aria-label={TT('ทีม')}>
            <SelectValue placeholder="—" />
          </SelectTrigger>
          <SelectContent>
            {free.map((t) => (
              <SelectItem key={t} value={t}>
                {t}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-[11.5px] text-muted-foreground">
          {TT('แสดงเฉพาะทีมที่ยังไม่มีแถวของปีงบ')} {fy}
        </p>
        {err && <p className="text-[12px] font-semibold text-destructive">{err}</p>}
      </div>
    </Modal>
  );
}
