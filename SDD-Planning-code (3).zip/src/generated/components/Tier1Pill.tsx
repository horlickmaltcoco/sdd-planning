// Session 1-04 (shared) · Tier1Pill + BandCell + KVRow. ONE copy for the whole app: the MP cell
// card, PersonDrill and TeamDrill all render tier-1 states through here. Read-only display.
import type { ReactNode } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { BAND_COLORS, band, fmt, pct, uSuf } from '@generated/engine';
import type { Tier1State } from '@generated/engine/part-c';
import { TT } from '@generated/i18n';

export type PillTone = 'nd' | 'un' | 'ov' | 'ok';

export const PILL_TONES: Record<PillTone, string> = {
  nd: 'bg-[#F2F4F7] text-[#667085]',
  un: 'bg-[#E0F2FE] text-[#0369A1]',
  ov: 'bg-[var(--rdl)] text-[color:var(--rd)]',
  ok: 'bg-[var(--gnl)] text-[color:var(--gn)]',
};

/** Pill tone for a tier-2/3 status class from pillOf ("pill ov" / "pill un" / "pill ok"). */
export function toneOfPillCls(cls: string): PillTone {
  if (cls.includes('ov')) return 'ov';
  if (cls.includes('un')) return 'un';
  return 'ok';
}

export function PillSpan({ tone, children }: { tone: PillTone; children: ReactNode }) {
  return (
    <span
      className={`inline-block whitespace-normal break-words rounded-[4px] px-[7px] py-[2px] text-left text-[10.5px] font-medium leading-[1.4] ${PILL_TONES[tone]}`}
    >
      {children}
    </span>
  );
}

/** Amount + unit suffix, without a dangling space for % (uSuf("%") is empty). */
function amt(h: number, cap: number, u: string): string {
  const suf = uSuf(u);
  return suf ? `${fmt(h, cap, u)} ${TT(suf)}` : fmt(h, cap, u);
}

export function tier1PillOf(s: Tier1State, cap: number, u: string): { tone: PillTone; txt: string; tip?: string } {
  switch (s.k) {
    case 'out':
      return { tone: 'nd', txt: TT('นอกช่วงการจ้างงาน') };
    case 'other':
      return { tone: 'nd', txt: `${TT('สังกัดทีมอื่น ·')} ${s.t}` };
    case 'exempt':
      return { tone: 'nd', txt: TT('ไม่ต้องวางแผน') };
    case 'nodata':
      return { tone: 'nd', txt: TT('ไม่มีข้อมูล') };
    case 'under':
      return s.blank
        ? { tone: s.bad ? 'un' : 'nd', txt: `${TT('ไม่ได้กรอก')} · ${TT('ขาด')} ${amt(s.gap, cap, u)}` }
        : { tone: s.bad ? 'un' : 'nd', txt: `${TT('ขาด')} ${amt(s.gap, cap, u)}` };
    case 'over':
      return s.bad
        ? { tone: 'ov', txt: `${TT('เกิน')} ${amt(s.gap, cap, u)}` }
        : {
            tone: 'ok',
            txt: `${TT('เกิน')} ${amt(s.gap, cap, u)} · ${TT('อนุญาต')}`,
            tip: TT('กติกาบนบอร์ดตั้งว่าแผนรายคนเกิน capacity ได้'),
          };
    default:
      return { tone: 'ok', txt: TT('พอดี') };
  }
}

export function Tier1Pill({ s, cap, u }: { s: Tier1State; cap: number; u: string }) {
  const p = tier1PillOf(s, cap, u);
  if (!p.tip) return <PillSpan tone={p.tone}>{p.txt}</PillSpan>;
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            aria-label={`${p.txt} — ${p.tip}`}
            className="inline-block cursor-help rounded-[4px] border-0 bg-transparent p-0 outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--gn)]"
          >
            <PillSpan tone={p.tone}>{p.txt}</PillSpan>
          </button>
        </TooltipTrigger>
        <TooltipContent>{p.tip}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

/** Band cell: % of capacity (always %), coloured by the same pctF value as band(). */
export function BandCell({ v, cap, bands }: { v: number; cap: number; bands?: number[] }) {
  const c = BAND_COLORS[band(v, cap, bands)] ?? BAND_COLORS.b0!;
  return (
    <span
      className="inline-block min-w-[52px] rounded-[4px] px-[6px] py-[2px] text-right font-mono text-[11px] font-semibold"
      style={{ background: c.bg, color: c.text }}
    >
      {pct(v, cap)}%
    </span>
  );
}

/** One key-value line of a drill box. `hi` = highlighted (pale pink) row. */
export function KVRow({ label, value, hi, tone }: { label: string; value: ReactNode; hi?: boolean; tone?: 'or' }) {
  return (
    <div
      className={`flex items-start justify-between gap-[16px] py-[4px] text-[13px] ${
        hi ? 'my-[2px] rounded-[4px] bg-[var(--ylb)] px-[6px] font-semibold' : ''
      }`}
    >
      <span className={`shrink-0 font-medium ${tone === 'or' ? 'text-[color:var(--or)]' : 'text-[color:var(--t2)]'}`}>{label}</span>
      <span className={`min-w-0 text-right leading-[1.45] ${tone === 'or' ? 'text-[color:var(--or)]' : ''}`}>{value}</span>
    </div>
  );
}
