// Session 1-06 Part A · 3.4 banners A / B / C. Each one disappears on its own as soon as
// its condition becomes false — there is no close button.
import type { ReactNode } from 'react';
import { MONTHS, OT_LABEL_OFF, OT_LABEL_ON } from '@generated/config';
import { TT } from '@generated/i18n';
import type { AssignClash } from '@generated/engine/part-b';

function Box({ cls, children }: { cls: string; children: ReactNode }) {
  return (
    <div className={`${cls} mb-[13px] rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[14px]`}>
      <div className="rounded-[6px] bg-[var(--cd2)] p-[10px]">{children}</div>
    </div>
  );
}

function Row({ label, value, hi }: { label: string; value: ReactNode; hi?: boolean }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-[12px] gap-y-[2px] border-b border-[color:var(--bd2)] py-[5px] last:border-b-0">
      <span className={`text-[12px] ${hi ? 'font-bold' : ''} text-[color:var(--t2)]`}>{label}</span>
      <span
        className={`min-w-0 text-[12px] ${hi ? 'font-bold' : ''}`}
        style={{ color: hi ? 'var(--rd)' : 'var(--tx)', whiteSpace: 'normal' }}
      >
        {value}
      </span>
    </div>
  );
}

interface OTBannersProps {
  noRow: string[];
  labelBad: { t: string; pl: string }[];
  clash: AssignClash[];
}

export function OTBanners(props: OTBannersProps) {
  return (
    <>
      {props.noRow.length > 0 && (
        <Box cls="otnorow">
          <Row
            hi
            label={TT('ทีมที่ยังไม่มีแถว OT ของปีงบนี้')}
            value={`${props.noRow.length} ${TT('ทีม')} · ${props.noRow.join(' · ')}`}
          />
          <Row
            label={TT('ต้องทำอะไร')}
            value={TT(
              'แจ้งผู้ดูแลให้สร้างแถวของทีมนี้บนบอร์ด OT Plan · ระหว่างนี้ระบบนับว่า OT ยังไม่กรอกทั้ง 12 เดือน',
            )}
          />
        </Box>
      )}

      {props.labelBad.length > 0 && (
        <Box cls="otlabel">
          <Row
            hi
            label={TT('พบค่าในคอลัมน์ Plan OT ที่ระบบไม่รู้จัก')}
            value={`${props.labelBad.length} ${TT('ทีม — ระบบถือว่าเปิดไว้ก่อน ต้องแก้บนบอร์ดเป็น')} "${OT_LABEL_ON}" ${TT('หรือ')} "${OT_LABEL_OFF}"`}
          />
          {props.labelBad.map((b) => (
            <Row key={b.t} label={b.t} value={b.pl ? `"${b.pl}"` : TT('ว่าง')} />
          ))}
        </Box>
      )}

      {props.clash.length > 0 && (
        <Box cls="otclash">
          <Row
            hi
            label={TT('พบคนถูกนับ 2 ทีมในเดือนเดียวกัน')}
            value={`${props.clash.length} ${TT('รายการ — ตัวหารจะนับเกิน ต้องแก้ช่วงเดือนในทะเบียนสังกัด')}`}
          />
          {props.clash.slice(0, 6).map((c) => (
            <Row
              key={`${c.emp}|${c.mi}`}
              label={`${c.name} · ${MONTHS[c.mi]}`}
              value={c.teams.join('  +  ')}
            />
          ))}
        </Box>
      )}
    </>
  );
}
