// A3–A7 · MP Plan page "แผนกำลังคน" row view (Session 1-03 Part A & B)
import React, { useCallback, useMemo, useState, useEffect, useRef } from 'react';
import { Button } from '@components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { ALLMI, MONTHS, BOARD_ID, MP_MONTH_COL, SRC_APP, SRC_IMPORT } from '@generated/config';
import { LANG, TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { MpDerived, Settings } from '@generated/model/types';
import type { MaskedRow } from '@generated/engine/part-b';
import type { Plan } from '@generated/engine/part-c';
import { Filters, UnitSeg, BoardTag, ImportBtn, Modal, SEG_LABEL } from '@generated/components/MPShared';
import { MPRowView } from '@generated/components/MPRowView';
import { MPRowDrill } from '@generated/components/MPRowDrill';
import { AddRowModal } from '@generated/components/AddRowModal';
import { SplitRowsModal } from '@generated/components/SplitRowsModal';
import { PersonView } from '@generated/components/PersonView';
import { ImportModal, type ImportApplyCtx } from '@generated/components/ImportModal';
import { buildPlanMP } from '@generated/lib/import-plan';
import { executePlan, findFyGroupId } from '@generated/lib/import-run';
import { writeItem, readItem } from '@generated/server/write';
import { doExportMP as doExportMPFn } from '@generated/lib/file-export';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { SYSTEM_RULE_MSG, systemMissing } from '@generated/lib/mp-fields';
import { MP_C } from '@generated/lib/cols';
import { dropVal } from '@generated/lib/write-values';

interface MPGridProps {
  S: Settings;
  P: Plan;
  mp: MpDerived[];
  model: Model;
  setMp: (fn: (prev: MpDerived[]) => MpDerived[]) => void;
  T: (msg: string) => void;
  setS: (fn: (prev: Settings) => Settings) => void;
  saveBands: (fy: string | number, bands: number[], redAt: number | string | null) => void;
  clearBands: (fy: string | number) => void;
  /** Re-reads board 04 into page state (C1 steps 4 and 5). */
  reloadMp: () => Promise<void>;
}

export default function MPGrid({ S, P, mp, model, setMp, T, setS, saveBands, clearBands, reloadMp }: MPGridProps) {
  // A3. Page state
  const [u, setU] = useState<'Hrs' | 'MD' | '%'>('Hrs');
  const [view, setView] = useState<string>('row');
  const [fT, setFT] = useState('ALL');
  const [fR, setFR] = useState('ALL');
  const [fN, setFN] = useState('ALL');
  const [fM, setFM] = useState('ALL');
  const [q, setQ] = useState('');
  const [back, setBack] = useState(false);
  const [drill, setDrill] = useState<
    | { k: 'row'; r: MaskedRow }
    | { k: 'cell'; name: string; key: string; mi: number }
    | null
  >(null);
  const [addRow, setAddRow] = useState(false);
  const [split, setSplit] = useState(false);
    const [imp, setImp] = useState(false);

  // Compute fTeam on mount and when S.fy changes
  // Default team is "ทุกทีม" ('ALL'), per customer acceptance feedback.
  const [fTeam, setFTeam] = useState(() => {
    return 'ALL';
  });

  // Reset fTeam and clear filters when S.fy changes
  useEffect(() => {
    setFTeam('ALL');
    clear();
  }, [S.fy]);

  const clear = () => {
    setFT('ALL');
    setFR('ALL');
    setFN('ALL');
    setFM('ALL');
    setQ('');
  };

  // A4. Derived values
  const MI = E.miOf(fM);
  const allTeam = fTeam === 'ALL';
  const inTeam: MaskedRow[] = useMemo(
    () =>
      allTeam
        ? mp.filter((r) => String(r.fy) === String(S.fy))
        : EB.rowsOfTeam(mp, fTeam, S.fy, model.ASSIGN, model.EMPWIN, model.FYCODE),
    [allTeam, mp, fTeam, S.fy, model.ASSIGN, model.EMPWIN, model.FYCODE],
  );

  const pastN = E.pastCount(S.fy, ALLMI, model.FYCODE);

  const lockOf = (r: MaskedRow, mi: number) => {
    if (!allTeam && r.own && !(r.own as boolean[])[mi]) {
      const t = EB.teamOfMonth(r.empid, S.fy, mi, model.ASSIGN, model.FYCODE);
      if (t == null) return { k: 'team' as const, t: '—', why: TT('เดือนนี้อยู่นอกช่วงการจ้างงาน · ไม่นับเข้าทีมใด') };
      return { k: 'team' as const, t, why: `${TT('เดือนนี้อยู่ทีม')} ${t}` };
    }
    if (!back && E.isPastMonth(S.fy, mi, model.FYCODE)) {
      return { k: 'time' as const, why: TT('เดือนที่ผ่านมาแล้ว · ต้องเปิดโหมดย้อนหลังก่อนจึงจะแก้ไขได้') };
    }
    return null;
  };

  const fileScope = useMemo(
    () => mp.filter((r) => r.team === fTeam && String(r.fy) === String(S.fy)),
    [mp, fTeam, S.fy],
  );

  const straddle = useMemo(
    () =>
      (allTeam ? mp.filter((r) => String(r.fy) === String(S.fy)) : fileScope).filter(
        (r) => EB.teamsOfRow(r, S.fy, model.ASSIGN, model.FYCODE).length > 1,
      ),
    [allTeam, mp, fileScope, S.fy, model.ASSIGN, model.FYCODE],
  );

  // C3 · applyImportMP — board 04, delete-replace within team × FY.
  const applyImportMP = useCallback(
    async (ctx: ImportApplyCtx) => {
      const boardId = BOARD_ID['MP Plan'];
      const groupId = await findFyGroupId(boardId, S.fy);

      const plan = buildPlanMP({
        fileRows: ctx.fileRows,
        d: ctx.diff,
        scopeRows: ctx.scopeRows as MpDerived[],
        team: fTeam,
        fy: S.fy,
        groupId,
        assign: model.ASSIGN,
        empWin: model.EMPWIN,
        fyCode: model.FYCODE,
        peopleByName: model.PEOPLE_BY_NAME,
        typeKind: (t: string) => (t === '01.Project' ? 'PJ' : 'MP'),
        typeIsLeave: (t: string) => t === '11.Leave',
        labels: { role: model.ROLES, system: model.SYSTEMS_ALL, task2: model.TASK2S_ALL },
      });

      // Nothing to write (test 1: an unchanged re-import must not touch Source).
      if (plan.ops.length === 0) {
        ctx.onProgress(0, 0);
        T(
          `${TT('นำเข้าสำเร็จ · แก้')} 0 ${TT('ช่อง')} · ${TT('เพิ่ม')} 0 ${TT('แถว')} · ${TT('ลบ')} 0 ${TT('แถว')}`,
        );
        return;
      }

      let res;
      try {
        res = await executePlan(boardId, plan, ctx.onProgress);
      } catch (e) {
        await reloadMp(); // C1 step 5 — reload the whole scope from the board
        throw e;
      }

      // C1 step 4 — local state: replace updated rows, append created, drop deleted.
      const updated = new Map<string, Record<string, unknown>>();
      const textOf = new Map<string, Record<string, string>>();
      const removed = new Set<string>();
      for (const o of plan.ops) {
        if (o.kind === 'update') {
          updated.set(String(o.itemId), (o.columnValues ?? {}) as Record<string, unknown>);
          if (o.textPatch) textOf.set(String(o.itemId), o.textPatch);
        } else if (o.kind === 'delete') {
          removed.add(String(o.itemId));
        }
      }

      setMp((prev) => {
        const next = prev
          .filter((r) => !removed.has(String(r.id)))
          .map((r) => {
            const cv = updated.get(String(r.id));
            if (!cv) return r;
            const m = [...r.m];
            MP_MONTH_COL.forEach((col, i) => {
              const raw = cv[col];
              if (raw !== undefined) m[i] = Number(raw) || 0;
            });
            // Session 1-18 · text fields written by the import (Type also re-derives kind / leave).
            const tp = textOf.get(String(r.id)) ?? {};
            const type = tp.type ?? r.type;
            const typeStr = String(type || '').replace(' ', '');
            return {
              ...r,
              t1: tp.t1 ?? r.t1,
              role: tp.role ?? r.role,
              detail: tp.detail ?? r.detail,
              system: tp.system ?? r.system,
              task2: tp.task2 ?? r.task2,
              type,
              kind: tp.type ? (typeStr === '01.Project' ? 'PJ' : 'MP') : r.kind,
              isLeave: tp.type ? typeStr === '11.Leave' : r.isLeave,
              m,
              src: SRC_IMPORT,
              editedAt: E.NOW(),
            };
          });
        return [...next, ...(res.createdRows as MpDerived[])];
      });

      const skipped = ctx.skipOther.length;
      T(
        `${TT('นำเข้าสำเร็จ · แก้')} ${plan.writtenCells} ${TT('ช่อง')} · ${TT('เพิ่ม')} ${plan.creates} ${TT('แถว')} · ${TT('ลบ')} ${plan.deletes} ${TT('แถว')}` +
          (skipped ? ` · ${TT('ข้ามช่องของทีมอื่น')} ${skipped} ${TT('ช่อง')}` : ''),
      );

      void reloadMp(); // background re-read
    },
    [S.fy, fTeam, model.ASSIGN, model.EMPWIN, model.FYCODE, model.PEOPLE_BY_NAME, setMp, T, reloadMp],
  );

  // Option lists
  const types = useMemo(() => {
    const set = new Set<string>();
    for (const r of inTeam) if (r.type) set.add(r.type);
    return Array.from(set).sort();
  }, [inTeam]);

  const roles = useMemo(() => {
    const set = new Set<string>();
    for (const r of inTeam) if (r.role) set.add(r.role);
    return Array.from(set).sort();
  }, [inTeam]);

  const personOpts = useMemo(() => {
    const map = new Map<string, string>();
    for (const r of inTeam) {
      const key = EB.personKeyOfRow(r, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME);
      if (map.has(key)) continue;
      const pr = EB.personOfRow(r, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME);
      const name = pr ? pr.mpname || pr.name : r.name;
      map.set(key, name);
    }
    return Array.from(map.entries())
      .map(([v, t]) => ({ v, t }))
      .sort((a, b) => a.t.localeCompare(b.t));
  }, [inTeam, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME]);

  // Filtered rows
  const rows = useMemo(() => {
    let filtered = inTeam;
    if (fT !== 'ALL') filtered = filtered.filter((r) => r.type === fT);
    if (fR !== 'ALL') filtered = filtered.filter((r) => r.role === fR);
    if (fN !== 'ALL')
      filtered = filtered.filter((r) => EB.personKeyOfRow(r, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME) === fN);
    if (q) filtered = filtered.filter((r) => E.hit(q, [r.t1, r.detail, r.name, r.type, r.role]));
    if (fM !== 'ALL') filtered = filtered.filter((r) => r.m[Number.parseInt(fM, 10)] > 0);
    return filtered;
  }, [inTeam, fT, fR, fN, fM, q, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME]);

  const colT = (mi: number) => rows.reduce((s, r) => s + (r.m[mi] ?? 0), 0);
  const grand = rows.reduce((s, r) => s + MI.reduce((ms, i) => ms + (r.m[i] ?? 0), 0), 0);

  const anyFilter = fT !== 'ALL' || fR !== 'ALL' || fN !== 'ALL' || !!q;
  const scopeTeams = allTeam ? model.SECTIONS.map((s) => s.c) : [fTeam];
  const headSel = allTeam
    ? scopeTeams.reduce((s, t) => s + E.headMaxOf(t, S.fy, model.ASSIGN, model.FYCODE), 0)
    : P.head[fTeam] || 1;
  const headsMSel = allTeam
    ? ALLMI.map((mi) => scopeTeams.reduce((s, t) => s + E.headOf(t, S.fy, mi, model.ASSIGN, model.FYCODE), 0))
    : P.headsM[fTeam] || E.z12();
  const capY = model.capSumOf(S.fy, MI) * (headSel || 1);

  // A1. Person view derived values (Session 1-04)
  const fullOf = useMemo(() => {
    const map = new Map<string, any>();
    const sums = E.personSums(inTeam, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME);
    for (const ps of sums) {
      map.set(ps.key, ps);
    }
    return map;
  }, [inTeam, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME]);

  const people = useMemo(() => {
    const sums = E.personSums(rows, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME);
    return sums.map((x) => {
      const a = MI.reduce((s, i) => s + (x.m[i] || 0), 0);
      const full = fullOf.get(x.key);
      const b = full ? MI.reduce((s, i) => s + (full.m[i] || 0), 0) : a;
      return { ...x, partial: Math.abs(a - b) > 0.001 };
    });
  }, [rows, fullOf, MI, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME]);

  const partialN = useMemo(() => people.filter((p) => p.partial).length, [people]);

  const noPlan = useMemo(() => {
    if (anyFilter) return [];
    const result: Array<{ emp: string; name: string }> = [];
    const seen = new Set<string>();
    const plannedSet = new Set(people.map((x) => x.emp).filter(Boolean));
    for (const t of scopeTeams) {
      const missing = EB.noPlanPeople(t, S.fy, MI, plannedSet, model.ASSIGN, model.PEOPLE_BY_EMP, model.PEOPLE, model.FYCODE);
      for (const m of missing) {
        if (!seen.has(m.emp)) {
          seen.add(m.emp);
          result.push(m);
        }
      }
    }
    return result;
  }, [anyFilter, scopeTeams, S.fy, MI, people, model.ASSIGN, model.PEOPLE_BY_EMP, model.PEOPLE, model.FYCODE]);

  type PersonEntry = (typeof people)[number] & { noplan?: boolean };
  const peopleWithNoPlan = useMemo((): PersonEntry[] => {
    if (noPlan.length === 0) return people;
    const extended: PersonEntry[] = [...people];
    for (const np of noPlan) {
      const pos = model.PEOPLE_BY_EMP[np.emp]?.pos || '';
      extended.push({
        n: np.name,
        key: np.emp,
        role: pos,
        roles: pos ? [pos] : [],
        emp: np.emp,
        own: null,
        partial: false,
        noplan: true,
        m: E.z12(),
        mo: E.z12(),
        lv: E.z12(),
      });
    }
    return extended.sort((a, b) => a.n.localeCompare(b.n));
  }, [people, noPlan, model.PEOPLE_BY_EMP]);

  const team = useMemo(
    () => ({ team: fTeam, people: peopleWithNoPlan }),
    [fTeam, peopleWithNoPlan],
  );

  const unitHint = useMemo(() => {
    if (u === '%') return TT('เทียบ capacity');
    if (u === 'MD') return TT('กรอกได้');
    return undefined;
  }, [u]);

  // Team options for dropdown
  const allTeams = model.SECTIONS.map((s) => s.c);
  const teamOpts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const r of mp) {
      if (String(r.fy) === String(S.fy)) {
        const c = counts.get(r.team) || 0;
        counts.set(r.team, c + 1);
      }
    }

    // Helper: build label with optional timeline when headcount varies
    const buildLabel = (teams: string[], baseSuffix: string): React.ReactNode => {
      const headNow = E.headNowOf(teams, S.fy, model.ASSIGN, model.FYCODE);
      const tip = E.headMonthsTip(teams, S.fy, model.ASSIGN, model.FYCODE);
      
      // Check if headcount varies: count runs in the tip
      // If tip is a single run (no " · " separator), headcount doesn't change
      const varies = tip.includes(' · ');
      
      const base = `${baseSuffix} · ${headNow} ${TT('คน')}`;
      if (!varies) return base;
      
      return (
        <>
          {base}{' '}
          <span className="text-[11.5px] font-normal text-muted-foreground opacity-70">
            ({tip})
          </span>
        </>
      );
    };

    const withRows = model.SECTIONS.filter((s) => counts.get(s.c)! > 0);
    const noRows = model.SECTIONS.filter((s) => !counts.get(s.c));

    const opts = [
      {
        v: 'ALL',
        t: buildLabel(allTeams, TT('ทุกทีม')),
      },
      ...withRows.map((s) => ({
        v: s.c,
        t: buildLabel([s.c], s.c),
      })),
      ...noRows.map((s) => ({
        v: s.c,
        t: (
          <>
            {buildLabel([s.c], s.c)} · {TT('ไม่มีแผน')}
          </>
        ),
      })),
    ];
    return opts;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mp, S.fy, model.SECTIONS, allTeams, model.ASSIGN, model.FYCODE, LANG]);

  // 01.Project rows in the current FY × team scope that still have no System (banner).
  const sysMissingN = useMemo(() => inTeam.filter((r) => systemMissing(r)).length, [inTeam]);

  // Row card · System. Same write path as a month cell: optimistic, Source = Vibe App, rollback on error.
  const setSystem = async (rid: string, label: string) => {
    const tgt = mp.find((x) => x.id === rid);
    if (!tgt) return;
    if (systemMissing({ type: tgt.type, system: label })) {
      T(TT(SYSTEM_RULE_MSG));
      return;
    }
    const prev = { system: tgt.system, src: tgt.src, editedAt: tgt.editedAt };
    setMp((rows) => rows.map((x) => (x.id === rid ? { ...x, system: label, src: SRC_APP, editedAt: E.NOW() } : x)));
    try {
      await writeItem({
        data: {
          boardId: BOARD_ID['MP Plan'],
          itemId: rid,
          colValues: { [MP_C.system]: dropVal(label), [MP_C.src]: { label: SRC_APP } },
        },
      });
    } catch (err) {
      console.error('System write failed', err);
      setMp((rows) => rows.map((x) => (x.id === rid ? { ...x, ...prev } : x)));
      T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
    }
  };

  // Row card · Task2 (optional). Same write path as System: optimistic, Source = Vibe App, rollback on error.
  const setTask2 = async (rid: string, label: string) => {
    const tgt = mp.find((x) => x.id === rid);
    if (!tgt) return;
    const prev = { task2: tgt.task2, src: tgt.src, editedAt: tgt.editedAt };
    setMp((rows) => rows.map((x) => (x.id === rid ? { ...x, task2: label, src: SRC_APP, editedAt: E.NOW() } : x)));
    try {
      await writeItem({
        data: {
          boardId: BOARD_ID['MP Plan'],
          itemId: rid,
          colValues: { [MP_C.task2]: dropVal(label), [MP_C.src]: { label: SRC_APP } },
        },
      });
    } catch (err) {
      console.error('Task2 write failed', err);
      setMp((rows) => rows.map((x) => (x.id === rid ? { ...x, ...prev } : x)));
      T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
    }
  };

  // Handlers
  const doExportMP = () => {
    doExportMPFn(fTeam, S.fy, mp, T);
  };

  // B3 · setCell write with debounce
  const debounceTimers = useRef<Map<string, NodeJS.Timeout>>(new Map());
  // C3 · cells whose write is in flight ("rowId:mi") — the cell shows "กำลังบันทึก".
  const [pending, setPending] = useState<Set<string>>(() => new Set());
  const markPending = (key: string, on: boolean) =>
    setPending((prev) => {
      if (prev.has(key) === on) return prev;
      const next = new Set(prev);
      if (on) next.add(key);
      else next.delete(key);
      return next;
    });

  const setCell = (rid: string, mi: number, v: number) => {
    // Find target and check lock
    const tgt = inTeam.find((x) => x.id === rid);
    if (!tgt || lockOf(tgt, mi)) return;

    // Optimistic update
    const rawIdx = mp.findIndex((x) => x.id === rid);
    if (rawIdx >= 0) {
      setMp((prev) => {
        const updated = [...prev];
        updated[rawIdx] = {
          ...updated[rawIdx],
          m: updated[rawIdx].m.map((val, i) => (i === mi ? v : val)),
          src: SRC_APP,
          editedAt: E.NOW(),
        };
        return updated;
      });
    }

    // Debounced write
    const key = `${rid}:${mi}`;
    const existing = debounceTimers.current.get(key);
    if (existing) clearTimeout(existing);
    markPending(key, true);

    const timer = setTimeout(async () => {
      debounceTimers.current.delete(key);
      try {
        await writeItem({
          data: {
            boardId: BOARD_ID['MP Plan'],
            itemId: rid,
            colValues: {
              [MP_MONTH_COL[mi]]: v === null || v === undefined || !Number.isFinite(v) ? '' : String(v),
              color_mm728ges: { label: SRC_APP },
            },
          },
        });
      } catch (err) {
        // Re-read item on error
        try {
          const item = await readItem({
            data: {
              itemId: rid,
              colIds: [...MP_MONTH_COL, 'color_mm728ges', 'pulse_updated_mm79ntna'],
            },
          });
          // Put the board's latest month values (and Source) back into the row.
          const cvs = item?.column_values ?? [];
          const byId = new Map(cvs.map((c) => [String(c?.id ?? ''), c]));
          setMp((prev) =>
            prev.map((x) => {
              if (String(x.id) !== String(rid)) return x;
              const m = MP_MONTH_COL.map((col, i) => {
                const c = byId.get(col);
                if (!c) return x.m[i] ?? 0;
                const n = Number.parseFloat(String(c.text ?? '').replace(/,/g, ''));
                return Number.isFinite(n) ? n : 0;
              });
              const srcTxt = byId.get('color_mm728ges')?.text;
              return { ...x, m, src: srcTxt != null && srcTxt !== '' ? srcTxt : x.src };
            }),
          );
          T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
        } catch {
          T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
        }
      } finally {
        markPending(key, false);
      }
    }, 600);

    debounceTimers.current.set(key, timer);
  };

  return (
    <div className="mx-auto w-full max-w-[1600px]">
      {/* Header */}
      <div className="mb-[16px] flex items-start justify-between">
        <div>
          <h1 className="flex items-center gap-[8px] text-[22px] font-bold leading-[1.3]">
            {TT('แผนกำลังคน')} · {fTeam} {TT('ปีงบ')} {S.fy}
            <BoardTag board="MP Plan" />
          </h1>
          <p className="mt-[4px] text-[13px] text-[color:var(--t2)]">
            <b>{TT('บันทึกทันทีเมื่อแก้')}</b>
            {u === '%' && TT(' · โหมด % แก้ค่าไม่ได้ (สลับเป็น Hrs หรือ MD เพื่อแก้)')}
            {u === 'MD' && TT(' · กรอกเป็น MD ระบบแปลงเป็นชั่วโมงให้')}
          </p>
        </div>
        <div className="flex gap-[8px]">
          <TooltipProvider>
            {pastN > 0 && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={back ? 'default' : 'secondary'}
                    size="sm"
                    onClick={() => setBack(!back)}
                  >
                    {back
                      ? `🔓 ${TT('โหมดย้อนหลัง เปิดอยู่')} (${pastN})`
                      : `🔒 ${TT('เดือนที่ผ่านมา ล็อกอยู่')} (${pastN})`}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {TT('ปีงบนี้มีเดือนที่ผ่านมาแล้ว')} {pastN} {TT('เดือน · ล็อกไว้เพื่อป้องกันการแก้ไขย้อนหลังโดยไม่ตั้งใจ')}
                </TooltipContent>
              </Tooltip>
            )}
            {allTeam ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <span>
                    <Button variant="secondary" size="sm" disabled>
                      {TT('+ เพิ่มแถว')}
                    </Button>
                  </span>
                </TooltipTrigger>
                <TooltipContent>{TT('เลือกทีมก่อน · แถวใหม่ต้องรู้ว่าเป็นของทีมไหน')}</TooltipContent>
              </Tooltip>
            ) : (
              <Button variant="secondary" size="sm" onClick={() => setAddRow(true)}>
                {TT('+ เพิ่มแถว')}
              </Button>
            )}
            {allTeam ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <span>
                    <Button variant="secondary" size="sm" disabled>
                      {TT('⇪ นำเข้าไฟล์')}
                    </Button>
                  </span>
                </TooltipTrigger>
                <TooltipContent>{TT('เลือกทีมก่อน · ไฟล์นำเข้าเป็นรายทีม')}</TooltipContent>
              </Tooltip>
            ) : (
              <Button variant="secondary" size="sm" onClick={() => setImp(true)}>
                {TT('⇪ นำเข้าไฟล์')}
              </Button>
            )}
            {allTeam ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <span>
                    <Button variant="secondary" size="sm" disabled>
                      ⤓ Export
                    </Button>
                  </span>
                </TooltipTrigger>
                <TooltipContent>{TT('เลือกทีมก่อน · ไฟล์ส่งออกเป็นรายทีม')}</TooltipContent>
              </Tooltip>
            ) : (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="secondary" size="sm" onClick={doExportMP}>
                    ⤓ Export
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  {TT('ได้ไฟล์ที่ติด Item ID มาให้ทุกแถว · ใช้ไฟล์นี้ไปแก้แล้วอัปโหลดกลับ')}
                </TooltipContent>
              </Tooltip>
            )}
          </TooltipProvider>
        </div>
      </div>

      {/* A6. Filter bar */}
      <Filters
        items={[
          {
            label: 'ทีม',
            value: fTeam,
            options: teamOpts,
            onChange: (v) => {
              setFTeam(v);
              clear();
            },
            all: fTeam,
            minWidth: '280px',
            maxMenuHeight: '700px',
          },
          {
            label: 'Type',
            value: fT,
            options: [
              { v: 'ALL', t: 'ทุก Type' },
              ...types.map((t) => ({ v: t, t: `${t} (${inTeam.filter((r) => r.type === t).length})` })),
            ],
            onChange: setFT,
            maxMenuHeight: '700px',
          },
          {
            label: 'Role',
            value: fR,
            options: [{ v: 'ALL', t: 'ทุก Role' }, ...roles.map((r) => ({ v: r, t: r }))],
            onChange: setFR,
            maxMenuHeight: '600px',
          },
          {
            label: 'พนักงาน',
            value: fN,
            options: [{ v: 'ALL', t: 'ทุกคน' }, ...personOpts],
            onChange: setFN,
            maxMenuHeight: '640px',
          },
          {
            label: 'เดือน',
            value: fM,
            options: [{ v: 'ALL', t: 'ทุกเดือน' }, ...ALLMI.map((i) => ({ v: String(i), t: MONTHS[i] }))],
            onChange: setFM,
            maxMenuHeight: '550px',
          },
        ]}
        extra={
          <>
            <UnitSeg value={u} onChange={setU} hint={unitHint} />
            <div style={{ minWidth: '160px' }}>
              <span className={SEG_LABEL}>{TT('มุมมอง')}</span>
              <div className="flex gap-[4px]" role="group" aria-label={TT('มุมมอง')}>
                <Button
                  variant={view === 'row' ? 'default' : 'secondary'}
                  size="sm"
                  onClick={() => setView('row')}
                >
                  {TT('รายแถว')}
                </Button>
                <Button
                  variant={view === 'person' ? 'default' : 'secondary'}
                  size="sm"
                  onClick={() => setView('person')}
                >
                  {TT('รายคน')}
                </Button>
              </div>
            </div>
          </>
        }
        search={{
          // Session 1-28 · wording only — the box still matches ชื่องาน, detail, ชื่อคน and Type.
          placeholder: 'ชื่องาน · detail',
          value: q,
          onChange: setQ,
        }}
        count={rows.length}
        total={inTeam.length}
        onClear={clear}
      />

      {/* 01.Project rows without a System — same banner style as the straddle banner below */}
      {sysMissingN > 0 && (
        <div
          className="mb-[13px] rounded-[8px] border p-[16px]"
          style={{ border: '1px solid #FDA29B', background: '#FFFBFA' }}
        >
          <h3 className="text-[14px] font-bold" style={{ color: '#B42318' }}>
            ⚠ {TT('มีแถวงานโครงการ (01.Project) ที่ยังไม่ระบุ System')} {sysMissingN} {TT('แถว')}
          </h3>
        </div>
      )}

      {/* A7. Straddle banner */}
      {straddle.length > 0 && (
        <div
          className="mb-[13px] rounded-[8px] border p-[16px]"
          style={{ border: '1px solid #FDA29B', background: '#FFFBFA' }}
        >
          <h3 className="mb-[8px] text-[14px] font-bold" style={{ color: '#B42318' }}>
            ⚠ {TT('แถวแผนที่คร่อมสองทีม')} {straddle.length} {TT('แถว')}
          </h3>
          <p className="mb-[9px] text-[12px]" style={{ color: '#7A271A' }}>
            {TT(
              "เจ้าของแถวย้ายทีมระหว่างปี แต่แถวแผนยังเป็นแถวเดียวครอบทั้งปี · ไฟล์ของทีมนี้จึงมีเดือนของอีกทีมติดไปด้วย และถูกพิมพ์ทับได้โดยไม่มีอะไรเตือน · ต้องแตกเป็นแถวละทีม",
            )}
          </p>
          <Button variant="default" size="sm" onClick={() => setSplit(true)}>
            {TT('ดูแถวที่ต้องแตก')} →
          </Button>
        </div>
      )}

      {/* Body: row view or person view */}
      {view === 'row' ? (
        <MPRowView
          rows={rows}
          MI={MI}
          S={S}
          P={P}
          u={u}
          capY={capY}
          headSel={headSel}
          lockOf={lockOf}
          onDrill={(r) => setDrill({ k: 'row', r })}
          capPerOf={model.capPerOf}
          peopleByEmp={model.PEOPLE_BY_EMP}
          peopleByName={model.PEOPLE_BY_NAME}
          types={model.TYPES}
        />
      ) : (
        <PersonView
          team={team}
          P={P}
          S={S}
          u={u}
          MI={MI}
          filtered={anyFilter}
          back={back}
          partialN={partialN}
          headsM={headsMSel}
          noPlan={noPlan}
          lockOf={lockOf}
          setS={setS}
          saveBands={saveBands}
          clearBands={clearBands}
          shown={rows.length}
          total={inTeam.length}
          pick={(x) => setDrill(x)}
          capPerOf={model.capPerOf}
          capSumOf={model.capSumOf}
          assign={model.ASSIGN}
          fyCode={model.FYCODE}
        />
      )}

      {/* Modals */}
      {drill && drill.k === 'row' && (
        <MPRowDrill
          r={drill.r}
          rows={inTeam}
          S={S}
          P={P}
          lock={lockOf}
          back={back}
          setBack={setBack}
          pastN={pastN}
          close={() => setDrill(null)}
          setCell={setCell}
          pending={pending}
          capPerOf={model.capPerOf}
          capSumOf={model.capSumOf}
          assign={model.ASSIGN}
          fyCode={model.FYCODE}
          peopleByEmp={model.PEOPLE_BY_EMP}
          peopleByName={model.PEOPLE_BY_NAME}
          systems={model.SYSTEMS}
          setSystem={setSystem}
          task2s={model.TASK2S}
          setTask2={setTask2}
        />
      )}

      {addRow && fTeam !== 'ALL' && (
        <AddRowModal
          S={S}
          team={fTeam}
          rows={mp}
          peopleNow={model.PEOPLE_NOW}
          assign={model.ASSIGN}
          fyCode={model.FYCODE}
          empWin={model.EMPWIN}
          roles={model.ROLES}
          systems={model.SYSTEMS}
          task2s={model.TASK2S}
          close={() => setAddRow(false)}
          add={(row) => {
            setMp((prev) => [...prev, row]);
          }}
          T={T}
        />
      )}

      {split && (
        <SplitRowsModal
          straddle={straddle}
          S={S}
          T={T}
          assign={model.ASSIGN}
          fyCode={model.FYCODE}
          close={() => setSplit(false)}
        />
      )}

      {imp && !allTeam && (
        <ImportModal
          which="mp"
          scope={fileScope}
          scopeTeam={fTeam}
          scopeFy={S.fy}
          apply={applyImportMP}
          S={S}
          T={T}
          close={() => setImp(false)}
          onExport={doExportMP}
          model={{
            TYPES: model.TYPES,
            ROLES: model.ROLES,
            SYSTEMS: model.SYSTEMS,
            TASK2S: model.TASK2S_ALL,
            GROUPS: model.GROUPS,
            COMPANIES: model.COMPANIES,
            PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
            ASSIGN: model.ASSIGN,
            EMPWIN: model.EMPWIN,
            FYCODE: model.FYCODE,
          }}
        />
      )}
    </div>
  );
}
