// Session 1-09 Part C · C4. The card behind the Type chart — one month split by Type, with a
// second level splitting one Type by team. Read-only: no writes to any board.
import { useEffect, useMemo, useState } from 'react';
import { Button } from '@components/ui/button';
import { HPD, fmt, n1, n2, nameKey, pct, typeColor, uSuf } from '@generated/engine';
import { grpLabel, personOfRow } from '@generated/engine/part-b';
import type { Plan } from '@generated/engine/part-c';
import type { ScopedMpRow } from '@generated/engine/part-d';
import { MONTHS } from '@generated/config';
import { fyMonthLabel } from '@generated/engine';
import { TT } from '@generated/i18n';
import { Modal } from '@generated/components/MPShared';
import type { Person, Settings, Span } from '@generated/model/types';

interface TypeDrillProps {
  S: Settings;
  P: Plan;
  mi: number;
  rows: ScopedMpRow[];
  u: 'Hrs' | 'MD' | '%';
  cap: number;
  focus: string | null;
  go: ((p: string) => void) | null;
  toTeam: (mi: number) => void;
  close: () => void;
  TYPES: string[];
  PEOPLE_BY_EMP: Record<string, Person>;
  PEOPLE_BY_NAME: Record<string, Person>;
  ASSIGN: Span[];
  grpOfMap: Record<string, string>;
  FYCODE?: Record<number, string[]>;
}

export function TypeDrill(props: TypeDrillProps) {
  const { S, P, mi, rows, u, cap, focus, go, toTeam, close, TYPES, PEOPLE_BY_EMP, PEOPLE_BY_NAME, ASSIGN, grpOfMap, FYCODE } =
    props;
  const [ty, setTy] = useState<string | null>(focus ?? null);
  useEffect(() => setTy(focus ?? null), [mi, focus]);

  const { by, order, tot } = useMemo(() => {
    const map: Record<string, { h: number; teams: Record<string, number>; names: Record<string, string> }> = {};
    let sum = 0;
    for (const r of rows) {
      const v = r.m[mi] ?? 0;
      if (v <= 0) continue;
      if (!map[r.type]) map[r.type] = { h: 0, teams: {}, names: {} };
      const e = map[r.type]!;
      e.h += v;
      const t = r.mteam[mi] || r.team;
      e.teams[t] = (e.teams[t] ?? 0) + v;
      const key = r.empid || `n:${nameKey(r.name)}`;
      const pr = personOfRow(r, PEOPLE_BY_EMP, PEOPLE_BY_NAME);
      e.names[key] = pr ? pr.mpname || pr.name : r.name;
      sum += v;
    }
    return { by: map, order: Object.keys(map).sort(), tot: sum };
  }, [rows, mi, PEOPLE_BY_EMP, PEOPLE_BY_NAME]);

  const cur = ty ? by[ty] : undefined;

  const gap = cap - tot;
  const gapTxt =
    gap > 0.001
      ? `${TT('ยังขาด')} ${fmt(gap, cap, u)}${uSuf(u) ? ` ${uSuf(u)}` : ''}`
      : gap < -0.001
        ? `${TT('เกิน')} ${fmt(-gap, cap, u)}${uSuf(u) ? ` ${uSuf(u)}` : ''}`
        : TT('พอดี');
  const planTxt = u === '%' ? '' : `${fmt(tot, cap, u)} ${uSuf(u)} · `;

  return (
    <Modal
      show
      onClose={close}
      size="large"
      pill={
        <span className="inline-block rounded-[4px] bg-[var(--gnl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--gn)]">
          {n1(tot)} {TT('ชม.')} · {pct(tot, cap)}% {TT('ของโควตา+OT')}
        </span>
      }
      title={`${TT('เดือน')} ${MONTHS[mi]} · ${TT('แยกตาม Type')}`}
      sub={`${fyMonthLabel(S.fy, mi)} · ${TT('วันทำงาน')} ${P.WD[mi] ?? '–'} ${TT('วัน')} · ${order.length} ${TT(
        'Type ที่มีแผนในเดือนนี้',
      )}`}
      footer={
        <>
          <Button variant="secondary" size="sm" onClick={() => toTeam(mi)}>
            {TT('ดูแยกรายทีมแทน →')}
          </Button>
          {go && (
            <Button
              size="sm"
              className="bg-[var(--yl)] text-white hover:bg-[var(--yld)]"
              onClick={() => {
                close();
                go('mp');
              }}
            >
              {TT('ไปหน้าแผนกำลังคน →')}
            </Button>
          )}
        </>
      }
    >
      <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <div className="flex items-start justify-between gap-[16px] py-[4px] text-[13px]">
          <span className="shrink-0 font-medium text-[color:var(--t2)]">{TT('โควตา+OT ของเดือนนี้')}</span>
          <span className="text-right">
            {fmt(cap, cap, u)} {uSuf(u)}
          </span>
        </div>
        <div className="flex items-start justify-between gap-[16px] border-t border-[color:var(--bd)] bg-[var(--ylb)] px-[6px] py-[4px] text-[13px]">
          <span className="shrink-0 font-medium text-[color:var(--t2)]">{TT('แผนที่กรอกมา')}</span>
          <span className="text-right leading-[1.45]">
            <b>
              {planTxt}
              {pct(tot, cap)}% {TT('ของโควตา+OT')} · {gapTxt}
            </b>
          </span>
        </div>
      </div>

      <h3 className="mb-[8px] text-[14px] font-semibold">{TT('แยกตาม Type')}</h3>
      <p className="mb-[8px] text-[11px] text-[color:var(--t3)]">
        <b>{TT('% ของแผนเดือนนี้')}</b> {TT('= สัดส่วนในแผน รวมกันได้ 100%')} · <b>{TT('% ของโควตา+OT')}</b>{' '}
        {TT('= ตัวเลขเดียวกับที่อยู่บนแท่งในกราฟ')} ({n1(cap)} {TT('ชม.')})
      </p>

      <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd)]">
        <table className="w-full min-w-[640px] border-collapse text-[12px]">
          <thead className="bg-[var(--cd2)]">
            <tr>
              {[TT('Type'), TT('ชม.'), TT('MD'), TT('% ของแผนเดือนนี้'), TT('% ของโควตา+OT'), TT('คน')].map((h) => (
                <th key={h} className="px-[8px] py-[6px] text-right font-semibold text-[color:var(--t2)] first:text-left">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {order.map((t) => {
              const e = by[t]!;
              const color = typeColor(t, TYPES);
              const names = Object.values(e.names).sort();
              const selected = ty === t;
              return (
                <tr
                  key={t}
                  onClick={() => setTy(selected ? null : t)}
                  role="button"
                  tabIndex={0}
                  aria-label={`${selected ? TT('ยกเลิกเลือก') : TT('เลือก')} ${t}`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setTy(selected ? null : t);
                    }
                  }}
                  className="cursor-pointer border-t border-[color:var(--bd)]"
                  style={selected ? { background: 'var(--ylb)' } : undefined}
                >
                  <td className="px-[8px] py-[6px] text-left">
                    <span
                      className="inline-block rounded-[4px] px-[6px] py-[2px] text-[10.5px] font-medium"
                      style={{ background: `${color}22`, color }}
                    >
                      {t}
                    </span>
                  </td>
                  <td className="px-[8px] py-[6px] text-right font-mono font-bold">{n1(e.h)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono">{n2(e.h / HPD)}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono">{pct(e.h, tot)}%</td>
                  <td className="px-[8px] py-[6px] text-right font-mono">{pct(e.h, cap)}%</td>
                  <td className="px-[8px] py-[6px] text-right">
                    <span className="cursor-help underline decoration-dotted" title={names.join(' · ')}>
                      {names.length}
                    </span>
                  </td>
                </tr>
              );
            })}
            <tr className="border-t-2 border-[color:var(--bd2)] font-bold">
              <td className="px-[8px] py-[6px] text-left">{TT('รวม')}</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{n1(tot)}</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{n2(tot / HPD)}</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{pct(tot, tot)}%</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{pct(tot, cap)}%</td>
              <td className="px-[8px] py-[6px]" />
            </tr>
          </tbody>
        </table>
      </div>

      {cur ? (
        <>
          <h3 className="mb-[8px] mt-[16px] text-[14px] font-semibold">
            {ty}{TT(' · ทีมที่วางไว้')}
          </h3>
          <p className="mb-[8px] text-[11px] text-[color:var(--t3)]">
            {TT('แยกทีมตามช่วงสังกัดของเดือนนั้น ชุดเดียวกับการ์ดแยกรายทีม · ไม่ใช่การเกลี่ยยอดให้')} ·{' '}
            {TT('% หารด้วย')} {n1(cur.h)} {TT('ชม. ของ Type นี้ทั้งเดือน')}
          </p>
          <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd)]">
            <table className="w-full min-w-[420px] border-collapse text-[12px]">
              <thead className="bg-[var(--cd2)]">
                <tr>
                  {[TT('ทีม'), TT('ชม.'), TT('% ของ Type นี้')].map((h) => (
                    <th key={h} className="px-[8px] py-[6px] text-right font-semibold text-[color:var(--t2)] first:text-left">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.keys(cur.teams)
                  .sort()
                  .map((t) => (
                    <tr key={t} className="border-t border-[color:var(--bd)]">
                      <td className="px-[8px] py-[6px] text-left">
                        <span className="font-bold">{t}</span>{' '}
                        <span className="text-[10.5px] text-[color:var(--t3)]">
                          {grpLabel(t, S.fy, ASSIGN, grpOfMap, FYCODE)}
                        </span>
                      </td>
                      <td className="px-[8px] py-[6px] text-right font-mono">{n1(cur.teams[t] ?? 0)}</td>
                      <td className="px-[8px] py-[6px] text-right font-mono">{pct(cur.teams[t] ?? 0, cur.h)}%</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <p className="mt-[12px] text-[11px] text-[color:var(--t3)]">{TT('คลิกแถว Type เพื่อดูว่าทีมไหนวางไว้เท่าไหร่')}</p>
      )}
    </Modal>
  );
}
