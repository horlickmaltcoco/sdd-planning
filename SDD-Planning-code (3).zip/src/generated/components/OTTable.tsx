// Session 1-06 Part A · 3.5 the team table. Cells are NEVER editable — a click opens the
// OT card (Part B). Closed teams show "—" everywhere and are excluded from every total.
import { MONTHS } from '@generated/config';
import { fmt } from '@generated/engine';
import { TT } from '@generated/i18n';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { EC, Sw } from '@generated/components/MPShared';
import { headTip, otTip, rowTotal, type OtCellView } from '@generated/lib/ot-derive';
import type { OtCell } from '@generated/model/types';

interface OTTableProps {
  teams: string[];
  MI: number[];
  fM: string;
  ot: Record<string, OtCell>;
  isOffOf: (t: string) => boolean;
  otAt: (t: string, i: number) => OtCellView;
  grpOfTeam: (t: string) => string;
  hcText: (t: string) => string;
  headsOf: (t: string) => number[];
  onTeams: string[];
  totM: OtCellView[];
  totPlan: number;
  totHc: string;
  onDrill: (t: string) => void;
  setNoOt: (t: string, off: boolean) => void;
  loading: boolean;
}

const TH = 'border-b border-[color:var(--bd2)] px-[8px] py-[7px] text-[11px] font-semibold text-[color:var(--t2)]';
const TD = 'border-b border-[color:var(--bd2)] px-[8px] py-[4px] text-[12px]';

export function OTTable(props: OTTableProps) {
  if (props.teams.length === 0) {
    return (
      <div className="rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)] p-[16px]">
        <p className="text-[13px] text-[color:var(--t3)]">
          {props.loading ? TT('กำลังโหลด…') : TT('ไม่มีทีมตามตัวกรองที่เลือก')}
        </p>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)]">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className={`${TH} text-left`}>{TT('ทีม')}</th>
              <th className={`${TH} text-center`}>Group</th>
              <th className={`${TH} text-center`} style={{ width: 104 }}>{TT('วางแผน OT')}</th>
              {props.MI.map((i) => (
                <th key={i} className={`${TH} text-right`}>{MONTHS[i]}</th>
              ))}
              <th className={`${TH} text-right`}>{props.fM === 'ALL' ? TT('รวมปี') : TT('รวม')}</th>
              <th className={`${TH} text-right`}>{TT('คน')}</th>
            </tr>
          </thead>
          <tbody>
            {props.teams.map((t) => {
              const off = props.isOffOf(t);
              return (
                <tr key={t} style={{ opacity: off ? 0.5 : 1 }}>
                  <td className={`${TD} text-left`}>
                    <button
                      type="button"
                      onClick={() => props.onDrill(t)}
                      className="font-medium hover:underline"
                    >
                      {t} <span className="text-[10px] text-[color:var(--t3)]">→</span>
                    </button>
                  </td>
                  <td className={`${TD} text-center text-[color:var(--t2)]`} style={{ whiteSpace: 'nowrap' }}>
                    {props.grpOfTeam(t)}
                  </td>
                  <td className={`${TD} text-center`}>
                    <div className="flex justify-center">
                      <Sw on={!off} onChange={(v) => props.setNoOt(t, !v)} label={t} />
                    </div>
                  </td>
                  {props.MI.map((i) => {
                    if (off) {
                      return (
                        <td key={i} className={`${TD} text-right text-[color:var(--bd2)]`}>—</td>
                      );
                    }
                    const c = props.otAt(t, i);
                    return (
                      <td
                        key={i}
                        aria-label={`${t} · ${MONTHS[i]}`}
                        className={`${TD} p-0 text-right`}
                        style={c.v == null ? { background: 'var(--orl)' } : undefined}
                      >
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div>
                              <EC v={c.v} cap={0} u="Hrs" ro onClick={() => props.onDrill(t)} />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>{otTip(c)}</TooltipContent>
                        </Tooltip>
                      </td>
                    );
                  })}
                  <td className={`${TD} bg-[var(--cd2)] text-right font-bold`}>
                    {off ? '—' : fmt(rowTotal(props.ot[t], props.MI), 0, 'Hrs')}
                  </td>
                  <td className={`${TD} bg-[var(--cd2)] cursor-help text-right text-[color:var(--t2)]`}>
                    {off ? (
                      '—'
                    ) : (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span>{props.hcText(t)}</span>
                        </TooltipTrigger>
                        <TooltipContent>
                          <span style={{ whiteSpace: 'pre-line' }}>{headTip(props.headsOf(t))}</span>
                        </TooltipContent>
                      </Tooltip>
                    )}
                  </td>
                </tr>
              );
            })}

            {props.onTeams.length > 1 && (
              <tr className="ottot bg-[var(--cd2)]">
                <td className={`${TD} text-left font-bold`}>{TT('รวมทุกทีมที่เปิดไว้')}</td>
                <td className={TD} aria-label="Group" />
                <td className={TD} aria-label={TT('วางแผน OT')} />
                {props.MI.map((i) => {
                  const c = props.totM[i] as OtCellView;
                  return (
                    <td
                      key={i}
                      aria-label={`${TT('รวมทุกทีมที่เปิดไว้')} · ${MONTHS[i]}`}
                      className={`${TD} text-right font-bold`}
                    >
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span>{c.v == null ? '—' : fmt(c.v, 0, 'Hrs')}</span>
                        </TooltipTrigger>
                        <TooltipContent>{otTip(c)}</TooltipContent>
                      </Tooltip>
                    </td>
                  );
                })}
                <td className={`${TD} bg-[var(--cd2)] text-right font-bold`}>
                  {fmt(props.totPlan, 0, 'Hrs')}
                </td>
                <td className={`${TD} bg-[var(--cd2)] text-right font-bold`}>{props.totHc}</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </TooltipProvider>
  );
}
