// 07 Company Plan · B4 cell card. Renders the CURRENT row passed in by the page (looked up by id
// every render). Edit → input with the full value; "บันทึก" (or Enter) writes once; "ยกเลิก" exits.
import { type ReactNode, useState } from 'react';
import { Button } from '@components/ui/button';
import { Input } from '@components/ui/input';
import { TT } from '@generated/i18n';
import { parseMdInput } from '@generated/lib/cp';
import type { CpRow } from '@generated/lib/types';
import { Modal } from '@generated/components/MPShared';

interface CPCardProps {
  row: CpRow;
  past: boolean;
  save: (id: string, text: string, value: number | null) => Promise<boolean>;
  close: () => void;
}

function Line(props: { label: string; value: ReactNode; hi?: boolean }) {
  return (
    <div
      className={`flex items-start justify-between gap-[16px] py-[6px] text-[13px] ${
        props.hi ? 'border-t border-[color:var(--bd)] bg-[var(--bll)] px-[6px]' : ''
      }`}
    >
      <span className="shrink-0 font-medium text-[color:var(--t2)]">{props.label}</span>
      <span className="break-all text-right leading-[1.45]">{props.value}</span>
    </div>
  );
}

export function CPCard({ row, past, save, close }: CPCardProps) {
  const [edit, setEdit] = useState(false);
  const [text, setText] = useState('');
  const [bad, setBad] = useState(false);
  const [busy, setBusy] = useState(false);

  const startEdit = () => {
    setText(row.md == null ? '' : String(row.md));
    setBad(false);
    setEdit(true);
  };

  const doSave = async () => {
    if (busy) return;
    const p = parseMdInput(text);
    if (!p.ok) {
      setBad(true);
      return;
    }
    setBad(false);
    setBusy(true);
    const ok = await save(row.id, p.text, p.value);
    setBusy(false);
    if (ok) setEdit(false);
  };

  const pill =
    row.md == null ? (
      <span className="inline-block rounded-[4px] bg-[var(--orl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--or)]">
        {TT('ยังไม่กรอก')}
      </span>
    ) : (
      <span className="inline-block rounded-[4px] bg-[var(--gnl)] px-[8px] py-[3px] text-[11.5px] font-medium text-[color:var(--gn)]">
        {TT('มีข้อมูล')}
      </span>
    );

  const footer = edit ? (
    <div className="flex gap-[8px]">
      <Button variant="ghost" size="sm" onClick={() => setEdit(false)} disabled={busy}>
        {TT('ยกเลิก')}
      </Button>
      <Button size="sm" onClick={() => void doSave()} disabled={busy}>
        {TT('บันทึก')}
      </Button>
    </div>
  ) : (
    <Button variant="secondary" size="sm" onClick={startEdit}>
      {TT('แก้ไข')}
    </Button>
  );

  return (
    <Modal
      show
      onClose={close}
      size="medium"
      pill={pill}
      title={`${TT('แผนงาน ISUZU Group')} · ${row.my}`}
      sub={`${row.grp} × ${row.co}`}
      footer={footer}
    >
      {past && (
        <p className="mb-[10px] rounded-[6px] border border-[color:var(--or)] bg-[var(--orl)] px-[10px] py-[7px] text-[12.5px] text-[color:var(--or)]">
          {TT('เดือนนี้ผ่านไปแล้ว · การแก้ไขจะเปลี่ยนแผนที่ใช้เทียบกั��ชั่วโมงจริงย้อนหลัง')}
        </p>
      )}
      <div className="rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <Line label="Group" value={row.grp} />
        <Line label="Company" value={row.co} />
        <Line label={TT('เดือน')} value={row.my} />
        <Line
          hi
          label="Plan MD"
          value={
            edit ? (
              <div className="w-[200px] text-left">
                <Input
                  aria-label="Plan MD"
                  inputMode="decimal"
                  autoFocus
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      void doSave();
                    }
                  }}
                  className="h-[34px] font-mono"
                />
                {bad && (
                  <p className="mt-[4px] text-[11.5px] text-[color:var(--rd)]">
                    {TT('ใส่ได้เฉพาะตัวเลขที่ไม่ติดลบ หรือเว้นว่าง')}
                  </p>
                )}
              </div>
            ) : row.md == null ? (
              <b>—</b>
            ) : (
              <b className="font-mono">{String(row.md)} MD</b>
            )
          }
        />
      </div>
    </Modal>
  );
}
