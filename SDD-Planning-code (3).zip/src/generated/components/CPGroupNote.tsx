// 07 Company Plan · Group banner. Groups on board 07 that are not in the employee spans of the FY
// (vendorGroupBad, unchanged). Shown only when the list is non-empty. Red card like the others.
import type { VendorGroupBad } from '@generated/engine/part-b';
import { TT } from '@generated/i18n';

export function CPGroupNote(props: { bad: VendorGroupBad[] }) {
  if (props.bad.length === 0) return null;
  const body = props.bad.map((b) => `${b.grp || TT('ว่าง')} · ${b.co}`).join(' | ');
  return (
    <div
      role="alert"
      className="C wipe cpgrp mb-[13px] rounded-[8px] border border-[#FDA29B] bg-[#FFFBFA] p-[14px]"
    >
      <p className="mb-[6px] text-[13px] font-bold text-[#B42318]">
        ⚠ {TT('พบ Group บนบอร์ด Company Plan ที่ไม่มีในทะเบียนพนักงาน')} {props.bad.length} {TT('รายการ')}
      </p>
      <p className="text-[12.5px] leading-[1.5] text-[#7A271A]">{body}</p>
    </div>
  );
}
