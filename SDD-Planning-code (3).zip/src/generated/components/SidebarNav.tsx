import { APP, type PageId } from '@generated/config';
import { TT } from '@generated/i18n';
import { cn } from '@lib/utils';

const SECTIONS = APP.planning.nav ?? [];

export default function SidebarNav(props: {
  page: PageId;
  go: (p: string) => void;
  dot: boolean;
}) {
  return (
    <nav className="min-h-0 flex-1 overflow-y-auto px-[9px] py-[12px]">
      {SECTIONS.map(([section, items]) => (
        <div key={section} className="mb-[10px] last:mb-0">
          <h5 className="px-[12px] pb-[5px] pt-[7px] text-[9px] font-semibold uppercase tracking-[1.2px] text-[color:var(--sb-t5)]">
            {TT(section)}
          </h5>
          {items.map(([id, icon, label]) => {
            const on = props.page === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => props.go(id)}
                aria-current={on ? 'page' : undefined}
                className={cn(
                  'relative flex w-full items-center gap-[1px] rounded-[6px] px-[12px] py-[9px] text-left text-[12.5px] font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-[color:var(--yl)]',
                  on
                    ? 'bg-[var(--nav-on)] font-semibold text-[color:var(--nav-on-tx)]'
                    : 'text-[color:var(--sb-t1)] hover:bg-[var(--sb2)] hover:text-white',
                )}
              >
                {on && (
                  <span
                    aria-hidden
                    className="absolute bottom-[8px] left-0 top-[8px] w-[3px] rounded-r-[2px] bg-[var(--yl)]"
                  />
                )}
                <span aria-hidden className="w-[17px] shrink-0 text-center text-[14px] leading-none">
                  {icon}
                </span>
                <span className="min-w-0 flex-1 truncate">{TT(label)}</span>
                {id === 'val' && props.dot && (
                  <span
                    aria-hidden
                    className="h-[7px] w-[7px] shrink-0 rounded-full bg-[var(--yl)]"
                  />
                )}
              </button>
            );
          })}
        </div>
      ))}
    </nav>
  );
}
