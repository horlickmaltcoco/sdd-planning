// Session 1-11 · Validation "val" · A5 Tier-2 table (team x month vs quota+OT). 132 rows in
// FY2026 — plain table (no virtualization needed under 300 rows). Read-only.
//
// Session 1-09 Part A fix: columns previously auto-sized to the longest value on screen, so
// switching FY / unit moved every column. All 14 columns now come from one fixed-width list
// (L2_COLS) rendered via a <colgroup> under table-layout: fixed + width: 100%, so the layout
// is identical for every FY, filter and unit, while the table still stretches to fill its
// card instead of leaving an empty strip — min-width keeps it scrollable on a narrow window.
import { fmt, pct, pillOf, statusOf, uLabel } from '@generated/engine';
import type { Tier2Row } from '@generated/engine/part-c';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import type { Settings } from '@generated/model/types';

type ColAlign = 'left' | 'right' | 'center';
interface Col {
  id: string;
  title: string;
  width: number;
  align: ColAlign;
}

const L2_COLS: Col[] = [
  { id: 'team', title: 'ทีม', width: 70, align: 'left' },
  { id: 'grp', title: 'Group', width: 75, align: 'center' },
  { id: 'month', title: 'เดือน', width: 70, align: 'left' },
  { id: 'wd', title: 'วัน', width: 55, align: 'center' },
  { id: 'head', title: 'คน', width: 55, align: 'center' },
  { id: 'quota', title: 'โควตา MP', width: 100, align: 'right' },
  { id: 'ot', title: 'OT Plan', width: 90, align: 'right' },
  { id: 'allow', title: 'โควตา+OT', width: 100, align: 'right' },
  { id: 'plan', title: 'แผนรวม', width: 100, align: 'right' },
  { id: 'leave', title: 'วันลา', width: 90, align: 'right' },
  { id: 'work', title: 'เฉพาะงาน', width: 130, align: 'right' },
  { id: 'dif', title: 'ส่วนต่าง', width: 100, align: 'right' },
  { id: 'st', title: 'สถานะ', width: 90, align: 'center' },
  { id: 'go', title: '', width: 40, align: 'right' },
];
const L2_TOTAL_W = L2_COLS.reduce((s, c) => s + c.width, 0);

function alignCls(a: ColAlign): string {
  return a === 'left' ? 'text-left' : a === 'center' ? 'text-center' : 'text-right';
}

interface ValL2TableProps {
  rows: Tier2Row[];
  S: Settings;
  u: 'Hrs' | 'MD' | '%';
  WD: (number | null)[];
  pick: (r: Tier2Row) => void;
}

export function ValL2Table({ rows, S, u, WD, pick }: ValL2TableProps) {
  return (
    <div className="overflow-hidden rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
      <h3 className="text-[15px] font-bold leading-[1.3]">{TT('แผนรวมรายทีมเทียบโควตา+OT')}</h3>
      <p className="mt-[5px] text-[12.5px] leading-[1.55] text-[color:var(--t2)]">
        {TT('โควตา+OT = (วันทำงาน × ')}
        {S.hoursPerDay}
        {TT(' × จำนวนคน) + OT Plan · ผ่อนผัน ±')}
        {S.teamTolerance ?? 0}
        {TT(' ชม. · หน่วยที่แสดง ')}
        <b>{uLabel(u, TT('โควตา+OT ของทีมในเดือนนั้น'))}</b>
        <br />
        {TT('วันลาถูกนับรวมในแผนรวม · คอลัมน์เฉพาะงาน = แผนที่ตัดวันลาออก')}
      </p>

      {rows.length === 0 ? (
        <p className="px-[22px] py-[18px] text-[13px] text-[color:var(--t3)]">{TT('ไม่มีรายการตามตัวกรองที่เลือก')}</p>
      ) : (
        <div className="mt-[10px] overflow-auto rounded-[8px] border border-[color:var(--bd)]" style={{ height: 520 }}>
          <table className="border-collapse text-[12px]" style={{ tableLayout: 'fixed', width: '100%', minWidth: L2_TOTAL_W }}>
            <colgroup>
              {L2_COLS.map((c) => (
                <col key={c.id} style={{ width: c.width }} />
              ))}
            </colgroup>
            <thead className="sticky top-0 z-10 bg-[var(--cd2)]">
              <tr>
                {L2_COLS.map((c) => (
                  <th
                    key={c.id}
                    className={`overflow-hidden whitespace-nowrap px-[8px] py-[7px] font-semibold text-[color:var(--t2)] ${alignCls(c.align)}`}
                  >
                    {TT(c.title)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const st = statusOf(r.dif, S.teamTolerance ?? 0);
                const show = (st === 'over' && S.teamOverWarn) || (st === 'under' && S.teamUnderWarn) || st === 'ok';
                const pl = pillOf(st);
                const difColor = st === 'over' ? 'var(--rd)' : st === 'under' ? '#0369A1' : 'var(--t2)';
                return (
                  <tr
                    key={`${r.team}|${r.mi}`}
                    onClick={() => pick(r)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        pick(r);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-label={`${r.team} · ${MONTHS[r.mi]} · ${TT(pl.txt)}`}
                    className="cursor-pointer border-t border-[color:var(--bd)] hover:bg-[var(--cd2)]"
                  >
                    <td className={`overflow-hidden px-[8px] py-[6px] font-bold ${alignCls(L2_COLS[0].align)}`}>{r.team}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] text-[color:var(--t2)] ${alignCls(L2_COLS[1].align)}`}>{r.grp}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L2_COLS[2].align)}`}>{MONTHS[r.mi]}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L2_COLS[3].align)}`}>{WD[r.mi] ?? '–'}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L2_COLS[4].align)}`}>{r.head}</td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono text-[color:var(--t2)] ${alignCls(L2_COLS[5].align)}`}>
                      {fmt(r.quota, r.allow, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono ${alignCls(L2_COLS[6].align)}`}>
                      {r.otMiss ? <span className="text-[color:var(--t3)]">—</span> : fmt(r.otPlan ?? 0, r.allow, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono font-semibold ${alignCls(L2_COLS[7].align)}`}>
                      {fmt(r.allow, r.allow, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono font-bold ${alignCls(L2_COLS[8].align)}`}>
                      {fmt(r.planSum, r.allow, u)}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono ${alignCls(L2_COLS[9].align)}`}>
                      {r.leave ? (
                        <span className="text-[color:var(--or)]">{fmt(r.leave, r.allow, u)}</span>
                      ) : (
                        <span className="text-[color:var(--bd2)]">–</span>
                      )}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] font-mono leading-[1.35] text-[color:var(--t2)] ${alignCls(L2_COLS[10].align)}`}>
                      {fmt(r.work, r.allow, u)}
                      {r.leave > 0 && (
                        <div className="text-[9.5px] font-normal text-[color:var(--or)]">
                          {pct(r.work, r.quota)}% {TT('ของโควตา')}
                        </div>
                      )}
                    </td>
                    <td
                      className={`overflow-hidden px-[8px] py-[6px] font-mono font-bold ${alignCls(L2_COLS[11].align)}`}
                      style={{ color: difColor }}
                    >
                      {fmt(r.dif, r.allow, u, { sign: true })}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] ${alignCls(L2_COLS[12].align)}`}>
                      {show ? (
                        <span
                          className={`inline-block rounded-[4px] px-[7px] py-[2px] text-[10.5px] font-medium ${
                            pl.cls.includes('ov')
                              ? 'bg-[var(--rdl)] text-[color:var(--rd)]'
                              : pl.cls.includes('un')
                                ? 'bg-[#E0F2FE] text-[#0369A1]'
                                : 'bg-[var(--gnl)] text-[color:var(--gn)]'
                          }`}
                        >
                          {TT(pl.txt)}
                        </span>
                      ) : (
                        <span className="inline-block rounded-[4px] bg-[var(--cd2)] px-[7px] py-[2px] text-[10.5px] font-medium text-[color:var(--t3)]">
                          {TT('ปิดเตือน')}
                        </span>
                      )}
                    </td>
                    <td className={`overflow-hidden px-[8px] py-[6px] text-[color:var(--t3)] ${alignCls(L2_COLS[13].align)}`}>{'→'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
