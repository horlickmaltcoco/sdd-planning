// Session 1-15c · the permanent way into "เตรียมข้อมูลปีงบ" (ภาพรวม, beside the fiscal-year selector),
// for every year, prepared or not. Opening it only counts; nothing is created until confirm.
import { useState } from 'react';
import { Button } from '@components/ui/button';
import { TT } from '@generated/i18n';
import { PrepareFyDialog } from '@generated/components/PrepareFyDialog';

export function PrepareFyButton(props: {
  fy: string;
  fyList: string[];
  done: () => Promise<void>;
  T: (msg: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="ghost" size="sm" className="self-end text-[12.5px] text-muted-foreground" onClick={() => setOpen(true)}>
        {TT('เตรียมข้อมูลปีงบ')}
      </Button>
      {open && (
        <PrepareFyDialog fy={props.fy} fyList={props.fyList} close={() => setOpen(false)} done={props.done} T={props.T} />
      )}
    </>
  );
}
