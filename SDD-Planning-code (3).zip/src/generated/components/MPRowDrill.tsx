// B2 · MP Plan row card (edit modal)
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Button } from '@components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@components/ui/table';
import type { MaskedRow } from '@generated/engine/part-b';
import type { Plan } from '@generated/engine/part-c';
import type { Settings } from '@generated/model/types';
import { Modal, UnitSeg, EC, FilterSelect } from '@generated/components/MPShared';
import { NONE, SYSTEM_HELP, SYSTEM_RULE_MSG, systemMissing } from '@generated/lib/mp-fields';
import { ALLMI, MONTHS, SRC_APP } from '@generated/config';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { TT } from '@generated/i18n';
import { cn } from '@lib/utils';

interface RowDrillProps {
  r: MaskedRow;
  rows: MaskedRow[];
  S: Settings;
  P: Plan;
  lock: (r: MaskedRow, mi: number) => { k: 'team' | 'time'; t?: string; why: string } | null;
  back: boolean;
  setBack: (v: boolean) => void;
  pastN: number;
  close: () => void;
  setCell: (rid: string, mi: number, v: number) => void;
  /** C3 · "rowId:mi" of cells whose write is still in flight. */
  pending?: Set<string>;
  capSumOf: (fy: string | number, MI: number[]) => number;
  capPerOf: (fy: string | number, mi: number) => number;
assign: any[];
  fyCode: Record<number, string[]> | undefined;
  peopleByEmp: Record<string, any>;
  peopleByName: Record<string, any>;
  /** ACTIVE System labels of board 04. */
  systems: string[];
  /** Writes System (the rule is applied there too). */
  setSystem: (rid: string, label: string) => void;
  /** ACTIVE Task2 labels of board 04. */
  task2s: string[];
  /** Writes Task2 (optional — clearing is allowed). */
  setTask2: (rid: string, label: string) => void;
}

export function MPRowDrill(props: RowDrillProps) {
  const { r: propsR, rows, S, P, lock, back, setBack, pastN, close, setCell, capSumOf, capPerOf, assign, fyCode, peopleByEmp, peopleByName } = props;
  
  const [u, setU] = useState<'Hrs' | 'MD'>('Hrs');
  const [edit, setEdit] = useState(false);

  // Live row (refresh after writes)
  const r = useMemo(() => {
    return rows.find((x) => x.id === props.r.id) || props.r;
  }, [rows, props.r]);

  const rowMI = useMemo(() => {
    if (!r.empid) return ALLMI;
    const owned = ALLMI.filter((i) => EB.inQuotaOf(r.team, r.empid, S.fy, i, assign, fyCode));
    return owned.length > 0 ? owned : ALLMI;
  }, [r, S.fy, assign, fyCode]);

  const capY = useMemo(() => capSumOf(S.fy, rowMI), [S.fy, rowMI, capSumOf]);
  const isPJ = r.type.replace(' ', '') === '01.Project';
  const person = EB.personOfRow(r, peopleByEmp, peopleByName);
  const disp = person ? (person.mpname || person.name) : r.name;
  const rowSum = E.sum(r.m);

  // Pill: Type tag
  const pill = (
    <span
      className={cn(
        'inline-block rounded px-2 py-1 text-[12px] font-medium',
        isPJ ? 'bg-[#F7D3D9] text-[#A30A23]' : 'border border-muted bg-background text-foreground',
      )}
    >
      {r.type}
    </span>
  );

  return (
    <Modal
      show
      onClose={close}
      title={r.t1}
      sub={`${r.team} · ${disp}`}
      pill={pill}
      footer={
        <Button
          variant={edit ? 'default' : 'secondary'}
          size="sm"
          onClick={() => setEdit(!edit)}
        >
          {edit ? TT('เสร็จ') : TT('แก้ไข')}
        </Button>
      }

      size="large"
    >
      {/* Info box */}
      <div className="mb-4 space-y-2 rounded border bg-muted/30 p-4 text-[13px]">
        <div className="flex justify-between">
          <span className="font-medium text-muted-foreground">Task1</span>
          <span>{r.t1}</span>
        </div>
        <div className="flex items-start justify-between gap-3">
          <span className="font-medium text-muted-foreground">System</span>
          {edit ? (
            <div className="max-w-[440px] flex-1">
              <FilterSelect
                item={{
                  label: 'System',
                  value: r.system || NONE,
                  onChange: (v) => props.setSystem(r.id, v === NONE ? '' : v),
                  minWidth: '100%',
                  maxMenuHeight: '360px',
                  // a deactivated label already on the row still shows as the current value
                  options: [
                    { v: NONE, t: TT('— ไม่ระบุ —') },
                    ...(r.system && !props.systems.includes(r.system) ? [{ v: r.system, t: r.system }] : []),
                    ...props.systems.map((s) => ({ v: s, t: s })),
                  ],
                }}
              />
              <div className="mt-1 text-[11px] text-muted-foreground">{TT(SYSTEM_HELP)}</div>
            </div>
          ) : (
            <span>{r.system || '—'}</span>
          )}
        </div>
        {systemMissing(r) && (
          <div className="text-right text-[12px] text-[color:var(--negative-color,var(--rd))]">{TT(SYSTEM_RULE_MSG)}</div>
        )}
        <div className="flex items-start justify-between gap-3">
          <span className="font-medium text-muted-foreground">Task2</span>
          {edit ? (
            <div className="max-w-[440px] flex-1">
              <FilterSelect
                item={{
                  label: 'Task2',
                  value: r.task2 || NONE,
                  onChange: (v) => props.setTask2(r.id, v === NONE ? '' : v),
                  minWidth: '100%',
                  maxMenuHeight: '360px',
                  options: [
                    { v: NONE, t: TT('— ไม่ระบุ —') },
                    ...(r.task2 && !props.task2s.includes(r.task2) ? [{ v: r.task2, t: r.task2 }] : []),
                    ...props.task2s.map((s) => ({ v: s, t: s })),
                  ],
                }}
              />
            </div>
          ) : (
            <span>{r.task2 || '—'}</span>
          )}
        </div>
        <div className="flex justify-between">
          <span className="font-medium text-muted-foreground">Detail</span>
          <span className="max-w-[440px] break-words font-normal">{r.detail || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium text-muted-foreground">Role</span>
          <span>{r.role || '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="font-medium text-muted-foreground">Name</span>
          <span>
            {disp}
            {disp !== r.name && ` (${TT('ชื่อในไฟล์แผน')}: ${r.name})`}
          </span>
        </div>
        <div className="flex justify-between border-t bg-primary/5 pt-2">
          <span className="font-semibold text-primary">{TT('รวมทั้งปี')}</span>
          <span className="font-semibold font-mono">
            {E.n1(rowSum)}
            {TT(' ชม. · ')}
            {E.n1(rowSum / E.HPD)} MD · {E.pct(rowSum, capY)}
            {TT('% ของ capacity 1 คน')}
            {rowMI.length < 12 && ` (${rowMI.length} ${TT('เดือนที่นับโควตา')})`}
          </span>
        </div>
      </div>

      {/* Section title + unit toggle */}
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-[15px] font-semibold">
          {edit ? TT('แก้ตัวเลขรายเดือน') : TT('ตัวเลขรายเดือน')}
        </h3>
        <UnitSeg value={u} onChange={(v) => v !== '%' && setU(v)} />
      </div>

      {/* Past-month notice */}
      {edit && !back && pastN > 0 && (
        <div className="mb-3 flex items-center gap-2 rounded bg-[#FFFBFA] border border-[#FDA29B] p-3 text-[12px] text-[#B54708]">
          <span>
            🔒 {TT('เดือนที่ผ่านไปแล้ว')} {pastN} {TT('เดือน ถูกล็อกเพื่อป้องกันการแก้ไขย้อนหลังโดยไม่ตั้งใจ')}
          </span>
          <Button variant="secondary" size="sm" onClick={() => setBack(true)}>
            {TT('ปลดล็อกเพื่อแก้ไขย้อนหลัง')}
          </Button>
        </div>
      )}

      {/* 12-month table */}
      <div className="overflow-x-auto">
        <Table className="w-full">
          <TableHeader>
            <TableRow>
              <TableHead>
                {TT('เดือน')} ({TT('ปีงบ')} {S.fy} = {E.fySpanTxt(S.fy)})
              </TableHead>
              <TableHead className="text-right">{TT('วันทำงาน')}</TableHead>
              <TableHead className="text-right">{TT('capacity (ชม.)')}</TableHead>
              <TableHead className="text-center">{edit ? TT('แก้ค่า') : TT('ค่า')} ({u})</TableHead>
              <TableHead className="text-right">{TT('= ชั่วโมง')}</TableHead>
              <TableHead className="text-right">= MD</TableHead>
              <TableHead className="text-right">% cap</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {ALLMI.map((mi) => {
              const lk = lock(r, mi);
              const cap = capPerOf(S.fy, mi);
              const v = lk && lk.k === 'team' ? ((r.mo && r.mo[mi]) || (r.m && r.m[mi]) || 0) : (r.m[mi] || 0);

              return (
                <TableRow key={mi} className={cn(lk && 'bg-muted/30')}>
                  <TableCell>
                    <span className="font-bold">{MONTHS[mi]}</span>
                    <span className="ml-2 font-mono text-[11px] text-muted-foreground">
                      {E.fyYearOf(S.fy, mi)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">{P.WD[mi]}</TableCell>
                  <TableCell className="text-right">{cap}</TableCell>
                  <TableCell className="w-[110px]">
                    <EC
                      v={v}
                      u={u}
                      cap={cap}
                      ro={!edit}
                      lock={lk || undefined}
                      lockTeam={lk && lk.k === 'team' ? lk.t : undefined}
                      lockWhy={lk ? lk.why : undefined}
                      set={(x) => x !== null && setCell(r.id, mi, x)}
                      nullable={false}
                    />
                    {props.pending?.has(`${r.id}:${mi}`) && (
                      <div className="mt-[2px] text-right text-[10px] font-medium text-[color:var(--t3)]" aria-live="polite">
                        {TT('กำลังบันทึก')}…
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono">{v !== null ? E.n1(v) : '–'}</TableCell>
                  <TableCell className="text-right font-mono">{v !== null ? E.n2(v / E.HPD) : '–'}</TableCell>
                  <TableCell className="text-right font-mono">{v !== null ? E.pct(v, cap) + '%' : '–'}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </Modal>
  );
}
