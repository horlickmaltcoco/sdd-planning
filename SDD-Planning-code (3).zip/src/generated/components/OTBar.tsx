// Session 1-06 Part B · 2. the OT bar chart. Hand-built SVG: the bars, the y axis and the
// native <title> tooltip per bar group. The numbers are the same ones the table shows.
import { ALLMI, MONTHS } from '@generated/config';
import { fmt, n1 } from '@generated/engine';
import { TT } from '@generated/i18n';
import { ticksOf, tickTxt } from '@generated/lib/ot-chart';
import type { OtCellView } from '@generated/lib/ot-derive';

const W = 320;
const H = 112;
const PL = 26;
const PR = 8;
const PT = 14;
const PB = 20;

interface OTBarProps {
  cells: OtCellView[];
  MI?: number[];
  /** The shared scale of the view. Omitted → this chart scales to itself. */
  max?: number;
  name?: string;
}

function tipOf(name: string | undefined, i: number, c: OtCellView): string {
  const head = `${name ? `${name} · ` : ''}${MONTHS[i]} · ${fmt(c.v ?? 0, 0, 'Hrs')} ${TT('ชม.')}`;
  if (c.avg == null) return head;
  return `${head} · ${TT('เฉลี่ย/คน')} ${n1(c.avg)} ${TT('ชม.')} (${c.head} ${TT('คน')})`;
}

export function OTBar(props: OTBarProps) {
  const MI = props.MI ?? ALLMI;

  let top = props.max ?? 0;
  if (props.max == null) {
    for (const i of MI) {
      const v = props.cells[i]?.v ?? 0;
      if (v > top) top = v;
    }
  }
  const max = top * 1.1 || 1;
  const iw = (W - PL - PR) / (MI.length || 1);
  const bw = Math.min(iw * 0.6, 40);
  const y = (v: number) => PT + (H - PT - PB) * (1 - v / max);
  const ticks = ticksOf(top);

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      role="img"
      aria-label={`${props.name ?? ''} OT plan`}
      // Session 1-28 · no height attribute; CSS height:auto sizes it from the viewBox, as before.
      className="block h-auto"
    >
      {/* y axis first, so the bars sit on top of the grid lines */}
      {ticks.map((tv) => (
        <g key={`t${tv}`}>
          <line
            x1={PL}
            x2={W - PR}
            y1={y(tv)}
            y2={y(tv)}
            stroke={tv === 0 ? '#D0D5DD' : '#EEF1F4'}
            strokeWidth={0.8}
          />
          <text x={PL - 4} y={y(tv) + 2.5} textAnchor="end" fontSize={7.5} fill="#98A2B3">
            {tickTxt(tv)}
          </text>
        </g>
      ))}

      {MI.map((i, k) => {
        const c = props.cells[i] ?? { v: null, head: 0, avg: null };
        const cx = PL + k * iw + iw / 2;
        if (c.v == null) {
          return (
            <text
              key={i}
              x={cx}
              y={H - PB - 2}
              textAnchor="middle"
              fontSize={9}
              fill="#D0D5DD"
            >
              –
            </text>
          );
        }
        return (
          <g key={i} className="otb">
            <title>{tipOf(props.name, i, c)}</title>
            <rect
              x={PL + k * iw + (iw - bw) / 2}
              y={y(c.v)}
              width={bw}
              height={(H - PT - PB) * (c.v / max)}
              fill="#9DC3E6"
              rx={1.5}
            />
            <text x={cx} y={H - PB + 11} textAnchor="middle" fontSize={8} fill="#98A2B3">
              {MONTHS[i]}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
