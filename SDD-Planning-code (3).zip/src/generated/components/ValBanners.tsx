// Session 1-11 · Validation "val" · Part B data-quality banners. Read-only — these only
// report; they never write to any board. Each check runs over the whole FY, unfiltered
// (banner 5 is scoped by Group/Team only, per spec). Empty when the register is clean.
import type { ReactNode } from 'react';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import type { Model } from '@generated/model';
import type { Settings } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import { HeadFallbackNote } from '@generated/components/HeadFallbackNote';

function Amber({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mb-[13px] rounded-[8px] border border-[#F5C86B] bg-[#FFFCF3] p-[14px]">
      <p className="mb-[8px] text-[13px] font-bold text-[#B54708]">⚠ {title}</p>
      <div className="text-[12px] leading-[1.6] text-[#7A2E0E]">{children}</div>
    </div>
  );
}

function Red({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mb-[13px] rounded-[8px] border border-[#FDA29B] bg-[#FFFBFA] p-[14px]">
      <p className="mb-[8px] text-[13px] font-bold text-[#B42318]">⚠ {title}</p>
      <div className="text-[12px] leading-[1.6] text-[#7A271A]">{children}</div>
    </div>
  );
}

function BTable({ head, rows }: { head: string[]; rows: ReactNode[][] }) {
  return (
    <table className="mt-[9px] w-full min-w-[420px] border-collapse text-[12px]">
      <thead>
        <tr className="bg-[var(--cd2)]">
          {head.map((h, i) => (
            <th key={h} className={`px-[8px] py-[5px] font-semibold ${i === 0 ? 'text-left' : 'text-right'}`}>
              {TT(h)}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((cells) => {
          const rowKey = cells.map((c) => (typeof c === 'string' || typeof c === 'number' ? String(c) : '')).join('|');
          return (
            <tr key={rowKey} className="border-t border-black/10">
              {cells.map((c, ci) => (
                <td key={`${rowKey}-${head[ci]}`} className={`px-[8px] py-[5px] ${ci === 0 ? 'text-left' : 'text-right'}`}>
                  {c}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

interface ValBannersProps {
  S: Settings;
  model: Model;
  P: Plan;
  fg: string;
  ft: string;
}

export function ValBanners({ S, model, P, fg, ft }: ValBannersProps) {
  const fy = S.fy;
  const A = model.ASSIGN;
  const FC = model.FYCODE;

  // Banner 1 — hours/day drift
  const b1 = E.hpdDrift(fy, { [String(fy)]: model.wdOf(fy) }, model.capPerOf, S.hoursPerDay);

  // Banner 3 — status vs dates
  const b3 = EB.statusDateMismatch(model.PEOPLE_NOW);

  // Banner 4 — unknown plan names
  const b4 = EB.unknownPlanNames(null, fy, model.MPROWS, model.PEOPLE_BY_EMP, model.PEOPLE_BY_NAME);

  // Banner 5 — head fallback (fg/ft scope only)
  const b5rows = P.L2.filter((r) => (fg === 'ALL' || r.grp === fg) && (ft === 'ALL' || r.team === ft));

  // Banner 6 — team codes not in register
  const otList = Object.entries(model.D_OT_MAP).flatMap(([f, teams]) => Object.keys(teams).map((t) => ({ fy: f, t })));
  const b6 = EB.teamsNotInRegister(fy, model.MPROWS, otList, model.SECTIONS);

  // Banner 7 — group clash within a team
  const b7 = EB.teamGroupClash(fy, model.SECTIONS, A, FC);

  // Banner 8 — assignment mismatch (drift + mismatch)
  const b8drift = EB.sectionDrift(fy, model.PEOPLE_NOW, A, model.ASSIGN_FROM_BOARD, FC);
  const b8mism = EB.assignMismatchPeople(null, fy, model.MPROWS, A, FC);
  const b8n = b8drift.length + b8mism.length;

  return (
    <>
      {b1 && (
        <Amber title={TT('ชม./วัน ที่กรอกไว้ ยังไม่ตรงกับ capacity บนบอร์ด')}>
          <p>
            {TT(
              'ช่อง Hours per Day บนแถวรวมทั้งปี ถูกแก้แล้ว และแอปใช้ค่าใหม่เป็นตัวหาร MD ทันที แต่ช่อง Capacity per Person (hrs) ของแต่ละเดือนยังเป็นค่าเดิม โควตากับ MD จึงยังไม่สอดคล้องกัน',
            )}
          </p>
          <BTable
            head={['ที่ไหน', 'ชั่วโมงต่อวัน']}
            rows={[
              [TT('ช่อง Hours per Day ที่กรอกไว้'), <b key="a">{E.n1(b1.onBoard)}</b>],
              [TT('คำนวณจาก capacity ต่อคน ÷ วันทำการ'), <b key="b" className="text-[color:var(--or)]">{E.n1(b1.calc)}</b>],
            ]}
          />
          <p className="mt-[8px]">
            {TT('วิธีแก้ · สั่งคำนวณ capacity ใหม่ด้วยคำสั่ง workday --fix แล้วค่าทั้ง 12 เดือนของปีงบนี้จะถูกเขียนใหม่จาก วันทำการ × ชม./วัน')}
          </p>
        </Amber>
      )}

      {b3.length > 0 && (
        <Amber title={`${TT('สถานะการจ้างงานไม่ตรงกับวันที่')} ${b3.length} ${TT('คน')}`}>
          <p>
            {TT(
              'ตัวเลขทุกตัวยังถูกต้อง เพราะระบบตัดสินจากวันเข้าและวันสิ้นสุดเท่านั้น ไม่ได้อ่านช่อง Employment Status · แต่ผู้ที่เปิดบอร์ดอ่านจะเข้าใจสถานะของคนเหล่านี้ผิด จึงควรแก้ให้ตรงกัน',
            )}
          </p>
          <BTable
            head={['พนักงาน', 'ทีม', 'Employment Status', 'วันสิ้นสุด', 'ไม่ตรงกันอย่างไร']}
            rows={b3.slice(0, 8).map((r) => [
              <b key="n">{r.name}</b>,
              r.sec,
              <b key="s" className="text-[color:var(--or)]">{TT(r.status)}</b>,
              r.end ? <span key="e" className="font-mono">{r.end}</span> : `— ${TT('เว้นว่าง')} —`,
              TT(r.why),
            ])}
          />
          <p className="mt-[8px]">
            {TT('วิธีแก้ · ที่บอร์ด SDD · Employee Master แก้ช่อง Employment Status ให้ตรงกับวันสิ้นสุด · ลาออกไปแล้วให้เป็น Resigned · ยังทำงานอยู่ให้เว้นวันสิ้นสุดไว้')}
          </p>
        </Amber>
      )}

      {b4.length > 0 && (
        <Red title={`${TT('พบชื่อในแผนที่ไม่มีในทะเบียนพนักงาน')} ${b4.length} ${TT('ชื่อ')}`}>
          <p>
            {TT(
              'ชื่อเหล่านี้ถูกนับรวมในยอดของทีมตามปกติ แต่ผูกกับทะเบียนไม่ได้ จึงไม่ถูกตรวจเกณฑ์รายคน และไม่ถูกนับเป็นหัวโควตา · สาเหตุที่พบบ่อยคือสะกดชื่อในไฟล์แผนไม่ตรงกับช่อง MP File Name ในทะเบียน',
            )}
          </p>
          <BTable
            head={['ชื่อในไฟล์แผน', 'ทีม', 'แถว', 'ชั่วโมง']}
            rows={b4.slice(0, 8).map((r) => [
              <b key="n" className="text-[color:var(--rd)]">{r.name}</b>,
              r.team,
              String(r.rows),
              E.n1(r.hrs),
            ])}
          />
          <p className="mt-[8px]">
            {TT(
              'วิธีแก้ · เทียบกับช่อง MP File Name ของคนนั้นที่บอร์ด SDD · Employee Master แล้วแก้ชื่อในไฟล์แผนให้ตรง หรือแก้ MP File Name ให้ต���งกับที่ใช้ในไฟล์ · ตัวพิมพ์ใหญ่เล็กและช่องว่างไม่ต้องตรงกัน ระบบเทียบให้เองอยู่แล้ว',
            )}
          </p>
        </Red>
      )}

      <HeadFallbackNote rows={b5rows} />

      {b6.length > 0 && (
        <Red title={`${TT('พบรหัสทีมบนบอร์ดแผนที่ไม่มีในทะเบียน')} ${b6.length} ${TT('ทีม')}`}>
          <BTable
            head={['ทีม', 'MP Plan', 'OT Plan']}
            rows={b6.map((r) => [
              <b key="t" className="text-[color:var(--rd)]">{r.t}</b>,
              `${r.mp} ${TT('แถว')}`,
              `${r.ot} ${TT('แถว')}`,
            ])}
          />
          <p className="mt-[8px]">
            {TT('วิธีแก้ · รหัสทีมต้องตรงกับ Section บนบอร์ด SDD · Employee Master · ถ้าเปลี่ยนรหัสทีม ต้องแก้ label ให้ตรงกันทั้ง Employee Master, MP Plan และ OT Plan')}
          </p>
        </Red>
      )}

      {b7.length > 0 && (
        <Red title={`${TT('พบทีมที่ช่วงสังกัดระบุ Group ไม่ตรงกันในเดือนเดียวกัน')} ${b7.length} ${TT('รายการ')}`}>
          <BTable
            head={['ทีม', 'เดือน', 'Group']}
            rows={b7.slice(0, 12).map((r) => [
              <b key="t">{r.team}</b>,
              MONTHS[r.mi],
              <span key="g" className="text-[color:var(--rd)]">{r.grps.join(' · ')}</span>,
            ])}
          />
          <p className="mt-[8px]">
            {TT('วิธีแก้ · ทีมย้าย Group ต้องเพิ่มช่วงสังกัดใหม่ให้ทุกคนในทีมพร้อมกัน ตั้งแต่เดือนที่ย้าย')}
          </p>
        </Red>
      )}

      {b8n > 0 && (
        <Red title={`${TT('พบทีมไม่ตรงกับทะเบียนสังกัด')} ${b8n} ${TT('คน')}`}>
          {b8drift.length > 0 && (
            <div>
              <p>
                {TT(
                  'ช่อง Section บนแถวพนักงานถูกแก้เป็นทีมใหม่ แต่ไม่มีช่วงสังกัดรองรับ · ระบบอ่านทีมรายเดือนจากช่วงสังกัดเท่านั้น การแก้ช่อง Section เฉย ๆ จึงไม่ถือว่าย้ายทีม และตัวหารกับยอดทีมยังเป็นทีมเดิมทั้งปี',
                )}
              </p>
              <BTable
                head={['พนักงาน', 'Section บนแถวพนักงาน', 'ช่วงสังกัดที่บันทึกไว้']}
                rows={b8drift.slice(0, 8).map((r) => [
                  <b key="n">{r.name}</b>,
                  <b key="s" className="text-[color:var(--rd)]">{r.sec}</b>,
                  r.txt,
                ])}
              />
              <p className="mt-[8px]">
                {TT(
                  'วิธีแก้ · ที่บอร์ด SDD · Employee Master เปิดแถวของคนนั้น แล้วเพิ่มรายการย่อยช่วงสังกัด: ปิดช่วงเดิมด้วยเดือนสุดท้ายที่อยู่ทีมเดิม และเพิ่มช่วงใหม่ที่เริ่มเดือนแรกของทีมใหม่ · Begin Date / End Date บนแถวหลักเป็นวันเข้าและวันลาออกจริง ห้ามใช้บันทึกการย้ายทีม',
                )}
              </p>
            </div>
          )}
          {b8mism.length > 0 && (
            <div className={b8drift.length > 0 ? 'mt-[12px]' : ''}>
              <p>
                {TT(
                  'ทะเบียนระบุว่าเดือนเหล่านี้อยู่ทีมใหม่ แต่แถวแผนยังเป็นทีมเดิม · มักเกิดจากการแก้ช่องสังกัดทับของเดิม แทนการเพิ่มแถวช่วงสังกัดใหม่ · ผลคือแผนของเดือนที่ผ่านมาถูกย้ายไปทีมใหม่ทั้งก้อน',
                )}
              </p>
              <BTable
                head={['พนักงาน', 'ทีมในแผน', 'ทีมในทะเบียน', 'เดือนที่กระทบ', 'ชั่วโมง']}
                rows={b8mism.slice(0, 8).map((r) => [
                  <b key="n">{r.name}</b>,
                  r.fileTeam,
                  <b key="r" className="text-[color:var(--rd)]">{r.regTeam}</b>,
                  r.mis.map((i) => MONTHS[i]).join(' '),
                  E.n1(r.hrs),
                ])}
              />
              <p className="mt-[8px]">
                {TT('วิธีแก้ · ที่บอร์ด SDD · Employee Master ให้คืนช่อง Section เป็นทีมเดิม แล้วบันทึกการย้ายเป็นรายการย่อยช่วงสังกัดแทน')}
              </p>
            </div>
          )}
        </Red>
      )}
    </>
  );
}
