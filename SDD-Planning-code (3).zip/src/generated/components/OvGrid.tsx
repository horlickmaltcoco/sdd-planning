// Session 1-09 · "ov" = ภาพรวมการวางแผน. READ-ONLY — never writes to any board.
// Every number comes from P (Session 1-02 engine); this page only scopes/sums what the engine
// already produced. FY is the GLOBAL fiscal year — changing it here changes it everywhere.
import { useCallback, useMemo, useState, type ReactNode } from 'react';
import { fyOptions } from '@generated/components/FyOptions';
import { APP, MONTHS, navPages } from '@generated/config';
import { md2, sumMd } from '@generated/lib/cp';
import type { CpRow } from '@generated/lib/types';
import { TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { MpDerived, Settings } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import * as ED from '@generated/engine/part-d';
import { Filters, K, UnitSeg } from '@generated/components/MPShared';
import { HeadFallbackNote } from '@generated/components/HeadFallbackNote';
import { OvStrip, type OvStripCell } from '@generated/components/OvStrip';
import { PlanBar, PlanBarLegend } from '@generated/components/PlanBar';
import { TypeStack, TypeLegend } from '@generated/components/TypeStack';
import { TypeSummary } from '@generated/components/TypeSummary';
import { MonthDrill } from '@generated/components/MonthDrill';
import { TypeDrill } from '@generated/components/TypeDrill';

type DrillState = { k: 'team'; mi: number } | { k: 'type'; mi: number; ty: string | null };

interface OvGridProps {
  S: Settings;
  setS: (fn: (prev: Settings) => Settings) => void;
  P: Plan;
  model: Model;
  mp: MpDerived[]; // unused by Part A (kept for the Part B type table that arrives next)
  /** 07 Company Plan rows (all FYs) — only the Company Plan card reads them. */
  cp: CpRow[];
  go: (p: string) => void;
  /** Session 1-15 · years with no FY group on 04/05/07 get a badge in the year dropdown. */
  fyUnprep?: (fy: string) => boolean;
  /** Session 1-15 · when set, replaces everything below the filters (unprepared year). */
  prepBody?: ReactNode;
  /** Session 1-15c · the permanent "เตรียมข้อมูลปีงบ" button, shown with the filters. */
  prepAction?: ReactNode;
}

export default function OvGrid({ S, setS, P, model, mp, cp, go, fyUnprep, prepBody, prepAction }: OvGridProps) {
  const [u, setU] = useState<'Hrs' | 'MD' | '%'>('Hrs');
  const [fg, setFg] = useState('ALL');
  const [ft, setFt] = useState('ALL');
  // Session 1-28 · narrows the Type summary table only (never the page) — see B3.
  const [fty, setFty] = useState('ALL');
  const [drill, setDrill] = useState<DrillState | null>(null);

  const A = model.ASSIGN;
  const FC = model.FYCODE;
  const grpOfMap = model.grpOf;

  // ---- scope ----------------------------------------------------------------
  const inScope = useCallback(
    (r: { team: string; grp: string }) => (ft !== 'ALL' ? r.team === ft : fg === 'ALL' || r.grp === fg),
    [ft, fg],
  );

  const L2 = useMemo(() => P.L2.filter(inScope), [P.L2, inScope]);

  const inScopeL1 = useCallback(
    (r: { team: string; mi: number }) =>
      inScope({ team: r.team, grp: EB.grpOfM(r.team, S.fy, r.mi, A, grpOfMap, FC) }),
    [inScope, S.fy, A, grpOfMap, FC],
  );

  const l1Rows = useMemo(() => P.L1.filter((r) => inScopeL1(r) && r.bad), [P.L1, inScopeL1]);
  const l1 = l1Rows.length;
  const l1people = useMemo(() => new Set(l1Rows.map((r) => `${r.team}|${r.name}`)).size, [l1Rows]);

  const l2oRows = useMemo(
    () => L2.filter((r) => E.statusOf(r.dif, S.teamTolerance ?? 0) === 'over'),
    [L2, S.teamTolerance],
  );
  const l2o = l2oRows.length;
  const l2oTeams = useMemo(() => new Set(l2oRows.map((r) => r.team)).size, [l2oRows]);

  const grpAt = useCallback(
    (mi: number) => (ft !== 'ALL' ? EB.grpOfM(ft, S.fy, mi, A, grpOfMap, FC) : fg),
    [ft, fg, S.fy, A, grpOfMap, FC],
  );

  const l3oRows = useMemo(
    () => P.L3.filter((r) => r.st === 'over' && (grpAt(r.mi) === 'ALL' || r.grp === grpAt(r.mi))),
    [P.L3, grpAt],
  );
  // B6 · Company Plan rows of this FY with a value, in the same Group scope month by month
  // (team level → the team's Group in that month). MD only — never converted to hours or %.
  const cpRows = useMemo(
    () =>
      cp.filter((r) => {
        if (String(r.fy) !== String(S.fy) || r.md == null) return false;
        const g = grpAt(Math.max(0, (MONTHS as readonly string[]).indexOf(r.mo)));
        return g === 'ALL' || r.grp === g;
      }),
    [cp, S.fy, grpAt],
  );
  const cpTotal = useMemo(() => sumMd(cpRows), [cpRows]);
  const cpCos = useMemo(() => new Set(cpRows.map((r) => r.co)).size, [cpRows]);
  const grpScope = ft !== 'ALL' ? EB.grpLabel(ft, S.fy, A, grpOfMap, FC) : fg;

  const l3o = l3oRows.length;
  const l3oGroups = useMemo(() => new Set(l3oRows.map((r) => r.grp)).size, [l3oRows]);

  const totQuota = useMemo(() => L2.reduce((s, r) => s + r.quota, 0), [L2]);
  const totAllow = useMemo(() => L2.reduce((s, r) => s + r.allow, 0), [L2]);
  const totPlan = useMemo(() => L2.reduce((s, r) => s + r.planSum, 0), [L2]);
  const totLeave = useMemo(() => L2.reduce((s, r) => s + r.leave, 0), [L2]);
  const totWork = totPlan - totLeave;
  const otMiss = useMemo(() => L2.filter((r) => r.otMiss).length, [L2]);

  // ---- Part B/C: Type chart + Type table scope (mpScope, month-by-month team ownership) ----
  const scopedMp = useMemo(
    () => ED.mpScope(mp, S.fy, fg, ft, A, model.EMPWIN, grpOfMap, FC),
    [mp, S.fy, fg, ft, A, model.EMPWIN, grpOfMap, FC],
  );
  const agg = useMemo(() => ED.typeAgg(scopedMp), [scopedMp]);
  const { q: qH, a: aH, s: sH } = useMemo(() => ED.monthSums(L2), [L2]);
  const capM = aH; // Σ L2.allow per month, in the same scope as L2 (business rule 1)
  const hasMpPage = navPages(APP.planning).includes('mp');

  const teamOpts = useMemo(() => {
    const codes = P.teams
      .map((t) => t.team)
      .filter((t) => EB.inGrpFy(t, fg, S.fy, A, grpOfMap, FC));
    return [{ v: 'ALL', t: TT('ทุกทีม') }, ...codes.map((t) => ({ v: t, t }))];
  }, [P.teams, fg, S.fy, A, grpOfMap, FC]);

  const clear = () => {
    setFg('ALL');
    setFt('ALL');
    setFty('ALL');
  };

  // ---- stat strip -------------------------------------------------------------
  const strip: OvStripCell[] = [
    {
      label: TT('ชั้น 1 · คนที่ต่ำกว่า capacity'),
      value: `${l1people} ${TT('คน')}`,
      color: l1 > 0 ? 'var(--rd)' : 'var(--gn)',
      sub: `${TT('ไม่ผ่านรวม')} ${l1} ${TT('ครั้ง')}`,
      onClick: () => go('val'),
    },
    {
      label: TT('ชั้น 2 · ทีมที่เกินโควตา+OT'),
      value: `${l2oTeams} ${TT('ทีม')}`,
      color: l2o > 0 ? 'var(--rd)' : 'var(--gn)',
      sub: `${TT('เกินรวม')} ${l2o} ${TT('ครั้ง')}`,
      onClick: () => go('val'),
    },
    {
      label: TT('ชั้น 3 · Group'),
      value: `${l3oGroups} Group`,
      color: l3o > 0 ? 'var(--rd)' : 'var(--gn)',
      sub: `${TT('เกินรวม')} ${l3o} ${TT('ครั้ง')}`,
      onClick: () => go('val'),
    },
    {
      label: TT('แผนที่เป็นวันลา'),
      value: E.fmt(totLeave, totQuota, u),
      color: 'var(--or)',
      sub: `${E.pctTxt(totLeave, totPlan)}% ${TT('ของแผน')}`,
      tooltip: TT('วันลาที่วางไว้ในแผน · นับรวมในแผน ไม่หักจาก capacity'),
      onClick: () => go('mp'),
    },
    {
      label: TT('OT ที่ยังไม่กรอก'),
      value: otMiss,
      color: 'var(--or)',
      sub: TT('ทีม × เดือน · ทีมที่ปิดไว้ไม่นับ'),
      onClick: () => go('ot'),
    },
  ];

  // ---- KPI grid -----------------------------------------------------------
  const workLower = E.pctF(totWork, totQuota) < E.pctF(totPlan, totQuota);
  const kpis: Array<{
    label: string;
    value: ReactNode;
    sub: ReactNode;
    color?: string;
    onClick?: () => void;
  }> = [
    { label: TT('โควตา MP'), value: E.fmt(totQuota, totAllow, u), sub: E.uLabel(u, TT('โควตา+OT รวม')) },
    {
      label: `+ OT Plan`,
      value: E.fmt(totAllow - totQuota, totAllow, u),
      sub: u === '%' ? TT('ของโควตา+OT รวม') : TT('เพิ่มจากโควตา'),
      color: 'var(--or)',
      onClick: () => go('ot'),
    },
    {
      label: TT('แผนที่กรอกมา'),
      value: E.fmt(totPlan, totAllow, u),
      sub: u === '%' ? TT('ของโควตา+OT รวม') : `${E.pct(totPlan, totAllow)}% ${TT('ของโควตา+OT')}`,
      color: 'var(--acv)',
      onClick: () => go('mp'),
    },
    {
      label: TT('ส่วนต่างรวมปี'),
      value: E.fmt(totPlan - totAllow, totAllow, u, { sign: true }),
      sub: totPlan > totAllow ? TT('เกินโควตา+OT') : TT('ยังไม่เต็มโควตา+OT'),
      color: totPlan > totAllow ? 'var(--rd)' : 'var(--gn)',
      onClick: () => go('val'),
    },
    {
      label: TT('ใช้กำลังคน · รวมลา'),
      value: `${E.pct(totPlan, totQuota)}%`,
      sub: `${TT('แผน')} ${E.fmt(totPlan, 0, 'Hrs')} ÷ ${TT('โควตา')} ${E.fmt(totQuota, 0, 'Hrs')}`,
      color: 'var(--acv)',
      onClick: () => go('val'),
    },
    {
      label: TT('ใช้กำลังคน · เฉพาะงาน'),
      value: `${E.pct(totWork, totQuota)}%`,
      sub: `${TT('ตัดวันลา')} ${E.n1(totLeave)} ${TT('ชม.')}`,
      color: workLower ? 'var(--or)' : 'var(--gn)',
      onClick: () => go('val'),
    },
    {
      label: TT('แผนงาน ISUZU Group'),
      value: u === 'MD' ? md2(cpTotal) : '–',
      sub:
        u !== 'MD'
          ? TT('มีเฉพาะหน่วย MD')
          : (ft !== 'ALL' ? `${TT('ยอดของ')} ${grpScope} · ` : '') + `${cpCos} ${TT('บริษัท')}`,
      color: 'var(--acv)',
      onClick: () => go('cp'),
    },
  ];

  return (
    <div className="mx-auto w-full max-w-[1600px]">
      <div className="mb-[16px]">
        <h1 className="text-[22px] font-bold leading-[1.3]">
          {TT('ภาพรวมการวางแผน')} · {TT('ปีงบ')} {S.fy}
        </h1>
        <p className="mt-[4px] text-[13px] text-[color:var(--t2)]">
          {TT('โควตา+OT = (วันทำงาน × ')}
          {S.hoursPerDay}
          {TT(' ชม. × จำนวนคน) + OT Plan')}
        </p>
      </div>

      <Filters
        items={[
          {
            label: TT('ปีงบ'),
            value: String(S.fy),
            all: String(S.fy),
            onChange: (v) => setS((prev) => ({ ...prev, fy: Number.parseInt(v, 10) })),
            options: fyOptions(model.fyList(), fyUnprep),
          },
          {
            label: 'Group',
            value: fg,
            onChange: (v) => {
              setFg(v);
              setFt('ALL');
            },
            options: E.optGroups(model.GROUPS).map((o) => ({ v: o.v, t: TT(o.t) })),
          },
          {
            label: TT('ทีม'),
            value: ft,
            onChange: setFt,
            options: teamOpts,
          },
          // Session 1-29 · in the row with the others, but it still narrows ONLY the Type summary table.
          {
            label: 'Type',
            value: fty,
            onChange: setFty,
            options: [{ v: 'ALL', t: 'ทุก Type' }, ...model.TYPES.map((t) => ({ v: t, t }))],
          },
        ]}
        extra={
          <>
            {prepAction}
            <UnitSeg value={u} onChange={setU} hint={u === '%' ? TT('เทียบโควตา+OT') : undefined} />
          </>
        }
        onClear={clear}
      />

      {prepBody ? (
        prepBody
      ) : (
      <>
      <HeadFallbackNote rows={L2} />

      <OvStrip cells={strip} />

      <div className="grid grid-cols-1 gap-[10px] sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {kpis.map((k) => (
          <K key={k.label} label={k.label} value={k.value} sub={k.sub} color={k.color} onClick={k.onClick} />
        ))}
      </div>
      {fty !== 'ALL' && (
        <p className="mt-[8px] text-[12px] text-[color:var(--t3)]">
          {TT('เลือก Type แล้วมีผลเฉพาะตารางสรุปตาม Type ด้านล่าง · การ์ดด้านบนและกราฟคิดจากทั้งหมด')}
        </p>
      )}

      {/* B1 */}
      <div className="mt-[16px] rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
        <h2 className="text-[15px] font-bold leading-[1.3]">{TT('แผนรวมเทียบโควตา+OT รายเดือน')}</h2>
        <div className="mt-[10px]">
          <PlanBar qH={qH} aH={aH} sH={sH} u={u} WD={P.WD} onPick={(mi) => setDrill({ k: 'team', mi })} />
        </div>
        <PlanBarLegend u={u} />
      </div>

      {/* B2 */}
      <div className="mt-[16px] rounded-[10px] border border-[color:var(--bd)] bg-[var(--cd)] p-[16px]">
        <h2 className="text-[15px] font-bold leading-[1.3]">{TT('แผนรายเดือน แยกตาม Type')}</h2>
        <p className="mt-[3px] text-[12px] text-[color:var(--t3)]">
          {u === '%'
            ? TT('ทุกตัวเลขในกราฟนี้คือ % ของโควตา+OT ของเดือนนั้น · 100% = เต็มโควตา+OT · คลิกแท่งเพื่อดูรายทีม')
            : TT('แท่งซ้อน = ชั่วโมงที่วางแผนไว้ของแต่ละ Type · ตัวเลขบนแท่ง = ยอดรวมของเดือนนั้น · คลิกแท่งเพื่อดูรายทีม')}
        </p>
        {agg.length === 0 ? (
          <p className="py-[14px] text-[13px] text-[color:var(--t3)]">{TT('ไม่มีแผนตามตัวกรองที่เลือก')}</p>
        ) : (
          <>
            <div className="mt-[10px]">
              <TypeStack
                agg={agg}
                u={u}
                WD={P.WD}
                cap={capM}
                TYPES={model.TYPES}
                onPick={(mi, ty) => setDrill({ k: 'type', mi, ty: ty ?? null })}
              />
            </div>
            <TypeLegend agg={agg} TYPES={model.TYPES} />
          </>
        )}
      </div>

      {/* B3 · the only thing the Type filter narrows: quota has no Type, so the cards and charts above
          always use every Type (the note under the cards says so while a Type is chosen). */}
      <div className="mt-[16px]">
        <TypeSummary
          rows={scopedMp}
          P={P}
          u={u}
          totPlan={totPlan}
          TYPES={model.TYPES}
          grpOfMap={grpOfMap}
          ASSIGN={A}
          FYCODE={FC}
          ty={fty}
        />
      </div>

      {/* C1 · drills */}
      {drill?.k === 'team' && (
        <MonthDrill S={S} P={P} mi={drill.mi} fg={fg} ft={ft} u={u} go={go} close={() => setDrill(null)} />
      )}
      {drill?.k === 'type' && (
        <TypeDrill
          S={S}
          P={P}
          mi={drill.mi}
          rows={scopedMp}
          u={u}
          cap={capM[drill.mi] ?? 0}
          focus={drill.ty}
          go={hasMpPage ? go : null}
          toTeam={(mi) => setDrill({ k: 'team', mi })}
          close={() => setDrill(null)}
          TYPES={model.TYPES}
          PEOPLE_BY_EMP={model.PEOPLE_BY_EMP}
          PEOPLE_BY_NAME={model.PEOPLE_BY_NAME}
          ASSIGN={A}
          grpOfMap={grpOfMap}
          FYCODE={FC}
        />
      )}
      </>
      )}
    </div>
  );
}
