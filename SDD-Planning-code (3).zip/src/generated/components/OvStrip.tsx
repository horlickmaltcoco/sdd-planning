// Session 1-09 · the Overview stat strip: one white card, 5 clickable cells side by side.
// Big number = people/teams; the "x month" granularity always sits in the sub line.
import { Fragment, type ReactNode } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { cn } from '@lib/utils';

export interface OvStripCell {
  label: string;
  value: ReactNode;
  color?: string;
  sub: ReactNode;
  tooltip?: string;
  onClick: () => void;
}

export function OvStrip(props: { cells: OvStripCell[] }) {
  return (
    <div className="mb-[16px] flex flex-wrap overflow-hidden rounded-[8px] border border-[color:var(--bd2)] bg-[var(--cd)]">
      {props.cells.map((c, i) => {
        const body = (
          <button
            type="button"
            onClick={c.onClick}
            className={cn(
              'flex min-w-[150px] flex-1 cursor-pointer flex-col gap-[3px] p-[12px] text-left outline-none transition-colors hover:bg-[var(--ylb)]',
              i < props.cells.length - 1 && 'border-r border-[color:var(--bd2)]',
            )}
          >
            <span className="text-[11.5px] font-semibold leading-[1.35] text-[color:var(--t2)]">
              {c.label}
            </span>
            <span
              className="text-[21px] font-bold leading-[1.15]"
              style={{ color: c.color || 'var(--tx)' }}
            >
              {c.value}
            </span>
            <span className="text-[11px] leading-[1.35] text-[color:var(--t3)]">{c.sub}</span>
          </button>
        );
        if (!c.tooltip) return <Fragment key={c.label}>{body}</Fragment>;
        return (
          <TooltipProvider key={c.label}>
            <Tooltip>
              <TooltipTrigger asChild>{body}</TooltipTrigger>
              <TooltipContent>{c.tooltip}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      })}
    </div>
  );
}
