import { APP_BUILD, APP_VERSION } from '@generated/config';

export default function PageFooter() {
  return (
    <footer className="py-[18px] text-center text-[10.5px] leading-[1.9] text-[color:var(--t3)]">
      <div>SDD Planning · ISUZU Corporate Identity</div>
      <div>{'v' + APP_VERSION + ' · build ' + APP_BUILD}</div>
    </footer>
  );
}
