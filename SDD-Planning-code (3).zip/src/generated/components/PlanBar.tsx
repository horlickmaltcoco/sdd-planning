// Session 1-09 Part B · B1. Plan vs quota+OT, 12 months. Hand-built SVG (no chart library
// carries a "quota+OT ceiling line + red overflow label" shape). Read-only: clicking a month
// opens MonthDrill; it never writes to a board.
import { HPD, fmt, n0, n1, uLabel } from '@generated/engine';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';

const W = 900;
const H = 250;
const PL = 52;
const PR = 10;
const PT = 24;
const PB = 42;

interface PlanBarProps {
  qH: number[];
  aH: number[];
  sH: number[];
  u: 'Hrs' | 'MD' | '%';
  WD: (number | null)[];
  onPick: (mi: number) => void;
}

export function PlanBar({ qH, aH, sH, u, WD, onPick }: PlanBarProps) {
  let q = qH.slice();
  let a = aH.slice();
  let s = sH.slice();
  if (u === '%') {
    const base = aH.map((v) => v || 1);
    q = qH.map((v, i) => (v / base[i]!) * 100);
    s = sH.map((v, i) => (v / base[i]!) * 100);
    a = a.map(() => 100);
  } else if (u === 'MD') {
    q = q.map((v) => v / HPD);
    a = a.map((v) => v / HPD);
    s = s.map((v) => v / HPD);
  }
  const max = Math.max(...a, ...s, 0) * 1.15 || 1;
  const iw = (W - PL - PR) / 12;
  const bw = iw * 0.3;
  const y = (v: number) => PT + (H - PT - PB) * (1 - v / max);
  const bh = (v: number) => (H - PT - PB) * (v / max);
  const ticks = [0, 0.25, 0.5, 0.75, 1];

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      // Session 1-28 · no height attribute ("auto" is not a length and was discarded, logging a warning);
      // CSS height:auto sizes it from the viewBox exactly as the browser already did.
      className="block h-auto"
    >
      {ticks.map((t) => {
        const v = t * max;
        return (
          <g key={t}>
            <line x1={PL} x2={W - PR} y1={y(v)} y2={y(v)} stroke="#E5E7EB" strokeWidth={1} strokeDasharray="3 3" />
            <text x={PL - 6} y={y(v) + 3} textAnchor="end" fontSize={10} fill="#98A2B3">
              {n0(v)}
              {u === '%' ? '%' : ''}
            </text>
          </g>
        );
      })}
      {MONTHS.map((mo, i) => {
        const x0 = PL + i * iw + iw * 0.16;
        const qi = q[i] ?? 0;
        const ai = a[i] ?? 0;
        const si = s[i] ?? 0;
        const over = si > ai;
        return (
          <g key={mo} style={{ cursor: 'pointer' }} onClick={() => onPick(i)}>
            <title>
              {`${mo} · ${TT('โควตา')} ${fmt(qi, ai, u)} · ${TT('โควตา+OT')} ${fmt(ai, ai, u)} · ${TT('แผน')} ${fmt(si, ai, u)}`}
            </title>
            <rect x={PL + i * iw} y={PT} width={iw} height={H - PT - PB} fill="transparent" />
            <rect x={x0} y={y(qi)} width={bw} height={bh(qi)} fill="var(--pl)" rx={1.5} />
            <rect x={x0 + bw + 2} y={y(si)} width={bw} height={bh(si)} fill={over ? '#C00000' : 'var(--acv)'} rx={1.5} />
            <line x1={x0 - 3} x2={x0 + bw * 2 + 5} y1={y(ai)} y2={y(ai)} stroke="#B54708" strokeWidth={2} />
            {over && (
              <text
                x={x0 + bw}
                y={y(Math.max(si, ai)) - 5}
                textAnchor="middle"
                fontSize={9.5}
                fontWeight={600}
                fill="#C00000"
              >
                {`+${n1(si - ai)}${u === '%' ? '%' : ''}`}
              </text>
            )}
            <text x={x0 + bw} y={H - PB + 15} textAnchor="middle" fontSize={11} fontWeight={600} fill="#475467">
              {mo}
            </text>
            <text x={x0 + bw} y={H - PB + 27} textAnchor="middle" fontSize={9.5} fill="#98A2B3">
              {(WD[i] ?? '–') + 'd'}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function PlanBarLegend({ u }: { u: 'Hrs' | 'MD' | '%' }) {
  return (
    <div className="mt-[8px] flex flex-wrap items-center gap-[14px] text-[11px] text-[color:var(--t3)]">
      <span className="flex items-center gap-[5px]">
        <span className="h-[9px] w-[9px] rounded-[2px]" style={{ background: 'var(--pl)' }} />
        {TT('โควตา')}
      </span>
      <span className="flex items-center gap-[5px]">
        <span className="h-[9px] w-[9px] rounded-[2px]" style={{ background: 'var(--acv)' }} />
        {TT('แผนที่กรอกมา')}
      </span>
      <span className="flex items-center gap-[5px]">
        <span className="h-[3px] w-[14px]" style={{ background: '#B54708' }} />
        {TT('โควตา+OT')}
      </span>
      <span className="ml-auto">
        {TT('หน่วย: ')}
        {uLabel(u, TT('โควตา+OT ของทีม'))}
      </span>
    </div>
  );
}
