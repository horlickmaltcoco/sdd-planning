// Session 1-04 Part A — PersonView: heatmap by person
import { useMemo, useState } from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { BandModal } from '@generated/components/BandModal';
import type { PersonSum } from '@generated/engine/part-c';
import type { Settings } from '@generated/model/types';
import type { Plan } from '@generated/engine/part-c';
import { ALLMI, BAND_DEFAULT, MONTHS } from '@generated/config';
import * as E from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { TT } from '@generated/i18n';
import { cn } from '@lib/utils';

export type PersonEntry = PersonSum & { partial: boolean; noplan?: boolean };

interface PersonTeam {
  team: string;
  people: PersonEntry[];
}

import type { Span } from '@generated/model/types';

interface PersonViewProps {
  team: PersonTeam;
  P: Plan;
  S: Settings;
  u: 'Hrs' | 'MD' | '%';
  MI: number[];
  filtered: boolean;
  back: boolean;
  partialN: number;
  headsM: number[];
  noPlan: Array<{ emp: string; name: string }>;
  lockOf: (r: any, mi: number) => { k: 'team' | 'time'; t?: string; why: string } | null;
  setS: (fn: (prev: Settings) => Settings) => void;
  saveBands: (fy: string | number, bands: number[], redAt: number | string | null) => void;
  clearBands: (fy: string | number) => void;
  shown: number;
  total: number;
  pick: (x: { k: 'cell'; name: string; key: string; mi: number }) => void;
  capPerOf: (fy: string | number, mi: number) => number;
  capSumOf: (fy: string | number, MI: number[]) => number;
  assign?: Span[];
  fyCode?: Record<number, string[]>;
}

// BandModal lives in @generated/components/BandModal (one copy for the whole app).

// ============================================================
// Legend (A3)
// ============================================================
interface LegendProps {
  S: Settings;
  setS?: (fn: (prev: Settings) => Settings) => void;
  saveBands?: (fy: string | number, bands: number[], redAt: number | string | null) => void;
  clearBands?: (fy: string | number) => void;
}

function Legend({ S, setS, saveBands, clearBands }: LegendProps) {
  const [open, setOpen] = useState(false);
  const bands = S.bands ?? BAND_DEFAULT;
  const labels = E.bandLabels(bands);
  const dirty = S.bandsDirty;

  return (
    <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1.5">
      <span className="text-[11.5px] font-bold text-muted-foreground">{TT('% ของ capacity เดือนนั้น:')}</span>
      {labels.map(([cls, label]) => {
        const color = E.BAND_COLORS[cls] ?? E.BAND_COLORS['b1'];
        return (
          <span
            key={cls}
            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-medium"
            style={{ background: color.bg, color: color.text }}
          >
            {label}%
          </span>
        );
      })}
      <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
        <span className="inline-block h-[14px] w-[20px] rounded-sm" style={{ outline: '2px solid #D92D20', outlineOffset: '-2px' }} />
        {TT('ต่ำกว่าเกณฑ์ชั้น 1')}
      </span>
      <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
        <span className="inline-block h-[14px] w-[20px] rounded-sm" style={{ outline: '2px dashed #D92D20', outlineOffset: '-2px' }} />
        {TT('ยังไม่ได้กรอก')}
      </span>
      {setS && saveBands && clearBands ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="ml-1 inline-flex items-center gap-1 rounded border border-border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-muted"
        >
          ⚙ {TT('ปรับเกณฑ์สี')}
          {dirty ? ` · ${TT('ปรับเองไว้')}` : ''}
        </button>
      ) : (
        <span className="ml-auto text-[11px] text-muted-foreground">{TT('แก้เกณฑ์ที่บอร์ด Working Day Master')}</span>
      )}
      {open && setS && saveBands && clearBands && (
        <BandModal S={S} setS={setS} save={saveBands} clear={clearBands} close={() => setOpen(false)} />
      )}
    </div>
  );
}

// ============================================================
// MonthTotBar — SVG bar chart (A2 item 5)
// ============================================================
interface MonthTotBarProps {
  m: number[];
  cap: number[];
  u: 'Hrs' | 'MD' | '%';
  WD: (number | null)[];
  MI: number[];
}

function MonthTotBar({ m, cap, u, WD, MI }: MonthTotBarProps) {
  const W = 980;
  const H = 160;
  const PL = 50;
  const PR = 12;
  const PT = 26;
  const PB = 36;

  const V = MI.map((i) => {
    const mv = m[i] ?? 0;
    const cv = cap[i] ?? 0;
    if (u === 'MD') return mv / E.HPD;
    if (u === '%') return cv > 0 ? (mv / cv) * 100 : 0;
    return mv;
  });

  const maxV = Math.max(...V, 0) * 1.2 || 1;
  const iw = (W - PL - PR) / MI.length;
  const bw = Math.min(iw * 0.55, 70);
  const baseY = PT + (H - PT - PB);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" className="overflow-visible">
      {/* Baseline */}
      <line x1={PL} y1={baseY} x2={W - PR} y2={baseY} stroke="#E5E7EB" strokeWidth={1} />
      {MI.map((mi, k) => {
        const x = PL + k * iw + iw / 2;
        const val = V[k] ?? 0;
        const barH = (val / maxV) * (H - PT - PB);
        const my = m[mi] ?? 0;
        const cv = cap[mi] ?? 0;
        const lbl = my > 0 ? E.fmt(my, cv, u) : '–';
        return (
          <g key={mi}>
            {/* Bar */}
            {val > 0 && (
              <rect
                x={x - bw / 2}
                y={baseY - barH}
                width={bw}
                height={barH}
                fill="#1F3864"
                rx={1.5}
              />
            )}
            {/* Value label above bar */}
            <text
              x={x}
              y={baseY - barH - 5}
              textAnchor="middle"
              fontSize={10}
              fontWeight={600}
              fill="#101828"
            >
              {lbl}
            </text>
            {/* Month name */}
            <text x={x} y={baseY + 14} textAnchor="middle" fontSize={11} fontWeight={600} fill="#475467">
              {MONTHS[mi]}
            </text>
            {/* WD */}
            <text x={x} y={baseY + 25} textAnchor="middle" fontSize={9.5} fill="#98A2B3">
              {WD[mi]}d
            </text>
          </g>
        );
      })}
    </svg>
  );
}

// ============================================================
// PersonView (A2)
// ============================================================
export function PersonView({
  team,
  P,
  S,
  u,
  MI,
  filtered,
  partialN,
  headsM,
  noPlan,
  lockOf,
  setS,
  saveBands,
  clearBands,
  shown,
  total,
  pick,
  capPerOf,
  capSumOf,
  assign = [],
  fyCode,
}: PersonViewProps) {
  const { team: teamName, people } = team;

  // Derived
  const capY = capSumOf(S.fy, MI);
  const tot = useMemo(() => ALLMI.map((i) => people.reduce((s, pp) => s + (pp.m[i] ?? 0), 0)), [people]);
  const lvT = useMemo(() => ALLMI.map((i) => people.reduce((s, pp) => s + (pp.lv[i] ?? 0), 0)), [people]);
  const hm = headsM ?? P.headsM[teamName] ?? E.z12();
  const capTeam = useMemo(() => ALLMI.map((i) => capPerOf(S.fy, i) * (hm[i] || 0)), [hm, S.fy, capPerOf]);

  const hcSel = MI.map((i) => hm[i] || 0);
  const hcNonZero = hcSel.filter((x) => x > 0);
  const hcMin = hcNonZero.length ? Math.min(...hcNonZero) : 0;
  const hcMax = hcNonZero.length ? Math.max(...hcNonZero) : 0;
  const hcTxt = hcNonZero.length === 0 ? '0' : hcMin === hcMax ? String(hcMin) : `${hcMin}–${hcMax}`;

  // Team totals
  const totYear = MI.reduce((s, i) => s + (tot[i] ?? 0), 0);
  const capTeamYear = MI.reduce((s, i) => s + (capTeam[i] ?? 0), 0);
  const lvYear = MI.reduce((s, i) => s + (lvT[i] ?? 0), 0);

  const noPlanCount = noPlan.length;
  const withPlanCount = people.length - noPlanCount;

  // ── Empty state ──
  if (people.length === 0) {
    return (
      <div className="mx-auto w-full max-w-[1600px]">
        <div className="rounded-[10px] border border-border bg-card p-6">
          <h2 className="text-[16px] font-bold">
            {TT('สรุปรายคน')}
            {teamName ? ` · ${teamName}` : ''}
          </h2>
          <p className="mt-2 text-[13px] text-muted-foreground">
            {filtered ? TT('ไม่มีแถวตามตัวกรองที่เลือก') : TT('ปีงบนี้ไม่มีแผนของทีมไหนเลย')}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-[1600px] space-y-3">
      <div className="rounded-[10px] border border-border bg-card p-4">
        {/* 1. Title */}
        <h2 className="mb-1 text-[16px] font-bold leading-tight">
          {TT('สรุปรายคน · ')}
          {teamName}
        </h2>

        {/* 2. Sub line */}
        <p className="mb-2 text-[13px] text-foreground">
          {TT('คนในตาราง')} <b>{people.length}</b>
          {noPlanCount > 0 && (
            <>
              {' '}· {TT('มีแผน')} <b>{withPlanCount}</b>
            </>
          )}
          {' '}· {TT('นับโควตา')} <b>{hcTxt}</b>
          {filtered && (
            <b className="text-[#B54708]">
              {' '}· {TT('กรองเหลือ')} {shown}/{total} {TT('แถว')}
            </b>
          )}
        </p>

        {/* 3. NoPlan warning */}
        {!filtered && noPlanCount > 0 && (
          <p className="mb-2 text-[12.5px] font-medium" style={{ color: '#B54708' }}>
            ⚠ <b>{noPlanCount}</b> {TT('คนที่นับโควตา')} <b>{TT('ไม่มีแผนในเดือนที่แสดง')}</b>{' '}
            {TT('· แสดงเป็นแถวเส้นประในตารางด้านล่าง · แถวรวมทีมคำนวณจากคนที่นับโควตาทั้งหมด จึงได้ % ต่ำกว่าแถวรายคน')}
          </p>
        )}

        {/* 4. Filter / mode notice */}
        {filtered && partialN > 0 ? (
          <p className="mb-2 text-[12px] font-medium" style={{ color: '#B54708' }}>
            {TT('ใช้ตัวกรองอยู่ ·')} <b>{partialN}</b>{' '}
            {TT('คนแสดงแผนไม่ครบ · ตัวเลขของคนเหล่านั้นคือสัดส่วนกำลังคนที่งานกลุ่มนี้ใช้')}{' '}
            <b>{TT('ไม่ใช่เกณฑ์ชั้น 1')}</b> {TT('จึงไม่แสดงกรอบแดง')}
          </p>
        ) : filtered ? (
          <p className="mb-2 text-[12px] text-muted-foreground">
            {TT('ใช้ตัวกรองอยู่ · ทุกคนที่แสดง')} <b>{TT('มีแผนครบ')}</b>{' '}
            {TT('· กรอบแดงจึงยังเป็นเกณฑ์ชั้น 1 และตรงกับหน้า Validation')}
          </p>
        ) : (
          <p className="mb-2 text-[12px] text-muted-foreground">
            {TT('เทียบ')} <b>{TT('capacity รายคนของเดือนนั้น')}</b> · {TT('แสดงเป็น')}{' '}
            <b>{E.uLabel(u, TT('capacity รายคน'))}</b>
            {TT(' · กรอบแดง = ต่ำกว่าเกณฑ์ชั้น 1')}
          </p>
        )}

        {/* 5. MonthTotBar */}
        <MonthTotBar m={tot} cap={capTeam} u={u} WD={P.WD} MI={MI} />

        {/* 6. Note */}
        <p className="mb-3 text-[11.5px] text-muted-foreground">
          {filtered
            ? TT('แท่ง = แผนรวมของแถวที่กรองไว้ ในเดือนนั้น')
            : TT('แท่ง = แผนรวมทั้งทีมของเดือนนั้น')}
          {u === '%' ? TT(' · เทียบ capacity ของทีม (คน × วันทำงาน × ชม./วัน)') : ''}
        </p>

        {/* 7. Heatmap table */}
        <div className="overflow-x-auto">
          <table className="w-max min-w-full border-collapse text-[12px]">
            <thead>
              <tr className="border-b-2 border-border bg-[var(--cd2)]">
                <th
                  className="sticky left-0 z-10 min-w-[160px] bg-[var(--cd2)] px-3 py-2 text-left text-[12px] font-semibold"
                  style={{ minWidth: 160 }}
                >
                  {TT('พนักงาน')}
                </th>
                {MI.map((mi) => (
                  <th key={mi} className="px-2 py-2 text-center text-[11px] font-semibold whitespace-nowrap">
                    <div>{MONTHS[mi]}</div>
                    <div className="text-[9.5px] font-normal text-muted-foreground">{P.WD[mi]}d</div>
                  </th>
                ))}
                <th className="px-3 py-2 text-right text-[11px] font-semibold whitespace-nowrap">{TT('รวม')}</th>
                <th className="px-3 py-2 text-right text-[11px] font-semibold whitespace-nowrap">{TT('วันลา')}</th>
              </tr>
            </thead>
            <tbody>
              {people.map((pp) => {
                const rowSum = MI.reduce((s, i) => s + (pp.m[i] ?? 0), 0);
                const lvY = MI.reduce((s, i) => s + (pp.lv[i] ?? 0), 0);
                const mv = pp.emp ? EB.spanTxt(pp.emp, S.fy, assign, fyCode) : '';
                const isNoPlan = !!pp.noplan;

                return (
                  <tr
                    key={pp.key || pp.n}
                    className={cn(
                      'border-b border-border/50 hover:bg-muted/20',
                      isNoPlan && 'nplrow',
                    )}
                    style={isNoPlan ? { background: 'repeating-linear-gradient(45deg,#FCFCFD,#FCFCFD 8px,transparent 8px,transparent 16px)' } : undefined}
                  >
                    {/* Name cell */}
                    <td className="sticky left-0 z-[1] min-w-[160px] bg-card px-3 py-2" style={{ minWidth: 160 }}>
                      <div className="flex flex-wrap items-center gap-1">
                        <span
                          className="text-[12.5px] font-bold"
                          style={isNoPlan ? { color: '#98A2B3' } : undefined}
                        >
                          {pp.n}
                        </span>
                        {mv && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="mvt inline-block rounded px-1 py-0.5 text-[10px]"
                                  style={{ background: '#FEF0C7', color: '#B54708' }}>
                                  {mv}
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                {TT('พนักงานย้ายทีมระหว่างปี · แต่ละทีมแสดงเฉพาะเดือนที่อยู่ในสังกัด')}
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {isNoPlan && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="npl inline-block rounded px-1 py-0.5 text-[10px]"
                                  style={{ background: '#F2F4F7', color: '#98A2B3' }}>
                                  {TT('ไม่มีแผน')}
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                {TT('นับในโควตาของทีม แต่ไม่มีแผนเลยสักเดือน')}
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                      <div className="mt-0.5 text-[10.5px] text-muted-foreground">{pp.role || ''}</div>
                    </td>

                    {/* Month cells */}
                    {MI.map((mi) => {
                      const cap = capPerOf(S.fy, mi);
                      const lk = lockOf({ empid: pp.emp, emp: pp.emp, own: pp.own } as any, mi);
                      const lkTeam = !!(lk && lk.k === 'team');
                      const v = lkTeam ? ((pp.mo ?? pp.m)[mi] ?? 0) : (pp.m[mi] ?? 0);
                      const filled = v > 0 || EB.inQuotaOf(team.team, pp.emp, S.fy, mi, assign, fyCode);
                      const jj = E.tier1Judge(v, cap, S);
                      const red = !pp.partial && !lkTeam && filled && jj.kind === 'under' && jj.bad;
                      const bCls = E.band(v, cap, S.bands ?? BAND_DEFAULT);
                      const bc = E.BAND_COLORS[bCls] ?? E.BAND_COLORS['b1']!;
                      const tipText = lk
                        ? `${lk.why} · ${pp.n} · ${MONTHS[mi]} · ${E.n1(v)}${TT(' ชม.')}`
                        : `${E.n1(v)}${TT(' ชม. · capacity ')}${E.n1(cap)}${TT(' ชม. · ')}${E.n1(v > 0 && cap > 0 ? (v / cap) * 100 : 0)}% (${TT('ค่าจริงก่อนปัด')})`;

                      const cellContent = (
                        <div
                          className={cn('relative flex h-[32px] min-w-[52px] items-center justify-end px-2 text-[11px] font-mono', lk ? 'cursor-not-allowed' : 'cursor-pointer')}
                          style={{
                            background: bc.bg,
                            color: bc.text,
                            ...(red && v > 0 ? { outline: '2px solid #D92D20', outlineOffset: '-2px' } : {}),
                            ...(red && v <= 0 ? { outline: '2px dashed #D92D20', outlineOffset: '-2px' } : {}),
                            ...(lk ? {
                              backgroundImage: 'repeating-linear-gradient(45deg,rgba(0,0,0,0.04),rgba(0,0,0,0.04) 3px,transparent 3px,transparent 8px)',
                            } : {}),
                          }}
                          onClick={!lk ? () => pick({ k: 'cell', name: pp.n, key: pp.key, mi }) : undefined}
                          role={!lk ? 'button' : undefined}
                          tabIndex={!lk ? 0 : undefined}
                          onKeyDown={!lk ? (e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              pick({ k: 'cell', name: pp.n, key: pp.key, mi });
                            }
                          } : undefined}
                          aria-label={!lk ? `${pp.n} ${MONTHS[mi]} ${E.n1(v)}${TT(' ชม.')}` : undefined}
                        >
                          {lkTeam && lk?.t && (
                            <span className="absolute left-0 top-0 w-full bg-[#7A5AF8] px-1 py-[1px] text-center text-[8px] font-bold text-white">
                              {lk.t}
                            </span>
                          )}
                          <span className={lkTeam ? 'mt-[10px]' : ''}>
                            {v > 0 ? E.fmt(v, cap, u) : '–'}
                          </span>
                        </div>
                      );

                      return (
                        <td key={mi} className="p-0 align-middle" style={{ overflow: 'visible' }}>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>{cellContent}</TooltipTrigger>
                              <TooltipContent>{tipText}</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </td>
                      );
                    })}

                    {/* รวม */}
                    <td className="px-3 py-2 text-right font-mono font-bold text-[12px]">
                      {E.fmt(rowSum, capY, u)}
                    </td>

                    {/* วันลา */}
                    <td className="px-3 py-2 text-right font-mono text-[12px]"
                      style={{ color: lvY > 0 ? '#B54708' : '#D1D5DB' }}>
                      {lvY > 0 ? E.n1(lvY) : '–'}
                    </td>
                  </tr>
                );
              })}

              {/* Totals row */}
              <tr className="totrow border-t-2 border-border bg-[var(--cd2)] font-bold">
                <td className="sticky left-0 z-10 bg-[var(--cd2)] px-3 py-2 text-[12px]">
                  {filtered ? TT('รวมที่กรองไว้') : TT('รวมทั้งทีม')}
                </td>
                {MI.map((mi) => {
                  const cv = capTeam[mi] ?? 0;
                  const tv = tot[mi] ?? 0;
                  return (
                    <td key={mi} className="p-0 align-middle" style={{ overflow: 'visible' }}>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex h-[32px] min-w-[52px] items-center justify-end px-2 font-mono text-[11px]">
                              {tv > 0 ? E.fmt(tv, cv, u) : '–'}
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            {E.n1(tv)}
                            {TT(' ชม. · capacity ทีม ')}
                            {E.n1(cv)}
                            {TT(' ชม.')}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </td>
                  );
                })}
                <td className="px-3 py-2 text-right font-mono text-[12px]">
                  {E.fmt(totYear, capTeamYear, u)}
                </td>
                <td className="px-3 py-2 text-right font-mono text-[12px]"
                  style={{ color: lvYear > 0 ? '#B54708' : '#D1D5DB' }}>
                  {lvYear > 0 ? E.n1(lvYear) : '–'}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* 8. Legend */}
        <Legend S={S} setS={setS} saveBands={saveBands} clearBands={clearBands} />
      </div>
    </div>
  );
}
