// B5 · Split Rows Modal for MP Plan (straddle resolution). Read-only: copies TSV, writes nothing.
import { Button } from '@components/ui/button';
import { Copy } from 'lucide-react';
import { Modal } from '@generated/components/MPShared';
import type { Settings, Span } from '@generated/model/types';
import type { MaskedRow } from '@generated/engine/part-b';
import { teamsOfRow } from '@generated/engine/part-b';
import { fmt } from '@generated/engine';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';

interface SplitRowsModalProps {
  straddle: MaskedRow[];
  S: Settings;
  close: () => void;
  T: (msg: string) => void;
  assign: Span[];
  fyCode: Record<number, string[]>;
}

export function SplitRowsModal(props: SplitRowsModalProps) {
  const { straddle, S, close, T, assign, fyCode } = props;

  // The teams a row really spans this FY (from the assignment spans), e.g. "SD1, SD4".
  const teamsTxt = (r: MaskedRow): string => teamsOfRow(r, S.fy, assign, fyCode).join(', ');

  const copyToClipboard = () => {
    const header = ['#', 'ID', 'Type', 'Task1', 'System', 'Task2', 'Role', 'Name', 'EMP ID', ...MONTHS, 'Teams'].join('\t');
    const rows = straddle.map((r, i) => {
      const months = r.m.map((v: number | null) => String(v || 0)).join('\t');
      return [i + 1, r.id, r.type, r.t1, r.system ?? '', r.task2 ?? '', r.role, r.name, r.empid, months, teamsTxt(r)].join('\t');
    });
    const tsv = [header, ...rows].join('\n');

    try {
      navigator.clipboard.writeText(tsv).then(
        () => T(TT('คัดลอก TSV แล้ว · วางลงใน Excel ได้เลย')),
        () => T(TT('คัดลอกไม่สำเร็จ · เบราว์เซอร์ไม่อนุญาตให้เข้าถึงคลิปบอร์ด')),
      );
    } catch {
      T(TT('คัดลอกไม่สำเร็จ · เบราว์เซอร์ไม่อนุญาตให้เข้าถึงคลิปบอร์ด'));
    }
  };

  return (
    <Modal
      show
      onClose={close}
      title={`${TT('แถวที่ต้องแตก')} · ${straddle.length} ${TT('แถว')}`}
      sub="แถวเหล่านี้เจ้าของย้ายทีมระหว่างปี แต่แถวแผนยังเป็นแถวเดียวครอบทั้งปี"
      size="large"
      footer={
        <Button variant="outline" onClick={copyToClipboard}>
          <Copy className="mr-2 h-4 w-4" />
          {TT('คัดลอก TSV')}
        </Button>
      }
    >
      <div className="space-y-4">
        <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] p-4 text-[13px] text-[#B54708]">
          <div className="mb-2 font-medium">⚠ {TT('ปัญหา')}</div>
          <p>
            {TT(
              'เจ้าของแถวย้ายทีมระหว่างปี แต่แถวแผนยังเป็นแถวเดียวครอบทั้งปี · ไฟล์ของทีมนี้จึงมีเดือนของอีกทีมติดไปด้วย และถูกพิมพ์ทับได้โดยไม่มีอะไรเตือน',
            )}
          </p>
          <p className="mt-2 font-medium">✓ {TT('วิธีแก้')}</p>
          <p>{TT('แตกแถวนี้เป็นแถวละทีม โดยคัดลอก TSV ไปแก้ใน Excel แล้ว re-import')}</p>
        </div>

        <div className="max-h-[400px] overflow-x-auto overflow-y-auto rounded border">
          <table className="w-full border-collapse text-[12px]">
            <thead className="sticky top-0 border-b bg-[var(--cd2)]">
              <tr>
                <th className="px-2 py-2 text-left">#</th>
                <th className="px-2 py-2 text-left">Type</th>
                <th className="px-2 py-2 text-left">Task1</th>
                <th className="px-2 py-2 text-left">Role</th>
                <th className="px-2 py-2 text-left">Name</th>
                <th className="px-2 py-2 text-left">EMP ID</th>
                <th className="px-2 py-2 text-left">Teams</th>
                <th className="px-2 py-2 text-right">{TT('ชม.รวม')}</th>
              </tr>
            </thead>
            <tbody>
              {straddle.map((r, i) => {
                const total = r.m.reduce<number>((s, v) => s + (v || 0), 0);
                return (
                  <tr key={r.id} className="border-b hover:bg-muted/30">
                    <td className="px-2 py-2 text-muted-foreground">{i + 1}</td>
                    <td className="px-2 py-2">{r.type}</td>
                    <td className="px-2 py-2 font-medium">{r.t1}</td>
                    <td className="px-2 py-2">{r.role}</td>
                    <td className="px-2 py-2">{r.name}</td>
                    <td className="px-2 py-2 font-mono">{r.empid}</td>
                    <td className="px-2 py-2 font-medium text-[#B54708]">{teamsTxt(r)}</td>
                    <td className="px-2 py-2 text-right font-mono">{fmt(total, 0, 'Hrs')}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="text-[11px] text-muted-foreground">
          💡 {TT('คัดลอก TSV → วางใน Excel → แยกแถวตาม Team → ล้างเดือนข้ามทีม → Re-import')}
        </div>
      </div>
    </Modal>
  );
}
