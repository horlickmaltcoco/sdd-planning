// 07 Company Plan · page "cp" (Session 1-11 Part B). Scope = rows of the app-wide FY (S.fy).
// Unit is MD only. Filter options come ONLY from values present in the rows of that FY.
import { useCallback, useMemo, useRef, useState } from 'react';
import { Button } from '@components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { MONTHS } from '@generated/config';
import { hit, isPastMonth } from '@generated/engine';
import * as EB from '@generated/engine/part-b';
import { TT } from '@generated/i18n';
import { buildBlocks, firstSeen, md2, monthsWithData, sumMd } from '@generated/lib/cp';
import { doExportCp } from '@generated/lib/file-export';
import type { CpRow } from '@generated/lib/types';
import type { Model } from '@generated/model';
import type { Settings } from '@generated/model/types';
import { Filters, ImportBtn, K } from '@generated/components/MPShared';
import { CPGroupNote } from '@generated/components/CPGroupNote';
import { CPTable } from '@generated/components/CPTable';
import { CPCard } from '@generated/components/CPCard';
import { ImportModal } from '@generated/components/ImportModal';
import { AddCompanyModal } from '@generated/components/AddCompanyModal';
import { useCpWrite } from '@generated/hooks/use-cp-write';

interface CPGridProps {
  S: Settings;
  model: Model;
  cp: CpRow[];
  setCp: (fn: (prev: CpRow[]) => CpRow[]) => void;
  T: (msg: string) => void;
  reloadCp: () => Promise<void>;
}

export default function CPGrid({ S, model, cp, setCp, T, reloadCp }: CPGridProps) {
  const [fg, setFg] = useState('ALL');
  const [fc, setFc] = useState('ALL');
  const [q, setQ] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const [imp, setImp] = useState(false);
  const [addCo, setAddCo] = useState(false);
  const lastCell = useRef<HTMLElement | null>(null);

  const FYK = String(S.fy);
  const inFy = useMemo(() => cp.filter((r) => String(r.fy) === FYK), [cp, FYK]);

  const grps = useMemo(() => firstSeen(inFy.map((r) => r.grp)), [inFy]);
  const cos = useMemo(() => firstSeen(inFy.map((r) => r.co)).sort((a, b) => a.localeCompare(b)), [inFy]);

  const rows = useMemo(
    () =>
      inFy.filter(
        (r) => (fg === 'ALL' || r.grp === fg) && (fc === 'ALL' || r.co === fc) && hit(q, [r.grp, r.co, r.my]),
      ),
    [inFy, fg, fc, q],
  );

  const blocks = useMemo(() => buildBlocks(rows), [rows]);

  // C3 · the real five-argument call; vendorGroupBad itself is unchanged.
  const bad = useMemo(
    () =>
      EB.vendorGroupBad(
        inFy.map((r) => ({ fy: r.fy, grp: r.grp, co: r.co, mh: r.md })) as Parameters<typeof EB.vendorGroupBad>[0],
        S.fy,
        model.ASSIGN,
        model.GROUPS,
        model.FYCODE,
      ),
    [inFy, S.fy, model.ASSIGN, model.GROUPS, model.FYCODE],
  );

  const cards = useMemo(() => {
    const filled = rows.filter((r) => r.md != null);
    const total = sumMd(filled);
    const monthsN = monthsWithData(filled);
    const lines = blocks.reduce((s, b) => s + b.lines.length, 0);
    const empty = blocks.reduce(
      (s, b) => s + b.lines.reduce((t, l) => t + l.cells.filter((c) => !c || c.md == null).length, 0),
      0,
    );
    return {
      total,
      monthsN,
      avg: total / Math.max(1, monthsN),
      nG: new Set(rows.map((r) => r.grp)).size,
      nC: new Set(rows.map((r) => r.co)).size,
      lines,
      empty,
    };
  }, [rows, blocks]);

  const { saveMd, applyImport } = useCpWrite({ fyKey: FYK, setCp, T, reloadCp });

  const exportNow = useCallback(() => doExportCp(S.fy, inFy, T), [S.fy, inFy, T]);

  const clear = () => {
    setFg('ALL');
    setFc('ALL');
    setQ('');
  };

  const openCell = (row: CpRow, el: HTMLElement) => {
    lastCell.current = el;
    setOpenId(row.id);
  };
  const closeCell = () => {
    setOpenId(null);
    const el = lastCell.current;
    if (el) setTimeout(() => el.focus(), 0);
  };

  // The card always shows the CURRENT row from state, never a snapshot.
  const cur = openId ? cp.find((r) => String(r.id) === openId) ?? null : null;
  const curPast = cur
    ? isPastMonth(cur.fy, Math.max(0, (MONTHS as readonly string[]).indexOf(cur.mo)), model.FYCODE)
    : false;

  return (
    <div className="mx-auto w-full max-w-[1600px]">
      <div className="mb-[16px] flex flex-wrap items-start justify-between gap-[10px]">
        <div className="min-w-0">
          <h1 className="text-[22px] font-bold leading-[1.3]">
            {TT('แผนงาน ISUZU Group ปีงบ')} {S.fy}
          </h1>
          <p className="mt-[4px] text-[13px] text-[color:var(--t2)]">
            {TT('แผน MD ที่ SDD ตกลงให้บริการบริษัทในกลุ่ม ISUZU · รายเดือน · อ่านและแก้ที่บอร์ด 07 SDD · Company Plan')}
          </p>
        </div>
        <div className="flex flex-wrap gap-[8px]">
          <TooltipProvider>
            <ImportBtn onClick={() => setImp(true)} />
            <Button variant="secondary" size="sm" onClick={() => setAddCo(true)}>
              + {TT('เพิ่มบริษัท')}
            </Button>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="secondary" size="sm" onClick={exportNow}>
                  ⤓ Export
                </Button>
              </TooltipTrigger>
              <TooltipContent>{TT('ได้ไฟล์ที่ติด Item ID มาให้ทุกแถว · ใช้ไฟล์นี้ไปแก้แล้วอัปโหลดกลับ')}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <Filters
        items={[
          {
            label: 'Group',
            value: fg,
            onChange: setFg,
            options: [{ v: 'ALL', t: TT('ทุก Group') }, ...grps.map((g) => ({ v: g, t: g }))],
          },
          {
            label: 'Company',
            value: fc,
            onChange: setFc,
            minWidth: '200px',
            options: [{ v: 'ALL', t: TT('ทุกบริษัท') }, ...cos.map((c) => ({ v: c, t: c }))],
          },
        ]}
        search={{ label: TT('ค้นหา'), placeholder: TT('บริษัท · Group · เดือน'), value: q, onChange: setQ }}
        count={rows.length}
        total={inFy.length}
        onClear={clear}
      />

      <CPGroupNote bad={bad} />

      <div className="mb-[16px] grid grid-cols-1 gap-[10px] sm:grid-cols-2 lg:grid-cols-4">
        <K label="แผนรวมทั้งปี" value={`${md2(cards.total)} MD`} sub={TT('ตามไฟล์ต้นทาง · ไม่ปัดเศษบนบอร์ด')} color="var(--acv)" />
        <K
          label="เฉลี่ยต่อเดือน"
          value={`${md2(cards.avg)} MD`}
          sub={`${TT('แผนรวม ÷ จำนวนเดือนที่มีข้อมูล')} (${cards.monthsN})`}
        />
        <K label="Group × Company" value={`${cards.nG} × ${cards.nC}`} sub={`${cards.lines} ${TT('แถวบนจอ')}`} />
        <K
          label="ช่องที่ยังไม่กรอก"
          value={cards.empty}
          sub={TT('Group × Company × เดือน ที่ยังไม่มีค่า')}
          color={cards.empty > 0 ? 'var(--or)' : 'var(--gn)'}
        />
      </div>

      <CPTable blocks={blocks} onOpen={openCell} />
      <p className="mt-[8px] text-[11.5px] text-[color:var(--t3)]">
        {TT('หน่วยคือ MD ตามไฟล์ต้นทาง ไม่ปัดเศษบนบอร์ด · บนจอแสดงทศนิยม 2 ตำแหน่ง ชี้ที่ช่องเพื่อดูค่าเต็ม')}
      </p>

      {cur && <CPCard key={cur.id} row={cur} past={curPast} save={saveMd} close={closeCell} />}

      {addCo && <AddCompanyModal fy={S.fy} cp={cp} close={() => setAddCo(false)} done={reloadCp} T={T} />}

      {imp && (
        <ImportModal
          which="cp"
          scope={inFy}
          scopeFy={S.fy}
          apply={applyImport}
          S={S}
          T={T}
          close={() => setImp(false)}
          onExport={exportNow}
          model={{
            TYPES: model.TYPES,
            ROLES: model.ROLES,
            GROUPS: model.GROUPS,
            COMPANIES: model.COMPANIES,
            PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
            ASSIGN: model.ASSIGN,
            EMPWIN: model.EMPWIN,
            FYCODE: model.FYCODE,
          }}
        />
      )}
    </div>
  );
}
