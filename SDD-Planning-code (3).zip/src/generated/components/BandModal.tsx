// Session 1-04 A3 / 1-09 C6 · BandModal — ONE colour-band + red-frame editor for the whole app.
// Overrides live ONLY in this browser (save/clear → "sdd.bands"); it NEVER writes to board 03.
import { type ReactNode, useState } from 'react';
import { Info as InfoIcon } from 'lucide-react';
import { Button } from '@components/ui/button';
import { Input } from '@components/ui/input';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { BAND_DEFAULT } from '@generated/config';
import { BAND_COLORS, bandLabels, bandsCheck } from '@generated/engine';
import { TT } from '@generated/i18n';
import type { Settings } from '@generated/model/types';
import { BoardTag, Modal } from '@generated/components/MPShared';

interface BandModalProps {
  S: Settings;
  setS?: (fn: (prev: Settings) => Settings) => void;
  save: (fy: string | number, bands: number[], redAt: number | string | null) => void;
  clear: (fy: string | number) => void;
  close: () => void;
}

const NAMES = ['เทา', 'ฟ้าอ่อน', 'ฟ้า', 'เขียว', 'เหลือง', 'แดง'];
const MEANINGS = ['ต่ำกว่าเกณฑ์มาก', 'ต่ำกว่าเกณฑ์', 'ต่ำกว่าเกณฑ์เล็กน้อย', 'ตามเกณฑ์', 'สูงกว่าเกณฑ์เล็กน้อย', 'สูงกว่าเกณฑ์มาก'];

const keepNum = (s: string) => s.replace(/[^0-9.]/g, '');

function Tip({ text, children }: { text: string; children: ReactNode }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent className="max-w-[360px]">{text}</TooltipContent>
    </Tooltip>
  );
}

export function BandModal({ S, save, clear, close }: BandModalProps) {
  const boardBands = S.bandsBoard ?? BAND_DEFAULT;
  const boardRedAt = S.redAtBoard ?? 100;
  const init = [...(S.bands ?? BAND_DEFAULT)];
  const initRed = S.redAt == null ? 100 : S.redAt;

  const [v, setV] = useState<(number | null)[]>(init);
  // Raw text mirrors so "92." can be typed on the way to "92.5".
  const [vt, setVt] = useState<string[]>(init.map((x) => String(x)));
  const [redAt, setRedAt] = useState<number | ''>(initRed);
  const [redTxt, setRedTxt] = useState<string>(String(initRed));
  const [info, setInfo] = useState(false);

  const bandsErr = bandsCheck(v);
  const redErr = redAt === '' || Number.isNaN(Number(redAt)) ? 'ต้องระบุค่ากรอบแดงเป็นตัวเลข' : null;

  const infoTip =
    TT('เกณฑ์สีมีผลต่อการแสดงสีของช่องเท่านั้น ไม่กระทบตัวเลข ยอดรวม หรือผลการตรวจสอบในหน้า Validation') +
    ' · ' +
    TT('ค่าตั้งต้นอ่านจากบอร์ด Working Day Master แถวรวมทั้งปีของปีงบ') +
    ' ' +
    S.fy +
    ' (' +
    boardBands.join(',') +
    ' · ' +
    TT('กรอบแดง') +
    ' ' +
    boardRedAt +
    '%)' +
    ' · ' +
    TT('แก้ไขค่าตั้งต้นได้ที่บอร์ด Working Day Master แถวรวมทั้งปี');

  const setBand = (i: number, raw: string) => {
    const t = keepNum(raw);
    setVt((prev) => prev.map((x, k) => (k === i ? t : x)));
    setV((prev) => prev.map((x, k) => (k === i ? (t === '' ? null : Number.parseFloat(t)) : x)));
  };

  const setRed = (raw: string) => {
    const t = keepNum(raw);
    setRedTxt(t);
    setRedAt(t === '' ? '' : Number.parseFloat(t));
  };

  const reset = () => {
    const nb = [...boardBands];
    setV(nb);
    setVt(nb.map((x) => String(x)));
    setRedAt(boardRedAt);
    setRedTxt(String(boardRedAt));
    clear(S.fy); // the modal stays open
  };

  const apply = () => {
    if (bandsErr || redErr) return;
    save(S.fy, (v as number[]).slice(), Number(redAt));
    close();
  };

  const rows = bandLabels(v.map((x) => x ?? 0));

  return (
    <TooltipProvider>
      <Modal
        id="band-modal"
        show
        onClose={close}
        size="medium"
        title={TT('เกณฑ์สีในตารางรายคน')}
        closeTitle={TT('ปิดหน้าต่างโดยไม่บันทึกการเปลี่ยนแปลง')}
        pill={<BoardTag board="Working Day Master" />}
        footer={
          <>
            <Tip text={TT('ลบเกณฑ์ที่บันทึกไว้ในเครื่องนี้ และกลับไปใช้ค่าตั้งต้นจากบอร์ด')}>
              <Button variant="secondary" onClick={reset}>
                {TT('คืนค่าตั้งต้น')}
              </Button>
            </Tip>
            <Tip text={TT('บันทึกเกณฑ์นี้ในเครื่องนี้และแสดงผลทันที ผู้ใช้รายอื่นไม่ได้รับผลกระทบ')}>
              <span className="inline-flex">
                <Button
                  className="bg-[var(--yl)] text-white hover:bg-[#A30A23]"
                  disabled={!!(bandsErr || redErr)}
                  aria-disabled={!!(bandsErr || redErr)}
                  onClick={apply}
                >
                  {TT('ใช้เกณฑ์นี้')}
                </Button>
              </span>
            </Tip>
          </>
        }
      >
        {/* sub line + "i" (click toggles the note — hover alone fails on touch screens) */}
        <div className="mb-[10px] flex flex-wrap items-center gap-[6px] text-[13px] text-[color:var(--t2)]">
          <span>
            {TT('ปีงบ')} {S.fy} · {TT('เทียบ capacity ต่อคนของเดือนนั้น')}
          </span>
          <Tip text={infoTip}>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-[22px] w-[22px] rounded-full"
              aria-label={TT('ข้อมูลเกณฑ์สี')}
              aria-pressed={info}
              onClick={() => setInfo((x) => !x)}
            >
              <InfoIcon size={14} />
            </Button>
          </Tip>
        </div>

        {/* (1) */}
        {info && (
          <p className="mb-[10px] rounded-[6px] bg-[var(--cd2)] p-[10px] text-[12px] leading-[1.6] text-[color:var(--t2)]">{infoTip}</p>
        )}

        {/* (2) */}
        <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[10px]">
          {rows.map(([cls, label], i) => {
            const c = BAND_COLORS[cls] ?? BAND_COLORS.b1!;
            return (
              <div key={cls} className="flex items-center justify-between gap-[12px] py-[3px] text-[12.5px]">
                <span className="flex min-w-0 items-center gap-[8px]">
                  <span className="inline-block h-[14px] w-[22px] shrink-0 rounded-[3px]" style={{ background: c.bg, border: `1px solid ${c.text}` }} />
                  <span>
                    {TT(NAMES[i] ?? '')} · {TT(MEANINGS[i] ?? '')}
                  </span>
                </span>
                <span className="shrink-0 font-mono">{label}%</span>
              </div>
            );
          })}
        </div>

        {/* (3) */}
        <p className="mb-[8px] text-[13px] font-bold">{TT('ขอบเขตทั้ง 5 ตัว')}</p>
        {/* (4) */}
        <div className="grid grid-cols-5 gap-[8px]">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="min-w-0">
              <label htmlFor={`band-${i + 1}`} className="mb-[4px] block text-[11px] text-[color:var(--t2)]">
                {TT('ตัวที่')} {i + 1}
              </label>
              <Input
                id={`band-${i + 1}`}
                type="text"
                inputMode="decimal"
                value={vt[i] ?? ''}
                aria-invalid={!!bandsErr}
                onChange={(e) => setBand(i, e.target.value)}
                className={`h-[34px] text-center text-[13px] ${bandsErr ? 'border-[color:var(--rd)]' : ''}`}
              />
            </div>
          ))}
        </div>
        {/* (5) */}
        {bandsErr ? (
          <p className="mt-[6px] text-[12px] text-[color:var(--rd)]">
            {TT('ค่าไม่ถูกต้อง')} — {TT(bandsErr)}
          </p>
        ) : (
          <p className="mt-[6px] text-[12px] text-[color:var(--t3)]">
            {TT('ระบุเรียงจากน้อยไปมาก · ค่าตั้งต้น 50, 75, 90, 105, 120')}
          </p>
        )}

        {/* (6) */}
        <p className="mb-[8px] mt-[12px] text-[13px] font-bold">{TT('กรอบแดง (เกณฑ์ชั้น 1)')}</p>
        {/* (7) */}
        <div className="flex flex-wrap items-center gap-[12px] sm:flex-nowrap">
          <div className="min-w-0 flex-1">
            <label htmlFor="band-red" className="block text-[13px] font-bold">
              {TT('ขึ้นกรอบแดงเมื่อต่ำกว่า')}
            </label>
            <p className="text-[11.5px] leading-[1.5] text-[color:var(--t3)]">
              {TT('ระบุเป็น % ของ capacity · 100 = แจ้งเตือนเมื่อแผนต่ำกว่า capacity เต็มของเดือนนั้น')}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-[6px]">
            <Input
              id="band-red"
              type="text"
              inputMode="decimal"
              aria-label={TT('ขึ้นกรอบแดงเมื่อต่ำกว่า')}
              aria-invalid={!!redErr}
              value={redTxt}
              onChange={(e) => setRed(e.target.value)}
              className={`h-[34px] w-[80px] text-center text-[13px] ${redErr ? 'border-[color:var(--rd)]' : ''}`}
            />
            <span className="text-[13px]">%</span>
          </div>
        </div>
        {/* (8) */}
        {redErr && (
          <p className="mt-[6px] text-[12px] text-[color:var(--rd)]">
            {TT('ค่าไม่ถูกต้อง')} — {TT(redErr)}
          </p>
        )}
        {/* (9) */}
        {redAt !== 100 && !bandsErr && !redErr && (
          <p className="mt-[6px] text-[12px] font-medium text-[color:var(--or)]">
            {TT('ค่านี้เป็นเกณฑ์ชั้น 1 ของทั้งแอป · รายการในหน้า Validation การ์ด และกรอบแดงจะเปลี่ยนตามพร้อมกัน')}
          </p>
        )}
      </Modal>
    </TooltipProvider>
  );
}
