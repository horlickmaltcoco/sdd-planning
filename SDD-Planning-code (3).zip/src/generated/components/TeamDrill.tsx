// Session 1-09 Part C · C4. TeamDrill — one team in one month (opened from Validation tier 2).
// Read-only: explains quota + OT, the plan, leave, and each person's tier-1 state.
import { useMemo } from 'react';
import { MONTHS } from '@generated/config';
import { fmt, fyMonthLabel, pct, pctTxt, statusOf, uLabel, uSuf } from '@generated/engine';
import { pillOf, tier1State, type Plan, type Tier2Row } from '@generated/engine/part-c';
import { TT } from '@generated/i18n';
import type { Model } from '@generated/model';
import type { Settings } from '@generated/model/types';
import { Modal } from '@generated/components/MPShared';
import { BandCell, KVRow, PillSpan, Tier1Pill, toneOfPillCls } from '@generated/components/Tier1Pill';

interface TeamDrillProps {
  S: Settings;
  P: Plan;
  row: Tier2Row;
  u: 'Hrs' | 'MD' | '%';
  close: () => void;
  model: Model;
  id?: string;
}

export function TeamDrill({ S, P, row, u, close, model, id }: TeamDrillProps) {
  const tm = P.teams.find((t) => t.team === row.team);
  const people = tm?.people ?? [];
  const cap = model.capPerOf(S.fy, row.mi);
  const st = statusOf(row.dif, S.teamTolerance ?? 0);
  const pl = pillOf(st);
  const suf = uSuf(u) ? ` ${TT(uSuf(u))}` : '';
  const A = row.allow;

  const deps = useMemo(
    () => ({
      EMPWIN: model.EMPWIN,
      ASSIGN: model.ASSIGN,
      FYCODE: model.FYCODE,
      PEOPLE_BY_EMP: model.PEOPLE_BY_EMP,
      PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
    }),
    [model],
  );

  const HEAD = ['พนักงาน', 'Role', 'แผน', '% capacity', 'เกณฑ์ชั้น 1'];

  return (
    <Modal
      id={id}
      show
      onClose={close}
      size="large"
      pill={<PillSpan tone={toneOfPillCls(pl.cls)}>{TT(pl.txt)}</PillSpan>}
      title={`${TT('ทีม')} ${row.team} · ${MONTHS[row.mi]}`}
      sub={`${row.grp} · ${fyMonthLabel(S.fy, row.mi)} · ${TT('วันทำงาน')} ${P.WD[row.mi] ?? '–'} ${TT('วัน')}`}
    >
      <div className="mb-[14px] rounded-[8px] border border-[color:var(--bd)] bg-[var(--cd2)] p-[12px]">
        <KVRow label={`${TT('วันทำงาน ×')} ${S.hoursPerDay} ${TT('ชม.')}`} value={`${fmt(cap, cap, 'Hrs')} ${TT('ชม./คน')}`} />
        <KVRow
          label={TT('× จำนวนคน')}
          value={`${row.head} ${TT('คน')}${row.active !== row.head ? ` (${TT('มีค่าจริง')} ${row.active} ${TT('คน')})` : ''}`}
        />
        <KVRow label={TT('= โควตา MP')} value={`${fmt(row.quota, A, u)}${suf}`} />
        <KVRow tone="or" label={TT('+ OT Plan')} value={row.otMiss ? '—' : `${fmt(row.otPlan || 0, A, u)}${suf}`} />
        <KVRow label={TT('= โควตา+OT ที่วางแผนได้')} value={`${fmt(A, A, u)}${suf}`} />
        <KVRow hi label={TT('แผนที่กรอกมา')} value={`${fmt(row.planSum, A, u)}${suf} · ${fmt(row.dif, A, u, { sign: true })}`} />
        <KVRow
          label={TT('ในนั้นเป็นวันลา')}
          value={
            row.leave ? (
              <span className="text-[color:var(--or)]">
                {fmt(row.leave, A, u)}
                {suf} ({pctTxt(row.leave, row.planSum)}% {TT('ของแผน')})
              </span>
            ) : (
              <span className="text-[color:var(--t3)]">{TT('ไม่มี')}</span>
            )
          }
        />
        <KVRow
          label={TT('แผนเฉพาะงาน (ตัดวันลา)')}
          value={`${fmt(row.work, A, u)}${suf} · ${pct(row.work, row.quota)}% ${TT('ของโควตา')}`}
        />
      </div>

      <p className="mb-[8px] text-[14px] font-bold leading-[1.4]">
        {TT('แผนรายคนในเดือนนี้ · เกณฑ์ชั้น 1 = ไม่น้อยกว่า')} {fmt(cap, cap, 'Hrs')} {TT('ชม.')} · {TT('แสดงเป็น')}{' '}
        {TT(uLabel(u, TT('capacity รายคน')))}
      </p>
      <div className="overflow-x-auto rounded-[8px] border border-[color:var(--bd)]">
        <table className="w-full min-w-[620px] border-collapse text-[12px]">
          <thead className="bg-[var(--cd2)]">
            <tr>
              {HEAD.map((h, i) => (
                <th
                  key={h}
                  className={`whitespace-nowrap px-[8px] py-[6px] font-semibold text-[color:var(--t2)] ${i === 2 || i === 3 ? 'text-right' : 'text-left'}`}
                >
                  {TT(h)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {people.map((pp) => {
              const v = pp.m[row.mi] ?? 0;
              const st1 = tier1State(row.team, pp, S.fy, row.mi, cap, S, deps);
              return (
                <tr key={pp.key || pp.n} className="border-t border-[color:var(--bd)]">
                  <td className="px-[8px] py-[6px] text-left font-bold">{pp.n}</td>
                  <td className="px-[8px] py-[6px] text-left text-[color:var(--t2)]">{pp.role}</td>
                  <td className="px-[8px] py-[6px] text-right font-mono font-bold">{v ? fmt(v, cap, u) : '–'}</td>
                  <td className="px-[8px] py-[6px] text-right">
                    <BandCell v={v} cap={cap} bands={S.bands} />
                  </td>
                  <td className="px-[8px] py-[6px] text-left">
                    <Tier1Pill s={st1} cap={cap} u={u} />
                  </td>
                </tr>
              );
            })}
            <tr className="border-t-2 border-[color:var(--bd)] bg-[var(--cd2)] font-bold">
              <td className="px-[8px] py-[6px] text-left">{TT('รวม')}</td>
              <td className="px-[8px] py-[6px]" aria-hidden="true">{'\u00a0'}</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{fmt(row.planSum, A, u)}</td>
              <td className="px-[8px] py-[6px] text-right font-mono">{pct(row.planSum, row.quota)}%</td>
              <td className="px-[8px] py-[6px]" aria-hidden="true">{'\u00a0'}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </Modal>
  );
}
