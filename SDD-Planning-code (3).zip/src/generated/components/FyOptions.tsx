// Session 1-15 · the fiscal-year dropdown options, unchanged in content and order, with a small
// "ยังไม่มีข้อมูล" badge beside each year that is not prepared. No action lives in this dropdown.
import * as E from '@generated/engine';
import { TT } from '@generated/i18n';

export function fyOptions(fyList: string[], unprep?: (fy: string) => boolean) {
  return E.optFY(fyList).map((o) =>
    unprep?.(o.v)
      ? {
          v: o.v,
          t: (
            <span className="inline-flex items-center gap-[6px]">
              {o.t}
              <span className="rounded-[4px] border border-[color:var(--bd)] px-[5px] py-[0.5px] text-[10.5px] font-medium text-[color:var(--t3)]">
                {TT('ยังไม่มีข้อมูล')}
              </span>
            </span>
          ),
          title: o.t,
        }
      : o,
  );
}
