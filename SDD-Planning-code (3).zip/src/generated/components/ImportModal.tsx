// Session 1-05 Part B — ImportModal: shared file import flow for MP / OT boards
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '@components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@components/ui/tooltip';
import { Loader2 } from 'lucide-react';
import { Modal, BoardTag } from '@generated/components/MPShared';
import {
  fileSpecOf,
  parseFileAsync,
  diffFile,
  exportedAtLabel,
  IMPORT_SPEC,
  type DiffResult,
  type ParsedFile,
} from '@generated/lib/file-mechanism';
import { readFreshCp, readFreshMp, readFreshOt } from '@generated/server/read-fresh';
import { MONTHS, TYPES_WITHOUT_TASK1 } from '@generated/config';
import { ownsMonth, personByName, teamOfMonth } from '@generated/engine/part-b';
import { ImportZeroBlock } from '@generated/components/ImportZeroBlock';
import { isProjectType, matchLabel, norm } from '@generated/lib/mp-fields';
import { isPastMonth, n1, sign } from '@generated/engine';
import { md2 } from '@generated/lib/cp';
import { toLocalStamp } from '@generated/lib/parse';
import { resolveCpRows } from '@generated/lib/cp-import';
import type { Settings } from '@generated/model/types';
import type { MpDerived } from '@generated/model/types';
import { cn } from '@lib/utils';
import { TT } from '@generated/i18n';

// ─── Types ────────────────────────────────────────────────────────────────────

/** C1 step 2–4 — everything the page's apply function needs to build and run the write plan. */
export interface ImportApplyCtx {
  fileRows: ParsedFile['rows'];
  diff: DiffResult;
  /** Decision-D cells the modal already excluded (MP only) — for the toast suffix. */
  skipOther: any[];
  /** The scope as re-read immediately before writing. */
  scopeRows: any[];
  onProgress: (done: number, total: number) => void;
}

interface ImportModalProps {
  which: 'mp' | 'ot' | 'cp';
  scope: any[]; // current in-scope rows from the page
  scopeTeam?: string; // MP only
  /** OT only · the team list. A file team IN this list but with no row this FY gets its own message. */
  teamList?: string[];
  scopeFy: string | number;
  /**
   * Builds the plan, runs it, updates page state and shows the page's success toast.
   * Must throw (ideally PartialWriteError) after reloading from the board on failure.
   */
  apply: (ctx: ImportApplyCtx) => Promise<void>;
  S: Settings;
  T: (msg: string) => void;
  close: () => void;
  /** Step ① — the SAME export the page's Export button runs, same board and scope. */
  onExport: () => void;
  model?: {
    TYPES: string[];
    ROLES: string[];
    /** MP only · active System labels of board 04. */
    SYSTEMS?: string[];
    /** MP only · Task2 labels of board 04 (optional column). */
    TASK2S?: string[];
    GROUPS: string[];
    COMPANIES: string[];
    PEOPLE_BY_NAME: Record<string, any>;
    ASSIGN: any[];
    EMPWIN?: Record<string, any>;
    FYCODE?: Record<number, string[]>;
  };
}

interface LoadedFile {
  name: string;
  meta: Record<string, string>;
  rows: ParsedFile['rows'];
  /** Company Plan only · unreadable or negative Plan MD cells (hard stop). */
  badNum: string[];
  /** Header cells of the file (which optional columns it carries). */
  cols: string[];
}

/**
 * A board read can fail for two very different reasons and the user needs different actions.
 * This app authenticates with a per-request session token; unlike the external-token path that
 * one is NOT auto-refreshed on 401, so an expired session surfaces as UNAUTHENTICATED / 401 and
 * is only fixed by reloading the app — retrying the upload will keep failing.
 */
function readErrText(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e);
  if (/UNAUTHENTICATED|401|session token/i.test(msg)) {
    return TT('หมดเวลาเชื่อมต่อกับ monday · โปรดรีเฟรศหน้านี้ (F5) แล้วนำเข้าไฟล์อีกครั้ง');
  }
  return TT('โหลดข้อมูลจากบอร์ดไม่สำเร็จ · ลองอีกครั้ง');
}

// Defect 2 fix: display null as "—", 0 as "0"
function displayVal(v: number | null): string {
  if (v == null) return '—';
  return n1(v);
}

/**
 * A listed change must never read as "0.00" / "-0.00" / "+0.0". When the page's usual format would
 * round the difference to zero (|d| below half its last digit), show enough digits to be true.
 */
function truthfulDiff(d: number, half: number, fmt: (v: number) => string): string {
  if (d === 0 || Math.abs(d) >= half) return fmt(d);
  const dec = Math.min(20, Math.ceil(-Math.log10(Math.abs(d))) + 2);
  const txt = Math.abs(d).toFixed(dec).replace(/0+$/, '').replace(/\.$/, '');
  return (d > 0 ? '+' : '-') + txt;
}

/** Company Plan · Plan MD at full precision (never rounded in the comparison table). */
function cpVal(v: number | null): string {
  return v == null ? '—' : String(v);
}

// ─── ImportHowTo ──────────────────────────────────────────────────────────────

function ImportHowTo({
  cellsOnly,
  board,
  ot,
  onClose,
}: {
  cellsOnly: boolean;
  board: string;
  /** OT is the only board with teams; every other board says "แถว". */
  ot: boolean;
  onClose: () => void;
}) {
  const steps = cellsOnly
    ? [
        {
          h: TT('กด Export ก่อนแก้ทุกครั้ง'),
          p: TT('ไฟล์ที่ได้มี Item ID ติดมาทุกแถว และประทับเวลาที่ export ไว้ในไฟล์'),
          n: TT('ไม่ต้องไปหาไฟล์ที่ใครเก็บไว้ — กด Export เมื่อไหร่ก็ได้ไฟล์ที่ตรงกับบอร์ด ณ ตอนนั้นเสมอ'),
        },
        {
          h: TT('แก้ตัวเลขในไฟล์นั้น'),
          p: TT('แก้ช่องเดือนได้ตามปกติ · คอลัมน์ Item ID ห้ามลบและห้ามแก้'),
          n: `${ot ? TT('เพิ่มหรือลบทีมทำที่บอร์ด') : TT('เพิ่มหรือลบแถวทำที่บอร์ด')} ${board} ${TT('เท่านั้น')} · ${TT('แถวที่เพิ่มหรือตัดออกในไฟล์ ระบบจะข้ามให้')}`,
        },
        {
          h: TT('อัปโหลดไฟล์กลับเข้าระบบ'),
          p: TT('ระบบเทียบให้ทีละช่อง แล้วบอกว่าตัวเลขไหนเปลี่ยน อยู่แถวไหน จากเท่าไหร่เป็นเท่าไหร่'),
          n: TT('ถ้ามีแถวที่ถูกแก้บนบอร์ดหลังคุณ export หรือแก้เดือนที่ผ่านมาแล้ว ต้องติ๊กรับทราบก่อนถึงกดต่อได้'),
        },
        {
          h: TT('รอบถัดไปกด Export ใหม่'),
          p: TT('บอร์ดคือความจริง ไฟล์คือภาพถ่ายของบอร์ด ณ เวลานั้น · ไม่ต้องเก็บไฟล์ไว้ที่ไหน'),
          n: TT('ยิ่งไฟล์เก่า ยิ่งมีโอกาสทับงานที่คนอื่นแก้ไปแล้ว'),
        },
      ]
    : [
        {
          h: TT('กด Export ก่อนแก้ทุกครั้ง'),
          p: TT('ไฟล์ที่ได้มี Item ID ติดมาทุกแถว และป���ะทับเวลาที่ export ไว้ในไฟล์'),
          n: TT('ไม่ต้องไปหาไฟล์ที่ใครเก็บไว้ — กด Export เมื่อไหร่ก็ได้ไฟล์ที่ตรงกับบอร์ด ณ ตอนนั้นเสมอ'),
        },
        {
          h: TT('แก้ตัวเลขในไฟล์นั้น'),
          p: TT('แก้ช่องเดือนได้ตามปกติ · คอลัมน์ Item ID ห้ามลบและห้ามแก้'),
          n: TT('ถ้าจะเพิ่มงานใหม่ด้วยการ copy แถวเดิม ให้ลบเลขในช่อง Item ID ของแถวที่ copy ออกก่อน'),
        },
        {
          h: TT('อัปโหลดไฟล์กลับเข้าระบบ'),
          p: TT('ระบบเทียบให้ทีละช่อง แล้วบอกว่าตัวเลขไหนเปลี่ยน อยู่แถวไหน จากเท่าไหร่เป็นเท่าไหร่'),
          n: TT('ถ้ามีการลบแถว หรือมีแถวที่ถูกแก้บนบอร์ดหลังคุณ export ต้องติ๊กรับทราบก่อนถึงกดต่อได้'),
        },
        {
          h: TT('รอบถัดไปกด Export ใหม่'),
          p: TT('บอร์ดคือความจริง ไฟล์คือภาพถ่ายของบอร์ด ณ เวลานั้น · ไม่ต้องเก็บไฟล์ไว้ที่ไหน'),
          n: TT('ยิ่งไฟล์เก่า ยิ่งมีโอกาสทับงานที่คนอื่นแก้ไปแล้ว'),
        },
      ];

  return (
    <Modal
      show
      onClose={onClose}
      size="medium"
      pill={<BoardTag board={board === 'OT Plan' ? 'OT Plan' : board === 'Company Plan' ? 'Company Plan' : 'MP Plan'} />}
      title={TT('วิ��ีนำเข้าไฟล์แผน')}
      sub={TT('ทำตาม 4 ขั้นนี้ทุกรอบ · เอกสารฉบับเต็มอยู่ใน monday doc')}
    >
      <div className="space-y-5">
        {steps.map((s, idx) => (
          <div key={`step-${idx}`} className="flex gap-3">
            <span className="mt-0.5 flex h-[22px] w-[22px] flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-[12px] font-bold text-primary">
              {idx + 1}
            </span>
            <div>
              <p className="text-[13px] font-semibold text-foreground">{s.h}</p>
              <p className="mt-0.5 text-[12.5px] text-foreground">{s.p}</p>
              <p className="mt-0.5 text-[11.5px] italic text-muted-foreground">{s.n}</p>
            </div>
          </div>
        ))}
      </div>
    </Modal>
  );
}

// ─── Mini table ────────────────────────────────────────────────────────────────

/** Company Plan · a hard-stop list of Group · Company · MonthYear keys (at most 8 shown). */
function KeyList({ title, keys }: { title: string; keys: string[] }) {
  return (
    <div className="mt-1 text-[#7A271A]">
      <p className="font-semibold">{title}</p>
      <ul className="mt-1 list-disc pl-5 text-[11.5px]">
        {keys.slice(0, 8).map((k) => (
          <li key={k}>{k}</li>
        ))}
      </ul>
      {keys.length > 8 && (
        <p className="mt-1 text-[11px]">
          {TT('และอีก')} {keys.length - 8} {TT('แถว')}
        </p>
      )}
    </div>
  );
}

function MiniTable({ cols, rows, stickyHead }: { cols: string[]; rows: (string | React.ReactNode)[][]; stickyHead?: string }) {
  return (
    <table className="mt-2 w-full border-collapse text-[11px]">
      <thead className={stickyHead ? cn('sticky top-0', stickyHead) : undefined}>
        <tr>
          {cols.map((c) => (
            <th key={c} className="border-b border-border/60 px-2 py-0.5 text-left font-semibold text-muted-foreground">
              {c}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, i) => (
          <tr key={`row-${i}`} className="border-b border-border/30">
            {row.map((cell, j) => (
              <td key={`cell-${i}-${j}`} className="px-2 py-0.5">
                {cell}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ─── Diff summary row ──────────────────────────────────────────────────────────

function DiffRow({ label, value, highlight }: { label: string; value: string; highlight?: 'orange' | 'green' | 'red' | 'none' }) {
  const colours: Record<string, string> = {
    orange: 'font-bold text-[#B54708]',
    green: 'font-bold text-[#027A48]',
    red: 'font-bold text-[#B42318]',
    none: 'text-foreground',
  };
  return (
    <div className="flex items-center justify-between gap-4 py-1 text-[12.5px]">
      <span className="text-muted-foreground">{label}</span>
      <span className={colours[highlight ?? 'none']}>{value}</span>
    </div>
  );
}

// ─── Main ImportModal ──────────────────────────────────────────────────────────

export function ImportModal({
  which,
  scope,
  scopeTeam,
  teamList,
  scopeFy,
  apply,
  S,
  T,
  close,
  onExport,
  model,
}: ImportModalProps) {
  const sp = IMPORT_SPEC[which];
  const fs = useMemo(() => fileSpecOf(which), [which]);
  const fyStr = String(scopeFy || S.fy);

  // State
  const [file, setFile] = useState<LoadedFile | null>(null);
  const [err, setErr] = useState('');
  const [okDelete, setOkDelete] = useState(false);
  const [okConflict, setOkConflict] = useState(false);
  const [okPast, setOkPast] = useState(false);
  // Session 1-25 · tick for new-row months zeroed by Decision D
  const [okZero, setOkZero] = useState(false);
  const [okFinal, setOkFinal] = useState(false);
  const [help, setHelp] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(0);
  const [total, setTotal] = useState(0);
  const [fresh, setFresh] = useState<{ rows: any[]; allIds: Set<string> } | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  // C1 step 1 — set when the board changed while this dialog was open.
  const [stale, setStale] = useState('');
  // OT only · file Team values that resolve to no row of this FY on the board ('(ว่าง)' = empty).
  const [otUnknownTeam, setOtUnknownTeam] = useState<string[]>([]);
  // OT · a real team (in the team list) that simply has no row for this FY yet.
  const [otNoRowTeam, setOtNoRowTeam] = useState<string[]>([]);
  // OT only · Team values that appear more than once in this file.
  const [otDupTeam, setOtDupTeam] = useState<string[]>([]);
  const [otFilledIds, setOtFilledIds] = useState<string[]>([]);
  // Company Plan · rows without Item ID resolved by Group + Company + MonthYear (Session 1-12).
  const [cpUnknownKey, setCpUnknownKey] = useState<string[]>([]);
  const [cpDupKey, setCpDupKey] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ─── scope re-read (shared by readFile and the confirm re-check) ─────────────

  /**
   * Reads the scope this board needs for the diff, BY ID: the union of every non-empty Item ID
   * in the file and the ids of the in-memory page scope. No dropdown filter is involved.
   */
  const readScope = useCallback(
    async (fileRows: ParsedFile['rows']) => {
      const fileIds = fileRows.map((r) => String(r.id ?? '').trim()).filter(Boolean);
      const scopeIds = scope.map((r: any) => String(fs.id(r) ?? '').trim()).filter(Boolean);
      const ids = [...new Set([...fileIds, ...scopeIds])];

      let rows: any[] = [];
      let allIds: string[] = [];

      if (which === 'mp' && scopeTeam) {
        const r = await readFreshMp({ data: { team: scopeTeam, fy: fyStr, ids } });
        rows = r.rows;
        allIds = r.allIds;
      } else if (which === 'ot') {
        const r = await readFreshOt({ data: { fy: fyStr, ids } });
        rows = r.rows;
        allIds = r.allIds;
      } else if (which === 'cp') {
        const r = await readFreshCp({ data: { fy: fyStr, ids } });
        rows = r.rows;
        allIds = r.allIds;
      }

      // Last updated arrives as raw ISO (UTC) and is localised HERE, on the viewer's machine, so
      // the local stamp and the local EXPORTED_AT are read in the same zone.
      rows = rows.map((r) => ({ ...r, editedAt: toLocalStamp(String(r?.editedAt ?? '')) }));

      return { rows, allIds: new Set(allIds.map((x) => String(x))) };
    },
    [which, scopeTeam, fyStr, scope, fs],
  );

  /** Fingerprint of a scope read: id set + every row's Last updated. */
  const sigOf = useCallback(
    (rows: any[]) =>
      rows
        .map((r) => `${String(fs.id(r))}:${String(r.editedAt ?? '')}`)
        .sort()
        .join('|'),
    [fs],
  );

  // ─── readFile ────────────────────────────────────────────────────────────────

  const readFile = useCallback(
    async (f: File) => {
      setErr('');
      setOtUnknownTeam([]);
      setOtNoRowTeam([]);
      setOtDupTeam([]);
      setOtFilledIds([]);
      setCpUnknownKey([]);
      setCpDupKey([]);
      setLoading(true);
      
      try {
        const result = await parseFileAsync(fs, f);

        if ('err' in result) {
          setErr(result.err);
          setFile(null);
          setLoading(false);
          return;
        }
        if (result.rows.length === 0) {
          setErr(TT('ไฟล์นี้ไม่มีแถวข��อมูล'));
          setFile(null);
          setLoading(false);
          return;
        }

        // Rule 19 — the diff always runs against a fresh read of the board.
        try {
          setFresh(await readScope(result.rows));
          setStale('');
        } catch (e) {
          console.error('Failed to re-read board:', e);
          setErr(readErrText(e));
          setFile(null);
          setLoading(false);
          return;
        }

        // Reset acks
        setOkDelete(false);
        setOkConflict(false);
        setOkPast(false);
        setOkZero(false);
        setOkFinal(false);
        // OT only · Team → Item ID. Team + FY is the natural key of board 05 and the page scope
        // holds exactly this FY's teams. A row that already carries an Item ID (an exported file)
        // is left alone. Empty or unknown Team → no id is invented; the value is listed and the
        // import is hard-stopped. The info key for Team is the single letter 't'.
        if (which === 'ot') {
          const unknown: string[] = [];
          // A Team listed twice in this file. Checked first, so a template user is told the TEAM
          // instead of an Item ID they never typed (the Item ID duplicate check still runs).
          const seenTeam = new Set<string>();
          const dupTeam: string[] = [];
          // Item IDs this loop filled in from Team (the user never typed them).
          const filled: string[] = [];
          for (const row of result.rows) {
            const t0 = String(row._?.t ?? '').trim();
            if (t0) {
              if (seenTeam.has(t0)) {
                if (!dupTeam.includes(t0)) dupTeam.push(t0);
              } else {
                seenTeam.add(t0);
              }
            }
            if (String(row.id ?? '').trim()) continue;
            const team = String(row._?.t ?? '').trim();
            const hit = team ? scope.find((s: any) => String(s?.t ?? '').trim() === team) : undefined;
            const hitId = String(hit?.id ?? '').trim();
            if (hitId) {
              row.id = hitId;
              filled.push(hitId);
            } else {
              unknown.push(team || '(ว่าง)');
            }
          }
          // A team that IS in the team list but has no row this FY is a different problem from a
          // name that is not a team at all — split them so each gets its own message.
          const known = new Set((teamList ?? []).map((x) => x.trim()));
          setOtNoRowTeam(unknown.filter((t) => known.has(t)));
          setOtUnknownTeam(unknown.filter((t) => !known.has(t)));
          setOtDupTeam(dupTeam);
          setOtFilledIds(filled);
        }
        if (which === 'cp') {
          const r = resolveCpRows(result.rows, scope);
          setCpUnknownKey(r.unknown);
          setCpDupKey(r.dup);
          setOtFilledIds(r.filled);
        }
        setFile({ name: f.name, meta: result.meta, rows: result.rows, badNum: result.badNum ?? [], cols: result.cols ?? [] });
      } finally {
        setLoading(false);
      }
    },
    [fs, readScope, which, scope, teamList],
  );

  // ─── Pre-computation ──────────────────────────────────────────────────────────

  const scopeRows = fresh?.rows ?? scope;
  const allBoardIds = fresh?.allIds ?? new Set(scope.map((r: any) => fs.id(r)));

  const rawDiff = useMemo<DiffResult | null>(() => {
    if (!file) return null;
    console.log('[ImportModal] Running diffFile with:', scopeRows.length, 'scope rows,', allBoardIds.size, 'board IDs');
    const result = diffFile(fs, file.rows, scopeRows, file.meta.EXPORTED_AT || null, allBoardIds);
    console.log('[ImportModal] Diff result:', {
      cells: result.cells.length,
      rows: result.rows,
      same: result.same,
      add: result.add.length,
      del: result.del.length,
      missing: result.missing.length,
      outScope: result.outScope.length,
    });
    return result;
  }, [file, fs, scopeRows, allBoardIds]);

  // Decision D: skip other-team months (MP only)
  const { d, skipOther } = useMemo(() => {
    if (!rawDiff || !file) return { d: rawDiff, skipOther: [] as any[] };

    if (which !== 'mp' || !scopeTeam || !model) {
      return { d: rawDiff, skipOther: [] as any[] };
    }

    const cells = [...rawDiff.cells];
    const skipped: any[] = [];

    // Filter cells: move other-team cells to skipped
    const kept = cells.filter((c) => {
      if (c.r.empid && !ownsMonth(scopeTeam, c.r.empid, fyStr, c.vi, model.ASSIGN, model.EMPWIN ?? {}, model.FYCODE)) {
        skipped.push(c);
        return false;
      }
      return true;
    });

    // For add rows: check if each month belongs to another team
    const addRows = rawDiff.add.map((g: any) => {
      const pr = model.PEOPLE_BY_NAME ? personByName(g._?.name || '', model.PEOPLE_BY_NAME) : null;
      if (!pr) return g;
      const newV = { ...g.v };
      for (let i = 0; i < 12; i++) {
        const v = g.v[i];
        if (v !== null && !Number.isNaN(v) && v !== 0) {
          if (!ownsMonth(scopeTeam, pr.emp, fyStr, i, model.ASSIGN, model.EMPWIN ?? {}, model.FYCODE)) {
            // Session 1-25 · tagged as a new row + its person, so the preview can say "set to 0" per person
            skipped.push({ lbl: g._?.t1 || '', vi: i, vn: MONTHS[i]!, from: 0, to: v, isNew: true, emp: pr.emp, who: pr.mpname || pr.name || g._?.name || '' });
            newV[i] = null; // zero out in planned add
          }
        }
      }
      return { ...g, v: newV };
    });

    // Recount changed rows
    const changedRows = new Set<string>();
    for (const c of kept) {
      changedRows.add(fs.id(c.r));
    }
    // Session 1-18 · a row whose only change is text is still a changed (written) row.
    for (const t of rawDiff.texts) changedRows.add(fs.id(t.r));
    const rows = changedRows.size;
    const same = Math.max(scopeRows.length - rows - rawDiff.del.length, 0);

    return {
      // A flagged row whose only changed cells belong to another team's months is not written
      // by this import, so it is not a conflict either (same rule as diffFile: written rows only).
      d: {
        ...rawDiff,
        cells: kept,
        add: addRows,
        rows,
        same,
        conflict: rawDiff.conflict.filter((r: any) => changedRows.has(fs.id(r))),
      },
      skipOther: skipped,
    };
  }, [rawDiff, which, scopeTeam, fyStr, model, fs, scopeRows]);

  // Session 1-25 · the same Decision D cells, split by what actually happens to them:
  // new rows → created as 0 (own block + tick); existing rows → the file value is not written (info box).
  const zeroNew = useMemo(() => skipOther.filter((c: any) => c.isNew), [skipOther]);
  const skipExisting = useMemo(() => skipOther.filter((c: any) => !c.isNew), [skipOther]);

  const meta = file?.meta ?? {};

  const wrongKind = !!(file && meta.KIND && meta.KIND !== sp.kind);
  const wrongTeam = !!(file && meta.TEAM && scopeTeam && meta.TEAM !== scopeTeam);
  const wrongFy = !!(file && meta.FY && scopeFy && String(meta.FY) !== String(scopeFy));
  // MP only · one team per file: every DATA row whose Team column names a team other than the
  // page's. Scans ALL file rows (edited export rows too, not just new ones). An EMPTY Team cell
  // makes no claim and is allowed — the page's team applies as before. Info keys are lowercase.
  const wrongRowTeam = useMemo(() => {
    const out: { label: string; team: string }[] = [];
    if (which !== 'mp' || !file || !scopeTeam) return out;
    for (const row of file.rows) {
      const team = row._?.team || '';
      if (team && team !== scopeTeam) {
        out.push({ label: `${row._?.t1 || ''} · ${row._?.name || ''}`, team });
      }
    }
    return out;
  }, [which, file, scopeTeam]);
  const dupStop = !!(d && d.dup.length);
  const badIdStop = !!(d && d.badId.length);
  const badNumStop = !!(file && file.badNum.length > 0);

  // badNew validation
  const badNew = useMemo<string[]>(() => {
    if (!d || !file) return [];
    const bad: string[] = [];
    for (const g of d.add) {
      if (which === 'mp') {
        const type = g._?.type || '';
        const t1 = g._?.t1 || '';
        const name = g._?.name || '';
        const label = `${t1} · ${name}`;
        if (!type || (model?.TYPES && !model.TYPES.includes(type))) {
          bad.push(`${label} (Type)`);
        } else if (!t1 && !TYPES_WITHOUT_TASK1.includes(type)) {
          // Session 1-21 · Task1 may be empty only for the Types in TYPES_WITHOUT_TASK1.
          bad.push(`${label} (Task1)`);
        } else if (!name) {
          bad.push(`${label} (Name)`);
        }
      }
    }
    return bad;
  }, [d, file, which, model]);

  // Session 1-18 · existing rows: a Type / Role the file would WRITE must be a board label, exactly as
  // for new rows. (Empty file cells are never in d.texts — they change nothing.)
  const badText = useMemo<string[]>(() => {
    if (!d || which !== 'mp') return [];
    const out: string[] = [];
    for (const t of d.texts) {
      // Role / System labels are checked by labelStop (by norm, with "#<line>" messages).
      const list = t.field === 'type' ? model?.TYPES : null;
      if (list && !list.includes(t.to)) {
        const [l0, l1] = fs.label(t.r);
        out.push(`${l1} · ${l0} (${t.col} "${t.to}")`);
      }
    }
    return out;
  }, [d, which, model, fs]);

  // Session 1-18 · Fy Year, on EVERY file row (new or existing), for any file whose spec carries it.
  // Empty → blocks; a year other than the page's → blocks. The file's value is never written.
  const fyRows = useMemo(() => {
    const empty: string[] = [];
    const other: { label: string; fy: string }[] = [];
    if (!file || !fs.info.some(([, f]) => f === 'fy')) return { empty, other };
    for (const row of file.rows) {
      const v = String(row._?.fy ?? '').trim();
      const label = `${row._?.t1 || ''} · ${row._?.name || ''}`;
      if (!v) empty.push(label);
      else if (v !== fyStr) other.push({ label, fy: v });
    }
    return { empty, other };
  }, [file, fs, fyStr]);
  const fileFys = [...new Set(fyRows.other.map((r) => r.fy))].join(', ');

  // System / Role on EVERY file row (new or existing): a value must match a board label by norm, or be
  // empty. Role: active labels; a deactivated Role passes only when the existing row already holds it.
  // When the file has the System column, every 01.Project row needs a System; without the column,
  // existing rows keep theirs and only a NEW 01.Project row stops.
  const labelStop = useMemo<string[]>(() => {
    if (!file || which !== 'mp' || !model) return [];
    const out: string[] = [];
    const hasSystem = file.cols.includes('System');
    const byId = new Map<string, any>(scopeRows.map((r: any) => [String(r.id), r]));
    for (const row of file.rows) {
      const ln = `#${row.line ?? '—'}`;
      const old = row.id ? byId.get(String(row.id)) : null;
      const sys = String(row._?.system ?? '').trim();
      const role = String(row._?.role ?? '').trim();
      if (hasSystem && sys && !matchLabel(sys, model.SYSTEMS ?? [])) out.push(`${ln} · System = “${sys}”`);
      // Task2 is optional: blank is fine; a value must match a board label (or what the row already holds).
      const t2 = String(row._?.task2 ?? '').trim();
      if (t2 && !matchLabel(t2, model.TASK2S ?? []) && !(old && norm(old.task2) === norm(t2))) out.push(`${ln} · Task2 = “${t2}”`);
      if (role && !matchLabel(role, model.ROLES) && !(old && norm(old.role) === norm(role))) out.push(`${ln} · Role = “${role}”`);
      const type = String(row._?.type ?? '').trim() || String(old?.type ?? '');
      if (isProjectType(type) && !sys && (hasSystem || !old)) out.push(`${ln} · System ว่าง (01.Project)`);
    }
    return out;
  }, [file, which, model, scopeRows]);

  const hardStop =
    labelStop.length > 0 ||
    badText.length > 0 ||
    fyRows.empty.length > 0 ||
    fyRows.other.length > 0 ||
    wrongKind ||
    wrongTeam ||
    wrongFy ||
    wrongRowTeam.length > 0 ||
    otUnknownTeam.length > 0 ||
    otNoRowTeam.length > 0 ||
    otDupTeam.length > 0 ||
    cpUnknownKey.length > 0 ||
    cpDupKey.length > 0 ||
    dupStop ||
    badIdStop ||
    badNumStop ||
    badNew.length > 0;

  // Past cells (Defect 1 fix: derive FROM changedCells, never rescan)
  const pastCells = useMemo<any[]>(() => {
    if (!d || !file) return [];
    const cells: any[] = [];

    // Helper to check if a month index is past
    const monthIsPast = (mi: number) => isPastMonth(fyStr, mi, model?.FYCODE);

    if (which === 'mp' || which === 'ot') {
      // Changed cells that are past months
      for (const c of d.cells) {
        if (monthIsPast(c.vi)) {
          cells.push(c);
        }
      }
      if (!fs.cellsOnly) {
        // Add rows: check each cell value.
        // Session 1-22 · on แผน MP a new row overwrites nothing (its "เดิม 0" is the absence of a row),
        // so new rows never count toward the past-month confirmation there. Only rows that already
        // exist on the board — matched cells above and deleted rows below — count. OT is unchanged.
        for (const g of which === 'mp' ? [] : d.add) {
          for (let i = 0; i < 12; i++) {
            const v = g.v[i];
            if (v !== null && !Number.isNaN(v) && v !== 0 && monthIsPast(i)) {
              const lbl =
                ((g._?.t1 || g._?.team || '') + (g._?.name ? ` · ${g._?.name}` : '') + ` (${TT('แถวใหม่')})`);
              cells.push({ r: null, lbl, vi: i, vn: MONTHS[i]!, from: 0, to: v });
            }
          }
        }
        // Del rows: check each month
        for (const r of d.del) {
          for (let i = 0; i < 12; i++) {
            const v = fs.val(r, i);
            if (v !== null && v !== 0 && monthIsPast(i)) {
              const [name0] = fs.label(r);
              cells.push({ r, lbl: `${name0} (${TT('ลบแถว')})`, vi: i, vn: MONTHS[i]!, from: Number(v), to: 0 });
            }
          }
        }
      }
    } else if (which === 'cp') {
      // Company Plan · one value per row; the month is the row's own month (never c.vi).
      for (const c of d.cells) {
        const mi = (MONTHS as readonly string[]).indexOf(String(c.r?.mo ?? ''));
        if (mi >= 0 && monthIsPast(mi)) cells.push({ ...c, vn: c.r.my });
      }
    }
    return cells;
  }, [d, file, which, fs, fyStr, model]);

  const pastMons = useMemo(() => {
    const seen = new Set<string>();
    const result: string[] = [];
    for (const c of pastCells) {
      if (!seen.has(c.vn)) {
        seen.add(c.vn);
        result.push(c.vn);
      }
    }
    return result;
  }, [pastCells]);

  const blocked =
    hardStop ||
    (!!d && !fs.cellsOnly && d.del.length > 0 && !okDelete) ||
    (!!d && d.conflict.length > 0 && !okConflict) ||
    (pastCells.length > 0 && !okPast) ||
    (zeroNew.length > 0 && !okZero) ||
    !okFinal;

  // ─── Event handlers ──────────────────────────────────────────────────────────

  const handleFile = (f: File) => {
    readFile(f);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) handleFile(f);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // C1 · confirm flow
  const handleConfirm = async () => {
    if (!file || !d || blocked || busy) return;

    // Step 1 — read the scope once more. If anything changed since `fresh` was read, re-diff
    // and stop so the user sees the new numbers before any write happens (rule 19).
    setBusy(true);
    setStale('');
    let latest: { rows: any[]; allIds: Set<string> };
    try {
      latest = await readScope(file.rows);
    } catch (e) {
      console.error('pre-write re-read failed', e);
      setBusy(false);
      setErr(readErrText(e)); // nothing was written — the scope read comes first
      return;
    }

    if (sigOf(latest.rows) !== sigOf(fresh?.rows ?? [])) {
      setFresh(latest); // Part B recomputes from step 1 off this
      setOkDelete(false);
      setOkConflict(false);
      setOkPast(false);
      setOkZero(false);
      setOkFinal(false);
      setStale('ข้อมูลบนบอร์ดเปลี่ยนระหว่างที่เปิดกล่องนี้ · ระบบเทียบใหม่ให้แล้ว โปรดตรวจสอบอีกครั้ง');
      setBusy(false);
      return;
    }

    // Step 2–5 — the page owns plan building, local state and its success toast.
    setDone(0);
    setTotal(0);
    try {
      await apply({
        fileRows: file.rows,
        diff: d,
        skipOther,
        scopeRows: latest.rows,
        onProgress: (dn, tt) => {
          setDone(dn);
          setTotal(tt);
        },
      });
      close();
    } catch (e) {
      // Step 5 — stop at the first failure; the page already reloaded from the board.
      console.error('import apply failed', e);
      const pe = e as { done?: number; total?: number };
      const dn = Number.isFinite(pe?.done) ? Number(pe.done) : done;
      const tt = Number.isFinite(pe?.total) ? Number(pe.total) : total;
      T(
        `${TT('บันทึกไม่ครบ · สำเร็จ')} ${dn} ${TT('จาก')} ${tt} ${TT('รายการ · ระบบโหลดข้อมูลล่าสุดจากบอร์ดแล้ว โปรดกด Export ใหม่แล้วนำเข้าอีกครั้งเพื่อทำส่วนที่เหลือ')}`,
      );
      close();
    } finally {
      setBusy(false);
    }
  };

  // ─── Render ───────────────────────────────────────────────────────────────────

  const ext = sp.ext;
  const extLabel = ext.replace('.', '').toUpperCase();

  // Button label
  const btnLabel = busy
    ? `${TT('กำลังบันทึก')} ${done}/${total} ${TT('รายการ')}`
    : hardStop
      ? TT('ไฟล์นี้ใช้ไม่ได้')
      : blocked
        ? TT('ต้องยืนยันก่อน')
        : TT('ยืนยันนำเข้า →');

  // Company Plan · the diff stores an empty file cell as 0; the table must show it as "—" (clear).
  const fileById = useMemo(
    () => new Map((file?.rows ?? []).map((r) => [String(r.id ?? '').trim(), r] as const)),
    [file],
  );
  // Past-month box · the OLD value is read from the board row itself (empty stays "—", never 0):
  // Company Plan → the row's Plan MD; MP / OT → the row's month cell. Rows without a board row
  // (new MP rows) have nothing to overwrite and keep their 0 as before.
  // Both columns are RAW stored values (no rounding, no separators) on every page — this box says
  // exactly what is lost in an approved month. Empty on the board reads "—", never 0.
  const pastOld = (c: any): string => {
    if (!c.r) return cpVal(c.from ?? null);
    if (which === 'cp') return cpVal(c.r.md ?? null);
    const m = Array.isArray(c.r.m) ? c.r.m[c.vi] : undefined;
    return cpVal(m === undefined ? c.from ?? null : m ?? null);
  };
  // NEW = the file's own value. An MP empty cell is written as 0 (nullAsZero), so it shows the 0
  // that will be written; a row with no file row (a deleted MP row) shows what diffFile writes.
  const pastNew = (c: any): string => {
    const fr = c.r ? fileById.get(String(fs.id(c.r)).trim()) : undefined;
    if (!fr) return cpVal(c.to ?? null);
    const v = fr.v[which === 'cp' ? 0 : c.vi] ?? null;
    if (v == null && fs.nullAsZero) return cpVal(c.to ?? null);
    return cpVal(v);
  };
  const cpFileVal = (r: any): number | null =>
    r ? fileById.get(String(fs.id(r)).trim())?.v[0] ?? null : null;
  const changedCells = d?.cells ?? [];
  const showFirst200 = changedCells.slice(0, 200);

  // Company Plan · cells the file empties (row present, Plan MD blank) — never silent.
  // Company Plan · rows the file could not resolve to a board row: still id-less after the
  // Group + Company + เดือน match, or carrying an Item ID that is not on the board.
  const cpUnresolved = which === 'cp' && d ? d.add.length + d.missing.length : 0;
  const cpClearN =
    which === 'cp' ? changedCells.filter((c: any) => c.r && cpFileVal(c.r) == null).length : 0;

  const footerButton = file ? (
    <div className="flex flex-col items-end gap-1">
    {cpClearN > 0 && (
      <p className="text-[12px] font-semibold text-[#B54708]">
        {TT('จะล้างค่า')} {cpClearN} {TT('ช่อง')}
      </p>
    )}
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span>
            <Button
              variant="default"
              disabled={blocked || busy}
              onClick={handleConfirm}
            >
              {btnLabel}
            </Button>
          </span>
        </TooltipTrigger>
        {(blocked || busy) && (
          <TooltipContent>
            {hardStop
              ? TT('ไฟล์นี้ใช้กับขอบเขตนี้ไม่ได้')
              : busy
                ? TT('กำลังบันทึก')
                : TT('ต้องยืนยันเงื่อนไขก่อนกดยืนยัน')}
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
    </div>
  ) : null;

  return (
    <>
      <Modal
        show
        alertModal={busy}
        onClose={busy ? () => {} : close}
        size="large"
        pill={<BoardTag board={sp.board as any} />}
        title={<>{TT('นำเข้าไฟล์')} · {sp.page ? TT(sp.page) : sp.kind}</>}
        sub={
          sp.page
            ? `${TT(sp.page)} · ${TT('เขียนลงบอร์ด')} ${sp.board} (${ext})`
            : `${TT('เขียนลงบอร์ด')} ${sp.board} (${ext})`
        }
        footer={footerButton}
      >

        {/* C1 step 1 — the board changed while this dialog was open (warning, orange) */}
        {stale && (
          <div className="mb-3 flex items-start gap-2 rounded-[8px] border border-[var(--or)] bg-[var(--or)]/10 px-3 py-2 text-[12.5px]">
            <span className="text-[var(--or)]">⚠</span>
            <p className="font-semibold text-[var(--or)]">{TT(stale)}</p>
          </div>
        )}

        {/* Step bar — told from where the user stands: ③ is the active step until a file is
            loaded; once the diff is shown no step is highlighted. ① is never the active one. */}
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-[8px] border border-border bg-muted/30 px-3 py-2 text-[12px]">
          <button
            type="button"
            onClick={onExport}
            disabled={busy}
            className="rounded px-2 py-0.5 font-semibold text-muted-foreground underline decoration-dotted underline-offset-2 hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"
          >
            ① {TT('ดาวน์โหลดไฟล์ของบอร์ดนี้')}
          </button>
          <span className="text-border">→</span>
          <span className="text-muted-foreground">② {TT(which === 'cp' ? 'เปิดใน Excel แก้เฉพาะตัวเลข · ถ้ามีคอลัมน์ Item ID อย่าแตะ' : 'เปิดใน Excel แก้เฉพาะตัวเลข · ห้ามแตะคอลัมน์ Item ID')}</span>
          <span className="text-border">→</span>
          <span className={cn('rounded px-2 py-0.5 font-semibold', !file ? 'bg-primary text-primary-foreground' : 'text-muted-foreground')}>
            ③ {TT('ลากไฟล์ที่แก้แล้วกลับมาที่นี่')}
          </span>
          <div className="ml-auto">
            <Button variant="secondary" size="sm" onClick={() => setHelp(true)}>
              ? {TT('ดูวิธีทำ')}
            </Button>
          </div>
        </div>
        <p className="mb-4 mt-1 text-[11px] text-muted-foreground">
          {which === 'cp'
            ? TT('ไม่ต้องมีคอลัมน์ Item ID ก็ได้ · ระบบจับคู่แถวจาก Group + Company + เดือน')
            : TT('ไฟล์ต้องมีคอลัมน์ Item ID ที่ระบบสร้างให้ · ระบบจึงจะรู้ว่าตัวเลขแต่ละตัวเป็นของแถวไหนบนบอร์ด')}
        </p>

        {/* Error box */}
        {err && (
          <div className="mb-3 rounded border border-[#FDA29B] bg-[#FFFBFA] px-3 py-2 text-[12.5px]">
            <p className="font-bold text-[#B42318]">⛔ {TT(err)}</p>
            <p className="mt-0.5 text-[#7A271A]">
              {which === 'cp' && (err === 'ไฟล์นี้ไม่มีแถวข้อมูล' || err === TT('ไฟล์นี้ไม่มีแถวข้อมูล')) ? (
                TT('เติมข้อมูลลงใน template ก่อน แล้วลากกลับมาใหม่')
              ) : (
                <>
                  {TT('ไฟล์ต้องเป็น')} {ext} {TT('ที่ออกจากปุ่ม Export บนหน้านี้')}
                </>
              )}
            </p>
          </div>
        )}

        {/* Drop zone or loading */}
        {!file && !loading && (
          <button
            type="button"
            className={cn(
              'flex w-full cursor-pointer flex-col items-center justify-center gap-2 rounded-[8px] border-2 border-dashed py-10 text-center transition-colors',
              dragOver ? 'border-primary bg-primary/5' : 'border-border hover:border-muted-foreground',
            )}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            aria-label={TT('อัปโหลดไฟล์')}
          >
            <span className="text-[28px] text-muted-foreground">⇪</span>
            <p className="text-[13px] font-bold text-foreground">
              {TT('ลากไฟล์ที่แก้แล้วมาวาง หรือคลิกเพื่อเลือก')}
            </p>
            <p className="text-[11.5px] text-muted-foreground">
              {which === 'cp'
                ? TT('ไฟล์ .csv จาก template กลาง หรือจากปุ่ม Export')
                : TT('ไฟล์ .csv ที่ออกจากปุ่ม Export · ต้องมีคอลัมน์ Item ID')}
            </p>
          </button>
        )}

        {/* Loading state */}
        {!file && loading && (
          <div className="flex flex-col items-center justify-center gap-3 rounded-[8px] border border-border bg-muted/20 py-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-[13px] font-semibold text-foreground">
              {TT('กำลังโหลดข้อมู���ล่าสุดจากบอร์ด…')}
            </p>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden"
          disabled={loading}
          onChange={handleChange}
        />

        {/* File loaded */}
        {file && (
          <div className="space-y-3">
            {/* File card */}
            <div className="flex items-start justify-between gap-3 rounded-[8px] border border-border bg-muted/30 px-3 py-2">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                    {extLabel}
                  </span>
                  <span className="text-[12.5px] text-foreground" style={{ wordBreak: 'break-all' }}>
                    {file.name}
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  {file.rows.length} {TT('แถว')}
                  {meta.TEAM ? ` · ${meta.TEAM}` : ''}
                  {meta.EXPORTED_AT ? ` · ${TT('export เมื่อ')} ${exportedAtLabel(meta.EXPORTED_AT)}` : ` · ${TT('ไม่มีเวลา export ในไฟล์')}`}
                </p>
              </div>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => { setFile(null); setErr(''); }}
              >
                {TT('เปลี่ยนไฟล์')}
              </Button>
            </div>

            {/* Hard-stop box */}
            {hardStop && (
              <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] px-3 py-2 text-[12.5px]">
                <p className="mb-1 font-bold text-[#B42318]">⛔ {TT('ไฟล์นี้ใช้กับขอบเขตนี้ไม่ได้')}</p>
                {wrongKind && (
                  <p className="text-[#7A271A]">
                    {TT('ไฟล์เป็นของบอร์ด')} {meta.KIND} · {TT('หน้านี้คือ')} {sp.kind}
                  </p>
                )}
                {wrongTeam && (
                  <p className="text-[#7A271A]">
                    {TT('ไฟล์เป็นของทีม')} {meta.TEAM} · {TT('หน้านี้กำลังดูทีม')} {scopeTeam}
                  </p>
                )}
                {otNoRowTeam.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('ทีมนี้ยังไม่มีแถวของปีงบนี้')}</p>
                    <p>{TT('กดปุ่ม เพิ่มทีม บนหน้านี้ก่อน แล้วนำเข้าไฟล์ใหม่')}</p>
                    <MiniTable cols={[TT('ทีมในไฟล์')]} rows={otNoRowTeam.slice(0, 8).map((t) => [t])} />
                    {otNoRowTeam.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {otNoRowTeam.length - 8} {TT('แถว')}
                      </p>
                    )}
                  </div>
                )}
                {otUnknownTeam.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('มีแถวที่ระบุทีมไม่ถูกต้อง')}</p>
                    <p>
                      {TT('ทุกแถวต้องเลือกทีมจากรายการในเทมเพลต · ทีมด้านล่างไม่มีอยู่บนบอร์ดในปีงบนี้ · แก้ไฟล์แล้วนำเข้าใหม่')}
                    </p>
                    <MiniTable
                      cols={[TT('ทีมในไฟล์')]}
                      rows={otUnknownTeam.slice(0, 8).map((t) => [t])}
                    />
                    {otUnknownTeam.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {otUnknownTeam.length - 8} {TT('แถว')}
                      </p>
                    )}
                  </div>
                )}
                {cpUnknownKey.length > 0 && <KeyList title={TT('ไม่พบแถวนี้บนบอร์ด')} keys={cpUnknownKey} />}
                {cpDupKey.length > 0 && <KeyList title={TT('มีแถวซ้ำกันในไฟล์')} keys={cpDupKey} />}
                {otDupTeam.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('มีทีมซ้ำกันในไฟล์')}</p>
                    <p>{TT('แต่ละทีมใส่ได้แถวเดียวต่อหนึ่งปีงบ · ลบแถวที่ซ้ำออกแล้วนำเข้าใหม่')}</p>
                    <MiniTable cols={[TT('ทีมที่ซ้ำ')]} rows={otDupTeam.slice(0, 8).map((t) => [t])} />
                    {otDupTeam.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {otDupTeam.length - 8} {TT('ทีม')}
                      </p>
                    )}
                  </div>
                )}
                {wrongRowTeam.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('มีแถวที่ระบุทีมไม่ตรงกับหน้านี้')}</p>
                    <p>
                      {TT('ไฟล์นี้ต้องมีทีมเดียว · แถวด้านล่างระบุทีมอื่นในคอลัมน์ Team · แก้ไฟล์ให้ทุกแถวเป็นทีมเดียวกับหน้านี้ก่อนนำเข้า')}
                    </p>
                    <MiniTable
                      cols={[TT('แถว'), TT('ทีมในไฟล์'), TT('หน้านี้กำลังดูทีม')]}
                      rows={wrongRowTeam.slice(0, 8).map((r) => [r.label, r.team, scopeTeam ?? ''])}
                    />
                    {wrongRowTeam.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {wrongRowTeam.length - 8} {TT('แถว')}
                      </p>
                    )}
                  </div>
                )}
                {wrongFy && (
                  <p className="text-[#7A271A]">
                    {TT('ไฟล์เป็นปีงบ')} {meta.FY} · {TT('หน้านี้กำลังดูปีงบ')} {scopeFy}
                  </p>
                )}
                {/* OT only · when every duplicated Item ID was filled in from a duplicated Team, the
                    team line above already explains it — the Item ID line is hidden (the import
                    still stops). Real duplicated Item IDs in the file still show. */}
                {dupStop && d && !(
                  ((which === 'ot' && otDupTeam.length > 0) || (which === 'cp' && cpDupKey.length > 0)) &&
                  d.dup.every((id) => otFilledIds.includes(String(id).trim()))
                ) && (
                  <p className="text-[#7A271A]">
                    {TT('มี Item ID ซ้ำกันเองในไฟล์')} {d.dup.length} {TT('ตัว')} — {d.dup.slice(0, 5).join(', ')} · {TT('มักเกิดตอน copy แถวแล้วลืมลบเลข')}
                  </p>
                )}
                {badIdStop && d && (
                  <p className="text-[#7A271A]">
                    {TT('Item ID ในไฟล์ไม่ใช่ตัวเลขล้วน')} {d.badId.length} {TT('ตัว')} — {d.badId.slice(0, 5).join(', ')} · {TT('มักเกิดเมื่อ Excel แปลง Item ID เป็นตัวเลขแบบย่อ เช่น 1.31E+10')} · {TT('โปรด Export ใหม่และไม่แก้คอลัมน์ Item ID')}
                  </p>
                )}
                {badNumStop && file && (
                  <p className="text-[#7A271A]">
                    {TT('มีช่องที่ไม่ใช่ตัวเลข หรือเป็นจำนวนติดลบ')} {file.badNum.length} {TT('ช่อง')} — {file.badNum.slice(0, 5).join(', ')} · {TT('โปรดแก้ในไฟล์ก่อนนำเข้า')}
                  </p>
                )}
                {badNew.length > 0 && (
                  <p className="text-[#7A271A]">
                    {TT('แถวใหม่')} {badNew.length} {TT('แถวมีค่าที่บอร์ดไม่รู้จักหรือเว้นว่าง')} — {badNew.slice(0, 5).join(', ')} · {TT('โปรดแก้ในไฟล์ก่อนนำเข้า')}
                  </p>
                )}
                {labelStop.length > 0 && (
                  <p className="text-[#7A271A]">
                    {labelStop.slice(0, 5).join(', ')} · {TT('โปรดแก้ในไฟล์ก่อนนำเข้า')}
                  </p>
                )}
                {badText.length > 0 && (
                  <p className="text-[#7A271A]">
                    {TT('แถวเดิม')} {badText.length} {TT('แถวมีค่าที่บอร์ดไม่รู้จัก')} — {badText.slice(0, 5).join(', ')} · {TT('โปรดแก้ในไฟล์ก่อนนำเข้า')}
                  </p>
                )}
                {fyRows.empty.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('ไม่ได้ระบุปีงบในไฟล์')}</p>
                    <p>
                      {TT('เติมปีงบ')} {fyStr} {TT('ในคอลัมน์ Fy Year ให้ครบทุกแถว แล้วนำเข้าใหม่')}
                    </p>
                    <MiniTable cols={[TT('แถว')]} rows={fyRows.empty.slice(0, 8).map((l) => [l])} />
                    {fyRows.empty.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {fyRows.empty.length - 8} {TT('แถว')}
                      </p>
                    )}
                  </div>
                )}
                {fyRows.other.length > 0 && (
                  <div className="mt-1 text-[#7A271A]">
                    <p className="font-semibold">{TT('ปีงบในไฟล์ไม่ตรงกับหน้าที่เปิดอยู่')}</p>
                    <p>
                      {TT('ไฟล์ระบุปีงบ')} {fileFys} · {TT('หน้านี้คือปีงบ')} {fyStr} · {TT('แก้ไฟล์ หรือสลับไปหน้าปีงบ')} {fileFys} {TT('แล้วนำเข้าใหม่')}
                    </p>
                    <MiniTable cols={[TT('แถว'), 'Fy Year']} rows={fyRows.other.slice(0, 8).map((r) => [r.label, r.fy])} />
                    {fyRows.other.length > 8 && (
                      <p className="mt-1 text-[11px]">
                        {TT('และอีก')} {fyRows.other.length - 8} {TT('แถว')}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Conflict box */}
            {d && d.conflict.length > 0 && (
              <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] px-3 py-2 text-[12.5px]">
                <p className="mb-1 font-bold text-[#B42318]">
                  ⚠ {TT('มีคนแก้ค่าบนบอร์ดหลังจากคุณดาวน์โหลดไฟล์นี้')}
                </p>
                <p className="text-[#7A271A]">
                  {TT('ถ้านำเข้าต่อ สิ่งที่เขาแก้จะถูกทับด้วยค่าในไฟล์ · ถ้าไม่ได้ตั้งใจ ให้กด Export ใหม่แล้วแก้บนไฟล์ล่าสุดแทน')}
                </p>
                <MiniTable
                  cols={['#', TT('ชื่อ'), TT('งาน'), TT('แก้เมื่อ')]}
                  rows={d.conflict.slice(0, 8).map((r: any) => {
                    const [l0, l1] = fs.label(r);
                    return [
                      <span key="id" className="font-mono text-[10px] text-muted-foreground">{fs.id(r)}</span>,
                      l0,
                      l1,
                      <span key="at" className="font-mono text-[10px]">{r.editedAt}</span>,
                    ];
                  })}
                />
                <label className="mt-2 flex cursor-pointer items-center gap-2 text-[12px]">
                  <input
                    type="checkbox"
                    checked={okConflict}
                    onChange={(e) => setOkConflict(e.target.checked)}
                    className="h-[14px] w-[14px] cursor-pointer rounded"
                  />
                  {TT('รับทราบว่าจะทับค่าที่มีคนแก้ไว้')} {d.conflict.length} {TT('แถว')}
                </label>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {TT('กด Export ใหม่เมื่อไหร่ก็ได้ไฟล์ที่ตรงกับบอร์ด ณ ตอนนั้นเสมอ')}
                </p>
              </div>
            )}

            {/* Diff summary */}
            {d && (
              <div>
                <p className="mb-1 text-[12px] font-semibold text-foreground">{TT('เทียบไฟล์กับบอร์ด')}</p>
                <div className="rounded-[8px] border border-border bg-muted/20 px-3 py-2">
                  <DiffRow
                    label={TT('ตัวเลขที่เปลี่ยนจริง')}
                    value={`${d.cells.length} ${TT('ช่อง')}${d.cells.length > 0 ? ` · ${TT('ใน')} ${d.rows} ${TT('แถว')}` : ''}`}
                    highlight={d.cells.length > 0 ? 'orange' : 'none'}
                  />
                  {which === 'mp' && (
                    <DiffRow
                      label={TT('ข้อความที่เปลี่ยน')}
                      value={`${d.texts.length} ${TT('ช่อง')}`}
                      highlight={d.texts.length > 0 ? 'orange' : 'none'}
                    />
                  )}
                  <DiffRow label={TT('ไม่มีการเปลี่ยนแปลง')} value={`${d.same} ${TT('แถว')}`} />
                  {d.timeSkip.length > 0 && (
                    <DiffRow
                      label={TT('แถวที่ตรวจเวลาแก้ไขไม่ได้')}
                      value={`${d.timeSkip.length} ${TT('แถว')} — ${TT('อ่านเวลา export ในไฟล์หรือเวลาแก้บนบอร์ดไม่ได้ · ข้ามการตรวจว่าแก้หลัง export')}`}
                      highlight="orange"
                    />
                  )}
                  {which === 'cp' ? (
                    <DiffRow
                      label={TT('แถวที่จับคู่ไม่ได้')}
                      value={`${cpUnresolved} ${TT('แถว')}${cpUnresolved > 0 ? ` — ${TT('ระบบจะข้ามให้ · เพิ่มแถวทำที่บอร์ด Company Plan เท่านั้น')}` : ''}`}
                      highlight={cpUnresolved > 0 ? 'orange' : 'none'}
                    />
                  ) : fs.cellsOnly ? (
                    <DiffRow
                      label={which === 'ot' ? TT('ทีมที่เพิ่มหรือหายไปจากไฟล์') : TT('แถวที่เพิ่มหรือหายไปจากไฟล์')}
                      value={`${d.add.length + d.del.length} ${TT('รายการ')}${d.add.length + d.del.length > 0 ? ` — ${TT('ระบบจะข้ามให้ · เพิ่มหรือลบทีมทำที่บอร์ด OT Plan เท่านั้น')}` : ''}`}
                      highlight={d.add.length + d.del.length > 0 ? 'orange' : 'none'}
                    />
                  ) : (
                    <>
                      <DiffRow
                        label={TT('เพิ่มใหม่ (ไม่มี Item ID)')}
                        value={`${d.add.length} ${TT('แถว')}`}
                        highlight={d.add.length > 0 ? 'green' : 'none'}
                      />
                      <DiffRow
                        label={TT('จะถูกลบ')}
                        value={`${d.del.length} ${TT('แถว')}`}
                        highlight={d.del.length > 0 ? 'red' : 'none'}
                      />
                    </>
                  )}
                  {d.missing.length > 0 && (
                    <DiffRow
                      label={TT('Item ID ที่ไม่มีบนบอร์ด')}
                      value={`${d.missing.length} ${TT('ตัว')} — ${TT('ระบบจะข้ามให้')}`}
                      highlight="orange"
                    />
                  )}
                  {d.outScope.length > 0 && (
                    <DiffRow
                      label={TT('Item ID ที่อยู่นอกขอบเขตนี้ (ทีมหรือปีงบอื่น)')}
                      value={`${d.outScope.length} ${TT('ตัว')} — ${TT('ระบบจะข้ามให้')}`}
                      highlight="orange"
                    />
                  )}
                  {skipExisting.length > 0 && (
                    <DiffRow
                      label={TT('ช่องของเดือนที่อยู่ทีมอื่น')}
                      value={`${skipExisting.length} ${TT('ช่อง')} — ${TT('ระบบจะข้ามให้')} · ${TT('แก้ได้เฉพาะในไฟล์ของทีมที่เป็นเจ้าของเดือนนั้น')}`}
                      highlight="orange"
                    />
                  )}
                </div>
              </div>
            )}

            {/* Changed cells table */}
            {changedCells.length > 0 && (
              <div>
                <p className="mb-1 text-[12px] font-semibold text-foreground">
                  {TT('ช่องที่เปลี่ยน')} · {changedCells.length} {TT('ช่อง')}
                </p>
                <div className="max-h-[260px] overflow-y-auto rounded border border-border">
                  <table className="w-full border-collapse text-[11.5px]">
                    <thead className="sticky top-0 bg-card">
                      <tr>
                        {/* Defect 3 fix: headers depend on which */}
                        {['#',
                          which === 'mp' ? TT('คน') : which === 'ot' ? TT('ทีม') : TT('Group · Company'),
                          which === 'mp' ? TT('งาน') : TT('เดือน'),
                          TT('ช่อง'), TT('เดิม'), TT('ใหม่'), TT('ต่าง')
                        ].map((h) => (
                          <th key={h} className="border-b border-border px-2 py-1 text-left font-semibold text-muted-foreground">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {showFirst200.map((c, i) => {
                        const [l0, l1] = fs.label(c.r);
                        const diff = (c.to ?? 0) - (c.from ?? 0);
                        // Company Plan · the difference is MD → md2 (2 decimals) with a leading "+";
                        // MP / OT stay on sign() / n1 (hours).
                        const diffDisplay =
                          c.from == null || c.to == null
                            ? '—'
                            : which === 'cp'
                              ? truthfulDiff(diff, 0.005, (v) => (v > 0 ? '+' : '') + md2(v))
                              : truthfulDiff(diff, 0.05, sign);
                        return (
                          <tr key={`change-${fs.id(c.r)}-${c.vi}`} className="border-b border-border/40 hover:bg-muted/20">
                            <td className="px-2 py-0.5 font-mono text-[10px] text-muted-foreground">{fs.id(c.r)}</td>
                            <td className="px-2 py-0.5">{l0}</td>
                            <td className="px-2 py-0.5 text-muted-foreground">{l1}</td>
                            <td className="px-2 py-0.5 font-semibold">{c.vn}</td>
                            <td className="px-2 py-0.5 font-mono">{which === 'cp' ? cpVal(c.r ? fs.val(c.r, 0) : null) : displayVal(c.from)}</td>
                            <td className="px-2 py-0.5 font-mono font-bold">
                              {which === 'cp'
                                ? cpFileVal(c.r) == null
                                  ? TT('ว่าง')
                                  : cpVal(cpFileVal(c.r))
                                : displayVal(c.to)}
                            </td>
                            <td className={cn('px-2 py-0.5 font-mono font-semibold', diff > 0 ? 'text-[#16A34A]' : 'text-[#D92D20]')}>
                              {diffDisplay}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {changedCells.length > 200 && (
                    <p className="px-3 py-1.5 text-[11px] text-muted-foreground">
                      … {TT('แสดง 200 ช่องแรก จากทั้งหมด')} {changedCells.length}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Session 1-18 · text changes on existing rows, under the month comparison */}
            {which === 'mp' && d && d.texts.length > 0 && (
              <div>
                <p className="mb-1 text-[12px] font-semibold text-foreground">
                  {TT('ข้อความที่เปลี่ยน')} · {d.texts.length} {TT('ช่อง')}
                </p>
                <div className="max-h-[220px] overflow-y-auto rounded border border-border">
                  <table className="w-full border-collapse text-[11.5px]">
                    <thead className="sticky top-0 bg-card">
                      <tr>
                        {[TT('แถว'), TT('คอลัมน์'), TT('เดิม'), TT('ใหม่')].map((h) => (
                          <th key={h} className="border-b border-border px-2 py-1 text-left font-semibold text-muted-foreground">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {d.texts.slice(0, 200).map((t) => {
                        const [l0, l1] = fs.label(t.r);
                        return (
                          <tr key={`text-${fs.id(t.r)}-${t.field}`} className="border-b border-border/40 align-top hover:bg-muted/20">
                            <td className="px-2 py-0.5">
                              <span className="font-mono text-[10px] text-muted-foreground">{fs.id(t.r)}</span> {l1} · {l0}
                            </td>
                            <td className="px-2 py-0.5 font-semibold">{t.col}</td>
                            <td className="whitespace-pre-wrap break-words px-2 py-0.5 text-muted-foreground">{t.from || '—'}</td>
                            <td className="whitespace-pre-wrap break-words px-2 py-0.5 font-bold">{t.to}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {d.texts.length > 200 && (
                    <p className="px-3 py-1.5 text-[11px] text-muted-foreground">
                      … {TT('แสดง 200 ช่องแรก จากทั้งหมด')} {d.texts.length}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Delete box */}
            {!fs.cellsOnly && d && d.del.length > 0 && (
              <div className="rounded border border-[#FDA29B] bg-[#FFFBFA] px-3 py-2 text-[12.5px]">
                <p className="mb-1 font-bold text-[#B42318]">
                  ⚠ {TT('ไฟล์นี้ทำให้')} {d.del.length} {TT('แถวถูกลบออกจากบอร์ด')}
                </p>
                <p className="text-[#7A271A]">
                  {TT('แถวที่เคยมี Item ID แต่ไม่อยู่ในไฟล์แล้ว = ตั้งใจลบ หรือ ไฟล์ส่งมาไม่ครบ · ต้องแยกให้ออกก่อน')}
                </p>
                <MiniTable
                  cols={['#', TT('ชื่อ'), TT('งาน')]}
                  rows={d.del.slice(0, 8).map((r: any) => {
                    const [l0, l1] = fs.label(r);
                    return [<span key="id" className="font-mono text-[10px] text-muted-foreground">{fs.id(r)}</span>, l0, l1];
                  })}
                />
                <label className="mt-2 flex cursor-pointer items-center gap-2 text-[12px]">
                  <input
                    type="checkbox"
                    checked={okDelete}
                    onChange={(e) => setOkDelete(e.target.checked)}
                    className="h-[14px] w-[14px] cursor-pointer rounded"
                  />
                  {TT('ตรวจแล้วว่าตั้งใจลบ')} {d.del.length} {TT('แถวนี้จริง')}
                </label>
              </div>
            )}

            {/* Past-month box */}
            {pastCells.length > 0 && (
              <div className="rounded border border-[#F5C86B] bg-[#FFFCF3] px-3 py-2 text-[12.5px]">
                <p className="mb-1 font-bold text-[#B54708]">
                  ⏮ {TT('ไฟล์นี้จะแก้ไขเดือนที่ผ่านมาแล้ว')} {pastCells.length} {TT('ช่อง')}
                </p>
                <p className="text-[#7A3600]">
                  {TT('เดือนที่ถูกแก้')} : {pastMons.join(' · ')} — {TT('แผนของเดือนที่ผ่านมาแล้วมักได้รับอนุมัติและนำไปใช้แล้ว · หากไม่ได้ตั้งใจแก้ไขย้อนหลัง โปรดตรวจสอบว่าเลือกไฟล์ถูกต้อง')}
                </p>
                {/* Session 1-24 · capped like the changed-cells table; its header row stays put */}
                <div className="mt-2 max-h-[220px] overflow-y-auto rounded border border-[#F5C86B]/60 [&>table]:mt-0">
                <MiniTable
                  stickyHead="bg-[#FFFCF3]"
                  cols={[TT('เดือน'), TT('ชื่อ'), TT('เดิม'), TT('ใหม่')]}
                  rows={pastCells.slice(0, 8).map((c) => {
                    const label = c.lbl || (c.r ? fs.label(c.r)[0] : '');
                    return [
                      c.vn,
                      label,
                      <span key="from" className="font-mono">{pastOld(c)}</span>,
                      <span key="to" className="font-mono font-bold">{pastNew(c)}</span>,
                    ];
                  })}
                />
                </div>
                <label className="mt-2 flex cursor-pointer items-center gap-2 text-[12px]">
                  <input
                    type="checkbox"
                    checked={okPast}
                    onChange={(e) => setOkPast(e.target.checked)}
                    className="h-[14px] w-[14px] cursor-pointer rounded"
                  />
                  {TT('ยืนยันการแก้ไขย้อนหลัง')} {pastCells.length} {TT('ช่อง')}
                </label>
              </div>
            )}

            {/* Other-team cells box */}
            {skipExisting.length > 0 && (
              <div className="rounded border border-border bg-muted/30 px-3 py-2 text-[12.5px]">
                <p className="mb-1 font-semibold text-muted-foreground">
                  ℹ {TT('ช่องที่อยู่ทีมอื่น — ระบบจะข้ามให้')} ({skipExisting.length} {TT('ช่อง')})
                </p>
                <MiniTable
                  cols={[TT('เดือน'), TT('ชื่อ'), TT('งาน'), TT('ทีมของเดือน'), TT('ในไฟล์')]}
                  rows={skipExisting.slice(0, 8).map((c) => {
                    const tm = c.r && model
                      ? teamOfMonth(c.r.empid, fyStr, c.vi, model.ASSIGN, model.FYCODE) || '—'
                      : '—';
                    const [l0, l1] = c.r ? fs.label(c.r) : [c.lbl || '', ''];
                    return [
                      MONTHS[c.vi] || c.vn || '',
                      l0,
                      l1,
                      tm,
                      <span key="to" className="font-mono">{n1(c.to)}</span>,
                    ];
                  })}
                />
              </div>
            )}

            {/* Session 1-25 · new-row months Decision D creates as 0 — one line per person, tick required */}
            {which === 'mp' && model && (
              <ImportZeroBlock cells={zeroNew} fy={fyStr} assign={model.ASSIGN} fyCode={model.FYCODE} ok={okZero} setOk={setOkZero} />
            )}

            {/* Final confirmation checkbox (always required when file is loaded and no hard stop) */}
            {!hardStop && (
              <div className="mt-4 rounded border border-border bg-background px-3 py-3">
                <label className="flex cursor-pointer items-start gap-2">
                  <input
                    type="checkbox"
                    checked={okFinal}
                    onChange={(e) => setOkFinal(e.target.checked)}
                    className="mt-0.5"
                  />
                  <span className="text-[13px] font-medium text-foreground">
                    {TT('ตรวจตัวเลขด้านบนแล้ว · ยืนยันเขียนลงบอร์ด')} {sp.board}
                  </span>
                </label>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* How-to overlay */}
      {help && (
        <ImportHowTo
          cellsOnly={!!fs.cellsOnly}
          board={sp.board}
          ot={which === 'ot'}
          onClose={() => setHelp(false)}
        />
      )}
    </>
  );
}
