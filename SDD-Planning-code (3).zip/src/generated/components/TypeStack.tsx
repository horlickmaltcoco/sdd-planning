// Session 1-09 Part B · B2. Plan split by Type, stacked per month. Custom SVG: no chart
// library renders stacked bars with a per-segment click that opens a Type drill while a click
// on the empty column opens the team drill for the whole month.
import { HPD, fmt, n0, typeColor } from '@generated/engine';
import type { TypeAggRow } from '@generated/engine/part-d';
import { MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';

const W = 980;
const H = 320;
const PL = 58;
const PR = 14;
const PT = 32;
const PB = 46;

interface TypeStackProps {
  agg: TypeAggRow[];
  u: 'Hrs' | 'MD' | '%';
  WD: (number | null)[];
  cap: number[];
  TYPES: string[];
  onPick: (mi: number, ty?: string) => void;
}

export function TypeStack({ agg, u, WD, cap, TYPES, onPick }: TypeStackProps) {
  const toV = (v: number, i: number) => {
    if (u === 'MD') return v / HPD;
    if (u === '%') return cap[i] ? (v / (cap[i] as number)) * 100 : 0;
    return v;
  };
  const tot: number[] = [];
  const totH: number[] = [];
  for (let i = 0; i < 12; i += 1) {
    let sv = 0;
    let sh = 0;
    for (const a of agg) {
      sv += toV(a.m[i] ?? 0, i);
      sh += a.m[i] ?? 0;
    }
    tot[i] = sv;
    totH[i] = sh;
  }
  const max = Math.max(...tot, 0) * 1.16 || 1;
  const iw = (W - PL - PR) / 12;
  const bw = iw * 0.54;
  const y = (v: number) => PT + (H - PT - PB) * (1 - v / max);
  const bh = (v: number) => (H - PT - PB) * (v / max);
  const ticks = [0, 0.25, 0.5, 0.75, 1];

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      width="100%"
      // Session 1-28 · no height attribute; CSS height:auto sizes it from the viewBox, as before.
      className="block h-auto"
    >
      {ticks.map((t) => {
        const v = t * max;
        return (
          <g key={t}>
            <line x1={PL} x2={W - PR} y1={y(v)} y2={y(v)} stroke="#E5E7EB" strokeWidth={1} strokeDasharray="3 3" />
            <text x={PL - 6} y={y(v) + 3} textAnchor="end" fontSize={10} fill="#98A2B3">
              {n0(v)}
              {u === '%' ? '%' : ''}
            </text>
          </g>
        );
      })}
      {MONTHS.map((mo, i) => {
        const x0 = PL + i * iw + (iw - bw) / 2;
        let cum = 0;
        const capI = cap[i] ?? 0;
        return (
          <g key={mo} style={{ cursor: 'pointer' }} onClick={() => onPick(i)}>
            <rect x={PL + i * iw} y={PT} width={iw} height={H - PT - PB} fill="transparent" />
            {agg.map((a) => {
              const raw = a.m[i] ?? 0;
              if (raw <= 0) return null;
              const v = toV(raw, i);
              const yTop = y(cum + v);
              const h = bh(v);
              cum += v;
              const color = typeColor(a.ty, TYPES);
              return (
                <g
                  key={a.ty}
                  className="cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    onPick(i, a.ty);
                  }}
                >
                  <rect x={x0} y={yTop} width={bw} height={h} fill={color}>
                    <title>{`${a.ty} · ${mo} · ${fmt(raw, capI, u)}`}</title>
                  </rect>
                  {h >= 13 && (
                    <text x={x0 + bw / 2} y={yTop + h / 2 + 3} textAnchor="middle" fontSize={9} fontWeight={600} fill="#fff">
                      {fmt(raw, capI, u)}
                    </text>
                  )}
                </g>
              );
            })}
            <text
              x={x0 + bw / 2}
              y={y(cum) - 6}
              textAnchor="middle"
              fontSize={10.5}
              fontWeight={700}
              fill={totH[i] ? '#101828' : '#98A2B3'}
            >
              {totH[i] ? fmt(totH[i] as number, capI, u) : '–'}
            </text>
            <text x={x0 + bw / 2} y={H - PB + 15} textAnchor="middle" fontSize={11} fontWeight={600} fill="#475467">
              {mo}
            </text>
            <text x={x0 + bw / 2} y={H - PB + 27} textAnchor="middle" fontSize={9.5} fill="#98A2B3">
              {(WD[i] ?? '–') + 'd'}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function TypeLegend({ agg, TYPES }: { agg: TypeAggRow[]; TYPES: string[] }) {
  return (
    <div className="mt-[8px] flex flex-wrap gap-[10px] text-[11px] text-[color:var(--t2)]">
      {agg.map((a) => (
        <span key={a.ty} className="flex items-center gap-[5px]">
          <span className="h-[9px] w-[9px] rounded-[2px]" style={{ background: typeColor(a.ty, TYPES) }} />
          {a.ty}
        </span>
      ))}
    </div>
  );
}
