// Session 1-06 Part A · 3.3 the four OT KPI cards.
// They follow exactly the same filtered team set as the table (R6).
import { MONTHS } from '@generated/config';
import { fmt } from '@generated/engine';
import { TT } from '@generated/i18n';
import { K } from '@generated/components/MPShared';

interface OTCardsProps {
  fM: string;
  totPlan: number;
  headMoved: number;
  missing: number;
  offN: number;
  teamN: number;
}

export function OTCards(props: OTCardsProps) {
  const all = props.fM === 'ALL';
  const mLabel = all ? '' : (MONTHS[Number.parseInt(props.fM, 10)] ?? '');

  return (
    <div className="mb-[16px] grid grid-cols-1 gap-[10px] sm:grid-cols-2 lg:grid-cols-4">
      <K
        label={TT(all ? 'Plan OT รวมปี' : 'Plan OT เดือนที่เลือก')}
        value={`${fmt(props.totPlan, 0, 'Hrs')}h`}
        sub={all ? TT('เฉพาะทีมที่วางแผน') : `${mLabel} · ${TT('เฉพาะทีมที่วางแผน')}`}
        tone="or"
      />
      <K
        label={TT('ทีมที่คนเปลี่ยนระหว่างปี')}
        value={props.headMoved}
        sub={TT('ตัวหารเฉลี่ย/คน ไม่คงที่')}
        tone={props.headMoved > 0 ? 'or' : 'gn'}
      />
      <K
        label={TT('ทีม × เดือน ที่ยังไม่กรอก')}
        value={props.missing}
        sub={`${all ? TT('ทั้งปี') : mLabel} · ${TT('นับเฉพาะทีมที่เปิดไว้')}`}
        tone={props.missing > 0 ? 'or' : 'gn'}
      />
      {/* Card 4 is deliberately NOT clickable — there is no settings page in this app. */}
      <K
        label={TT('ทีมที่ปิดไว้')}
        value={props.offN}
        sub={`${TT('จาก')} ${props.teamN} ${TT('ทีม')}`}
      />
    </div>
  );
}
