// Session 1-25 · Decision D made visible. A NEW row's month that the page's team does not own is
// created as 0; this block lists those cells per person (never per cell) before the user confirms.
// It only reports — the rule itself lives in the preview diff and in buildPlanMP, unchanged.
import { useMemo } from 'react';
import { TT } from '@generated/i18n';
import { n1 } from '@generated/engine';
import { teamOfMonth } from '@generated/engine/part-b';

export interface ZeroCell {
  vi: number;
  to: number;
  emp?: string;
  who?: string;
}

interface Props {
  cells: ZeroCell[];
  fy: string;
  assign: Parameters<typeof teamOfMonth>[3];
  fyCode?: Parameters<typeof teamOfMonth>[4];
  ok: boolean;
  setOk: (v: boolean) => void;
}

export function ImportZeroBlock({ cells, fy, assign, fyCode, ok, setOk }: Props) {
  const people = useMemo(() => {
    const by = new Map<string, { who: string; months: Set<number>; teams: string[]; sum: number }>();
    for (const c of cells) {
      const k = c.emp || c.who || '';
      const p = by.get(k) ?? { who: c.who || c.emp || '—', months: new Set<number>(), teams: [], sum: 0 };
      p.months.add(c.vi);
      p.sum += Number.isFinite(c.to) ? c.to : 0;
      const t = c.emp ? teamOfMonth(c.emp, fy, c.vi, assign, fyCode) : null;
      const tl = t || '—';
      if (!p.teams.includes(tl)) p.teams.push(tl);
      by.set(k, p);
    }
    return [...by.values()];
  }, [cells, fy, assign, fyCode]);

  if (cells.length === 0) return null;
  const n = cells.length;
  return (
    <div className="rounded border border-[#F5C86B] bg-[#FFFCF3] px-3 py-2 text-[12.5px]">
      <p className="mb-1 font-bold text-[#B54708]">
        {TT('จะถูกตั้งเป็น 0 เพราะไม่ใช่เดือนของทีมนี้')} · {n} {TT('ช่อง')}
      </p>
      <p className="text-[#7A3600]">
        {TT('ระบบคิดชั่วโมงให้เฉพาะเดือนที่ทะเบียนพนักงานระบุว่าอยู่ทีมนี้ · ถ้าไม่ถูกต้อง ให้แก้ช่วงสังกัดในทะเบียนพนักงานก่อน')}
      </p>
      <div className="mt-2 max-h-[220px] overflow-y-auto rounded border border-[#F5C86B]/60">
        <table className="w-full border-collapse text-[11px]">
          <thead className="sticky top-0 bg-[#FFFCF3]">
            <tr>
              {[TT('ชื่อ'), TT('ทีมตามทะเบียน'), TT('จำนวนเดือน'), TT('ค่ารวมในไฟล์ที่จะหายไป')].map((h) => (
                <th key={h} className="border-b border-border/60 px-2 py-0.5 text-left font-semibold text-muted-foreground">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {people.map((p) => (
              <tr key={p.who} className="border-b border-border/30">
                <td className="px-2 py-0.5">{p.who}</td>
                <td className="px-2 py-0.5">{p.teams.join(' · ')}</td>
                <td className="px-2 py-0.5 font-mono">{p.months.size}</td>
                <td className="px-2 py-0.5 font-mono font-bold">{n1(p.sum)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <label className="mt-2 flex cursor-pointer items-center gap-2 text-[12px]">
        <input
          type="checkbox"
          checked={ok}
          onChange={(e) => setOk(e.target.checked)}
          className="h-[14px] w-[14px] cursor-pointer rounded"
        />
        {TT('ทราบแล้วว่า')} {n} {TT('ช่องจะถูกตั้งเป็น 0')}
      </label>
    </div>
  );
}
