// Session 1-06 Part B · writes of the OT Plan page.
// W-B · one cell of one team × FY (board 05), debounced, optimistic, rolled back from the board.
// W-C · the file import (cells only): never creates, never deletes, never touches OT Planned.
import { toLocalStamp } from '@generated/lib/parse';
import { useCallback, useRef } from 'react';
import { ALLMI, BOARD_ID, SRC_APP, SRC_IMPORT } from '@generated/config';
import { isPastMonth } from '@generated/engine';
import { TT } from '@generated/i18n';
import { OT_C, OT_M } from '@generated/lib/cols';
import { buildPlanOT } from '@generated/lib/import-plan';
import { executePlan } from '@generated/lib/import-run';
import type { OtRow } from '@generated/lib/types';
import { numVal, statusVal } from '@generated/lib/write-values';
import type { OtCell, OtMap } from '@generated/model/types';
import type { ImportApplyCtx } from '@generated/components/ImportModal';
import { readFreshOt } from '@generated/server/read-fresh';
import { writeItem } from '@generated/server/write';

interface Args {
  fy: number;
  /** String key of the selected FY — the ONLY bucket these writes ever touch. */
  fyKey: string;
  ot: Record<string, OtCell>;
  setOtAll: (fn: (prev: OtMap) => OtMap) => void;
  T: (msg: string) => void;
  back: boolean;
  fyCode?: Record<number, string[]>;
  reloadOt: () => Promise<void>;
}

export function useOtWrite(a: Args) {
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  /** Pull the row back from the board. restore=false → only the monday-set Last updated. */
  const refresh = useCallback(
    async (team: string, itemId: string, restore: boolean) => {
      try {
        const res = await readFreshOt({ data: { fy: a.fyKey, ids: [String(itemId)] } });
        const row = (res?.rows ?? []).find((r) => String(r.id) === String(itemId));
        if (!row) return;
        a.setOtAll((prev) => {
          const box = prev[a.fyKey] ?? {};
          const cur = box[team];
          if (!cur) return prev;
          const next: OtCell = restore
            ? {
                ...cur,
                plan: ALLMI.map((i) => row.m?.[i] ?? null),
                pl: row.pl,
                src: row.src,
                editedAt: toLocalStamp(row.editedAt),
              }
            : { ...cur, editedAt: toLocalStamp(row.editedAt) };
          return { ...prev, [a.fyKey]: { ...box, [team]: next } };
        });
      } catch (e) {
        console.error('OT re-read failed', e);
      }
    },
    [a],
  );

  const flush = useCallback(
    async (team: string, mi: number, v: number | null, itemId: string) => {
      timers.current.delete(`${itemId}:${mi}`);
      const col = OT_M[mi];
      if (!col) return;
      try {
        await writeItem({
          data: {
            boardId: BOARD_ID['OT Plan'],
            itemId: String(itemId),
            // null → "" CLEARS the cell ("ยังไม่กรอก"); 0 is a real value and stays "0".
            colValues: { [col]: numVal(v), [OT_C.src]: statusVal(SRC_APP) },
          },
        });
        await refresh(team, itemId, false);
      } catch (err) {
        console.error('OT setCell failed', err);
        await refresh(team, itemId, true);
        a.T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
      }
    },
    [a, refresh],
  );

  const setCell = useCallback(
    (team: string, mi: number, v: number | null) => {
      // Guard first — it also refuses a programmatic call (R17).
      if (isPastMonth(a.fy, mi, a.fyCode) && !a.back) return;
      const rec = a.ot[team];
      if (!rec?.id) return;

      const plan = ALLMI.map((i) => (i === mi ? v : rec.plan?.[i] ?? null));
      a.setOtAll((prev) => ({
        ...prev,
        [a.fyKey]: { ...(prev[a.fyKey] ?? {}), [team]: { ...rec, plan, src: SRC_APP } },
      }));

      const key = `${rec.id}:${mi}`;
      const running = timers.current.get(key);
      if (running) clearTimeout(running);
      timers.current.set(
        key,
        setTimeout(() => {
          void flush(team, mi, v, String(rec.id));
        }, 600),
      );
    },
    [a, flush],
  );

  const applyImport = useCallback(
    async (ctx: ImportApplyCtx) => {
      const boardId = BOARD_ID['OT Plan'];
      const plan = buildPlanOT({ fileRows: ctx.fileRows, scopeRows: ctx.scopeRows as OtRow[] });

      const skipped = ctx.diff.add.length + ctx.diff.del.length;
      const tail = skipped ? ` · ${TT('ข้ามการเพิ่มหรือลบทีม')} ${skipped} ${TT('รายการ')}` : '';

      if (plan.ops.length === 0) {
        ctx.onProgress(0, 0);
        a.T(`${TT('นำเข้าสำเร็จ · แก้')} 0 ${TT('ช่อง')}${tail}`);
        return;
      }

      try {
        await executePlan(boardId, plan, ctx.onProgress);
      } catch (e) {
        await a.reloadOt();
        throw e;
      }

      const byId = new Map<string, Record<string, unknown>>();
      for (const op of plan.ops) {
        if (op.kind === 'update' && op.itemId) {
          byId.set(String(op.itemId), (op.columnValues ?? {}) as Record<string, unknown>);
        }
      }

      a.setOtAll((prev) => {
        const box = prev[a.fyKey] ?? {};
        const next: Record<string, OtCell> = { ...box };
        for (const team of Object.keys(box)) {
          const rec = box[team];
          if (!rec) continue;
          const cvs = byId.get(String(rec.id));
          if (!cvs) continue;
          const plan2 = ALLMI.map((i) => rec.plan?.[i] ?? null);
          OT_M.forEach((col, i) => {
            const raw = cvs[col];
            if (raw === undefined) return;
            plan2[i] = raw === '' || raw === null ? null : Number(raw);
          });
          next[team] = { ...rec, plan: plan2, src: SRC_IMPORT };
        }
        return { ...prev, [a.fyKey]: next };
      });

      a.T(`${TT('นำเข้าสำเร็จ · แก้')} ${ctx.diff.cells.length} ${TT('ช่อง')}${tail}`);
      void a.reloadOt();
    },
    [a],
  );

  return { setCell, applyImport };
}
