// Session 1-15 · which fiscal years are prepared (FY group on boards 04, 05 AND 07, live groups only).
// Re-read on every completed data load and after a preparation run; never on a timer, never
// reacting to SDD Master, never from rows or FY column options.
import { useCallback, useState } from 'react';
import { isPrepared, type PrepSnapshot } from '@generated/lib/prepare-plan';
import { readFyGroups } from '@generated/server/prepare-fy';

export interface Prepared {
  /** false until the groups are read — nothing is marked or replaced while unknown. */
  known: boolean;
  isPrepared: (fy: string | number) => boolean;
  refresh: () => Promise<void>;
}

export function usePrepared(): Prepared {
  const [groups, setGroups] = useState<PrepSnapshot['groups'] | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await readFyGroups({ data: {} });
      setGroups(res?.groups ?? null);
    } catch (e) {
      console.error('readFyGroups failed', e);
    }
  }, []);

  // No read on mount of its own: App re-reads the groups on every completed data load.

  const check = useCallback((fy: string | number) => isPrepared(groups, fy), [groups]);
  return { known: groups != null, isPrepared: check, refresh };
}
