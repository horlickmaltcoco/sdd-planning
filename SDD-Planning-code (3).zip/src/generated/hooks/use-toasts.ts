// A6 · toast stack: max 3, auto-remove after 4000 ms.
import { useCallback, useEffect, useRef, useState } from 'react';

export interface Toast {
  id: number;
  msg: string;
}

export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<number[]>([]);

  const drop = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const T = useCallback(
    (msg: string) => {
      const id = Date.now() + Math.random();
      setToasts((prev) => [...prev, { id, msg }].slice(-3));
      const handle = window.setTimeout(() => drop(id), 4000);
      timers.current.push(handle);
    },
    [drop],
  );

  useEffect(() => {
    const handles = timers.current;
    return () => {
      handles.forEach((h) => window.clearTimeout(h));
    };
  }, []);

  return { toasts, T, drop };
}
