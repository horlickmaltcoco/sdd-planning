// B1 · the only place the app reads monday. Pages never call the API directly.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PAGE_IDS, PAGE_NEEDS, type BoardKey, type PageId } from '@generated/config';
import { buildBd, EMPTY_BD } from '@generated/lib/masters';
import { toLocalStamp } from '@generated/lib/parse';
import { loadMpPaged } from '@generated/lib/load-mp';
import { PERF_CODE, printPageReady, printPerfTable, printReq, readLegacy, type PerfRow } from '@generated/lib/load-perf';
import type {
  AssignRow,
  CpRow,
  BdLists,
  BoardState,
  EmpRow,
  LoadStats,
  MpRow,
  OtRow,
  RuleMap,
  WdMap,
} from '@generated/lib/types';
import { getWdData } from '@generated/server/read-wd';
import { getOtData } from '@generated/server/read-ot';
import { getCpData } from '@generated/server/read-cp';
import { getEmpData } from '@generated/server/read-emp';
import { findYearRows } from '@generated/server/misplaced';
import type { MisplacedRow } from '@generated/components/MisplacedBanner';

const LOADING: BoardState = { status: 'loading', msg: '' };
const OK: BoardState = { status: 'ok', msg: '' };

const ALL: BoardKey[] = ['Working Day Master', 'MP Plan', 'OT Plan', 'Company Plan', 'Employee Master'];
// Session 1-17f · these three read the selected fiscal year only (by FY value); the other two in full.
// Working Day Master stays whole: the fiscal-year dropdown is built from it.
type Scoped = 'MP Plan' | 'OT Plan' | 'Company Plan';
const SCOPED: Scoped[] = ['MP Plan', 'OT Plan', 'Company Plan'];
const WHOLE: BoardKey[] = ['Working Day Master', 'Employee Master'];
const isScoped = (k: BoardKey): k is Scoped => (SCOPED as BoardKey[]).includes(k);

/** One board × one fiscal year: its load state and when its rows were read. */
interface Slot {
  st: BoardState;
  at: number | null;
}
type Years<T> = Record<string, T[]>;
const fyKey = (fy: string | number) => String(fy).trim();
/** Rows of the year in the order loaded; a row's FY value decides its year, as every screen does. */
function concatYears<T>(y: Years<T>): T[] {
  return Object.keys(y)
    .sort()
    .flatMap((k) => y[k] ?? []);
}

// C3 · the banner shows the board key + the monday error message itself (not a translated text).
function err(e: unknown): BoardState {
  const raw = e instanceof Error ? e.message : String(e ?? '');
  return { status: 'error', msg: raw.trim() || '—' };
}

function stamp<T extends { editedAt: string }>(rows: T[]): T[] {
  return rows.map((r) => ({ ...r, editedAt: toLocalStamp(r.editedAt) }));
}

const NO_HOLIDAYS: string[] = []; // board 01 Company Calendar is not connected to this app

// The raw collections. Stable identity: it only changes when board data changes.
export interface SddCore {
  D_WD: WdMap;
  D_CAP: WdMap;
  D_RULE: RuleMap;
  D_MPR: MpRow[];
  D_OT: OtRow[];
  /** 07 Company Plan · CPLAN rows (Group × Company × FY × Month). */
  D_CP: CpRow[];
  D_EMP: EmpRow[];
  D_ASSIGN: AssignRow[];
  D_BD: BdLists;
  D_HOL: string[];
  wdCount: number;
  /** Session 1-17f · the loaded years per board; each year's array keeps its identity until re-read. */
  mpYears: Years<MpRow>;
  otYears: Years<OtRow>;
  cpYears: Years<CpRow>;
}

export const EMPTY_CORE: SddCore = {
  D_WD: {},
  D_CAP: {},
  D_RULE: {},
  D_MPR: [],
  D_OT: [],
  D_CP: [],
  D_EMP: [],
  D_ASSIGN: [],
  D_BD: EMPTY_BD,
  D_HOL: NO_HOLIDAYS,
  wdCount: 0,
  mpYears: {},
  otYears: {},
  cpYears: {},
};

export type Prog = Record<BoardKey, number | null>;

export interface SddData {
  bs: Record<BoardKey, BoardState>;
  reload: (k?: BoardKey) => Promise<void>;
  /** Session 1-17f · make the selected fiscal year the one on screen; loads it if not in memory. */
  ensureFy: (fy: string) => void;
  /** True while any of the 5 boards is still loading. */
  loading: boolean;
  /** CHANGE 3 · the data committed for a page — only once every board on ITS list finished. */
  coreOf: (p: PageId) => SddCore | null;
  /** CHANGE 3 · true while any board on the page's list is loading. */
  pageBusy: (p: PageId) => boolean;
  /** The most recently committed snapshot of any page (keeps FY / state steady while hidden). */
  last: SddCore | null;
  /** When the OLDEST piece of data on screen was read (selected year + whole boards), or null. */
  loadedAt: Date | null;
  /** Session 1-17i · rows of year `fy` that the load did not read (they sit in another year's group). */
  misplacedOf: (fy: string | number) => { board: BoardKey; rows: MisplacedRow[] }[];
  /** C1 · board codes currently simulated empty (temporary test switch). */
  sim: string[];
  /** CHANGE 4 · live item count per board (null = nothing received yet). */
  prog: Prog;
  /** Temporary measurement switch (?sddLoad=legacy). */
  legacy: boolean;
}

function readSim(): string[] {
  try {
    const q =
      new URLSearchParams(window.location.search).get('sddEmpty') ??
      window.localStorage.getItem('sddEmpty') ??
      '';
    const raw = q.trim().toUpperCase() === 'ALL' ? '02,03,04,05,07' : q;
    return raw.split(',').map((x) => x.trim()).filter(Boolean);
  } catch {
    return [];
  }
}

const NO_PROG: Prog = {
  'Working Day Master': null,
  'MP Plan': null,
  'OT Plan': null,
  'Company Plan': null,
  'Employee Master': null,
};

export function useSddData(): SddData {
  const [wholeBs, setWholeBs] = useState<Record<string, Slot>>({
    'Working Day Master': { st: LOADING, at: null },
    'Employee Master': { st: LOADING, at: null },
  });
  const [slots, setSlots] = useState<Record<Scoped, Record<string, Slot>>>({ 'MP Plan': {}, 'OT Plan': {}, 'Company Plan': {} });
  const [fy, setFy] = useState<string | null>(null);
  const fyRef = useRef<string | null>(null);
  // newest request per board × year; an older answer arriving late is ignored
  const seq = useRef<Record<string, number>>({});
  // board × year already asked for in this session (cleared for the years a re-read forgets)
  const asked = useRef<Set<string>>(new Set());
  const [wd, setWd] = useState<{ wd: WdMap; cap: WdMap; rule: RuleMap; count: number }>({
    wd: {},
    cap: {},
    rule: {},
    count: 0,
  });
  const [mpYears, setMpYears] = useState<Years<MpRow>>({});
  const [mpLabels, setMpLabels] = useState<{ types: string[]; roles: string[]; systems: string[]; systemsAll: string[]; task2s: string[]; task2sAll: string[] }>({
    types: [],
    roles: [],
    systems: [],
    systemsAll: [],
    task2s: [],
    task2sAll: [],
  });
  const [otYears, setOtYears] = useState<Years<OtRow>>({});
  const [cpYears, setCpYears] = useState<Years<CpRow>>({});
  // Company names of EVERY year (board-wide Company column), read with each Company Plan load.
  const [cpCos, setCpCos] = useState<string[]>([]);
  const [empData, setEmpData] = useState<{
    emp: EmpRow[];
    assign: AssignRow[];
    sections: string[];
    groups: string[];
    subSections: string[];
    subGroups: string[];
  }>({ emp: [], assign: [], sections: [], groups: [], subSections: [], subGroups: [] });
  const [prog, setProgAll] = useState<Prog>(NO_PROG);
  const [sim, setSim] = useState<string[]>([]);
  const [legacy, setLegacy] = useState(false);

  const mark = useCallback((k: BoardKey, s: BoardState, y: string | null) => {
    const at = s.status === 'ok' ? Date.now() : null;
    if (isScoped(k)) {
      if (y === null) return;
      setSlots((prev) => {
        const old = prev[k][y];
        // a failed re-read keeps the time of the rows still held
        const slot = { st: s, at: s.status === 'ok' ? at : s.status === 'error' ? (old?.at ?? null) : null };
        return { ...prev, [k]: { ...prev[k], [y]: slot } };
      });
    } else {
      setWholeBs((prev) => ({ ...prev, [k]: { st: s, at: s.status === 'ok' ? at : (prev[k]?.at ?? null) } }));
    }
  }, []);
  const setProg = useCallback((k: BoardKey, n: number | null) => {
    setProgAll((prev) => (prev[k] === n ? prev : { ...prev, [k]: n }));
  }, []);

  // Measurement bookkeeping: one "cycle" = one load of all five boards.
  const perf = useRef<{ cycle: number; t0: number; rows: Partial<Record<BoardKey, PerfRow>> }>({
    cycle: 0,
    t0: 0,
    rows: {},
  });

  const load = useCallback(
    async (k: BoardKey, cycle: number | null, y: string | null = null) => {
      const sk = `${k}|${y ?? '*'}`;
      const my = (seq.current[sk] ?? 0) + 1;
      seq.current[sk] = my;
      const stale = () => seq.current[sk] !== my;
      mark(k, LOADING, y);
      setProg(k, null);
      const t = performance.now();
      const isLegacy = readLegacy();
      let stats: LoadStats | null = null;
      try {
        // C1 · temporary: a simulated-empty board is fed [] IN MEMORY. monday is not called.
        const simList = readSim();
        setSim(simList);
        const off = simList.includes(PERF_CODE[k]);
        if (off) console.warn(`[SDD sim] board ${PERF_CODE[k]} ${k} · simulated EMPTY in memory`);
        const q = { data: { legacy: isLegacy } };
        const yq = { data: { fy: y ?? '' } };
        if (k === 'Working Day Master') {
          const r = off ? null : await getWdData(q);
          stats = r?.perf ?? null;
          console.log(`[SDD client] 03 Working Day Master · loaded ${r?.count ?? 'UNKNOWN'} items`);
          setWd({ wd: r?.wd ?? {}, cap: r?.cap ?? {}, rule: r?.rule ?? {}, count: r?.count ?? 0 });
        } else if (k === 'MP Plan') {
          const r = off ? null : await loadMpPaged(y ?? '', (n) => setProg(k, n));
          if (stale()) return;
          stats = r?.stats ?? null;
          console.log(`[SDD client] 04 MP Plan · FY${y} ·`, JSON.stringify(r ? { loaded: r.rows.length, num: r.diag } : 'UNKNOWN'));
          const rows = stamp((r?.rows ?? []).filter((x) => fyKey(x.fy) === y));
          setMpYears((prev) => ({ ...prev, [y!]: rows }));
          if (r) setMpLabels({ types: r.types, roles: r.roles, systems: r.systems, systemsAll: r.systemsAll, task2s: r.task2s, task2sAll: r.task2sAll });
        } else if (k === 'OT Plan') {
          const r = off ? null : await getOtData(yq);
          if (stale()) return;
          stats = r?.perf ?? null;
          console.log(`[SDD client] 05 OT Plan · FY${y} ·`, JSON.stringify(r?.diag ?? 'UNKNOWN'));
          const rows = stamp((r?.rows ?? []).filter((x) => fyKey(x.fy) === y));
          setOtYears((prev) => ({ ...prev, [y!]: rows }));
        } else if (k === 'Company Plan') {
          const r = off ? null : await getCpData(yq);
          if (stale()) return;
          stats = r?.perf ?? null;
          console.log(`[SDD client] 07 Company Plan · FY${y} · loaded ${r?.count ?? 'UNKNOWN'} items`);
          const rows = stamp((r?.rows ?? []).filter((x) => fyKey(x.fy) === y));
          setCpYears((prev) => ({ ...prev, [y!]: rows }));
          if (r) setCpCos([...new Set(r.companies)].sort((a, b) => a.localeCompare(b)));
        } else {
          const r = off ? null : await getEmpData(q);
          stats = r?.perf ?? null;
          console.log('[SDD client] 02 Employee Master ·', JSON.stringify(r?.diag ?? 'UNKNOWN'));
          setEmpData({
            emp: r?.emp ?? [],
            assign: r?.assign ?? [],
            sections: r?.sections ?? [],
            groups: r?.groups ?? [],
            subSections: r?.subSections ?? [],
            subGroups: r?.subGroups ?? [],
          });
        }
        // MP Plan prints its own lines, one per server call (getMpStart / getMpMore).
        const who = `${PERF_CODE[k]} ${k}${y ? ` · FY${y}` : ''}`;
        if (k !== 'MP Plan' && !off) printReq(who, 'read', performance.now() - t, stats);
        setProg(k, stats?.items ?? 0);
        mark(k, OK, y);
      } catch (e) {
        if (stale()) return;
        console.error(`load ${k}${y ? ` FY${y}` : ''} failed`, e);
        mark(k, err(e), y);
      }
      const row: PerfRow = {
        board: `${PERF_CODE[k]} ${k}${y ? ` · FY${y}` : ''}`,
        ms: performance.now() - t,
        requests: stats?.requests ?? 0,
        items: stats?.items ?? 0,
        mode: stats ? stats.mode + (stats.note ? ` (${stats.note})` : '') : 'none',
        serverMs: stats?.ms ?? 0,
      };
      if (cycle === null || cycle !== perf.current.cycle) {
        console.log(`[SDD perf] single board · ${row.board} | ${Math.round(row.ms)} ms | ${row.requests} requests | ${row.items} items | ${row.mode}`);
        return;
      }
      perf.current.rows[k] = row;
      if (ALL.every((b) => perf.current.rows[b])) {
        const now = performance.now();
        printPerfTable(isLegacy, cycle, ALL.map((b) => perf.current.rows[b]!), now - perf.current.t0, now);
      }
    },
    [mark, setProg],
  );

  const startCycle = useCallback(() => {
    perf.current = { cycle: perf.current.cycle + 1, t0: performance.now(), rows: {} };
    return perf.current.cycle;
  }, []);

  // The two whole boards start at once; the three year-scoped boards start when ensureFy names the
  // year (App calls it on its first render, so all five still start together).
  useEffect(() => {
    setLegacy(readLegacy());
    const c = startCycle();
    WHOLE.forEach((k) => {
      void load(k, c);
    });
  }, [load, startCycle]);

  /** Forget every other year of these boards: after a re-read only the selected year is held. */
  const dropOthers = useCallback((keep: string, boards: Scoped[]) => {
    for (const key of asked.current) {
      const [b, y] = key.split('|');
      if (y !== keep && (boards as string[]).includes(b ?? '')) asked.current.delete(key);
    }
    const only = <T,>(prev: Years<T>): Years<T> => (keep in prev ? { [keep]: prev[keep]! } : {});
    if (boards.includes('MP Plan')) setMpYears(only);
    if (boards.includes('OT Plan')) setOtYears(only);
    if (boards.includes('Company Plan')) setCpYears(only);
    setSlots((prev) => {
      const next = { ...prev };
      for (const b of boards) next[b] = keep in prev[b] ? { [keep]: prev[b][keep]! } : {};
      return next;
    });
  }, []);

  const ensureFy = useCallback(
    (raw: string) => {
      const y = fyKey(raw);
      if (!y || fyRef.current === y) return;
      const first = fyRef.current === null;
      fyRef.current = y;
      setFy(y);
      // a year already in memory switches instantly; a new one loads now
      for (const b of SCOPED) {
        const key = `${b}|${y}`;
        if (asked.current.has(key)) continue;
        asked.current.add(key);
        void load(b, first ? perf.current.cycle : null, y);
      }
    },
    [load],
  );

  const reload = useCallback(
    async (k?: BoardKey) => {
      const y = fyRef.current;
      if (k && !isScoped(k)) return load(k, null);
      if (k && isScoped(k)) {
        if (!y) return;
        dropOthers(y, [k]);
        return load(k, null, y);
      }
      // "โหลดข้อมูลใหม่" · a full re-read: whole boards + the selected year; other years forgotten.
      const c = startCycle();
      if (y) dropOthers(y, SCOPED);
      await Promise.all([...WHOLE.map((b) => load(b, c)), ...(y ? SCOPED.map((b) => load(b, c, y)) : [])]);
    },
    [load, startCycle, dropOthers],
  );

  const bs = useMemo<Record<BoardKey, BoardState>>(() => {
    const of = (b: Scoped) => (fy ? (slots[b][fy]?.st ?? LOADING) : LOADING);
    return {
      'Working Day Master': wholeBs['Working Day Master']?.st ?? LOADING,
      'Employee Master': wholeBs['Employee Master']?.st ?? LOADING,
      'MP Plan': of('MP Plan'),
      'OT Plan': of('OT Plan'),
      'Company Plan': of('Company Plan'),
    };
  }, [wholeBs, slots, fy]);

  // Rows were stamped when stored; each year's array keeps its identity until that year is re-read.
  const D_MPR = useMemo(() => concatYears(mpYears), [mpYears]);
  const D_OT = useMemo(() => concatYears(otYears), [otYears]);
  const D_CP = useMemo(() => concatYears(cpYears), [cpYears]);
  // Company names for the shared master list come from the ROWS of board 07, every year (never label settings).
  const cpCompanies = cpCos;
  const D_BD = useMemo(() => {
    if (!empData.emp.length && !D_MPR.length && !cpCompanies.length) return EMPTY_BD;
    return buildBd({
      sections: empData.sections,
      groups: empData.groups,
      subSections: empData.subSections,
      subGroups: empData.subGroups,
      types: mpLabels.types,
      roles: mpLabels.roles,
      systems: mpLabels.systems,
      systemsAll: mpLabels.systemsAll,
      task2s: mpLabels.task2s,
      task2sAll: mpLabels.task2sAll,
      companies: cpCompanies,
      emp: empData.emp,
      assign: empData.assign,
      mp: D_MPR,
    });
  }, [empData, D_MPR, mpLabels, cpCompanies]);

  const live = useMemo<SddCore>(
    () => ({
      D_WD: wd.wd,
      D_CAP: wd.cap,
      D_RULE: wd.rule,
      D_MPR,
      D_OT,
      D_CP,
      D_EMP: empData.emp,
      D_ASSIGN: empData.assign,
      D_BD,
      D_HOL: NO_HOLIDAYS,
      wdCount: wd.count,
      mpYears,
      otYears,
      cpYears,
    }),
    [wd, D_MPR, D_OT, D_CP, empData, D_BD, mpYears, otYears, cpYears],
  );

  // CHANGE 3 · `core` is committed PER PAGE: a page's snapshot is taken from `live` only while
  // none of the boards on ITS list is loading, so a page never mixes a finished board with one
  // still in flight. Legacy switch: every page waits for all five (the old behaviour).
  const needsOf = useCallback((p: PageId): BoardKey[] => (legacy ? ALL : PAGE_NEEDS[p]), [legacy]);
  const busyOf = useCallback(
    (p: PageId) => needsOf(p).some((b) => bs[b].status === 'loading'),
    [needsOf, bs],
  );
  const [snap, setSnap] = useState<{ byPage: Partial<Record<PageId, SddCore>>; last: SddCore | null }>({
    byPage: {},
    last: null,
  });
  useEffect(() => {
    setSnap((prev) => {
      let byPage = prev.byPage;
      let changed = false;
      for (const p of PAGE_IDS) {
        if (busyOf(p) || byPage[p] === live) continue;
        if (!changed) byPage = { ...byPage };
        changed = true;
        byPage[p] = live;
      }
      return changed ? { byPage, last: live } : prev;
    });
  }, [busyOf, live]);

  // f · first moment each page became usable, measured from when the page was opened.
  const seen = useRef<Set<PageId>>(new Set());
  useEffect(() => {
    for (const p of PAGE_IDS) {
      if (snap.byPage[p] && !seen.current.has(p)) {
        seen.current.add(p);
        printPageReady(legacy, p, performance.now());
      }
    }
  }, [snap, legacy]);

  const loading = ALL.some((b) => bs[b].status === 'loading');
  const allOk = ALL.every((b) => bs[b].status === 'ok');
  // "ข้อมูล ณ" · the OLDEST read among what is on screen: the two whole boards and the selected
  // year of the three scoped boards. A year held in memory keeps the time it was read.
  const [loadedAt, setLoadedAt] = useState<Date | null>(null);
  useEffect(() => {
    if (loading || !allOk || !fy) return;
    const ats = [
      wholeBs['Working Day Master']?.at,
      wholeBs['Employee Master']?.at,
      ...SCOPED.map((b) => slots[b][fy]?.at),
    ];
    if (ats.some((a) => a == null)) return;
    const oldest = Math.min(...(ats as number[]));
    setLoadedAt((prev) => (prev && prev.getTime() === oldest ? prev : new Date(oldest)));
  }, [loading, allOk, fy, wholeBs, slots]);

  const coreOf = useCallback((p: PageId) => snap.byPage[p] ?? null, [snap]);

  // Session 1-17i · detector. Starts only once nothing is loading (screens already usable), once per
  // completed load of a board × year (a reload or a new year gives a new read time → runs again).
  // A failed detector stays silent: the load itself succeeded.
  const [misplaced, setMisplaced] = useState<Record<string, MisplacedRow[]>>({});
  const detected = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (loading || !fy) return;
    const loadedOf: Record<Scoped, { id: string }[] | undefined> = {
      'MP Plan': mpYears[fy],
      'OT Plan': otYears[fy],
      'Company Plan': cpYears[fy],
    };
    for (const b of SCOPED) {
      const slot = slots[b][fy];
      const ids = loadedOf[b];
      if (slot?.st.status !== 'ok' || slot.at == null || !ids) continue;
      const runKey = `${b}|${fy}|${slot.at}`;
      if (detected.current.has(runKey)) continue;
      detected.current.add(runKey);
      const have = new Set(ids.map((r) => String(r.id)));
      const t = performance.now();
      findYearRows({ data: { board: b, fy } })
        .then((r) => {
          const miss = (r?.rows ?? []).filter((x) => !have.has(x.id));
          console.log(
            `[SDD detect] ${PERF_CODE[b]} ${b} · FY${fy} | client ${Math.round(performance.now() - t)} ms | handler ${r?.ms ?? 0} ms | ` +
              `${r?.total ?? 0} rows returned by the filter (other-year groups) | ${r?.rows?.length ?? 0} with FY ${fy} | ${have.size} loaded | ${miss.length} outside the load`,
          );
          setMisplaced((prev) => ({ ...prev, [`${b}|${fy}`]: miss }));
        })
        .catch((e) => {
          console.warn(`[SDD detect] ${PERF_CODE[b]} ${b} · FY${fy} · detector read failed (nothing shown)`, e);
          setMisplaced((prev) => ({ ...prev, [`${b}|${fy}`]: [] }));
        });
    }
  }, [loading, fy, slots, mpYears, otYears, cpYears]);
  const misplacedOf = useCallback(
    (y: string | number) => SCOPED.map((b) => ({ board: b as BoardKey, rows: misplaced[`${b}|${fyKey(y)}`] ?? [] })),
    [misplaced],
  );

  return {
    bs,
    reload,
    ensureFy,
    loading,
    coreOf,
    pageBusy: busyOf,
    last: snap.last,
    loadedAt,
    misplacedOf,
    sim,
    prog,
    legacy,
  };
}
