// 07 Company Plan · writes (Session 1-11 Part B). Plan MD is written exactly as typed / as in the
// file — never rounded. Source is set on every write; Import Batch is never written; items are
// never created or deleted. Last updated is set by monday itself.
import { toLocalStamp } from '@generated/lib/parse';
import { useCallback } from 'react';
import { BOARD_ID, SRC_APP, SRC_IMPORT } from '@generated/config';
import { TT } from '@generated/i18n';
import { CP_C } from '@generated/lib/cols';
import { fileSpecOf } from '@generated/lib/file-mechanism';
import type { WriteOp, WritePlan } from '@generated/lib/import-plan';
import { executePlan } from '@generated/lib/import-run';
import type { CpRow } from '@generated/lib/types';
import { numVal, statusVal } from '@generated/lib/write-values';
import type { ImportApplyCtx } from '@generated/components/ImportModal';
import { readFreshCp } from '@generated/server/read-fresh';
import { writeItem } from '@generated/server/write';

interface Args {
  fyKey: string;
  setCp: (fn: (prev: CpRow[]) => CpRow[]) => void;
  T: (msg: string) => void;
  reloadCp: () => Promise<void>;
}

export function useCpWrite(a: Args) {
  const { fyKey, setCp, T, reloadCp } = a;

  /** Pull one row back. restore=false → only Last updated; true → md / src too (rollback). */
  const refresh = useCallback(
    async (id: string, restore: boolean) => {
      try {
        const res = await readFreshCp({ data: { fy: fyKey, ids: [id] } });
        const row = (res?.rows ?? []).find((r) => String(r.id) === id);
        if (!row) return;
        setCp((prev) =>
          prev.map((r) =>
            String(r.id) !== id
              ? r
              : restore
                ? { ...r, md: row.md, src: row.src, editedAt: toLocalStamp(row.editedAt) }
                : { ...r, editedAt: toLocalStamp(row.editedAt) },
          ),
        );
      } catch (e) {
        console.error('Company Plan re-read failed', e);
      }
    },
    [fyKey, setCp],
  );

  /** B4 · one call per save. text '' clears the cell; otherwise the typed text is stored as is. */
  const saveMd = useCallback(
    async (id: string, text: string, value: number | null): Promise<boolean> => {
      setCp((prev) => prev.map((r) => (String(r.id) === id ? { ...r, md: value, src: SRC_APP } : r)));
      try {
        await writeItem({
          data: {
            boardId: BOARD_ID['Company Plan'],
            itemId: id,
            colValues: { [CP_C.md]: text, [CP_C.src]: statusVal(SRC_APP) },
          },
        });
        await refresh(id, false);
        return true;
      } catch (err) {
        console.error('Company Plan save failed', err);
        await refresh(id, true);
        T(TT('บันทึกไม่สำเร็จ · ระบบโหลดค่าล่าสุดจากบอร์ดให้แล้ว'));
        return false;
      }
    },
    [setCp, refresh, T],
  );

  /** B5 · cells only: one update per changed cell; the value comes from the FILE row (empty = clear). */
  const applyImport = useCallback(
    async (ctx: ImportApplyCtx) => {
      const fs = fileSpecOf('cp');
      const byId = new Map(ctx.fileRows.map((r) => [String(r.id ?? '').trim(), r] as const));
      const ops: WriteOp[] = [];
      for (const c of ctx.diff.cells) {
        const id = String(fs.id(c.r)).trim();
        const fr = byId.get(id);
        if (!id || !fr) continue;
        ops.push({
          kind: 'update',
          itemId: id,
          columnValues: { [CP_C.md]: numVal(fr.v[0] ?? null), [CP_C.src]: statusVal(SRC_IMPORT) },
        });
      }
      const plan: WritePlan = { ops, writtenCells: ops.length, updatedRows: ops.length, creates: 0, deletes: 0 };

      if (ops.length === 0) {
        ctx.onProgress(0, 0);
        T(`${TT('นำเข้าสำเร็จ · ��ก้')} 0 ${TT('ช่อง')}`);
        return;
      }
      try {
        await executePlan(BOARD_ID['Company Plan'], plan, ctx.onProgress);
      } catch (e) {
        await reloadCp();
        throw e;
      }
      T(`${TT('นำเข้าสำเร็จ · แก้')} ${ops.length} ${TT('ช่อง')}`);
      void reloadCp();
    },
    [T, reloadCp],
  );

  return { saveMd, applyImport };
}
