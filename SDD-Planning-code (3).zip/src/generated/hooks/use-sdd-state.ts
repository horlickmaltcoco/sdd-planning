// C4 · app root state. Names are fixed: Sraw/setS, mp/setMp, otAll/setOtAll.
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { SddCore } from '@generated/hooks/use-sdd-data';
import { allowedPages, APP, HPD_FALLBACK, type PageId } from '@generated/config';
import { TT, type Lang } from '@generated/i18n';
import { loadBandsEdit, saveBandsEdit, type BandsEdit } from '@generated/lib/bands';
import type { Model } from '@generated/model';
import { defaultSettings } from '@generated/model/rules';
import type { MpDerived, OtMap, Settings } from '@generated/model/types';
import { buildPlan, statusOf, type Plan } from '@generated/engine';
import type { CpRow } from '@generated/lib/types';

// Fiscal year runs Apr → Mar: Sep 2026 belongs to FY2026.
function fyOfToday(): number {
  const d = new Date();
  return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
}

/**
 * Session 1-17f · several fiscal years can be held at once. When the board data changes, only the
 * years whose rows were (re)read restart from the fresh data; a year untouched by that load keeps
 * its on-screen rows (including a cell just saved), and a year the load forgot is dropped.
 */
function mergeYears<R>(
  prev: R[],
  before: Record<string, unknown[]> | undefined,
  after: Record<string, unknown[]>,
  fresh: R[],
  fyOf: (r: R) => string,
): R[] {
  if (!before) return fresh;
  const keep = new Set(Object.keys(after).filter((y) => before[y] === after[y]));
  return [...prev.filter((r) => keep.has(fyOf(r))), ...fresh.filter((r) => !keep.has(fyOf(r)))];
}

function mergeOt(prev: OtMap, before: Record<string, unknown[]> | undefined, after: Record<string, unknown[]>, fresh: OtMap): OtMap {
  if (!before) return fresh;
  const out: OtMap = {};
  for (const y of Object.keys(after)) {
    const v = before[y] === after[y] ? prev[y] : fresh[y];
    if (v) out[y] = v;
  }
  return out;
}

function noOtOf(ot: OtMap): Record<string, Record<string, boolean>> {
  const out: Record<string, Record<string, boolean>> = {};
  for (const fy of Object.keys(ot)) {
    const teams = ot[fy] ?? {};
    const box: Record<string, boolean> = {};
    for (const t of Object.keys(teams)) box[t] = String(teams[t]?.pl || '') === 'No';
    out[fy] = box;
  }
  return out;
}

export function useSddState(
  T: (msg: string) => void,
  model: Model,
  /** the raw snapshot `model` was built from — used to reset only the slices whose board changed */
  src: SddCore,
  /** page state lives in App, because the model is chosen per page (CHANGE 3) */
  pageState: [PageId, (p: PageId) => void],
) {
  const [lang, setLang] = useState<Lang>('th');
  const [page, setPage] = pageState;
  const [Sraw, setS] = useState<Settings>(() =>
    defaultSettings(fyOfToday(), HPD_FALLBACK, {}),
  );
  const [mp, setMp] = useState<MpDerived[]>([]);
  const [otAll, setOtAll] = useState<OtMap>({});
  // 07 Company Plan rows (all FYs) — the cell card updates these optimistically.
  const [cp, setCp] = useState<CpRow[]>([]);

  // bandsEdit is the only persisted setting.
  useEffect(() => {
    setS((prev) => ({ ...prev, bandsEdit: loadBandsEdit() }));
  }, []);

  // After every (re)load the engine states restart from the freshly derived structures.
  // Performance pass (CHANGE 3): pages now open while other boards still load, so the model is
  // rebuilt more than once. A slice restarts only when ITS board data changed — otherwise an
  // OT cell just saved on the OT page would be overwritten when MP Plan finishes later.
  const prevSrc = useRef<SddCore | null>(null);
  useEffect(() => {
    const p = prevSrc.current;
    const fyOf = (r: { fy: string }) => String(r.fy).trim();
    if (!p || p.D_MPR !== src.D_MPR) setMp((prev) => mergeYears(prev, p?.mpYears, src.mpYears, model.MPROWS, fyOf));
    if (!p || p.D_OT !== src.D_OT) setOtAll((prev) => mergeOt(prev, p?.otYears, src.otYears, model.D_OT_MAP));
    if (!p || p.D_CP !== src.D_CP) setCp((prev) => mergeYears(prev, p?.cpYears, src.cpYears, model.CPLAN, fyOf));
    prevSrc.current = src;
    setS((prev) => {
      const fy = model.fyList().includes(String(prev.fy)) ? prev.fy : model.defaultFy();
      return {
        ...prev,
        fy,
        hoursPerDay: model.hpdOf(fy),
        noOtTeams: noOtOf(model.D_OT_MAP),
      };
    });
  }, [model, src]);

  // goPage is the only way to change page.
  const go = useCallback(
    (x: string) => {
      // An id that is no longer a page (e.g. the removed "ven") falls back to Overview, never blank.
      setPage(allowedPages(APP.planning).includes(x as PageId) ? (x as PageId) : 'ov');
    },
    [setPage],
  );

  const saveBands = useCallback(
    (targetFy: string | number, bands: number[], redAt: number | string | null) => {
      setS((prev) => {
        const m: BandsEdit = { ...(prev.bandsEdit ?? {}) };
        m[String(targetFy)] = {
          bands,
          redAt: redAt === '' || redAt === null || redAt === undefined ? null : Number(redAt),
        };
        saveBandsEdit(m);
        return { ...prev, bandsEdit: m };
      });
      T(`${TT('ใช้เกณฑ์สีใหม่แล้ว')} ${bands.join(',')} · ${TT('บันทึกในเครื่องนี้แล้ว')}`);
    },
    [T],
  );

  const clearBands = useCallback(
    (targetFy: string | number) => {
      setS((prev) => {
        const m: BandsEdit = { ...(prev.bandsEdit ?? {}) };
        delete m[String(targetFy)];
        saveBandsEdit(m);
        return { ...prev, bandsEdit: Object.keys(m).length > 0 ? m : null };
      });
      T(TT('กลับไปใช้ค่าตั้งต้นจากบอร์ดแล้ว'));
    },
    [T],
  );

  // withRules runs on every render (it also refreshes HPD).
  // noOtTeams is derived from the LIVE otAll state, not from model.D_OT_MAP: the OT switch
  // updates otAll optimistically, and the engine (otPlan / otMiss / allow) must see that change
  // on the same render so Overview and Validation stay in step. There is no second noOt setting.
  //
  // C2 · memoized. S is keyed by (data version = model, FY + local band override = Sraw,
  // live OT switches = otAll). P is keyed by (S, mp, otAll, model): every optimistic write
  // replaces mp / otAll, so the engine recalculates exactly once per write, in the same
  // render. Units live in page state and never reach this hook, so a unit change never
  // recomputes the engine.
  const S = useMemo(
    () => ({ ...model.withRules(Sraw), noOtTeams: noOtOf(otAll) }),
    [model, Sraw, otAll],
  );
  // withRules sets the MD divisor for the selected FY; re-assert it on every render so a
  // model rebuild (which sets it to the latest FY) can never leave a stale divisor behind.
  model.withRules(Sraw);

  const P = useMemo(
    () =>
      buildPlan(S, mp, otAll, {
        SECTIONS: model.SECTIONS,
        PEOPLE_BY_EMP: model.PEOPLE_BY_EMP,
        PEOPLE_BY_NAME: model.PEOPLE_BY_NAME,
        PEOPLE: model.PEOPLE,
        ASSIGN: model.ASSIGN,
        D_OT_MAP: model.D_OT_MAP,
        EMPWIN: model.EMPWIN,
        FYCODE: model.FYCODE,
        capPerOf: model.capPerOf,
        wdOfS: model.wdOfS,
      }),
    [S, mp, otAll, model],
  );

  return {
    lang,
    setLang,
    page,
    go,
    S,
    Sraw,
    setS,
    mp,
    setMp,
    otAll,
    setOtAll,
    cp,
    setCp,
    saveBands,
    clearBands,
    P,
  };
}
