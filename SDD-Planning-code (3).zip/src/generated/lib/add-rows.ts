// Session 1-14 · the only rows the app itself creates: one OT Plan row (team × FY) and twelve
// Company Plan rows (group × company × the 12 months of one FY). Value cells are never written —
// a new month / Plan MD cell starts EMPTY ("not planned yet"), never 0. Nothing is edited or deleted.
import { BOARD_ID, MONTHS, SRC_APP } from '@generated/config';
import { CP_C, OT_C } from '@generated/lib/cols';
import { monthYearOf } from '@generated/lib/parse';
import { findFyGroupId } from '@generated/lib/import-run';
import { createItem } from '@generated/server/write';

/** Thrown when the board has no "FY<year>" group — nothing is created in that case. */
export class NoFyGroupError extends Error {
  constructor(public board: string, public fy: string) {
    super(`no FY${fy} group on ${board}`);
  }
}

/** 05 OT Plan · ONE item for this team and FY. All twelve month cells and OT Planned stay empty. */
export async function createOtTeamRow(team: string, fy: string | number): Promise<string> {
  const fyS = String(fy);
  const boardId = BOARD_ID['OT Plan'];
  const groupId = await findFyGroupId(boardId, fyS);
  if (!groupId) throw new NoFyGroupError('OT Plan', fyS);
  const res = await createItem({
    data: {
      boardId,
      itemName: `${team} · FY${fyS}`,
      groupId,
      colValues: {
        [OT_C.t]: { labels: [team] },
        [OT_C.fy]: { labels: [fyS] },
        [OT_C.src]: { label: SRC_APP },
      },
    },
  });
  return String(res?.id ?? '');
}

/** The 12 MonthYear labels of a fiscal year, April → March (FY2026 ends with Mar2027). */
export function fyMonthYears(fy: string | number): string[] {
  return MONTHS.map((mo) => monthYearOf(mo, fy));
}

/**
 * 07 Company Plan · TWELVE items for this group and company, one per month of the FY, Plan MD
 * left empty. Created one at a time so every returned id is known; stops at the first failure and
 * reports how many were created, so a retry never runs blind.
 */
export async function createCpCompanyRows(
  grp: string,
  co: string,
  fy: string | number,
  onProgress?: (done: number) => void,
): Promise<{ created: string[]; failed: boolean }> {
  const fyS = String(fy);
  const boardId = BOARD_ID['Company Plan'];
  const groupId = await findFyGroupId(boardId, fyS);
  if (!groupId) throw new NoFyGroupError('Company Plan', fyS);
  const created: string[] = [];
  for (const mo of MONTHS) {
    try {
      const res = await createItem({
        data: {
          boardId,
          itemName: `${grp} · ${co} · ${monthYearOf(mo, fyS)}`,
          groupId,
          colValues: {
            [CP_C.grp]: { labels: [grp] },
            [CP_C.co]: { labels: [co] },
            [CP_C.mo]: { labels: [mo] },
            [CP_C.fy]: { labels: [fyS] },
            [CP_C.src]: { label: SRC_APP },
          },
        },
      });
      created.push(String(res?.id ?? ''));
      onProgress?.(created.length);
    } catch (e) {
      console.error('createCpCompanyRows failed at', mo, e);
      return { created, failed: true };
    }
  }
  return { created, failed: false };
}
