// B2 · value parsing rules. One helper each — used everywhere, never bypassed.
import type { RawCv, RawItem } from '@generated/lib/types';

export function cvMap(item: RawItem): Record<string, RawCv> {
  const m: Record<string, RawCv> = {};
  for (const cv of item.column_values ?? []) {
    if (cv?.id) m[cv.id] = cv;
  }
  return m;
}

export function itemId(item: RawItem): string {
  return String(item.id);
}

export function txt(cv?: RawCv): string {
  return (cv?.text ?? '').trim();
}

// Empty is null, NOT 0 (exception: MP month cells, which the MP reader coerces to 0).
// Emptiness is decided FIRST, from what monday shows (text) — never from `number` alone.
// "" / null / undefined → null. A real 0 has text "0" and still reads as 0.
export function num(cv?: RawCv): number | null {
  if (!cv) return null;
  const shown = typeof cv.text === 'string' ? cv.text.trim() : null;
  if (shown === '') return null;
  if (shown === null) {
    const v = cv.value == null ? '' : String(cv.value).trim();
    if (v === '' || v === 'null' || v === '""') return null;
  }
  const raw = cv.number;
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  if (typeof raw === 'string' && raw.trim() !== '') {
    const asNum = Number(raw.trim());
    if (Number.isFinite(asNum)) return asNum;
  }
  const t = (cv.text ?? '').trim().replace(/,/g, '');
  if (t === '' || !/^-?\d*\.?\d+$/.test(t)) return null;
  const p = Number.parseFloat(t);
  return Number.isFinite(p) ? p : null;
}

// Emptiness comes from value, never from text: monday returns the label of index 5
// for an empty status cell.
export function status(cv?: RawCv): string {
  if (!cv) return '';
  const v = cv.value == null ? '' : String(cv.value).trim();
  if (v === '' || v === 'null' || v === '{}') return '';
  return (cv.label ?? cv.text ?? '').trim();
}

export function dropdown(cv?: RawCv): string {
  return (cv?.values?.[0]?.label ?? '').trim();
}

// "YYYY-MM-DD" — never through a local Date object (time zones shift the day).
export function dateOf(cv?: RawCv): string {
  const d = (cv?.date ?? '').trim();
  if (d) return d.slice(0, 10);
  const t = (cv?.text ?? '').trim();
  return t ? t.slice(0, 10) : '';
}

export function lastUpdatedIso(cv?: RawCv): string {
  return (cv?.updated_at ?? '').trim();
}

// ISO (UTC) → LOCAL "YYYY-MM-DD HH:MM:SS". Runs where the viewer is, so it can be
// compared with the local-time EXPORTED_AT stamp of a file.
export function toLocalStamp(iso: string): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(
    d.getMinutes(),
  )}:${p(d.getSeconds())}`;
}

export function lastUpdated(cv?: RawCv): string {
  return toLocalStamp(lastUpdatedIso(cv));
}

// "2026-04-05" → "202604"; month granularity spans.
export function ymCode(d: string): string {
  return d ? d.slice(0, 7).replace('-', '') : '';
}

// MonthYear composer for Vendor MA: "Apr" + "2026" → "Apr2026"
// Apr–Dec → fy, Jan–Mar → fy+1
export function monthYearOf(mo: string, fy: string | number): string {
  if (!mo || !fy) return '';
  const fyNum = typeof fy === 'string' ? Number.parseInt(fy, 10) : fy;
  const year = ['Jan', 'Feb', 'Mar'].includes(mo) ? fyNum + 1 : fyNum;
  return `${mo}${year}`;
}

export function month12<T>(fill: T): T[] {
  return Array.from({ length: 12 }, () => fill);
}

export function parseLabels(settings?: string | null): string[] {
  if (!settings) return [];
  try {
    const j = JSON.parse(settings) as {
      labels?: Record<string, string> | ({ id?: number; name?: string } | null)[] | null;
    };
    const l = j?.labels;
    if (!l) return [];
    if (Array.isArray(l)) {
      return l.map((x) => String(x?.name ?? '').trim()).filter(Boolean);
    }
    return Object.keys(l)
      .sort((a, b) => Number(a) - Number(b))
      .map((k) => String(l[k] ?? '').trim())
      .filter(Boolean);
  } catch {
    return [];
  }
}
