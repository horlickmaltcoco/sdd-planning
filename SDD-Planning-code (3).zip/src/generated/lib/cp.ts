// 07 Company Plan · page helpers (Session 1-11 Part B). Unit is MD only — never hours.
import { MONTHS } from '@generated/config';
import type { CpRow } from '@generated/lib/types';

const MD_FMT = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** B2 · display only: "–" for empty · "<0.01" below 0.005 · else half-up 2 decimals with separators. */
export function md2(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return '–';
  if (v > 0 && v < 0.005) return '<0.01';
  const r = Math.sign(v) * (Math.round(Math.abs(v) * 100 + 1e-9) / 100);
  return MD_FMT.format(r);
}

/** C2 · number of DISTINCT months (r.my) among rows whose md != null — never the row count. */
export function monthsWithData(rows: Pick<CpRow, 'my' | 'md'>[]): number {
  const seen = new Set<string>();
  for (const r of rows) if (r.md != null && r.my) seen.add(r.my);
  return seen.size;
}

/** Σ md of rows with a value (null → skipped). */
export function sumMd(rows: Pick<CpRow, 'md'>[]): number {
  let s = 0;
  for (const r of rows) if (r.md != null) s += r.md;
  return s;
}

/** Distinct values in first-seen order. */
export function firstSeen(list: string[]): string[] {
  const out: string[] = [];
  for (const v of list) if (v && !out.includes(v)) out.push(v);
  return out;
}

export interface CpLine {
  grp: string;
  co: string;
  /** one slot per fiscal month (Apr…Mar): the item, or null when the board has no row for it */
  cells: (CpRow | null)[];
  year: number;
}

export interface CpBlock {
  grp: string;
  lines: CpLine[];
  months: number[];
  year: number;
}

/** B3 table · Groups in first-seen order, companies A→Z inside a Group, 12 month slots each. */
export function buildBlocks(rows: CpRow[]): CpBlock[] {
  const blocks: CpBlock[] = [];
  for (const grp of firstSeen(rows.map((r) => r.grp))) {
    const inG = rows.filter((r) => r.grp === grp);
    const cos = firstSeen(inG.map((r) => r.co)).sort((a, b) => a.localeCompare(b));
    const lines: CpLine[] = cos.map((co) => {
      const cells = MONTHS.map((mo) => inG.find((r) => r.co === co && r.mo === mo) ?? null);
      const year = cells.reduce<number>((s, c) => s + (c?.md ?? 0), 0);
      return { grp, co, cells, year };
    });
    const months = MONTHS.map((_, i) => lines.reduce<number>((s, l) => s + (l.cells[i]?.md ?? 0), 0));
    blocks.push({ grp, lines, months, year: months.reduce((s, v) => s + v, 0) });
  }
  return blocks;
}

/** B4 · input check: strip thousands commas · empty → clear · else a non-negative decimal. */
export function parseMdInput(raw: string): { ok: true; text: string; value: number | null } | { ok: false } {
  const t = raw.replace(/,/g, '').trim();
  if (t === '') return { ok: true, text: '', value: null };
  if (!/^\d+(\.\d+)?$/.test(t)) return { ok: false };
  return { ok: true, text: t, value: Number(t) };
}
