// B8 · master lists. Nothing here is typed by hand except MONTHS: new teams, types and
// companies appear automatically once they exist on the boards.
import { BOARD_ID, MONTHS } from '@generated/config';
import {
  A,
  E,
  PENDING,
  type AssignRow,
  type BdLists,
  type EmpRow,
  type MpRow,
} from '@generated/lib/types';

function clean(list: string[]): string[] {
  const out: string[] = [];
  for (const raw of list) {
    const v = (raw ?? '').trim();
    if (!v || v === PENDING || out.includes(v)) continue;
    out.push(v);
  }
  return out;
}

function sorted(list: string[]): string[] {
  return clean(list).sort((a, b) => a.localeCompare(b));
}

export interface BdInput {
  sections: string[];
  groups: string[];
  subSections: string[];
  subGroups: string[];
  types: string[];
  roles: string[];
  systems: string[];
  systemsAll: string[];
  task2s: string[];
  task2sAll: string[];
  companies: string[];
  emp: EmpRow[];
  assign: AssignRow[];
  mp: MpRow[];
}

export function buildBd(i: BdInput): BdLists {
  const sections = sorted([
    ...i.sections,
    ...i.subSections,
    ...i.emp.map((r) => r[E.sec] ?? ''),
    ...i.assign.map((r) => r[A.team] ?? ''),
  ]);
  const groups = sorted([
    ...i.groups,
    ...i.subGroups,
    ...i.emp.map((r) => r[E.grp] ?? ''),
    ...i.assign.map((r) => r[A.grp] ?? ''),
  ]);

  // CURRENT team → group, for labels only. First person wins.
  const grpOf: Record<string, string> = {};
  for (const r of i.emp) {
    const sec = (r[E.sec] ?? '').trim();
    const grp = (r[E.grp] ?? '').trim();
    if (sec && grp && !grpOf[sec]) grpOf[sec] = grp;
  }

  const types = sorted(i.types.length ? i.types : i.mp.map((r) => r.type));
  // settings order, empty labels dropped
  const roles = clean(i.roles.length ? i.roles : i.mp.map((r) => r.role));
  // Company labels come from the Company dropdown settings of board 07 Company Plan.
  const companies = clean(i.companies);

  // System labels come only from the System column settings of board 04 (never from rows).
  const systems = clean(i.systems);
  const systemsAll = clean(i.systemsAll);
  const task2s = clean(i.task2s);
  const task2sAll = clean(i.task2sAll);
  return { sections, groups, grpOf, types, roles, systems, systemsAll, task2s, task2sAll, companies, months: MONTHS, boards: BOARD_ID };
}

export const EMPTY_BD: BdLists = {
  sections: [],
  groups: [],
  grpOf: {},
  types: [],
  roles: [],
  systems: [],
  systemsAll: [],
  task2s: [],
  task2sAll: [],
  companies: [],
  months: MONTHS,
  boards: BOARD_ID,
};
