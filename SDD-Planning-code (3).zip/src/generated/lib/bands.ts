// A7 · personal colour bands. Browser storage only — never the board.
import { BANDS_KEY } from '@generated/config';

export interface BandEntry {
  bands: number[];
  redAt: number | null;
}
export type BandsEdit = Record<string, BandEntry>;

export function loadBandsEdit(): BandsEdit | null {
  try {
    const raw = window.localStorage.getItem(BANDS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as BandsEdit | null;
    return parsed ?? null;
  } catch {
    return null;
  }
}

export function saveBandsEdit(m: BandsEdit | null): void {
  try {
    if (m && Object.keys(m).length > 0) {
      window.localStorage.setItem(BANDS_KEY, JSON.stringify(m));
    } else {
      window.localStorage.removeItem(BANDS_KEY);
    }
  } catch {
    /* private mode or storage blocked — display preference only */
  }
}
