// Session 1-06 Part A · OT Plan derivations. Pure functions only — no React, no board access.
// Rule: an empty month cell is null ("not filled"), which is NEVER 0. 0 means "filled with zero".
import { MONTHS, OT_LABEL_OFF } from '@generated/config';
import { n1 } from '@generated/engine';
import { TT } from '@generated/i18n';
import type { OtCell } from '@generated/model/types';

export type OtStatus = 'off' | 'empty' | 'partial' | 'ok';

/** One team-month as the table, the totals and (Part B) the charts all see it. */
export interface OtCellView {
  v: number | null;
  head: number;
  avg: number | null;
}

/**
 * The OT switch. Exact, case-sensitive match on the board label: only "No" is OFF.
 * Empty, "yes", "รอยืนยัน" or anything else counts as ON (and lands in banner B).
 */
export function isOff(c: OtCell | undefined): boolean {
  return String(c?.pl ?? '') === OT_LABEL_OFF;
}

/** off → empty → partial → ok, evaluated over the months currently in view. */
export function statusOfTeam(c: OtCell | undefined, MI: number[]): OtStatus {
  if (isOff(c)) return 'off';
  const vals = MI.map((i) => c?.plan?.[i] ?? null);
  if (vals.every((v) => v == null)) return 'empty';
  if (vals.some((v) => v == null)) return 'partial';
  return 'ok';
}

/** The ONE tooltip for every OT month number: table cells, total row, Part B charts. */
export function otTip(c: OtCellView): string {
  if (c.v == null) return TT('ยังไม่กรอก');
  if (c.head > 0) {
    return `${n1(c.v)} ÷ ${c.head} ${TT('คน')} = ${TT('เฉลี่ย')} ${n1(c.avg ?? 0)} ${TT('ชม./คน')}`;
  }
  return TT('ยังไม่มีคนที่นับโควตาในเดือนนี้');
}

/**
 * The คน tooltip: always all 12 months from the register, whatever the month filter is.
 * Two lines — the caller must render it with white-space: pre-line.
 */
export function headTip(heads: number[]): string {
  const list = MONTHS.map((m, j) => `${m} ${heads[j] ?? 0}`).join('  ');
  return `${TT('คนที่นับโควตา · ช่วงต่ำสุด–สูงสุดของช่วงท��่เลือก · ตัวหารของ เฉลี่ย/คน')}\n${list}`;
}

/** Sum of the months in view, treating null as 0 (display only — never for "missing"). */
export function rowTotal(c: OtCell | undefined, MI: number[]): number {
  return MI.reduce<number>((acc, i) => acc + (c?.plan?.[i] ?? 0), 0);
}
