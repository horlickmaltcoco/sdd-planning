// Session 1-05 Part C3–C5 — write-plan builders.
// Pure functions: they turn (fileRows, diff, fresh scope) into an ordered op list. No board
// access, no state. Every update writes ABSOLUTE values, so replaying a plan is safe.
import { MP_MONTH_COL, SRC_IMPORT } from '@generated/config';
import { MP_C, OT_C } from '@generated/lib/cols';
import { OT_MONTH_COL } from '@generated/lib/file-mechanism';
import { numVal, dropVal, statusVal } from '@generated/lib/write-values';
import { ownsMonth, personByName } from '@generated/engine/part-b';
import { NOW } from '@generated/engine';
import { matchLabel } from '@generated/lib/mp-fields';
import type { DiffResult, ParsedFile } from '@generated/lib/file-mechanism';
import type { MpDerived } from '@generated/model/types';
import type { OtRow } from '@generated/lib/types';

const EPS = 0.0001;

export interface WriteOp {
  kind: 'update' | 'create' | 'delete';
  itemId?: string;
  columnValues?: Record<string, unknown>;
  itemName?: string;
  groupId?: string;
  /** Local row to append once monday returns the new id (creates only). */
  newRow?: unknown;
  /** Session 1-18 · updates only: the text fields written, for the page's local state. */
  textPatch?: Record<string, string>;
}

export interface WritePlan {
  ops: WriteOp[];
  writtenCells: number;
  updatedRows: number;
  creates: number;
  deletes: number;
}

/** Ops are always ordered updates → creates → deletes. */
function assemble(
  updates: WriteOp[],
  creates: WriteOp[],
  deletes: WriteOp[],
  writtenCells: number,
): WritePlan {
  return {
    ops: [...updates, ...creates, ...deletes],
    writtenCells,
    updatedRows: updates.length,
    creates: creates.length,
    deletes: deletes.length,
  };
}

const key = (v: unknown) => String(v ?? '').trim();

/** File value → number for MP (blank/NaN means 0). */
function mpVal(v: number | null | undefined): number {
  return v == null || !Number.isFinite(v) ? 0 : v;
}

/** File value → number|null for OT/Vendor (blank stays empty, never 0). */
function keepNull(v: number | null | undefined): number | null {
  return v == null || !Number.isFinite(v) ? null : v;
}

// =============================================================================
// C3 · MP Plan (board 04) — delete-replace within team × FY
// =============================================================================

export interface MpPlanArgs {
  fileRows: ParsedFile['rows'];
  d: DiffResult;
  scopeRows: MpDerived[];
  team: string;
  fy: string | number;
  groupId?: string;
  assign: Parameters<typeof ownsMonth>[4];
  empWin: Parameters<typeof ownsMonth>[5];
  fyCode?: Parameters<typeof ownsMonth>[6];
  peopleByName: Record<string, { emp?: string; name?: string; mpname?: string }>;
  typeKind: (type: string) => 'PJ' | 'MP';
  typeIsLeave: (type: string) => boolean;
  /** Board labels the import writes as THEIR text (matched by norm): Role (active), System (all). */
  labels?: { role: string[]; system: string[]; task2?: string[] };
}

export function buildPlanMP(a: MpPlanArgs): WritePlan {
  const byId = new Map<string, MpDerived>();
  for (const r of a.scopeRows) byId.set(key(r.id), r);

  const delIds = new Set(a.d.del.map((r: MpDerived) => key(r.id)));
  // Session 1-18 · text changes per row, exactly as the preview listed them (non-empty file values only).
  const textsById = new Map<string, DiffResult['texts']>();
  for (const t of a.d.texts ?? []) {
    const id = key(t.r?.id);
    textsById.set(id, [...(textsById.get(id) ?? []), t]);
  }
  const fy = String(a.fy);
  const batchText = NOW(); // Defect 6 fix: generate batch text once per import
  // Always write the board's own label text (the preview already refused anything unmatched).
  const roleLabel = (v: string) => matchLabel(v, a.labels?.role ?? []) ?? v;
  const sysLabel = (v: string) => matchLabel(v, a.labels?.system ?? []) ?? v;
  const t2Label = (v: string) => matchLabel(v, a.labels?.task2 ?? []) ?? v;

  const updates: WriteOp[] = [];
  const creates: WriteOp[] = [];
  const deletes: WriteOp[] = [];
  let writtenCells = 0;

  // a) UPDATE — in-scope, in the file, not being deleted, ≥ 1 applied changed cell.
  for (const fr of a.fileRows) {
    const id = key(fr.id);
    if (!id) continue; // → create
    const r = byId.get(id);
    if (!r) continue; // unknown / out of scope → skipped (rule d)
    if (delIds.has(id)) continue;

    const cv: Record<string, unknown> = {};
    let n = 0;

    for (let i = 0; i < 12; i++) {
      const nv = mpVal(fr.v[i]);
      const cur = r.m[i] ?? 0;
      if (Math.abs(cur - nv) <= EPS) continue;

      // Decision D — never write a month owned by another team or outside employment.
      if (r.empid && !ownsMonth(a.team, r.empid, fy, i, a.assign, a.empWin, a.fyCode)) continue;

      const col = MP_MONTH_COL[i];
      if (!col) continue;
      cv[col] = numVal(nv);
      n += 1;
    }

    // Session 1-18 · Type, Task1, Role, Detail — never Name, never an empty value.
    const textPatch: Record<string, string> = {};
    for (const t of textsById.get(id) ?? []) {
      const v = t.to.trim();
      if (!v) continue;
      if (t.field === 'type') cv[MP_C.type] = dropVal(v);
      else if (t.field === 't1') cv[MP_C.t1] = v;
      else if (t.field === 'role') cv[MP_C.role] = statusVal(roleLabel(v));
      else if (t.field === 'system') cv[MP_C.system] = dropVal(sysLabel(v));
      else if (t.field === 'task2') cv[MP_C.task2] = dropVal(t2Label(v));
      else if (t.field === 'detail') cv[MP_C.detail] = { text: v };
      else continue;
      textPatch[t.field] = t.field === 'role' ? roleLabel(v) : t.field === 'system' ? sysLabel(v) : t.field === 'task2' ? t2Label(v) : v;
      n += 1;
    }

    // Rows with no written change are not touched at all (Source / Last updated stay put).
    if (n === 0) continue;
    // Defect 6 fix: write Source AND Import Batch together
    cv[MP_C.src] = statusVal(SRC_IMPORT);
    cv[MP_C.batch] = batchText;
    updates.push({ kind: 'update', itemId: id, columnValues: cv, ...(Object.keys(textPatch).length ? { textPatch } : {}) });
    writtenCells += n;
  }

  // b) CREATE — one per d.add row. The file's own Team / Fy Year columns are ignored.
  for (const fr of a.d.add as ParsedFile['rows']) {
    const g = fr._ ?? {};
    const nameInFile = key(g.name);
    const pr = nameInFile ? personByName(nameInFile, a.peopleByName as never) : null;
    const type = key(g.type);
    const task1 = key(g.t1);
    const detail = key(g.detail);
    const role = key(g.role) ? roleLabel(key(g.role)) : '';
    const system = key(g.system) ? sysLabel(key(g.system)) : '';
    const task2 = key(g.task2) ? t2Label(key(g.task2)) : '';

    const cv: Record<string, unknown> = {
      [MP_C.team]: dropVal(a.team),
      [MP_C.fy]: dropVal(fy),
      [MP_C.type]: dropVal(type),
      [MP_C.t1]: task1,
      [MP_C.name]: pr ? pr.mpname || pr.name || nameInFile : nameInFile,
      // Section Resolved = the matched person's REGISTERED section (Employee Master), so it can be
      // compared with Team. Person not found → empty (the row is already 'Unmatched: ชื่อคน');
      // never the page's team.
      [MP_C.sec]: pr?.sec ?? '',
      // Never "Matched" when the name was not found (rule 14).
      [MP_C.ms]: statusVal(pr ? 'Matched' : 'Unmatched: ชื่อคน'),
      [MP_C.src]: statusVal(SRC_IMPORT),
      [MP_C.batch]: batchText,
    };
    if (role) cv[MP_C.role] = statusVal(role);
    if (detail) cv[MP_C.detail] = { text: detail }; // omitted when empty
    if (system) cv[MP_C.system] = dropVal(system); // omitted when empty
    if (task2) cv[MP_C.task2] = dropVal(task2); // optional · omitted when empty
    if (pr?.emp) cv[MP_C.empid] = pr.emp; // omitted when the person was not found

    const months: number[] = [];
    for (let i = 0; i < 12; i++) {
      let nv = mpVal(fr.v[i]);
      // Decision D applies to new rows too — an unowned month is created as 0.
      if (pr?.emp && !ownsMonth(a.team, pr.emp, fy, i, a.assign, a.empWin, a.fyCode)) nv = 0;
      const col = MP_MONTH_COL[i];
      if (col) cv[col] = numVal(nv);
      months.push(nv);
    }

    const newRow: MpDerived = {
      id: '', // filled from the create response
      title: task1,
      team: a.team,
      type,
      t1: task1,
      role,
      detail,
      system,
      task2,
      name: String(cv[MP_C.name] ?? ''),
      m: months,
      empid: pr?.emp ?? '',
      sec: a.team,
      ms: pr ? 'Matched' : 'Unmatched: ชื่อคน',
      fy,
      kind: a.typeKind(type),
      isLeave: a.typeIsLeave(type),
      src: SRC_IMPORT,
      editedAt: '',
      batch: batchText,
    };

    creates.push({
      kind: 'create',
      // Session 1-21 · an empty Task1 (allowed for leave) names the row "{Type} · {Name}" so it does not
      // collide with the person's other rows. The Task1 column itself stays empty.
      itemName: task1 || (type && nameInFile ? `${type} · ${nameInFile}` : nameInFile || 'New row'),
      groupId: a.groupId,
      columnValues: cv,
      newRow,
    });
  }

  // c) DELETE — in-scope rows whose Item ID is absent from the file (after the okDelete tick).
  for (const r of a.d.del as MpDerived[]) {
    deletes.push({ kind: 'delete', itemId: key(r.id) });
  }

  return assemble(updates, creates, deletes, writtenCells);
}

// =============================================================================
// C4 · OT Plan (board 05) — CELLS ONLY: never creates, never deletes
// =============================================================================

export interface OtPlanArgs {
  fileRows: ParsedFile['rows'];
  scopeRows: OtRow[];
}

export function buildPlanOT(a: OtPlanArgs): WritePlan {
  const byId = new Map<string, OtRow>();
  for (const r of a.scopeRows) byId.set(key(r.id), r);

  const batchText = NOW(); // Defect 6 fix
  const updates: WriteOp[] = [];
  let writtenCells = 0;

  for (const fr of a.fileRows) {
    const id = key(fr.id);
    if (!id) continue; // no Item ID → skipped, never created
    const block = byId.get(id);
    if (!block) continue; // unknown id → skipped

    const cv: Record<string, unknown> = {};
    let n = 0;

    for (let i = 0; i < 12; i++) {
      const nv = keepNull(fr.v[i]);
      const cur = block.m?.[i] ?? null;
      const same =
        (cur == null && nv == null) || (cur != null && nv != null && Math.abs(cur - nv) < EPS);
      if (same) continue;
      const col = OT_MONTH_COL[i];
      if (!col) continue;
      cv[col] = numVal(nv); // null → "" clears the cell, never 0
      n += 1;
    }

    if (n === 0) continue;
    // Defect 6 fix: write Source AND Import Batch together
    cv[OT_C.src] = statusVal(SRC_IMPORT);
    cv[OT_C.batch] = batchText;
    // OT Planned (OT_C.pl) and Total Plan OT are never written.
    updates.push({ kind: 'update', itemId: id, columnValues: cv });
    writtenCells += n;
  }

  return assemble(updates, [], [], writtenCells);
}
