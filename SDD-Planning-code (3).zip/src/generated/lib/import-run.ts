// Session 1-05 Part C1/C2 — plan executor.
// Requests run SEQUENTIALLY in the order the plan already has: updates (≤25 aliased per
// request), then creates (one per request), then deletes (≤25 aliased per request).
// The first failed request stops the run and throws PartialWriteError so the caller can
// reload from the board and report how much was saved.
import { BATCH, batchDelete, batchUpdate, createOneItem, readBoardGroups } from '@generated/server/batch';
import type { WriteOp, WritePlan } from '@generated/lib/import-plan';

export class PartialWriteError extends Error {
  done: number;
  total: number;
  constructor(done: number, total: number, cause?: unknown) {
    super(`บันทึกไม่ครบ (${done}/${total})`);
    this.name = 'PartialWriteError';
    this.done = done;
    this.total = total;
    if (cause !== undefined) this.cause = cause;
  }
}

/** Ops counted as "รายการ": one per updated row, created row and deleted row. */
export function planTotal(plan: WritePlan): number {
  return plan.ops.length;
}

function chunk<T>(list: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < list.length; i += size) out.push(list.slice(i, i + size));
  return out;
}

/** The group whose title is "FY"+fy, resolved at runtime. undefined → omit group_id. */
export async function findFyGroupId(boardId: string, fy: string | number): Promise<string | undefined> {
  try {
    const want = `FY${String(fy)}`.toLowerCase();
    const res = await readBoardGroups({ data: { boardId } });
    const hit = (res?.groups ?? []).find((g) => g.title.trim().toLowerCase() === want);
    return hit?.id;
  } catch (e) {
    console.error('findFyGroupId failed — creating without a group', e);
    return undefined;
  }
}

export interface RunResult {
  /** ids monday returned for each create op, in plan order. */
  createdIds: string[];
  /** The newRow payloads of the creates, with their real ids filled in. */
  createdRows: unknown[];
  done: number;
}

/**
 * Executes the plan. onProgress is called with the running count after every request so the
 * confirm button can render "กำลังบันทึก {done}/{total} รายการ".
 */
export async function executePlan(
  boardId: string,
  plan: WritePlan,
  onProgress: (done: number, total: number) => void,
): Promise<RunResult> {
  const total = planTotal(plan);
  let done = 0;
  onProgress(0, total);

  const updates = plan.ops.filter((o) => o.kind === 'update');
  const creates = plan.ops.filter((o) => o.kind === 'create');
  const deletes = plan.ops.filter((o) => o.kind === 'delete');

  const createdIds: string[] = [];
  const createdRows: unknown[] = [];

  // 1 — updates, ≤ 25 aliased mutations per request
  for (const group of chunk(updates, BATCH.update)) {
    try {
      await batchUpdate({
        data: {
          boardId,
          ops: group.map((o) => ({
            itemId: String(o.itemId),
            columnValues: (o.columnValues ?? {}) as Record<string, unknown>,
          })),
        },
      });
    } catch (e) {
      console.error('batchUpdate failed', e);
      throw new PartialWriteError(done, total, e);
    }
    done += group.length;
    onProgress(done, total);
  }

  // 2 — creates, strictly one per request so every new id is known
  for (const op of creates) {
    let id: string;
    try {
      const res = await createOneItem({
        data: {
          boardId,
          itemName: String(op.itemName ?? ''),
          ...(op.groupId ? { groupId: op.groupId } : {}),
          columnValues: (op.columnValues ?? {}) as Record<string, unknown>,
        },
      });
      id = String(res?.id ?? '');
      if (!id) throw new Error('create returned no id');
    } catch (e) {
      console.error('createOneItem failed', e);
      throw new PartialWriteError(done, total, e);
    }
    createdIds.push(id);
    if (op.newRow && typeof op.newRow === 'object') {
      createdRows.push({ ...(op.newRow as Record<string, unknown>), id });
    }
    done += 1;
    onProgress(done, total);
  }

  // 3 — deletes, ≤ 25 aliased mutations per request
  for (const group of chunk(deletes, BATCH.delete)) {
    try {
      await batchDelete({ data: { itemIds: group.map((o) => String(o.itemId)) } });
    } catch (e) {
      console.error('batchDelete failed', e);
      throw new PartialWriteError(done, total, e);
    }
    done += group.length;
    onProgress(done, total);
  }

  return { createdIds, createdRows, done };
}

/** Op list re-shaped for callers that want to inspect the plan before running it. */
export function describePlan(ops: WriteOp[]): string {
  const u = ops.filter((o) => o.kind === 'update').length;
  const c = ops.filter((o) => o.kind === 'create').length;
  const d = ops.filter((o) => o.kind === 'delete').length;
  return `update ${u} · create ${c} · delete ${d}`;
}
