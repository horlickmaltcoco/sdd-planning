// Session 1-15 · เตรียมข้อมูลปีงบ — the pure part: what is prepared, and what is still missing.
// Everything is computed from a FRESH snapshot of the boards, never from page state, and never
// from hardcoded counts. Shared by the server (snapshot) and the client (dialog + run).
import { MONTHS } from '@generated/config';

export type PrepBoard = 'MP Plan' | 'OT Plan' | 'Company Plan';
export const PREP_BOARDS: PrepBoard[] = ['MP Plan', 'OT Plan', 'Company Plan'];

export interface PrepSnapshot {
  /** Group titles per board (04, 05, 07). */
  groups: Record<PrepBoard, { id: string; title: string }[]>;
  /** 05 OT Plan · one entry per item: team + FY. */
  ot: { t: string; fy: string }[];
  /** 07 Company Plan · one entry per item: group + company + month + FY. */
  cp: { grp: string; co: string; mo: string; fy: string }[];
  /** FY dropdown labels of 04, 05 and 07 (null = could not be read). Read only — never written. */
  fyLabels: Record<PrepBoard, string[] | null>;
}

export interface PrepPlan {
  fy: string;
  src: string;
  /** Boards that still have no "FY{fy}" group. */
  groupsMissing: PrepBoard[];
  /** 05 · teams in the source year with no row in the target year. */
  otTeams: string[];
  /** 07 · Group + Company pairs present in the source year. */
  pairs: number;
  /** 07 · the (pair × month) rows of the target year that do not exist yet. */
  cpRows: { grp: string; co: string; mo: string }[];
  /** Rows to create (groups are not rows). */
  total: number;
  /** Boards whose FY column has no option for this FY yet. Blocks the run. */
  labelMissing: PrepBoard[];
}

const norm = (s: unknown) => String(s ?? '').trim().toLowerCase();

/** A board has the FY group when a group titled exactly "FY{fy}" (trimmed, any case) exists. */
export function fyGroupOf(groups: { id: string; title: string }[] | undefined, fy: string | number) {
  const want = norm(`FY${fy}`);
  return (groups ?? []).find((g) => norm(g.title) === want);
}

/** Prepared = the FY group exists on ALL THREE boards. Rows are never part of this test. */
export function isPrepared(groups: PrepSnapshot['groups'] | null | undefined, fy: string | number): boolean {
  if (!groups) return false;
  return PREP_BOARDS.every((b) => !!fyGroupOf(groups[b], fy));
}

/** Source choices: prepared years (other than the target) that have rows on 05 or 07, newest first. */
export function sourceYears(snap: PrepSnapshot, fyList: string[], target: string | number): string[] {
  const withRows = new Set([...snap.ot.map((r) => String(r.fy)), ...snap.cp.map((r) => String(r.fy))]);
  return fyList
    .map(String)
    .filter((y) => y !== String(target) && isPrepared(snap.groups, y) && withRows.has(y))
    .sort((a, b) => Number(b) - Number(a));
}

/** THE function that decides what is missing. Reads the source year, never writes it. */
export function planPrepare(snap: PrepSnapshot, fy: string | number, src: string | number): PrepPlan {
  const FY = String(fy);
  const SRC = String(src);
  const groupsMissing = PREP_BOARDS.filter((b) => !fyGroupOf(snap.groups[b], FY));

  // 05 OT · teams with a row in the source year, minus teams that already have one in the target.
  const otHave = new Set(snap.ot.filter((r) => String(r.fy) === FY).map((r) => norm(r.t)));
  const otTeams: string[] = [];
  const otSeen = new Set<string>();
  for (const r of snap.ot) {
    if (String(r.fy) !== SRC || !r.t) continue;
    const k = norm(r.t);
    if (otHave.has(k) || otSeen.has(k)) continue;
    otSeen.add(k);
    otTeams.push(r.t);
  }

  // 07 CP · every Group + Company pair of the source year × the 12 months, minus what exists.
  const key = (g: string, c: string, m: string) => `${norm(g)}\u0001${norm(c)}\u0001${norm(m)}`;
  const cpHave = new Set(snap.cp.filter((r) => String(r.fy) === FY).map((r) => key(r.grp, r.co, r.mo)));
  const pairs: { grp: string; co: string }[] = [];
  const pairSeen = new Set<string>();
  for (const r of snap.cp) {
    if (String(r.fy) !== SRC || !r.grp || !r.co) continue;
    const k = `${norm(r.grp)}\u0001${norm(r.co)}`;
    if (pairSeen.has(k)) continue;
    pairSeen.add(k);
    pairs.push({ grp: r.grp, co: r.co });
  }
  const cpRows: PrepPlan['cpRows'] = [];
  for (const p of pairs) {
    for (const mo of MONTHS) {
      if (!cpHave.has(key(p.grp, p.co, mo))) cpRows.push({ grp: p.grp, co: p.co, mo });
    }
  }

  // The FY label must already exist on the board's FY dropdown; the app never adds labels.
  const lacks = (labels: string[] | null) => labels != null && !labels.map((x) => x.trim()).includes(FY);
  const labelMissing: PrepPlan['labelMissing'] = [];
  // 04 MP Plan · no rows are created here, but every team's MP import will write this FY later.
  if (lacks(snap.fyLabels['MP Plan'])) labelMissing.push('MP Plan');
  if (otTeams.length > 0 && lacks(snap.fyLabels['OT Plan'])) labelMissing.push('OT Plan');
  if (cpRows.length > 0 && lacks(snap.fyLabels['Company Plan'])) labelMissing.push('Company Plan');

  return {
    fy: FY,
    src: SRC,
    groupsMissing,
    otTeams,
    pairs: pairs.length,
    cpRows,
    total: otTeams.length + cpRows.length,
    labelMissing,
  };
}
