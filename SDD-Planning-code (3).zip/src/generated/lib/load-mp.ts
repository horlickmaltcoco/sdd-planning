// Performance pass · client side of the MP Plan read. Step 1 returns every group's first page;
// every group that came back with a cursor then walks its own chain, ALL CONCURRENTLY.
// Final order = groups in the order the API returned them, items in group order.
// `onCount` reports the running item total after every page (CHANGE 4).
import { LOAD_MAX_PAGES } from '@generated/config';
import type { LoadStats, MpRow } from '@generated/lib/types';
import { getMpMore, getMpStart } from '@generated/server/read-mp';
import { printReq } from '@generated/lib/load-perf';

export interface MpLoad {
  rows: MpRow[];
  types: string[];
  roles: string[];
  systems: string[];
  systemsAll: string[];
  task2s: string[];
  task2sAll: string[];
  stats: LoadStats;
  diag: { items: number; cells: number; emptyNow: number; changedByFix: number };
}

export async function loadMpPaged(fy: string, onCount: (n: number) => void): Promise<MpLoad> {
  const t0 = performance.now();
  const start = await getMpStart({ data: { fy } });
  printReq('04 MP Plan', 'getMpStart', performance.now() - t0, start?.stats);
  const groups = (start?.groups ?? []).map((g) => ({ rows: [...g.rows], cursor: g.cursor }));
  const diag = { ...(start?.diag ?? { items: 0, cells: 0, emptyNow: 0, changedByFix: 0 }) };
  let requests = start?.stats?.requests ?? 0;
  let count = groups.reduce((s, g) => s + g.rows.length, 0);
  onCount(count);

  await Promise.all(
    groups.map(async (g) => {
      let pages = 0;
      while (g.cursor && pages < LOAD_MAX_PAGES) {
        pages += 1;
        const tc = performance.now();
        const next = await getMpMore({ data: { cursor: g.cursor } });
        printReq('04 MP Plan', 'getMpMore', performance.now() - tc, { ms: next?.ms, calls: [{ what: 'next page', ms: next?.ms ?? 0, rows: next?.rows?.length ?? 0 }] });
        requests += 1;
        const got = next?.rows ?? [];
        g.rows.push(...got);
        g.cursor = next?.cursor ?? null;
        diag.items += next?.diag?.items ?? 0;
        diag.cells += next?.diag?.cells ?? 0;
        diag.emptyNow += next?.diag?.emptyNow ?? 0;
        diag.changedByFix += next?.diag?.changedByFix ?? 0;
        count += got.length;
        onCount(count);
      }
    }),
  );

  const rows = groups.flatMap((g) => g.rows);
  const base = start?.stats;
  return {
    rows,
    types: start?.types ?? [],
    roles: start?.roles ?? [],
    systems: start?.systems ?? [],
    systemsAll: start?.systemsAll ?? [],
    task2s: start?.task2s ?? [],
    task2sAll: start?.task2sAll ?? [],
    diag,
    stats: {
      requests,
      items: rows.length,
      ms: base?.ms ?? 0,
      mode: base?.mode ?? 'grouped',
      groups: base?.groups ?? groups.length,
      ...(base?.note ? { note: base.note } : {}),
    },
  };
}
