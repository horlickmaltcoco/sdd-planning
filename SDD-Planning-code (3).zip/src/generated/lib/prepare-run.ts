// Session 1-15 · เตรียมข้อมูลปีงบ — the run. Every run starts from a FRESH snapshot and recomputes
// what is missing, so pressing again after any failure creates only what is still absent.
// Groups first (reuse, create only if absent), then rows in batches of 25. Value cells are never
// written: months and Plan MD stay EMPTY. Nothing is ever deleted, renamed or updated.
import { SRC_APP } from '@generated/config';
import { CP_C, OT_C } from '@generated/lib/cols';
import { monthYearOf } from '@generated/lib/parse';
import { planPrepare, PREP_BOARDS, type PrepPlan } from '@generated/lib/prepare-plan';
import { createPrepBatch, ensureFyGroup, readPrepareSnapshot } from '@generated/server/prepare-fy';

const BATCH = 25;
/** Pause between requests so a long run does not trip the sign-in service's rate limit. */
const PACE_MS = 700;
/** Waits before each retry of a request that was turned away for rate (HTTP 429). */
const RETRY_WAITS_MS = [5_000, 15_000, 30_000, 60_000];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * A 429 / rate-limit answer means the request was refused BEFORE monday ran it (the token service
 * or monday's limiter said no), so sending the same batch again cannot create a duplicate row.
 * Any other error is not retried here — the run stops and the next press recounts from the boards.
 */
function isRateLimited(e: unknown): boolean {
  const msg = e instanceof Error ? e.message : String(e);
  return /HTTP 429|\b429\b|rate.?limit|too many requests/i.test(msg);
}

async function paced<T>(call: () => Promise<T>): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try {
      const out = await call();
      await sleep(PACE_MS);
      return out;
    } catch (e) {
      const wait = RETRY_WAITS_MS[attempt];
      if (!isRateLimited(e) || wait === undefined) throw e;
      console.warn(`[runPrepare] rate limited — waiting ${wait / 1000}s, retry ${attempt + 1}/${RETRY_WAITS_MS.length}`);
      await sleep(wait);
    }
  }
}

function chunks<T>(list: T[], n: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < list.length; i += n) out.push(list.slice(i, i + n));
  return out;
}

export async function runPrepare(
  fy: string,
  src: string,
  onProgress: (done: number, total: number) => void,
): Promise<{ done: number; total: number; failed: boolean; plan: PrepPlan }> {
  // 1 · recount from the boards themselves — never from the dialog's earlier numbers.
  const snap = await readPrepareSnapshot({ data: {} });
  const plan = planPrepare(snap, fy, src);
  const total = plan.total;
  let done = 0;
  onProgress(done, total);
  // A missing FY label would fail every create — stop BEFORE any group is made.
  if (plan.labelMissing.length > 0) return { done, total, failed: true, plan };

  try {
    // 2 · the FY group on all three boards (04 gets one too: MP Plan import needs a place to write).
    const gid: Record<string, string> = {};
    for (const b of PREP_BOARDS) {
      const r = await paced(() => ensureFyGroup({ data: { board: b, fy } }));
      gid[b] = r.id;
    }

    // 3 · 05 OT Plan · one empty row per missing team.
    const otItems = plan.otTeams.map((t) => ({
      name: `${t} · FY${fy}`,
      columnValues: { [OT_C.t]: { labels: [t] }, [OT_C.fy]: { labels: [fy] }, [OT_C.src]: { label: SRC_APP } },
    }));
    for (const part of chunks(otItems, BATCH)) {
      await paced(() => createPrepBatch({ data: { board: 'OT Plan', groupId: gid['OT Plan']!, items: part } }));
      done += part.length;
      onProgress(done, total);
    }

    // 4 · 07 Company Plan · the missing (pair × month) rows, Plan MD empty.
    const cpItems = plan.cpRows.map((r) => ({
      name: `${r.grp} · ${r.co} · ${monthYearOf(r.mo, fy)}`,
      columnValues: {
        [CP_C.grp]: { labels: [r.grp] },
        [CP_C.co]: { labels: [r.co] },
        [CP_C.mo]: { labels: [r.mo] },
        [CP_C.fy]: { labels: [fy] },
        [CP_C.src]: { label: SRC_APP },
      },
    }));
    for (const part of chunks(cpItems, BATCH)) {
      await paced(() => createPrepBatch({ data: { board: 'Company Plan', groupId: gid['Company Plan']!, items: part } }));
      done += part.length;
      onProgress(done, total);
    }
  } catch (e) {
    console.error('runPrepare stopped', { fy, src, done, total }, e);
    return { done, total, failed: true, plan };
  }
  return { done, total, failed: false, plan };
}
