// MP Plan · System (+ Role options) — the ONE rule and the label helpers every screen and the file
// import share. Lists always come from the MP Plan board's own column settings, never hardcoded.

/** trim + collapse inner spaces + lowercase — how a typed value is compared with a board label. */
export function norm(v: unknown): string {
  return String(v ?? '')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

/** The board's own label text for `v` (by norm), or null when no label matches. */
export function matchLabel(v: unknown, labels: readonly string[]): string | null {
  const n = norm(v);
  if (!n) return null;
  return labels.find((l) => norm(l) === n) ?? null;
}

/** A Type in the 01.xxx family (01.Project). */
export function isProjectType(type: unknown): boolean {
  return String(type ?? '').trim().startsWith('01.');
}

/** THE rule: a 01.Project row must have a System ("All System" is a valid System). */
export function systemMissing(row: { type?: string | null; system?: string | null }): boolean {
  return isProjectType(row.type) && !String(row.system ?? '').trim();
}

export const SYSTEM_RULE_MSG = 'งานประเภท 01.Project ต้องระบุ System (เลือก All System ได้ เมื่อแผนครอบหลายระบบ)';
export const SYSTEM_HELP =
  'System ต้องตรงกับส่วนท้ายของชื่อบอร์ด WBS (ชื่อโครงการ : ชื่อระบบ) · งานประจำที่ลงเวลาบน Task Master เลือก Task2 ได้';

/** Picker value for "no System". */
export const NONE = '__none__';

/**
 * Labels of a dropdown / status column from its settings_str: `active` (what pickers offer) and
 * `all` (active + deactivated — a row already holding a deactivated label still displays it).
 */
export function parseLabelSet(settings?: string | null): { active: string[]; all: string[] } {
  if (!settings) return { active: [], all: [] };
  try {
    type L = Record<string, string> | ({ id?: number; name?: string } | number | null)[] | null | undefined;
    const j = JSON.parse(settings) as { labels?: L; deactivated_labels?: L };
    const read = (l: L): { id: number; name: string }[] =>
      !l
        ? []
        : Array.isArray(l)
          ? l.map((x) => (typeof x === 'number' ? { id: x, name: '' } : { id: Number(x?.id), name: String(x?.name ?? '').trim() }))
          : Object.keys(l)
              .sort((a, b) => Number(a) - Number(b))
              .map((k) => ({ id: Number(k), name: String(l[k] ?? '').trim() }));
    const labels = read(j?.labels);
    const off = read(j?.deactivated_labels);
    const offIds = new Set(off.map((x) => x.id));
    const active = labels.filter((x) => x.name && !offIds.has(x.id)).map((x) => x.name);
    const all = [...new Set([...labels.map((x) => x.name), ...off.map((x) => x.name)].filter(Boolean))];
    return { active, all };
  } catch {
    return { active: [], all: [] };
  }
}
