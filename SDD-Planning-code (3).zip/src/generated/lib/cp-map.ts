// 07 · Company Plan · one item → one CPLAN row (B1). Pure mapping, shared by the loader and the
// re-read. Plan MD keeps the board's full precision; an empty cell stays null (0 is a real value).
import { CP_C } from '@generated/lib/cols';
import { cvMap, dropdown, itemId, lastUpdatedIso, monthYearOf, num, status } from '@generated/lib/parse';
import type { CpRow, RawItem } from '@generated/lib/types';

export function cpRowOf(it: RawItem): CpRow {
  const cv = cvMap(it);
  const mo = dropdown(cv[CP_C.mo]);
  const fy = dropdown(cv[CP_C.fy]);
  return {
    id: String(itemId(it)),
    grp: dropdown(cv[CP_C.grp]),
    co: dropdown(cv[CP_C.co]),
    mo,
    fy,
    my: monthYearOf(mo, fy),
    md: num(cv[CP_C.md]),
    src: status(cv[CP_C.src]),
    editedAt: lastUpdatedIso(cv[CP_C.edited]),
  };
}
