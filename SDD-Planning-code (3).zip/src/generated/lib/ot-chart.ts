// Session 1-06 Part B · chart derivations for the OT Plan page. Pure functions — no React,
// no board access. Every chart of ONE view shares ONE scale (customer decision 2026-09-24),
// so the numbers here are computed once for the whole view and handed to every card.
import { ALLMI } from '@generated/config';
import { n1 } from '@generated/engine';
import type { OtCellView } from '@generated/lib/ot-derive';

export type OtView = 'team' | 'grp';

export interface GrpChart {
  g: string;
  cells: OtCellView[];
  teams: string[];
  tot: number;
  /** "5" when every month has the same headcount, else "26–27". */
  hc: string;
}

/** The shared scale of a view: the tallest bar of every chart in it. 0 when there is none. */
export function maxOf(charts: OtCellView[][], MI: number[]): number {
  let m = 0;
  for (const cells of charts) {
    for (const i of MI) {
      const v = cells[i]?.v ?? 0;
      if (v > m) m = v;
    }
  }
  return m;
}

/** "5" or "26–27". An empty list is handled on its own — never by seeding min/max with 0. */
export function rangeTxt(nums: number[]): string {
  if (nums.length === 0) return '0';
  let lo = nums[0] as number;
  let hi = nums[0] as number;
  for (const n of nums) {
    if (n < lo) lo = n;
    if (n > hi) hi = n;
  }
  return lo === hi ? String(hi) : `${lo}–${hi}`;
}

/** Σ of the months in view, null counted as 0 (display only). */
export function totOf(cells: OtCellView[], MI: number[]): number {
  return MI.reduce<number>((acc, i) => acc + (cells[i]?.v ?? 0), 0);
}

/**
 * One chart per Group. The Group of a team is read PER MONTH from the assignment spans, so a
 * team that moved Group mid-year puts each month's hours into the Group of that month.
 */
export function buildGroups(
  shown: string[],
  MI: number[],
  grpAt: (t: string, i: number) => string,
  otAt: (t: string, i: number) => OtCellView,
  fg: string,
): GrpChart[] {
  const order: string[] = [];
  for (const t of shown) {
    for (const i of MI) {
      const g = grpAt(t, i);
      if (!order.includes(g)) order.push(g);
    }
  }
  const keep = fg === 'ALL' ? order : order.filter((g) => g === fg);

  return keep.map((g) => {
    const cells: OtCellView[] = [];
    const teams: string[] = [];
    for (const i of ALLMI) {
      let s = 0;
      let h = 0;
      let any = false;
      for (const t of shown) {
        if (grpAt(t, i) !== g) continue;
        const c = otAt(t, i);
        if (c.v != null) {
          any = true;
          s += c.v;
        }
        h += c.head || 0;
        if (MI.includes(i) && !teams.includes(t)) teams.push(t);
      }
      cells[i] = { v: any ? s : null, head: h, avg: any && h > 0 ? s / h : null };
    }
    return {
      g,
      cells,
      teams,
      tot: totOf(cells, MI),
      hc: rangeTxt(MI.map((i) => cells[i]?.head ?? 0)),
    };
  });
}

/**
 * Y-axis ticks (customer decision 2026-09-25). `top` is the shared scale of the view, so every
 * chart of that view shows the SAME ticks: 87 → 0 · 25 · 50 · 75 · 254 → 0 · 100 · 200.
 */
export function ticksOf(top: number): number[] {
  if (!(top > 0)) return [];
  const max = top * 1.1;
  const raw = top / 4;
  const mag = 10 ** Math.floor(Math.log10(raw || 1));
  const step = [1, 2, 2.5, 5, 10].map((f) => f * mag).find((s) => s >= raw) ?? 10 * mag;
  const out: number[] = [];
  for (let k = 0; k < 6; k += 1) {
    const v = step * k;
    if (v > max) break;
    out.push(v);
  }
  return out;
}

/** Tick label: whole numbers get thousands separators and no decimals, else one decimal. */
export function tickTxt(v: number): string {
  return n1(v);
}
