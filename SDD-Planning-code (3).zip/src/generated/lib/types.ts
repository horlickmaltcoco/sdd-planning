// Raw GraphQL shapes + the collection shapes Session 1-02 (engine) depends on.

export interface RawCv {
  id: string;
  text?: string | null;
  value?: string | null;
  type?: string | null;
  index?: number | null;
  label?: string | null;
  values?: ({ label?: string | null } | null)[] | null;
  number?: number | string | null;
  date?: string | null;
  updated_at?: string | null;
}

/** Performance pass · what one board read cost. `requests` counts item-page requests only. */
export interface LoadStats {
  requests: number;
  items: number;
  /** server-side elapsed ms for the item reads */
  ms: number;
  mode: 'grouped' | 'sequential-fallback' | 'legacy';
  groups: number;
  note?: string;
  /** Session 1-17b · one entry per monday request made inside the server call (logging only). */
  calls?: ReqLog[];
}

export interface ReqLog {
  what: string;
  ms: number;
  rows: number;
}

export interface RawItem {
  id: string | number;
  name?: string | null;
  column_values?: RawCv[] | null;
  subitems?: RawItem[] | null;
}

/* ---- B3 · Working Day Master ---- */
export type MonthArr = (number | null)[]; // always 12 slots, fiscal order Apr..Mar
export interface RuleRow {
  tol: number | null;
  minPer: string;
  maxPer: string;
  bands: string;
  redAt: number | null;
  hpd: number | null;
}
export type WdMap = Record<string, MonthArr>;
export type RuleMap = Record<string, RuleRow>;

/* ---- B4 · MP Plan ---- */
export interface MpRow {
  id: string;
  title: string;
  team: string;
  type: string;
  t1: string;
  role: string;
  detail: string;
  /** System dropdown label ('' = empty). */
  system: string;
  /** Task2 dropdown label ('' = empty, optional). */
  task2: string;
  name: string;
  empid: string;
  sec: string;
  ms: string;
  m: number[]; // 12 hours, empty cell read as 0
  fy: string;
  batch: string;
  src: string;
  editedAt: string; // local "YYYY-MM-DD HH:MM:SS"
}

/* ---- B5 · OT Plan ---- */
export interface OtRow {
  id: string;
  name: string;
  t: string;
  fy: string;
  pl: string;
  m: (number | null)[]; // 12, null = not entered
  batch: string;
  src: string;
  editedAt: string;
}

/* ---- 07 · Company Plan (CPLAN) ---- */
export interface CpRow {
  /** item id — the row identity everywhere (cell edits, Item ID in files). Never match by name. */
  id: string;
  grp: string;
  co: string;
  mo: string;
  fy: string;
  /** monthYearOf(mo, fy), e.g. "Apr2026" · "Jan2027" — the board has no MonthYear column. */
  my: string;
  /** Plan MD at full precision; null = cell empty (not filled). 0 is a real value. */
  md: number | null;
  src: string;
  editedAt: string;
}

/* ---- B7 · Employee Master ---- */
export type EmpRow = string[]; // 14 slots, see E
export type AssignRow = string[]; // 7 slots, see A

export const E = {
  name: 0,
  emp: 1,
  email: 2,
  grp: 3,
  sec: 4,
  pos: 5,
  begin: 6,
  end: 7,
  status: 8,
  quota: 9,
  incharge: 10,
  mpname: 11,
  plan: 12,
  lvl: 13,
} as const;

export const A = {
  emp: 0,
  team: 1,
  from: 2,
  to: 3,
  quota: 4,
  why: 5,
  grp: 6,
} as const;

/* ---- B8 · master lists ---- */
export interface BdLists {
  sections: string[];
  groups: string[];
  grpOf: Record<string, string>;
  types: string[];
  roles: string[];
  /** MP Plan System labels (active only — what pickers offer). */
  systems: string[];
  /** Every System label incl. deactivated. */
  systemsAll: string[];
  /** MP Plan Task2 labels: active (pickers) and all. */
  task2s: string[];
  task2sAll: string[];
  companies: string[];
  months: readonly string[];
  boards: Record<string, string>;
}

export type LoadStatus = 'loading' | 'ok' | 'error';
export interface BoardState {
  status: LoadStatus;
  msg: string;
}

export const PENDING = '— รอระบุ —';
