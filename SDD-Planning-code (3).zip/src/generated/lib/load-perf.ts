// Performance pass · measurement only. Prints per-board ms · requests · items after every
// full load, plus the moment each page first became usable. Nothing here changes data.
import type { BoardKey, PageId } from '@generated/config';

export const PERF_CODE: Record<BoardKey, string> = {
  'Employee Master': '02',
  'Working Day Master': '03',
  'MP Plan': '04',
  'OT Plan': '05',
  'Company Plan': '07',
};

export interface PerfRow {
  board: string;
  /** client wall clock for this board, performance.now() before the call → data in hand */
  ms: number;
  requests: number;
  items: number;
  mode: string;
  serverMs: number;
}

/**
 * Temporary switch for the BEFORE measurement on this same build:
 * ?sddLoad=legacy (or localStorage sddLoad = "legacy") → the old sequential walk, the old full
 * selection (with `type`) for every column, and every page waiting for all five boards.
 */
export function readLegacy(): boolean {
  try {
    const q =
      new URLSearchParams(window.location.search).get('sddLoad') ??
      window.localStorage.getItem('sddLoad') ??
      '';
    return q.trim().toLowerCase() === 'legacy';
  } catch {
    return false;
  }
}

export function perfTag(legacy: boolean): string {
  return legacy ? 'BEFORE · legacy loader' : 'AFTER · grouped loader';
}

/**
 * Session 1-17b · one line per server call: client wall clock, time inside the server handler, and
 * the difference (route overhead: browser → app server → back). Then one line per monday request.
 */
export function printReq(board: string, call: string, clientMs: number, stats?: { ms?: number; calls?: { what: string; ms: number; rows: number }[] } | null): void {
  const handler = stats?.ms ?? 0;
  console.log(
    `[SDD req] ${board} · ${call} | client ${Math.round(clientMs)} ms | handler ${Math.round(handler)} ms | route ${Math.round(clientMs - handler)} ms`,
  );
  for (const c of stats?.calls ?? []) console.log(`[SDD req] ${board} ·   monday · ${c.what} | ${c.ms} ms | ${c.rows} rows`);
}

export function printPerfTable(
  legacy: boolean,
  cycle: number,
  rows: PerfRow[],
  wallMs: number,
  sinceOpenMs: number,
): void {
  const tag = perfTag(legacy);
  const kind = cycle === 1 ? 'cold load' : `reload #${cycle - 1}`;
  console.log(`[SDD perf] ${tag} · ${kind} · board | ms | requests | items | mode | server ms`);
  for (const r of rows) {
    console.log(
      `[SDD perf] ${tag} · ${r.board} | ${Math.round(r.ms)} | ${r.requests} | ${r.items} | ${r.mode} | ${Math.round(r.serverMs)}`,
    );
  }
  console.log(
    `[SDD perf] ${tag} · ${kind} · wall clock ${(wallMs / 1000).toFixed(2)} s (first call → last board)` +
      ` · ${(sinceOpenMs / 1000).toFixed(2)} s since the page was opened`,
  );
  try {
    console.table(rows.map((r) => ({ ...r, ms: Math.round(r.ms), serverMs: Math.round(r.serverMs) })));
  } catch {
    /* console.table is optional */
  }
}

export function printPageReady(legacy: boolean, page: PageId, sinceOpenMs: number): void {
  console.log(
    `[SDD perf] ${perfTag(legacy)} · page "${page}" usable at ${(sinceOpenMs / 1000).toFixed(2)} s since the page was opened`,
  );
}
