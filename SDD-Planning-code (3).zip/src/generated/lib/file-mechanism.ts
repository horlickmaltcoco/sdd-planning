/**
 * Session 1-05 Part A — File Export/Import Mechanism
 * Shared by MP Plan and OT Plan boards
 */

import { MONTHS, ALLMI, MP_MONTH_COL, SRC_IMPORT, SRC_APP } from '@generated/config';
import { norm } from '@generated/lib/mp-fields';
import { NOW } from '@generated/engine';
import { TT } from '@generated/i18n';
import type { CpRow, MpRow, OtRow } from '@generated/lib/types';

// =============================================================================
// A2. FILE SPECS
// =============================================================================

export interface FileSpec<T = any> {
  id: (r: T) => string;
  info: Array<[string, string]>; // [fileHeader, fieldKey]
  vals: string[];
  val: (r: T, i: number) => number | null;
  label: (r: T) => [string, string]; // for display in diff
  name: string; // file stem
  cellsOnly: boolean;
  nullAsZero: boolean;
  /** Optional compare tolerance. Unset → the shared 0.0001 (MP / OT unchanged). */
  eps?: number;
  /**
   * Session 1-18 · MP only. Text / label columns an EXISTING row (matched by Item ID) may have
   * updated from the file: [file header, field]. An empty file cell means "no change" — it never
   * clears the board. Name is deliberately NOT here.
   */
  text?: Array<[string, string]>;
}

export function fileSpecOf(which: 'mp' | 'ot' | 'cp'): FileSpec {
  if (which === 'cp') {
    // 07 Company Plan · cells only, one value (Plan MD, unit MD) at full precision.
    return {
      id: (r: CpRow) => String(r.id),
      info: [
        ['Group', 'grp'],
        ['Company', 'co'],
        ['MonthYear', 'my'],
      ],
      vals: ['Plan MD'],
      val: (r: CpRow) => r.md,
      label: (r: CpRow) => [`${r.grp} · ${r.co}`, r.my],
      name: 'Company_Plan',
      cellsOnly: true,
      nullAsZero: false,
      eps: 1e-9,
    };
  }

  if (which === 'mp') {
    return {
      id: (r: MpRow) => String(r.id),
      info: [
        ['Team', 'team'],
        ['Type', 'type'],
        ['Task1', 't1'],
        ['System', 'system'],
        ['Task2', 'task2'],
        ['Role', 'role'],
        ['Detail', 'detail'],
        ['Name', 'name'],
        ['Fy Year', 'fy'],
      ],
      vals: [...MONTHS],
      val: (r: MpRow, i: number) => r.m[i] ?? 0,
      label: (r: MpRow) => [r.name, r.t1],
      name: 'MP',
      cellsOnly: false,
      nullAsZero: true,
      text: [
        ['Type', 'type'],
        ['Task1', 't1'],
        ['System', 'system'],
        ['Task2', 'task2'],
        ['Role', 'role'],
        ['Detail', 'detail'],
      ],
    };
  }

  // ot
  return {
    id: (r: OtRow) => String(r.id),
    info: [['Team', 't']],
    vals: [...MONTHS],
    val: (r: OtRow, i: number) => (r.m && r.m[i] !== undefined ? r.m[i] : null),
    label: (r: OtRow) => [r.t, ''], // grpOf will be added by caller if needed
    name: 'OT_Plan',
    cellsOnly: true,
    nullAsZero: false,
  };
}

export const IMPORT_SPEC: Record<
  'mp' | 'ot' | 'cp',
  { board: string; kind: string; ext: string; page?: string }
> = {
  mp: { board: 'MP Plan', kind: 'MP Plan', ext: '.csv' },
  ot: { board: 'OT Plan', kind: 'OT Plan', ext: '.csv' },
  cp: { board: 'Company Plan', kind: 'Company Plan', ext: '.csv', page: 'แผนงาน ISUZU Group' },
};

// OT month column IDs (fiscal order Apr..Mar)
export const OT_MONTH_COL = [
  'numeric_mm7123ad',  // 0 Apr
  'numeric_mm71ets0',  // 1 May
  'numeric_mm71kp1p',  // 2 Jun
  'numeric_mm713s0b',  // 3 Jul
  'numeric_mm71zyff',  // 4 Aug
  'numeric_mm71ma7',   // 5 Sep
  'numeric_mm71zbme',  // 6 Oct
  'numeric_mm71aa73',  // 7 Nov
  'numeric_mm718xwq',  // 8 Dec
  'numeric_mm713fpx',  // 9 Jan
  'numeric_mm714mj1',  // 10 Feb
  'numeric_mm718k6f',  // 11 Mar
] as const;

// =============================================================================
// A3. FILE FORMAT — CSV GENERATION
// =============================================================================

function escapeCSV(v: string | number | null): string {
  if (v == null || v === '') return '';
  const s = String(v);
  // Quote if contains comma, quote, CR or LF
  if (s.includes(',') || s.includes('"') || s.includes('\r') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function csvLine(cells: (string | number | null)[]): string {
  return cells.map(escapeCSV).join(',');
}

// =============================================================================
// Export time ↔ instant. Shared by MP, OT and Company Plan (conflict gate in diffFile).
// =============================================================================

const LOCAL_STAMP = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/;
const ZONED_STAMP = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})$/;

/**
 * A stamp → epoch ms. With a zone marker (Z / ±hh:mm) it is that instant. Without one
 * ("YYYY-MM-DD HH:mm:ss", the old EXPORTED_AT and every editedAt the app holds) it is LOCAL time,
 * the way it was produced. Any other shape (e.g. "15/10/26 00:55" after Excel re-saved the file)
 * is NaN — never guessed, because day/month order cannot be known.
 */
export function stampMs(s: string | null | undefined): number {
  const t = String(s ?? '').trim();
  if (!t) return NaN;
  if (ZONED_STAMP.test(t)) return Date.parse(t);
  const m = LOCAL_STAMP.exec(t);
  if (!m) return NaN;
  const [, y, mo, d, h, mi, se] = m;
  return new Date(+y!, +mo! - 1, +d!, +h!, +mi!, se ? +se : 0).getTime();
}

/** Local "YYYY-MM-DD HH:mm:ss" → the same instant as ISO 8601 with this machine's offset. */
export function zonedStamp(local: string): string {
  const ms = stampMs(local);
  if (Number.isNaN(ms)) return local;
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, '0');
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? '+' : '-';
  const oh = p(Math.floor(Math.abs(off) / 60));
  const om = p(Math.abs(off) % 60);
  return (
    `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}` +
    `T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}${sign}${oh}:${om}`
  );
}

/** EXPORTED_AT as shown on screen: the same local "YYYY-MM-DD HH:mm:ss" look as before. */
export function exportedAtLabel(s: string | null | undefined): string {
  const raw = String(s ?? '').trim();
  const ms = stampMs(raw);
  if (Number.isNaN(ms)) return raw;
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

/** Clock slack between monday and this app: only MORE than this after export counts as an edit. */
const EDIT_SLACK_MS = 1000;

export function buildCSV<T>(
  spec: FileSpec<T>,
  rows: T[],
  meta: { kind: string; fy: string | number; team?: string; stamp: string }
): string {
  const lines: string[] = [];
  
  // Row 1: metadata
  const metaRow = ['#SDD', 'KIND', meta.kind, 'FY', String(meta.fy)];
  if (meta.team) {
    metaRow.push('TEAM', meta.team);
  }
  // EXPORTED_AT carries its zone (ISO 8601 + offset) so the conflict gate compares instants, and
  // Excel keeps it as text instead of re-formatting it as a local date (which it does to
  // "YYYY-MM-DD HH:mm:ss"). The on-screen stamp (meta.stamp, the toast) stays as it was.
  metaRow.push('EXPORTED_AT', zonedStamp(meta.stamp));
  // Data-row count for people checking the file. Display only — the importer never compares it
  // (users may append new rows, so the real count is expected to exceed ROWS).
  metaRow.push('ROWS', String(rows.length));
  lines.push(csvLine(metaRow));

  // Row 2: header
  const headers = ['Item ID', ...spec.info.map(([h]) => h), ...spec.vals];
  lines.push(csvLine(headers));

  // Data rows
  for (const r of rows) {
    const row: (string | number | null)[] = [spec.id(r)];
    // Info columns
    for (const [, field] of spec.info) {
      row.push((r as any)[field] ?? '');
    }
    // Value columns
    for (let i = 0; i < spec.vals.length; i++) {
      const v = spec.val(r, i);
      row.push(v);
    }
    lines.push(csvLine(row));
  }

  // UTF-8 BOM + CRLF
  return '\uFEFF' + lines.join('\r\n');
}

export function fileName(
  which: 'mp' | 'ot' | 'cp',
  fy: string | number,
  team?: string
): string {
  const stamp = NOW().replace(/[-: ]/g, '').slice(0, 12); // YYYYMMDDHHMM
  const ext = IMPORT_SPEC[which].ext;
  
  if (which === 'mp' && team) {
    return `${fy}_MP_${team}_${stamp}${ext}`;
  }
  if (which === 'cp') {
    return `${fy}_Company_Plan_${stamp}${ext}`;
  }
  return `${fy}_OT_Plan_${stamp}${ext}`;
}

export function downloadFile(content: string, name: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// =============================================================================
// A5. READ-BACK — parseFile
// =============================================================================

export interface ParsedFile {
  meta: Record<string, string>;
  rows: Array<{
    id: string;
    _: Record<string, string>;
    v: (number | null)[];
    /** 1-based line number in the file, for "#<line> · …" messages. */
    line?: number;
  }>;
  /** Trimmed header cells of the file (which optional columns it carries). */
  cols?: string[];
  badId: string[]; // Item IDs that are not digits-only
  /** Company Plan only · "Item ID · text" of every unreadable or negative Plan MD cell. */
  badNum?: string[];
}

function parseCSV(text: string): string[][] {
  // Strip BOM
  if (text.charCodeAt(0) === 0xfeff) {
    text = text.slice(1);
  }

  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuote = false;
  let i = 0;

  while (i < text.length) {
    const c = text[i];
    const next = text[i + 1];

    if (inQuote) {
      if (c === '"') {
        if (next === '"') {
          cell += '"';
          i += 2;
          continue;
        }
        inQuote = false;
        i++;
        continue;
      }
      cell += c;
      i++;
      continue;
    }

    // Not in quote
    if (c === '"') {
      inQuote = true;
      i++;
      continue;
    }

    if (c === ',') {
      row.push(cell);
      cell = '';
      i++;
      continue;
    }

    if (c === '\r') {
      i++;
      continue;
    }

    if (c === '\n') {
      row.push(cell);
      if (row.some((x) => x.trim())) {
        rows.push(row);
      }
      row = [];
      cell = '';
      i++;
      continue;
    }

    cell += c;
    i++;
  }

  // Last row
  if (cell || row.length) {
    row.push(cell);
    if (row.some((x) => x.trim())) {
      rows.push(row);
    }
  }

  return rows;
}

// Async wrapper that reads a File object. Only CSV is readable: an .xlsx is a ZIP and always
// begins with the bytes "PK" — detected from the CONTENT (never the file name), never parsed.
export async function parseFileAsync(
  spec: FileSpec,
  file: File,
): Promise<{ err: string } | ParsedFile> {
  try {
    const text = await readFileAsText(file);
    if (text.startsWith('PK')) {
      return {
        err: 'ไฟล์นี้เป็น .xlsx ซึ่งระบบยังอ่านไม่ได้ · เปิดใน Excel แล้วเลือก Save As ชนิด CSV UTF-8 (Comma delimited) ก่อนนำเข้า',
      };
    }
    return parseFile(spec, text);
  } catch {
    return { err: 'อ่านไฟล์ไม่สำเร็จ' };
  }
}

function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string ?? '');
    reader.onerror = () => reject(new Error('อ่านไฟล์ไม่สำเร็จ'));
    reader.readAsText(file, 'utf-8');
  });
}

// ==== SHARED PARSING HELPERS (Defect 1 fix) ====

/** Parse a file cell to number | null (null for empty/non-finite). */
export function parseFileValue(text: string | null | undefined): number | null {
  // Thousands separators are removed so "1,000" reads as 1000 (it passed isBadNum the same way).
  const t = String(text ?? '').replace(/,/g, '').trim();
  if (t === '' || t === null || t === undefined) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

/** Shared bad-number gate: non-empty text that is not a finite, non-negative number. */
export function isBadNum(text: string): boolean {
  // Thousands separators are stripped first (Excel writes "1,000" for formatted cells),
  // exactly as the Company Plan cell card does.
  const t = text.replace(/,/g, '').trim();
  if (t === '') return false;
  return !/^\d+(\.\d+)?$/.test(t);
}

/** Check if two values are the same (Defect 1 fix). */
/**
 * Round-trip tolerance. Excel writes the DISPLAYED value into a CSV (~10 significant digits), so
 * an untouched long decimal comes back slightly different. A cell is a change only when it differs
 * by MORE than max(1e-6, |board| × 1e-8); the spec's own eps (MP / OT: 0.0001 h) stays as a floor,
 * so this never makes the hours comparison stricter than before.
 */
export function changeTolerance(old: number, eps = 0.0001): number {
  return Math.max(eps, 1e-6, Math.abs(old) * 1e-8);
}

export function sameValue(old: number | null, nv: number | null, eps = 0.0001): boolean {
  if (old == null && nv == null) return true;
  if ((old == null) !== (nv == null)) return false; // null vs 0 IS a change
  return Math.abs(old! - nv!) <= changeTolerance(old!, eps);
}

/** A guide / comment line: its first cell, trimmed of surrounding spaces, begins with "#". */
export function isCommentRow(r: string[] | undefined): boolean {
  return String(r?.[0] ?? '').trim().startsWith('#');
}

export function parseFile(
  spec: FileSpec,
  fileContent: string
): { err: string } | ParsedFile {
  try {
    const raw = parseCSV(fileContent);
    if (raw.length === 0) {
      return { err: 'ไฟล์นี้ว่างเปล่า' };
    }

    let dataStart = 0;
    const meta: Record<string, string> = {};

    // MP only · the #SDD row is mandatory: without it every KIND / TEAM / FY scope check in the
    // import dialog silently passes. OT and Vendor MA keep it optional.
    if (spec.name === 'MP' && !raw[0]?.[0]?.trim().startsWith('#SDD')) {
      return {
        err: 'ไฟล์นี้ไม่มีแถว #SDD · กรุณาใช้ไฟล์ที่ export จากระบบหรือเทมเพลตกลาง และอย่าลบแถวแรกทิ้ง',
      };
    }

    // Check for metadata row
    if (raw[0]?.[0]?.trim().startsWith('#SDD')) {
      const metaRow = raw[0];
      for (let i = 1; i < metaRow.length; i += 2) {
        const key = metaRow[i]?.trim() ?? '';
        const val = metaRow[i + 1]?.trim() ?? '';
        if (key) meta[key] = val;
      }
      dataStart = 1;
    }

    // Session 1-13 · comment lines. Every line AFTER the #SDD meta row whose FIRST cell, trimmed,
    // begins with "#" is a guide line, not data — dropped here, before the header is located, so it
    // is never counted, matched, added, missing or reported. Judged on the first cell alone ("#" on
    // its own with values after it is still a comment); a "#" in any other cell is ordinary text.
    const kept = [
      ...raw.slice(0, dataStart).map((r, i) => ({ r, line: i + 1 })),
      ...raw
        .map((r, i) => ({ r, line: i + 1 }))
        .slice(dataStart)
        .filter((x) => !isCommentRow(x.r)),
    ];
    const rows = kept.map((x) => x.r);

    if (dataStart >= rows.length) {
      return { err: 'ไฟล์นี้ไม่มีแถวข้อมูล' };
    }

    // Header row
    const header = rows[dataStart].map((h) => h.trim());
    const idCol = header.findIndex((h) => h === 'Item ID');
    // OT Plan may omit Item ID: the import dialog resolves it from Team (Team + FY is unique on
    // board 05). With idCol === -1 every row's id reads as '' below. MP and Vendor MA still require it.
    // Company Plan may omit it too (the blank template): the dialog resolves each row from
    // Group + Company + MonthYear inside the selected FY, so those three columns become required.
    if (idCol === -1 && spec.name !== 'OT_Plan' && spec.name !== 'Company_Plan') {
      return { err: 'ไฟล์ขาดคอลัมน์ Item ID' };
    }
    if (idCol === -1 && spec.name === 'Company_Plan') {
      const lack = spec.info.map(([h]) => h).filter((h) => !header.includes(h));
      if (lack.length > 0) return { err: TT('ไฟล์ขาดคอลัมน์') + ' ' + lack.join(' · ') };
    }

    // Check for value columns
    const valCols: number[] = [];
    const missing: string[] = [];
    for (const v of spec.vals) {
      const idx = header.findIndex((h) => h === v);
      if (idx === -1) {
        missing.push(v);
      } else {
        valCols.push(idx);
      }
    }

    if (missing.length > 0) {
      return { err: TT('ไฟล์ขาดคอลัมน์') + ' ' + missing.join(' · ') };
    }

    // Info column indices
    const infoCols = spec.info.map(([h]) => header.findIndex((x) => x === h));

    // Parse data rows
    const dataRows: ParsedFile['rows'] = [];
    const badId: string[] = [];
    const badNum: string[] = [];

    for (let ri = dataStart + 1; ri < rows.length; ri++) {
      const r = rows[ri];
      if (!r || r.every((c) => !c.trim())) continue;

      let id = r[idCol]?.trim() ?? '';
      
      // Check Item ID shape: must be digits only (or digits with .0 suffix)
      if (id) {
        const clean = id.replace(/\.0+$/, '');
        if (!/^\d+$/.test(clean)) {
          if (!badId.includes(id)) badId.push(id);
          id = clean; // still try to use it
        } else {
          id = clean;
        }
      }

      const info: Record<string, string> = {};
      for (let j = 0; j < spec.info.length; j++) {
        const idx = infoCols[j];
        if (idx !== -1) {
          info[spec.info[j]![1]] = r[idx]?.trim() ?? '';
        }
      }

      const vals: (number | null)[] = [];
      for (const idx of valCols) {
        const txt = r[idx]?.trim() ?? '';
        vals.push(parseFileValue(txt));
        // Every spec (MP, OT, Company Plan) · one shared check: a value cell that is neither empty
        // nor a non-negative number stops the import. Otherwise OT would read it as empty (clears
        // the board cell) and MP as 0 (nullAsZero). Empty stays legal everywhere.
        if (isBadNum(txt)) badNum.push(`${id || '—'} · ${txt}`);
      }

      dataRows.push({ id, _: info, v: vals, line: kept[ri]?.line });
    }

    if (dataRows.length === 0) {
      return { err: 'ไฟล์นี้ไม่มีแถวข้อมูล' };
    }

    return { meta, rows: dataRows, badId, badNum, cols: header };
  } catch (e) {
    console.error('parseFile error', e);
    return { err: 'อ่านไฟล์ไม่สำเร็จ' };
  }
}

// =============================================================================
// A6. DIFF — diffFile
// =============================================================================

export interface DiffResult {
  cells: Array<{
    r: any;
    vi: number;
    vn: string;
    from: number;
    to: number;
    lbl?: string; // for display
  }>;
  add: any[];
  del: any[];
  dup: string[];
  unknown: string[];
  outScope: string[];
  missing: string[];
  conflict: any[];
  rows: number;
  same: number;
  badId: string[]; // Vibe addition: non-digit Item IDs
  /** Item IDs whose edit time or the file's EXPORTED_AT could not be read as a time. */
  timeSkip: string[];
  /** Session 1-18 · text changes on existing rows (spec.text only; empty file cell = no change). */
  texts: TextChange[];
}

export interface TextChange {
  r: any;
  /** file header, e.g. "Task1" */
  col: string;
  /** row field, e.g. "t1" */
  field: string;
  from: string;
  to: string;
}

export function diffFile<T>(
  spec: FileSpec<T>,
  fileRows: ParsedFile['rows'],
  scopeRows: T[],
  exportedAt: string | null,
  allBoardIds: Set<string> // all Item IDs on the board (any FY/team)
): DiffResult {
  // Ids are keyed as trimmed STRINGS on both sides. monday returns the id as a string in some
  // shapes and a number in others; "2867175515" !== 2867175515 would make every file row look
  // "missing from the board" while nothing is marked for deletion.
  const key = (v: unknown) => String(v ?? '').trim();

  const byId = new Map<string, T>();
  for (const r of scopeRows) {
    byId.set(key(spec.id(r)), r);
  }

  const cells: DiffResult['cells'] = [];
  const texts: TextChange[] = [];
  const add: any[] = [];
  const dup: string[] = [];
  const unknown: string[] = [];
  const outScope: string[] = [];
  const missing: string[] = [];
  const conflict: T[] = [];
  const badId: string[] = [];
  const timeSkip: string[] = [];
  const exportedMs = stampMs(exportedAt);
  const seen = new Set<string>();

  // allBoardIds re-keyed the same way, so membership tests cannot miss on type alone.
  const boardIdKeys = new Set<string>();
  for (const b of allBoardIds) boardIdKeys.add(key(b));

  for (const fr of fileRows) {
    const id = key(fr.id);

    // Validate Item ID format (digits only, after stripping trailing ".0")
    if (id) {
      const cleaned = id.endsWith('.0') ? id.slice(0, -2) : id;
      if (!/^\d+$/.test(cleaned) && !badId.includes(id)) {
        badId.push(id);
      }
    }

    if (!id) {
      add.push(fr);
      continue;
    }

    if (seen.has(id)) {
      if (!dup.includes(id)) dup.push(id);
      continue;
    }
    seen.add(id);

    const br = byId.get(id);
    if (!br) {
      // Split unknown into outScope and missing
      if (boardIdKeys.has(id)) {
        outScope.push(id);
      } else {
        missing.push(id);
      }
      continue;
    }

    const cellsBefore = cells.length;
    const textsBefore = texts.length;
    // Compare values (Defect 1 fix: use sameValue everywhere)
    for (let i = 0; i < spec.vals.length; i++) {
      let oldVal = spec.val(br, i);
      let fileVal = fr.v[i];

      // nullAsZero: treat null file value as 0
      if (spec.nullAsZero && fileVal === null) {
        fileVal = 0;
      }

      if (!sameValue(oldVal, fileVal, spec.eps)) {
        cells.push({
          r: br,
          vi: i,
          vn: spec.vals[i]!,
          from: oldVal ?? 0,
          to: fileVal ?? 0,
        });
      }
    }

    // Session 1-18 · text columns. Only a NON-EMPTY file value that differs from the board counts;
    // an empty (or absent) file cell leaves the board value exactly as it is.
    for (const [col, field] of spec.text ?? []) {
      const to = String(fr._?.[field] ?? '').trim();
      if (!to) continue;
      const from = String((br as any)[field] ?? '').trim();
      // Label columns (Role, System, Task2) compare by norm — case / spacing alone is not a change.
      const same = field === 'role' || field === 'system' || field === 'task2' ? norm(to) === norm(from) : to === from;
      if (!same) texts.push({ r: br, col, field, from, to });
    }

    // Conflict check — compares INSTANTS, never text. A side that cannot be read as a time is
    // not treated as newer: the row skips this gate and is counted in timeSkip instead.
    // A row is a conflict ONLY when this file will write at least one of its cells: an edit
    // on a row the import leaves alone overwrites nothing.
    const rowWrites = cells.length > cellsBefore || texts.length > textsBefore;
    if (rowWrites && exportedAt && (br as any).editedAt) {
      const edited = stampMs(String((br as any).editedAt));
      if (Number.isNaN(edited) || Number.isNaN(exportedMs)) {
        timeSkip.push(id);
      } else if (edited - exportedMs > EDIT_SLACK_MS) {
        conflict.push(br);
      }
    }
  }

  // Del: rows not seen in file
  const del: T[] = [];
  for (const r of scopeRows) {
    if (!seen.has(key(spec.id(r)))) {
      del.push(r);
    }
  }

  // Count distinct rows with changes
  const changedRows = new Set<string>();
  for (const c of cells) {
    changedRows.add(key(spec.id(c.r)));
  }
  for (const t of texts) changedRows.add(key(spec.id(t.r)));
  const rows = changedRows.size;
  const same = Math.max(scopeRows.length - rows - del.length, 0);

  return {
    cells,
    add,
    del,
    dup,
    unknown,
    outScope,
    missing,
    conflict,
    rows,
    same,
    badId,
    timeSkip,
    texts,
  };
}
