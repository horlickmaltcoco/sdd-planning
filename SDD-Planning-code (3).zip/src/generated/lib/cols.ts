// Column ids read from the 5 connected boards. Only these ids are ever requested.

/* 03 · Working Day Master */
export const WD_C = {
  fy: 'dropdown_mm7g3n86',
  month: 'dropdown_mm72775w',
  days: 'numeric_mm72x7hb',
  cap: 'numeric_mm72d2q3',
  bands: 'text_mm79aqrs',
  redAt: 'numeric_mm792wrh',
  tol: 'numeric_mm79s5cx',
  minPer: 'dropdown_mm79ft54',
  maxPer: 'dropdown_mm79y9k1',
  hpd: 'numeric_mm7egmeb',
} as const;
export const WD_COLS: string[] = Object.values(WD_C);

/* 04 · MP Plan */
export const MP_C = {
  fy: 'dropdown_mm7gh9b9',
  team: 'dropdown_mm7gemym',
  type: 'dropdown_mm71y3ex',
  t1: 'text_mm712g3d',
  role: 'color_mm71hgnd',
  detail: 'long_text_mm71bkm0',
  name: 'text_mm716jca',
  empid: 'text_mm71sj5r',
  sec: 'text_mm7121my',
  ms: 'color_mm71ee3q',
  batch: 'text_mm71pmkk',
  src: 'color_mm728ges',
  edited: 'pulse_updated_mm79ntna',
  /** "System" — single-value dropdown; labels from the column settings. */
  system: 'dropdown_mm8hcfe',
  /** "Task2" — single-value dropdown, optional; labels from the column settings. */
  task2: 'dropdown_mm8jwqsg',
} as const;
// fiscal order Apr..Mar
export const MP_M: string[] = [
  'numeric_mm71tgxt',
  'numeric_mm71pqj7',
  'numeric_mm71qm8k',
  'numeric_mm71ser5',
  'numeric_mm71614f',
  'numeric_mm71jw3v',
  'numeric_mm71qek9',
  'numeric_mm71nyzp',
  'numeric_mm7165s0',
  'numeric_mm71w60p',
  'numeric_mm71jwqh',
  'numeric_mm7188vh',
];
export const MP_COLS: string[] = [...Object.values(MP_C), ...MP_M];

/* 05 · OT Plan */
export const OT_C = {
  t: 'dropdown_mm7gnxwv',
  fy: 'dropdown_mm7gqv9x',
  pl: 'color_mm71y4kp',
  batch: 'text_mm71bzy1',
  src: 'color_mm72t7k8',
  edited: 'pulse_updated_mm796be9',
} as const;
export const OT_M: string[] = [
  'numeric_mm7123ad',
  'numeric_mm71ets0',
  'numeric_mm71kp1p',
  'numeric_mm713s0b',
  'numeric_mm71zyff',
  'numeric_mm71ma7',
  'numeric_mm71zbme',
  'numeric_mm71aa73',
  'numeric_mm718xwq',
  'numeric_mm713fpx',
  'numeric_mm714mj1',
  'numeric_mm718k6f',
];
export const OT_COLS: string[] = [...Object.values(OT_C), ...OT_M];

/* 07 · Company Plan — one item = Group × Company × FY × Month. Plan MD is in MD (no hours). */
export const CP_C = {
  grp: 'group_dd',
  co: 'company',
  mo: 'month',
  fy: 'fy',
  md: 'plan_md',
  src: 'color_mm82np97',
  edited: 'pulse_updated_mm82nzra',
} as const;
export const CP_COLS: string[] = Object.values(CP_C);


/* 02 · Employee Master (parents) */
export const EMP_C = {
  emp: 'text_mm714p3k',
  email: 'email_mm71y4g6',
  grp: 'dropdown_mm7g6azy',
  sec: 'dropdown_mm71pdy9',
  pos: 'dropdown_mm715hdg',
  begin: 'date_mm71k79e',
  end: 'date_mm71wxsq',
  status: 'color_mm714t4w',
  quota: 'dropdown_mm71jxyv',
  incharge: 'text_mm71pckb',
  mpname: 'text_mm71556y',
  plan: 'color_mm727rat',
} as const;
export const EMP_COLS: string[] = Object.values(EMP_C);

/* 02 · subitems "ช่วงสังกัด" */
export const SUB_C = {
  team: 'dropdown_mm7ev7p1',
  from: 'date_mm7eh8s3',
  to: 'date_mm7ewq1t',
  quota: 'dropdown_mm7e54zx',
  why: 'text_mm7e8ryc',
  grp: 'dropdown_mm7ew6c9',
} as const;
export const SUB_COLS: string[] = Object.values(SUB_C);
