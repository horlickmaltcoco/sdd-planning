// 07 Company Plan · import row matching (Session 1-12).
// A row that carries an Item ID keeps it untouched — resolved by Item ID exactly as before.
// A row without one is resolved by Group + Company + MonthYear against the rows of the selected FY
// (the page scope). Matching trims surrounding spaces and ignores case; otherwise it is exact —
// never fuzzy. Nothing is created: an unknown combination is listed and the import stops.

type FileRow = { id: string; _: Record<string, string> };
type ScopeRow = { id: string | number; grp?: string | null; co?: string | null; my?: string | null };

const norm = (s: unknown): string => String(s ?? '').trim().toLowerCase();
const keyOf = (g: unknown, c: unknown, m: unknown): string => `${norm(g)}\u0001${norm(c)}\u0001${norm(m)}`;
const labelOf = (r: FileRow): string =>
  `${String(r._?.grp ?? '').trim() || '(ว่าง)'} · ${String(r._?.co ?? '').trim() || '(ว่าง)'} · ${
    String(r._?.my ?? '').trim() || '(ว่าง)'
  }`;

export function resolveCpRows(
  rows: FileRow[],
  scope: ScopeRow[],
): { unknown: string[]; dup: string[]; filled: string[] } {
  // Board side: key → Item ID. A key held by two board rows is ambiguous and never resolved.
  const byKey = new Map<string, string>();
  const ambiguous = new Set<string>();
  for (const s of scope) {
    const k = keyOf(s.grp, s.co, s.my);
    if (byKey.has(k)) ambiguous.add(k);
    else byKey.set(k, String(s.id));
  }

  const seen = new Set<string>();
  const dupSeen = new Set<string>();
  const dup: string[] = [];
  const unknown: string[] = [];
  const filled: string[] = [];

  for (const row of rows) {
    const k = keyOf(row._?.grp, row._?.co, row._?.my);
    const hasKey = !!(norm(row._?.grp) || norm(row._?.co) || norm(row._?.my));

    // Gate b · the same Group + Company + MonthYear twice in the file (every row, with or without ID).
    if (hasKey) {
      if (seen.has(k)) {
        if (!dupSeen.has(k)) {
          dupSeen.add(k);
          dup.push(labelOf(row));
        }
      } else {
        seen.add(k);
      }
    }

    // Rows with an Item ID: unchanged path.
    if (String(row.id ?? '').trim()) continue;

    // Gate a · not on the board for this FY (or ambiguous on the board) → listed, no id invented.
    const hit = !ambiguous.has(k) ? byKey.get(k) : undefined;
    if (hit) {
      row.id = hit;
      filled.push(hit);
    } else {
      unknown.push(labelOf(row));
    }
  }

  return { unknown, dup, filled };
}
