// B10 · column value formats for writeItem. Wrong shape = monday rejects the whole call.
import { SRC_APP, SRC_IMPORT } from '@generated/config';

export type ColValue = string | { label: string } | { labels: string[] } | { date: string };

// numbers → "12.5" (string); "" clears the cell
export function numVal(n: number | null | undefined): string {
  return n === null || n === undefined || !Number.isFinite(n) ? '' : String(n);
}

// status → { label: "<exact label>" }
export function statusVal(label: string): { label: string } {
  return { label };
}

// dropdown → { labels: ["<exact label>"] }
export function dropVal(label: string): { labels: string[] } {
  return { labels: label ? [label] : [] };
}

// date → { date: "YYYY-MM-DD" }
export function dateVal(d: string): { date: string } {
  return { date: d };
}

export function textVal(s: string): string {
  return s;
}

// Every in-app edit on 04/05/06 also sets Source = "Vibe App"; imports set "Import".
export function srcAppVal(): { label: string } {
  return { label: SRC_APP };
}

export function srcImportVal(): { label: string } {
  return { label: SRC_IMPORT };
}
