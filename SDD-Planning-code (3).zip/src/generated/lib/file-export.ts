/**
 * Session 1-05 Part A — Export Functions
 * doExportMP, doExportOT
 */

import { NOW } from '@generated/engine';
import { TT } from '@generated/i18n';
import type { CpRow, MpRow, OtRow } from '@generated/lib/types';
import {
  fileSpecOf,
  buildCSV,
  fileName,
  downloadFile,
  IMPORT_SPEC,
} from '@generated/lib/file-mechanism';

// =============================================================================
// A4. EXPORT FUNCTIONS
// =============================================================================

export function doExportMP(
  team: string,
  fy: string | number,
  rows: MpRow[],
  toast: (msg: string) => void
) {
  const stamp = NOW();
  const fileScope = rows.filter(
    (r) => r.team === team && String(r.fy) === String(fy)
  );

  if (fileScope.length === 0) {
    toast(`${TT('ทีม')} ${team} ${TT('ปีงบ')} ${fy} ${TT('ไม่���ีแผน ไม่มีอะไรให้ส่งออก')}`);
    return;
  }

  const spec = fileSpecOf('mp');
  const csv = buildCSV(spec, fileScope, {
    kind: IMPORT_SPEC.mp.kind,
    fy,
    team,
    stamp,
  });

  const name = fileName('mp', fy, team);
  downloadFile(csv, name);

  toast(
    `${TT('ส่งออก')} ${fileScope.length} ${TT('แถว')} · ${TT('ติด Item ID ทุกแถว · ประทับเวลา')} ${stamp}`
  );
}

export function doExportOT(
  fy: string | number,
  rows: OtRow[],
  toast: (msg: string) => void
) {
  const stamp = NOW();
  const fileScope = rows.filter((r) => String(r.fy) === String(fy));

  const spec = fileSpecOf('ot');
  const csv = buildCSV(spec, fileScope, {
    kind: IMPORT_SPEC.ot.kind,
    fy,
    stamp,
  });

  const name = fileName('ot', fy);
  downloadFile(csv, name);

  toast(
    `${TT('ส่งออก')} ${fileScope.length} ${TT('ทีม')} · ${TT('ติด Item ID ทุกแถว · ประทับเวลา')} ${stamp}`
  );
}

/** 07 Company Plan · every row of the selected FY (page filters ignored), Plan MD at full precision. */
export function doExportCp(
  fy: string | number,
  rows: CpRow[],
  toast: (msg: string) => void
) {
  const stamp = NOW();
  const fileScope = rows.filter((r) => String(r.fy) === String(fy));

  const spec = fileSpecOf('cp');
  const csv = buildCSV(spec, fileScope, {
    kind: IMPORT_SPEC.cp.kind,
    fy,
    stamp,
  });

  downloadFile(csv, fileName('cp', fy));

  toast(
    `${TT('ส่งออก')} ${fileScope.length} ${TT('แถว')} · ${TT('ติด Item ID ทุกแถว · ประทับเวลา')} ${stamp}`
  );
}
