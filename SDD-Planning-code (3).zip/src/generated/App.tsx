import { useCallback, useEffect, useMemo, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { APP, missingBoards, navLabel, ownerClashes, PAGE_NEEDS, type PageId } from '@generated/config';
import { setLang, TT } from '@generated/i18n';
import { useToasts } from '@generated/hooks/use-toasts';
import { EMPTY_CORE, useSddData } from '@generated/hooks/use-sdd-data';
import { useSddState } from '@generated/hooks/use-sdd-state';
import { usePrepared } from '@generated/hooks/use-prepared';
import { buildModel } from '@generated/model';
import { statusOf } from '@generated/engine';
import Sidebar from '@generated/components/Sidebar';
import Toasts from '@generated/components/Toasts';
import PageFooter from '@generated/components/PageFooter';
import PlaceholderPage from '@generated/components/PlaceholderPage';
import LoadError from '@generated/components/LoadError';
import { RuleFallbackNote } from '@generated/components/RuleFallbackNote';
import LoadingCard from '@generated/components/LoadingCard';
import { MisplacedBanner } from '@generated/components/MisplacedBanner';
import { cn } from '@lib/utils';

const BOARD_ORDER = ['MP Plan', 'OT Plan', 'Company Plan', 'Employee Master', 'Working Day Master'] as const;

export default function App() {
  const { toasts, T, drop } = useToasts();
  const data = useSddData();
  // CHANGE 3 · each page has its own committed snapshot (ready once ITS boards finished).
  // While the page is not ready yet it stays hidden; the model then comes from the latest
  // snapshot of any page so FY / filters are not reset in the meantime.
  const pageState = useState<PageId>('ov');
  const page = pageState[0];
  const pageCore = data.coreOf(page);
  const pageBusy = data.pageBusy(page);
  const modelCore = pageCore ?? data.last ?? EMPTY_CORE;
  // every derived structure is rebuilt after every (re)load
  const model = useMemo(() => buildModel(modelCore), [modelCore]);
  const st = useSddState(T, model, modelCore, pageState);
  const prep = usePrepared();
  // Session 1-15c · the group list is part of every data load: each completed load (first load,
  // "โหลดข้อมูลใหม่", a page refresh, a reload after an import) re-reads the FY groups.
  const prepRefresh = prep.refresh;
  useEffect(() => {
    if (data.loadedAt) void prepRefresh();
  }, [data.loadedAt, prepRefresh]);
  // Session 1-17f · MP Plan, OT Plan and Company Plan load the selected fiscal year only.
  const ensureFy = data.ensureFy;
  const selFy = String(st.S.fy);
  useEffect(() => {
    ensureFy(selFy);
  }, [ensureFy, selFy]);
  const [menu, setMenu] = useState(false);
  const [retrying, setRetrying] = useState(false);

  // LANG mirrors the language state on every render (A3).
  setLang(st.lang);

  // Developer checks (A2) — must stay empty.
  useEffect(() => {
    const clashes = ownerClashes();
    if (clashes.length) console.error('ownerClashes', clashes);
    const missing = missingBoards(APP.planning);
    if (missing.length) console.error('missingBoards', missing);
  }, []);

  const reloadAll = useCallback(async () => {
    setRetrying(true);
    try {
      await data.reload();
    } finally {
      setRetrying(false);
    }
  }, [data]);

  // Sidebar link: reload every board, keep page / FY / filters, then confirm.
  const reloadFromSidebar = useCallback(async () => {
    await reloadAll();
    T(TT('โหลดข้อมูลจากบอร์ดแล้ว'));
  }, [reloadAll, T]);

  const failed = BOARD_ORDER.filter((b) => data.bs[b].status === 'error').map((b) => ({
    key: b,
    msg: data.bs[b].msg,
  }));

  // Red dot on Validation: tier 1 bad + tier 2 not-ok (only once numbers may be shown)
  const dot =
    !data.loading &&
    st.P.L1.length +
      st.P.L2.filter((r) => statusOf(r.dif, st.S.teamTolerance ?? 0) !== 'ok').length >
      0;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[var(--bg)] font-[family-name:var(--font-body)] text-[14px] text-[color:var(--tx)]">
      {menu && (
        <button
          type="button"
          aria-label={TT('ปิด')}
          onClick={() => setMenu(false)}
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
        />
      )}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-[238px] shrink-0 transition-transform duration-200 md:static md:translate-x-0',
          menu ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <Sidebar
          page={st.page}
          go={(p) => {
            st.go(p);
            setMenu(false);
          }}
          lang={st.lang}
          setLang={st.setLang}
          dot={dot}
          loadedAt={data.loadedAt}
          busy={data.loading}
          reload={() => void reloadFromSidebar()}
        />
      </aside>

      <main className="flex min-w-0 flex-1 flex-col overflow-y-auto px-[26px] py-[22px]">
        <button
          type="button"
          aria-label={menu ? TT('ปิด') : TT('เมนู')}
          onClick={() => setMenu((v) => !v)}
          className="mb-[14px] flex h-[40px] w-[40px] items-center justify-center rounded-[var(--rs)] border border-[color:var(--bd)] bg-[var(--cd)] text-[color:var(--t2)] shadow-[var(--sd)] outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--yl)] md:hidden"
        >
          {menu ? <X size={18} /> : <Menu size={18} />}
        </button>

        {/* C3 · pinned on every page until a reload succeeds */}
        {failed.length > 0 && <LoadError boards={failed} onRetry={() => void reloadAll()} busy={retrying} />}

        {pageBusy && <LoadingCard bs={data.bs} order={[...BOARD_ORDER]} prog={data.prog} />}

        {/* C1 · temporary empty-board simulation (in memory only — nothing on monday changes) */}
        {data.sim.length > 0 && (
          <p className="mb-[10px] rounded-[6px] border border-dashed border-[color:var(--or)] px-[10px] py-[6px] font-mono text-[11px] text-[color:var(--or)]">
            SIMULATION · sddEmpty={data.sim.join(',')}
          </p>
        )}

        {pageCore && !pageBusy && (
          <RuleFallbackNote
            fy={st.S.fy}
            hasRule={model.ruleOf(st.S.fy) != null}
            hasWd={pageCore.D_WD[String(st.S.fy)] != null}
            hpd={model.hpdOf(st.S.fy)}
          />
        )}

        {/* Session 1-17i · rows of this year sitting in another year's group (on every page that uses that board) */}
        {pageCore && !pageBusy && (
          <MisplacedBanner fy={st.S.fy} found={data.misplacedOf(st.S.fy).filter((f) => PAGE_NEEDS[st.page].includes(f.board))} />
        )}

        {/* The page stays mounted while loading (hidden) so its filters survive a reload,
            but nothing — no number, chart or card — is visible until every board on the
            page's own list (PAGE_NEEDS) is done. */}
        {pageCore && (
          <div className={cn('min-w-0 flex-1', pageBusy && 'hidden')} aria-hidden={pageBusy}>
            <PlaceholderPage
              id={st.page}
              label={navLabel(APP.planning, st.page)}
              go={st.go}
              T={T}
              data={data}
              model={model}
              S={st.S}
              P={st.P}
              setS={st.setS}
              mp={st.mp}
              setMp={st.setMp}
              otAll={st.otAll}
              setOtAll={st.setOtAll}
              cp={st.cp}
              setCp={st.setCp}
              saveBands={st.saveBands}
              clearBands={st.clearBands}
              prep={prep}
            />
          </div>
        )}

        <PageFooter />
      </main>

      <Toasts toasts={toasts} drop={drop} />
    </div>
  );
}
