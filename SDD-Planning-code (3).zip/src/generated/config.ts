// SDD Planning — shared constants and shell functions (Session 1-01, Part A1/A2).
// Every later session imports from here. Nothing in this file renders text through TT():
// translation happens at render time only.

export const APP_VERSION = '1.0.0';
export const APP_BUILD = '2026-09-29'; // update by hand on each release
export const BOARD_CAP = 5;

export type BoardKey =
  | 'MP Plan'
  | 'OT Plan'
  | 'Company Plan'
  | 'Employee Master'
  | 'Working Day Master';

// Board ids of the boards connected to this app in this workspace.
// Data is always read/written through the generated Board SDK classes below.
export const BOARD_ID: Record<BoardKey, string> = {
  'MP Plan': '5031548536',
  'OT Plan': '5031548533',
  'Company Plan': '5031856644',
  'Employee Master': '5031548537',
  'Working Day Master': '5031548535',
};

// Subitem board of Employee Master ("ช่วงสังกัด") — read through Employee Master, not a 6th board.
export const SUBITEM_BOARD_ID = '5031548538';

export type Mode = 'w' | 'r';

// Owner declaration. Owner = the only app allowed to write a board.
// "master" is the sister app (SDD Master); it is declared so the sidebar can say
// who owns a read-only board.
export const APP_BOARDS: { planning: Record<BoardKey, Mode>; master: Record<string, Mode> } = {
  planning: {
    'MP Plan': 'w',
    'OT Plan': 'w',
    'Company Plan': 'w',
    'Employee Master': 'r',
    'Working Day Master': 'r',
  },
  master: {
    'Employee Master': 'w',
    'Company Calendar': 'w',
    'Working Day Master': 'w',
  },
};

export const APP_MODE = 'planning';

export type PageId = 'ov' | 'val' | 'mp' | 'ot' | 'cp';

// Which board each page touches ("w" = the page writes back, "r" = read only).
export const PAGE_BOARDS: Record<PageId, Partial<Record<BoardKey, Mode>>> = {
  ov: {
    'MP Plan': 'r',
    'OT Plan': 'r',
    'Company Plan': 'r',
    'Employee Master': 'r',
    'Working Day Master': 'r',
  },
  val: { 'MP Plan': 'r', 'OT Plan': 'r', 'Employee Master': 'r', 'Working Day Master': 'r' },
  mp: { 'MP Plan': 'w', 'Employee Master': 'r', 'Working Day Master': 'r' },
  ot: { 'OT Plan': 'w', 'Employee Master': 'r', 'Working Day Master': 'r' },
  cp: { 'Company Plan': 'w', 'Employee Master': 'r', 'Working Day Master': 'r' },
};

// Performance pass · CHANGE 3 — the boards a page must have FINISHED before it renders.
// (PAGE_BOARDS above is the ownership/touch map and is not used for gating.)
export const PAGE_NEEDS: Record<PageId, BoardKey[]> = {
  ov: ['MP Plan', 'OT Plan', 'Company Plan', 'Employee Master', 'Working Day Master'],
  val: ['MP Plan', 'OT Plan', 'Employee Master', 'Working Day Master'],
  mp: ['MP Plan', 'Employee Master', 'Working Day Master'],
  ot: ['OT Plan', 'Employee Master', 'Working Day Master'],
  // Employee Master: the Group banner checks Groups against the employee spans of the FY.
  // Working Day Master: the FY list / past-month rule, same as every other page.
  cp: ['Company Plan', 'Employee Master', 'Working Day Master'],
};
export const PAGE_IDS: PageId[] = ['ov', 'val', 'mp', 'ot', 'cp'];

// Board read paging — page size and per-chain safety valve (unchanged values).
export const LOAD_PAGE = 500;
export const LOAD_MAX_PAGES = 60;

export type NavItem = [PageId, string, string];
export type NavSection = [string, NavItem[]];
export interface AppDef {
  title: string;
  sub?: string;
  nav?: NavSection[];
}

export const APP: { planning: AppDef; master: AppDef } = {
  planning: {
    title: 'SDD Planning',
    sub: 'ISUZU',
    nav: [
      [
        'Overview',
        [
          ['ov', '◉', 'ภาพรวมการวางแผน'],
          ['val', '✓', 'Validation'],
        ],
      ],
      [
        'แผน',
        [
          ['mp', '⊞', 'แผนกำลังคน'],
          ['ot', '⧖', 'OT Plan'],
          ['cp', '▤', 'แผนงาน ISUZU Group'],
        ],
      ],
    ],
  },
  master: { title: 'SDD Master' },
};

export const MONTHS = [
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
  'Jan',
  'Feb',
  'Mar',
] as const;
export const ALLMI = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

export const YES = 'Yes';
export const NO = 'No';
export const SRC_IMPORT = 'Import';

/**
 * Session 1-21 · MP Plan Types whose rows may leave Task1 empty on import (leave is not a task).
 * Every other Type still requires Task1. Add a Type here to exempt it.
 */
export const TYPES_WITHOUT_TASK1: readonly string[] = ['11.Leave'];
export const SRC_APP = 'Vibe App';
export const OT_LABEL_ON = 'Yes';
export const OT_LABEL_OFF = 'No';
export const HPD_FALLBACK = 8;
export const BAND_DEFAULT = [50, 75, 90, 105, 120];
export const BANDS_KEY = 'sdd.bands';

// MP month column IDs (fiscal order Apr..Mar) — used by every write
export const MP_MONTH_COL = [
  'numeric_mm71tgxt',  // 0 Apr
  'numeric_mm71pqj7',  // 1 May
  'numeric_mm71qm8k',  // 2 Jun
  'numeric_mm71ser5',  // 3 Jul
  'numeric_mm71614f',  // 4 Aug
  'numeric_mm71jw3v',  // 5 Sep
  'numeric_mm71qek9',  // 6 Oct
  'numeric_mm71nyzp',  // 7 Nov
  'numeric_mm7165s0',  // 8 Dec
  'numeric_mm71w60p',  // 9 Jan
  'numeric_mm71jwqh',  // 10 Feb
  'numeric_mm7188vh',  // 11 Mar
] as const;

/* ---------- A2 · shell functions ---------- */

export function navPages(a: AppDef): PageId[] {
  return (a.nav ?? []).flatMap(([, items]) => items.map(([id]) => id));
}

export function allowedPages(a: AppDef): PageId[] {
  return navPages(a);
}

export function navLabels(a: AppDef): Record<string, string> {
  const lbl: Record<string, string> = {};
  (a.nav ?? []).forEach(([, items]) =>
    items.forEach(([id, , label]) => {
      lbl[id] = label;
    }),
  );
  return lbl;
}

export function navLabel(a: AppDef, id: string): string {
  return navLabels(a)[id] ?? '';
}

export function ownerOf(b: string): string {
  const all = APP_BOARDS as unknown as Record<string, Record<string, Mode>>;
  for (const key of Object.keys(all)) {
    if (all[key]?.[b] === 'w') return key;
  }
  return '';
}

export function ownerClashes(): string[] {
  const all = APP_BOARDS as unknown as Record<string, Record<string, Mode>>;
  const owners: Record<string, string[]> = {};
  for (const app of Object.keys(all)) {
    const boards = all[app] ?? {};
    for (const b of Object.keys(boards)) {
      if (boards[b] === 'w') (owners[b] ??= []).push(app);
    }
  }
  return Object.keys(owners)
    .filter((b) => (owners[b] ?? []).length > 1)
    .map((b) => `${b}: ${(owners[b] ?? []).join(' + ')}`);
}

export interface BoardLine {
  name: BoardKey;
  mode: Mode;
  pages: string[];
}

export function boardsOf(a: AppDef): BoardLine[] {
  const lbl = navLabels(a);
  const pages = allowedPages(a);
  return (Object.keys(APP_BOARDS.planning) as BoardKey[]).map((name) => {
    const labels: string[] = [];
    for (const p of pages) {
      if (!PAGE_BOARDS[p]?.[name]) continue;
      const label = lbl[p];
      if (label && !labels.includes(label)) labels.push(label);
    }
    return { name, mode: APP_BOARDS.planning[name], pages: labels };
  });
}

export function missingBoards(a: AppDef): string[] {
  const out: string[] = [];
  for (const p of allowedPages(a)) {
    for (const b of Object.keys(PAGE_BOARDS[p] ?? {})) {
      if (!(b in APP_BOARDS.planning)) out.push(`${p}→${b}`);
    }
  }
  return out;
}

export function appTitle(key: string): string {
  const all = APP as unknown as Record<string, AppDef>;
  return all[key]?.title ?? '—';
}
