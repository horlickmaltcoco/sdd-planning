// Session 1-17i · detector, not part of the load. Finds rows whose FY value is the asked year but which
// sit in another fiscal-year group — the groups the year's load never reads. Session 1-25 · instead of
// scanning the whole board, each other-year group is asked through monday's filter for the year's rows
// (id, name, FY column only); see readYearRowsElsewhere. The client still compares the ids with the
// ids the load actually read. Reads only.
import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID } from '@generated/config';
import { CP_C, MP_C, OT_C } from '@generated/lib/cols';
import { readYearRowsElsewhere } from '@generated/server/gql.server';

const FY_COL = { 'MP Plan': MP_C.fy, 'OT Plan': OT_C.fy, 'Company Plan': CP_C.fy } as const;

export const findYearRows = createServerFn({ method: 'POST' })
  .validator(z.object({ board: z.enum(['MP Plan', 'OT Plan', 'Company Plan']), fy: z.string().min(1) }))
  .handler(async ({ data }) => {
    const t0 = Date.now();
    const fy = data.fy.trim();
    const r = await readYearRowsElsewhere(BOARD_ID[data.board], FY_COL[data.board], fy, `detector · ${data.board}`);
    const ms = Date.now() - t0;
    console.log(`[SDD detect] ${data.board} · FY${fy} · ${r.requests} requests · ${r.returned} rows returned by the filter · ${r.rows.length} with FY ${fy} · ${ms} ms`);
    return { rows: r.rows, total: r.returned, ms };
  });
