// Session 1-15 · เตรียมข้อมูลปีงบ — server functions. Reads boards 04 / 05 / 07 and creates ONLY
// missing groups and missing rows on 05 / 07. Never updates, renames or deletes anything, and never
// writes to board 03 or 01.
import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID } from '@generated/config';
import { CP_C, MP_C, OT_C } from '@generated/lib/cols';
import { cvMap, dropdown } from '@generated/lib/parse';
import { fyGroupOf, PREP_BOARDS, type PrepBoard, type PrepSnapshot } from '@generated/lib/prepare-plan';
import {
  mutateCreateGroup,
  mutateCreateMany,
  readBoard,
  readBoardGroupList,
  readLabelSets,
} from '@generated/server/gql.server';

const PREP_BOARD_ID: Record<PrepBoard, string> = {
  'MP Plan': BOARD_ID['MP Plan'],
  'OT Plan': BOARD_ID['OT Plan'],
  'Company Plan': BOARD_ID['Company Plan'],
};

async function readGroups(): Promise<PrepSnapshot['groups']> {
  const lists = await Promise.all(PREP_BOARDS.map((b) => readBoardGroupList(PREP_BOARD_ID[b])));
  return { 'MP Plan': lists[0] ?? [], 'OT Plan': lists[1] ?? [], 'Company Plan': lists[2] ?? [] };
}

/** Group titles of boards 04, 05, 07 — the only input to "is this year prepared". */
export const readFyGroups = createServerFn({ method: 'POST' })
  .validator(z.object({}).optional())
  .handler(async () => ({ groups: await readGroups() }));

/** A fresh snapshot for the dialog AND for every run: groups + the key columns of 05 and 07. */
export const readPrepareSnapshot = createServerFn({ method: 'POST' })
  .validator(z.object({}).optional())
  .handler(async (): Promise<PrepSnapshot> => {
    const [groups, ot, cp, otLab, cpLab, mpLab] = await Promise.all([
      readGroups(),
      readBoard(BOARD_ID['OT Plan'], [OT_C.t, OT_C.fy], 'prepare · 05 OT Plan'),
      readBoard(BOARD_ID['Company Plan'], [CP_C.grp, CP_C.co, CP_C.mo, CP_C.fy], 'prepare · 07 Company Plan'),
      readLabelSets(BOARD_ID['OT Plan'], [OT_C.fy]),
      readLabelSets(BOARD_ID['Company Plan'], [CP_C.fy]),
      readLabelSets(BOARD_ID['MP Plan'], [MP_C.fy]),
    ]);
    return {
      groups,
      fyLabels: {
        'MP Plan': mpLab[MP_C.fy] ?? null,
        'OT Plan': otLab[OT_C.fy] ?? null,
        'Company Plan': cpLab[CP_C.fy] ?? null,
      },
      ot: ot.items.map((it) => {
        const cv = cvMap(it);
        return { t: dropdown(cv[OT_C.t]), fy: dropdown(cv[OT_C.fy]) };
      }),
      cp: cp.items.map((it) => {
        const cv = cvMap(it);
        return { grp: dropdown(cv[CP_C.grp]), co: dropdown(cv[CP_C.co]), mo: dropdown(cv[CP_C.mo]), fy: dropdown(cv[CP_C.fy]) };
      }),
    };
  });

/** The "FY{fy}" group of one board: re-read right now; reuse it if present, create it only if not. */
export const ensureFyGroup = createServerFn({ method: 'POST' })
  .validator(z.object({ board: z.enum(['MP Plan', 'OT Plan', 'Company Plan']), fy: z.string().regex(/^\d{4}$/) }))
  .handler(async ({ data }) => {
    const boardId = PREP_BOARD_ID[data.board];
    const hit = fyGroupOf(await readBoardGroupList(boardId), data.fy);
    if (hit) return { id: hit.id, created: false };
    return { id: await mutateCreateGroup(boardId, `FY${data.fy}`), created: true };
  });

/** Up to 25 new items in one request, into one group of board 05 or 07. */
export const createPrepBatch = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      board: z.enum(['OT Plan', 'Company Plan']),
      groupId: z.string().min(1),
      items: z
        .array(z.object({ name: z.string().min(1), columnValues: z.record(z.string(), z.any()) }))
        .min(1)
        .max(25),
    }),
  )
  .handler(async ({ data }) => ({ ids: await mutateCreateMany(PREP_BOARD_ID[data.board], data.groupId, data.items) }));
