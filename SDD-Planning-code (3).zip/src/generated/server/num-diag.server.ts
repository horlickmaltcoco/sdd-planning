// Read-only diagnostics for the "cleared cell reads as 0" investigation. Server-only.
// Prints the RAW monday column value, the result of the OLD number rule and of the CURRENT
// rule, side by side. Writes nothing anywhere.
import { cvMap, num } from '@generated/lib/parse';
import type { RawCv, RawItem } from '@generated/lib/types';

/** The number rule exactly as it was BEFORE the fix — kept only for the side-by-side print. */
function numBefore(cv?: RawCv): number | null {
  if (!cv) return null;
  const raw = cv.number;
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  if (typeof raw === 'string' && raw.trim() !== '') {
    const asNum = Number(raw.trim());
    if (Number.isFinite(asNum)) return asNum;
  }
  const t = (cv.text ?? '').trim().replace(/,/g, '');
  if (t === '' || !/^-?\d*\.?\d+$/.test(t)) return null;
  const p = Number.parseFloat(t);
  return Number.isFinite(p) ? p : null;
}

export interface NumDiff {
  item: string;
  name: string;
  col: string;
  raw: RawCv | '(column missing)';
  before: number | null;
  after: number | null;
}

export interface NumDiag {
  board: string;
  items: number;
  cells: number;
  emptyNow: number;
  changedByFix: number;
  samples: NumDiff[];
}

/** Every number cell of the listed columns: how many read as empty now, how many the fix changed. */
export function diagNumbers(board: string, items: RawItem[], cols: string[]): NumDiag {
  let cells = 0;
  let emptyNow = 0;
  let changedByFix = 0;
  const samples: NumDiff[] = [];
  for (const it of items) {
    const cv = cvMap(it);
    for (const c of cols) {
      cells += 1;
      const before = numBefore(cv[c]);
      const after = num(cv[c]);
      if (after === null) emptyNow += 1;
      if (before !== after) {
        changedByFix += 1;
        if (samples.length < 10) {
          samples.push({
            item: String(it.id),
            name: String(it.name ?? ''),
            col: c,
            raw: cv[c] ?? '(column missing)',
            before,
            after,
          });
        }
      }
    }
  }
  const out: NumDiag = { board, items: items.length, cells, emptyNow, changedByFix, samples };
  console.log(
    `[SDD num] ${board} · ${items.length} items · ${cells} cells · ${emptyNow} read as empty (null) · ${changedByFix} changed by the fix`,
  );
  for (const s of samples) console.log(`[SDD num] ${board} · ${JSON.stringify(s)}`);
  return out;
}
