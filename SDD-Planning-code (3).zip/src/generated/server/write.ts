import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { executeGraphQL } from '@api/api-methods';

// B10 · shared write helper. Defined now, called from Sessions 1-03 … 1-07.
// Value formats per column type live in @generated/lib/write-values.
export const writeItem = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      boardId: z.string().min(1),
      itemId: z.string().min(1),
      colValues: z.record(z.string(), z.any()),
    }),
  )
  .handler(async ({ data }) => {
    const mutation = `mutation ($b: ID!, $i: ID!, $v: JSON!) {
      change_multiple_column_values(board_id: $b, item_id: $i, column_values: $v) { id }
    }`;
    const res = (await executeGraphQL(mutation, {
      b: data.boardId,
      i: data.itemId,
      v: JSON.stringify(data.colValues),
    })) as { change_multiple_column_values?: { id?: string | number } | null };
    const id = res?.change_multiple_column_values?.id;
    if (!id) throw new Error('บันทึกลงบอร์ดไม่สำเร็จ');
    return { id: String(id) };
  });

export const createItem = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      boardId: z.string().min(1),
      itemName: z.string(),
      groupId: z.string().optional(),
      colValues: z.record(z.string(), z.any()),
    }),
  )
  .handler(async ({ data }) => {
    const mutation = `mutation ($b: ID!, $n: String!, $g: String, $v: JSON!) {
      create_item(board_id: $b, item_name: $n, group_id: $g, column_values: $v) { id }
    }`;
    const res = (await executeGraphQL(mutation, {
      b: data.boardId,
      n: data.itemName,
      g: data.groupId || null,
      v: JSON.stringify(data.colValues),
    })) as { create_item?: { id?: string | number } | null };
    const id = res?.create_item?.id;
    if (!id) throw new Error('สร้าง item ไม่สำเร็จ');
    return { id: String(id) };
  });

export const readItem = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      itemId: z.string().min(1),
      colIds: z.array(z.string()),
    }),
  )
  .handler(async ({ data }) => {
    const query = `query ($id: [ID!]!) {
      items(ids: $id, limit: 1) {
        id
        name
        column_values { id text value }
      }
    }`;
    const res = (await executeGraphQL(query, { id: [data.itemId] })) as {
      items?: Array<{ id?: string | number; name?: string; column_values?: Array<{ id?: string; text?: string; value?: string }> }>;
    };
    const item = res?.items?.[0];
    if (!item?.id) throw new Error('อ่าน item ไม่สำเร็จ');
    return item;
  });
