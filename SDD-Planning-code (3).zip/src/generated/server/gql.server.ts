// Server-only monday GraphQL access for the data layer. Never imported from a component.
// Performance pass: every group's FIRST page in one request, then each group's own
// next_items_page chain, all chains concurrently. Page size and safety valve unchanged.
import { executeGraphQL } from '@api/api-methods';
import { getCurrentUser } from '@api/current-user.server';
import { LOAD_MAX_PAGES, LOAD_PAGE } from '@generated/config';
import { cvMap, parseLabels } from '@generated/lib/parse';
import type { LoadStats, RawCv, RawItem, ReqLog } from '@generated/lib/types';

const PAGE = LOAD_PAGE;
const MAX_PAGES = LOAD_MAX_PAGES; // safety valve per chain: 60 × 500 items

// Full selection. `type` is not requested: nothing in parse.ts or model/ reads it.
const CV = `{ id text value
  ... on StatusValue { index label }
  ... on DropdownValue { values { label } }
  ... on NumbersValue { number }
  ... on DateValue { date }
  ... on LastUpdatedValue { updated_at } }`;

// Month cells only. parse.ts num() decides emptiness from `text` (always a string for a numbers
// column) and consults `value` only when text is NOT a string — so value is not requested here.
const CV_NUM = `{ id text ... on NumbersValue { number } }`;

// The selection exactly as it was before the performance pass. Used ONLY by the temporary
// legacy switch (?sddLoad=legacy) so the "before" table can be measured on this same build.
const CV_LEGACY = `{ id text value type
  ... on StatusValue { index label }
  ... on DropdownValue { values { label } }
  ... on NumbersValue { number }
  ... on DateValue { date }
  ... on LastUpdatedValue { updated_at } }`;

export interface SelOpts {
  subCols?: string[];
  /** numeric month columns requested with the slim CV_NUM selection (aliased `mv`) */
  numCols?: string[];
  legacy?: boolean;
}

type Wire = RawItem & { cv?: RawCv[] | null; mv?: RawCv[] | null };

interface Page {
  cursor?: string | null;
  items?: Wire[] | null;
}

export function selection(cols: string[], o: SelOpts = {}): string {
  const full = o.legacy ? CV_LEGACY : CV;
  const sub =
    o.subCols && o.subCols.length
      ? ` subitems { id name column_values(ids: ${JSON.stringify(o.subCols)}) ${full} }`
      : '';
  const num = o.legacy ? [] : (o.numCols ?? []).filter((c) => cols.includes(c));
  if (num.length === 0) return `{ id name column_values(ids: ${JSON.stringify(cols)}) ${full}${sub} }`;
  const rest = cols.filter((c) => !num.includes(c));
  return (
    `{ id name cv: column_values(ids: ${JSON.stringify(rest)}) ${CV}` +
    ` mv: column_values(ids: ${JSON.stringify(num)}) ${CV_NUM}${sub} }`
  );
}

/** Merge the aliased halves back into `column_values`, so nothing downstream changes. */
function merge(list?: Wire[] | null): RawItem[] {
  return (list ?? []).map((w) => {
    if (w.cv === undefined && w.mv === undefined) return w;
    const { cv, mv, ...rest } = w;
    return { ...rest, column_values: [...(cv ?? []), ...(mv ?? [])] };
  });
}

function errText(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e ?? '');
  return msg.slice(0, 200);
}

export async function readNextPage(
  cursor: string,
  sel: string,
): Promise<{ items: RawItem[]; cursor: string | null }> {
  const q = `query ($c: String!) {
    next_items_page(limit: ${PAGE}, cursor: $c) { cursor items ${sel} }
  }`;
  const r = (await withRetry(() => executeGraphQL(q, { c: cursor }), 'readNextPage')) as {
    next_items_page?: Page | null;
  };
  const np = r?.next_items_page;
  return { items: merge(np?.items), cursor: np?.cursor ?? null };
}

/**
 * Session 1-25b · THE "page this group to the end" loop, lifted unchanged out of readFyRows. Follows
 * one group's cursor through readNextPage, appending in page order, until the cursor runs out, the
 * MAX_PAGES safety valve is hit, or `more()` says stop (readFyRows' in-call time budget). Every
 * page is timed and logged into `calls`. Returns the number of extra pages read.
 */
export async function pageToEnd(
  out: { items: RawItem[]; cursor: string | null },
  sel: string,
  label: string,
  what: (page: number) => string,
  calls: ReqLog[],
  more: () => boolean = () => true,
): Promise<number> {
  let pages = 0;
  while (out.cursor && pages < MAX_PAGES && more()) {
    pages += 1;
    const cur = out.cursor;
    const n = await timed(label, what(pages + 1), calls, () => readNextPage(cur, sel), (r) => r.items.length);
    out.items.push(...n.items);
    out.cursor = n.cursor;
  }
  return pages;
}

/** The walk as it was: board-wide items_page, then one next_items_page after another. */
async function walkSequential(boardId: string, sel: string): Promise<{ items: RawItem[]; requests: number }> {
  const q = `query ($b: ID!) {
    boards(ids: [$b]) { items_page(limit: ${PAGE}) { cursor items ${sel} } }
  }`;
  const first = (await executeGraphQL(q, { b: boardId })) as {
    boards?: ({ items_page?: Page | null } | null)[] | null;
  };
  const page = first?.boards?.[0]?.items_page;
  const items: RawItem[] = merge(page?.items);
  let cursor: string | null = page?.cursor ?? null;
  let requests = 1;
  let pages = 0;
  while (cursor && pages < MAX_PAGES) {
    pages += 1;
    requests += 1;
    const n = await readNextPage(cursor, sel);
    items.push(...n.items);
    cursor = n.cursor;
  }
  return { items, requests };
}

/** Session 1-17b · time one monday request; logged one line per request and kept for the client. */
export async function timed<T>(
  label: string,
  what: string,
  calls: ReqLog[],
  run: () => Promise<T>,
  rowsOf: (r: T) => number,
): Promise<T> {
  const t = Date.now();
  const r = await run();
  const entry = { what, ms: Date.now() - t, rows: rowsOf(r) };
  calls.push(entry);
  console.log(`[SDD req] ${label} · ${what} · ${entry.ms} ms · ${entry.rows} rows`);
  return r;
}

export interface GroupStart {
  id: string;
  title: string;
  items: RawItem[];
  cursor: string | null;
}

/**
 * CHANGE 1a · one request for every group's FIRST page. If the grouped query is rejected
 * (complexity or anything else), fall back to the sequential walk and say so — the result is
 * then ONE pseudo-group holding every item, with no cursor left.
 */
export async function readGroupsStart(
  boardId: string,
  cols: string[],
  label: string,
  o: SelOpts = {},
): Promise<{ groups: GroupStart[]; requests: number; mode: LoadStats['mode']; note?: string; calls: ReqLog[] }> {
  const sel = selection(cols, o);
  const calls: ReqLog[] = [];
  if (o.legacy) {
    const r = await walkSequential(boardId, sel);
    return { groups: [{ id: '*', title: '*', items: r.items, cursor: null }], requests: r.requests, mode: 'legacy', calls };
  }
  // Session 1-17b · the group list (same groups, same order as the old combined query), then ONE
  // request per group, all fired at the same moment, each at the full page size (500, monday's max).
  // Same selection, so every row and value is identical to the combined first call.
  type WireGroup = { id?: string; title?: string; items_page?: Page | null };
  type WireBoards = { boards?: ({ groups?: (WireGroup | null)[] | null } | null)[] | null };
  const listQ = `query ($b: ID!) { boards(ids: [$b]) { groups { id title } } }`;
  const pageQ = `query ($b: ID!, $g: [String]) {
    boards(ids: [$b]) { groups(ids: $g) { id title items_page(limit: ${PAGE}) { cursor items ${sel} } } }
  }`;
  try {
    const list = await timed(
      label,
      'group list',
      calls,
      async () =>
        ((await withRetry(() => executeGraphQL(listQ, { b: boardId }), label)) as WireBoards)?.boards?.[0]?.groups ?? [],
      (r) => r.length,
    );
    const ids = list.filter((g): g is WireGroup => !!g?.id).map((g) => ({ id: String(g.id), title: String(g.title ?? '') }));
    const groups: GroupStart[] = await Promise.all(
      ids.map(async (g) => {
        const page = await timed(
          label,
          `group ${g.title} · page 1`,
          calls,
          async () => {
            const res = (await withRetry(() => executeGraphQL(pageQ, { b: boardId, g: [g.id] }), label)) as WireBoards;
            const hit = (res?.boards?.[0]?.groups ?? []).find((x) => String(x?.id ?? '') === g.id);
            return { items: merge(hit?.items_page?.items), cursor: hit?.items_page?.cursor ?? null };
          },
          (r) => r.items.length,
        );
        return { id: g.id, title: g.title, items: page.items, cursor: page.cursor };
      }),
    );
    return { groups, requests: 1 + ids.length, mode: 'grouped', calls };
  } catch (e) {
    const note = errText(e);
    console.warn(`[SDD load] ${label} · grouped query rejected (${note}) — falling back to the sequential walk`);
    const r = await walkSequential(boardId, sel);
    return {
      groups: [{ id: '*', title: '*', items: r.items, cursor: null }],
      requests: r.requests,
      mode: 'sequential-fallback',
      note,
      calls,
    };
  }
}

/**
 * Every item of a board. CHANGE 1b/c · each group that still has a cursor walks its own chain,
 * all groups CONCURRENTLY; the final array is groups in API order, items in group order.
 */
export async function readBoard(
  boardId: string,
  cols: string[],
  label: string,
  o: SelOpts = {},
): Promise<{ items: RawItem[]; stats: LoadStats }> {
  const t0 = Date.now();
  const start = await readGroupsStart(boardId, cols, label, o);
  const sel = selection(cols, o);
  const extra = await Promise.all(
    start.groups.map(async (g) => {
      let pages = 0;
      while (g.cursor && pages < MAX_PAGES) {
        pages += 1;
        const cur = g.cursor;
        const n = await timed(label, `group ${g.title} · page ${pages + 1}`, start.calls, () => readNextPage(cur, sel), (r) => r.items.length);
        g.items.push(...n.items);
        g.cursor = n.cursor;
      }
      return pages;
    }),
  );
  const items = start.groups.flatMap((g) => g.items);
  const stats: LoadStats = {
    requests: start.requests + extra.reduce((a, b) => a + b, 0),
    items: items.length,
    ms: Date.now() - t0,
    mode: start.mode,
    groups: start.groups.length,
    ...(start.note ? { note: start.note } : {}),
    calls: start.calls,
  };
  console.log(
    `[SDD load] ${label} · board ${boardId} · ${stats.mode} · ${stats.groups} group(s) · ` +
      `${stats.requests} requests · ${stats.items} items · ${stats.ms} ms`,
  );
  return { items, stats };
}

// ─── Read a known set of items by id ─────────────────────────────────────────────
// Used by the import diff: items(ids:) has no filter syntax to get wrong (items_page
// query_params wants the label INDEX for dropdown columns, so compare_value:["SD1"]
// silently returns nothing) and touches only the rows the diff needs.
//
// monday's top-level items(ids:) applies a DEFAULT limit of 25 when `limit` is omitted and
// silently truncates instead of erroring — 147 ids in 2 calls returned 25+25=50 rows and the
// other 97 looked "missing from the board". `limit` is therefore ALWAYS sent explicitly and
// is never smaller than the chunk size.
const ID_CHUNK = 50;

export async function readItemsByIds(
  ids: string[],
  cols: string[],
  tag = 'readItemsByIds',
): Promise<RawItem[]> {
  const clean = [...new Set(ids.map((v) => String(v ?? '').trim()).filter(Boolean))];
  if (clean.length === 0) return [];

  const sel = selection(cols);
  const query = `query ($ids: [ID!]!, $limit: Int!) { items (ids: $ids, limit: $limit) ${sel} }`;

  const chunks: string[][] = [];
  for (let i = 0; i < clean.length; i += ID_CHUNK) chunks.push(clean.slice(i, i + ID_CHUNK));

  const out: RawItem[] = [];
  const perChunk: number[] = [];

  // Every chunk is fetched and APPENDED. No break, no reassignment, no operation-wide cap.
  for (let c = 0; c < chunks.length; c += 1) {
    const chunk = chunks[c]!;
    const res = (await withRetry(() => executeGraphQL(query, { ids: chunk, limit: ID_CHUNK }), tag)) as {
      items?: RawItem[] | null;
    };
    const got = res?.items ?? [];
    perChunk.push(got.length);

    if (got.length < chunk.length) {
      const back = new Set(got.map((it) => String(it?.id ?? '')));
      const absent = chunk.filter((id) => !back.has(id));
      console.warn(
        `[${tag}] chunk ${c + 1}/${chunks.length} short by ${chunk.length - got.length} —` +
          ` ids not returned: ${absent.slice(0, 10).join(', ')}` +
          (absent.length > 10 ? ` +${absent.length - 10} more` : ''),
      );
    }
    out.push(...got);
  }

  console.log(
    `[${tag}] ${chunks.length} chunk(s) [${perChunk.join(' + ')}] = ${out.length} rows` +
      ` of ${clean.length} ids asked`,
  );
  return out;
}

// Groups of a board, for looking a group up by title at runtime ("FY2026").
export async function readBoardGroupList(
  boardId: string,
): Promise<{ id: string; title: string }[]> {
  // Session 1-15c · a group deleted or archived on the board is NOT a group: it must neither make a
  // year look prepared nor be reused as the place new rows are created.
  const query = `query ($b: ID!) { boards(ids: [$b]) { groups { id title archived deleted } } }`;
  const res = (await executeGraphQL(query, { b: boardId })) as {
    boards?: ({
      groups?: ({ id?: string; title?: string; archived?: boolean | null; deleted?: boolean | null } | null)[] | null;
    } | null)[] | null;
  };
  return (res?.boards?.[0]?.groups ?? [])
    .filter((g): g is { id: string; title: string } => !!g?.id && !g.archived && !g.deleted)
    .map((g) => ({ id: String(g.id), title: String(g.title ?? '') }));
}

// ─── Mutations for the import batch runner (C2) ──────────────────────────────────
// Aliased so up to 25 rows move in ONE request. Sequential by caller.

/** Retry-once delay for a complexity / rate-limit answer, in ms. 0 = not a retryable error. */
function retryDelayMs(e: unknown): number {
  const msg = e instanceof Error ? e.message : String(e);
  const cause = (e as { cause?: { errors?: { message?: string }[]; code?: string } })?.cause;
  const all = [msg, cause?.code ?? '', ...(cause?.errors ?? []).map((x) => x?.message ?? '')].join(' ');
  // A rejected user token (401 UNAUTHENTICATED) is usually a token that expired while the page sat
  // open; the platform refreshes it once inside the same call. Give the refreshed token a moment
  // and retry ONCE more before showing "โปรดรีเฟรชหน้า".
  if (/UNAUTHENTICATED|HTTP 401/i.test(all)) return 1500;
  if (!/complexity|rate.?limit|budget|429|too many/i.test(all)) return 0;
  const m = /(?:reset|retry)[^0-9]{0,20}(\d+)\s*second/i.exec(all) ?? /(\d+)\s*seconds?/i.exec(all);
  const secs = m?.[1] ? Number(m[1]) : 10;
  return Math.min(Math.max(secs, 1), 60) * 1000;
}

async function withRetry<T>(run: () => Promise<T>, tag: string): Promise<T> {
  try {
    return await run();
  } catch (e) {
    const wait = retryDelayMs(e);
    if (wait === 0) throw e; // any other error stops the run
    const auth = /UNAUTHENTICATED|HTTP 401/i.test(e instanceof Error ? e.message : String(e));
    if (auth) await logAuthFailure(tag, e);
    console.warn(`[${tag}] ${auth ? 'monday rejected the user token (401)' : 'rate limited'} — waiting ${wait / 1000}s then retrying once`);
    await new Promise((r) => setTimeout(r, wait));
    try {
      return await run();
    } catch (e2) {
      if (auth) await logAuthFailure(`${tag} · retry`, e2);
      throw e2;
    }
  }
}

/** Server log only: who was rejected and monday's real error body (the client sees "[object Object]"). */
async function logAuthFailure(tag: string, e: unknown): Promise<void> {
  let who = 'UNKNOWN';
  try {
    const u = await getCurrentUser();
    who = u ? `${u.kind} ${u.id}` : 'no identifiable viewer';
  } catch {
    /* identity lookup must never mask the original error */
  }
  const cause = (e as { cause?: unknown; response?: unknown })?.cause ?? (e as { response?: unknown })?.response;
  let body = '';
  try {
    body = JSON.stringify(cause ?? null).slice(0, 600);
  } catch {
    body = String(cause);
  }
  console.error(`[${tag}] 401 UNAUTHENTICATED · viewer: ${who} · monday says: ${body}`);
}

/** Up to 25 change_multiple_column_values in one request. Absolute values only. */
export async function mutateUpdateMany(
  boardId: string,
  ops: { itemId: string; columnValues: Record<string, unknown> }[],
): Promise<number> {
  if (ops.length === 0) return 0;
  const defs = ops.map((_, k) => `$i${k}: ID!, $v${k}: JSON!`).join(', ');
  const body = ops
    .map(
      (_, k) =>
        `u${k}: change_multiple_column_values(board_id: $b, item_id: $i${k}, column_values: $v${k}) { id }`,
    )
    .join('\n');
  const mutation = `mutation ($b: ID!, ${defs}) {\n${body}\n}`;

  const vars: Record<string, unknown> = { b: boardId };
  ops.forEach((o, k) => {
    vars[`i${k}`] = o.itemId;
    vars[`v${k}`] = JSON.stringify(o.columnValues);
  });

  await withRetry(() => executeGraphQL(mutation, vars), 'mutateUpdateMany');
  return ops.length;
}

/**
 * Session 1-15 · up to 25 aliased create_item in ONE request, all into the same group. Used ONLY by
 * "เตรียมข้อมูลปีงบ", which recounts what is missing on every run, so a request that fails part-way
 * is repaired by pressing again — never by deleting.
 */
export async function mutateCreateMany(
  boardId: string,
  groupId: string,
  items: { name: string; columnValues: Record<string, unknown> }[],
): Promise<string[]> {
  if (items.length === 0) return [];
  const defs = items.map((_, k) => `$n${k}: String!, $v${k}: JSON!`).join(', ');
  const body = items
    .map((_, k) => `c${k}: create_item(board_id: $b, group_id: $g, item_name: $n${k}, column_values: $v${k}) { id }`)
    .join('\n');
  const mutation = `mutation ($b: ID!, $g: String!, ${defs}) {\n${body}\n}`;
  const vars: Record<string, unknown> = { b: boardId, g: groupId };
  items.forEach((it, k) => {
    vars[`n${k}`] = it.name;
    vars[`v${k}`] = JSON.stringify(it.columnValues);
  });
  const res = (await withRetry(() => executeGraphQL(mutation, vars), 'mutateCreateMany')) as Record<
    string,
    { id?: string | number } | null
  >;
  const ids = items.map((_, k) => res?.[`c${k}`]?.id);
  if (ids.some((x) => !x)) throw new Error('สร้าง item ไม่สำเร็จ');
  return ids.map(String);
}

/** Session 1-15 · create ONE group. Callers check by title first — never a second group of a name. */
export async function mutateCreateGroup(boardId: string, name: string): Promise<string> {
  const mutation = `mutation ($b: ID!, $n: String!) { create_group(board_id: $b, group_name: $n) { id } }`;
  const res = (await withRetry(() => executeGraphQL(mutation, { b: boardId, n: name }), 'mutateCreateGroup')) as {
    create_group?: { id?: string } | null;
  };
  const id = res?.create_group?.id;
  if (!id) throw new Error('สร้างกลุ่มไม่สำเร็จ');
  return String(id);
}

/** ONE create_item per request — the returned id must be known for every created row. */
export async function mutateCreateOne(
  boardId: string,
  itemName: string,
  columnValues: Record<string, unknown>,
  groupId?: string,
): Promise<string> {
  const mutation = `mutation ($b: ID!, $n: String!, $g: String, $v: JSON!) {
    create_item(board_id: $b, item_name: $n, group_id: $g, column_values: $v) { id }
  }`;
  const res = (await withRetry(
    () =>
      executeGraphQL(mutation, {
        b: boardId,
        n: itemName,
        g: groupId || null,
        v: JSON.stringify(columnValues),
      }),
    'mutateCreateOne',
  )) as { create_item?: { id?: string | number } | null };
  const id = res?.create_item?.id;
  if (!id) throw new Error('สร้าง item ไม่สำเร็จ');
  return String(id);
}

/** Up to 25 delete_item in one request. "not found" counts as done (already gone). */
export async function mutateDeleteMany(itemIds: string[]): Promise<number> {
  if (itemIds.length === 0) return 0;
  const defs = itemIds.map((_, k) => `$d${k}: ID!`).join(', ');
  const body = itemIds.map((_, k) => `x${k}: delete_item(item_id: $d${k}) { id }`).join('\n');
  const mutation = `mutation (${defs}) {\n${body}\n}`;

  const vars: Record<string, unknown> = {};
  itemIds.forEach((id, k) => {
    vars[`d${k}`] = id;
  });

  try {
    await withRetry(() => executeGraphQL(mutation, vars), 'mutateDeleteMany');
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    // An item already absent from the board is the desired end state, not a failure.
    if (!/not found|does not exist|doesn't exist|InvalidItemId/i.test(msg)) throw e;
    console.warn('[mutateDeleteMany] some ids were already gone — counted as done');
  }
  return itemIds.length;
}

// Label lists straight from the column settings. Empty result → the caller falls back to
// the distinct values found in the rows.
// ─── Session 1-17h · read ONE fiscal year: its group + every non-year group, keep by FY value ───
/** The FY dropdown's options as monday stores them: option id + label. */
export interface FyOption {
  id: number;
  name: string;
}

function parseFyOptions(raw: string | null | undefined, where: string): FyOption[] {
  if (!raw) throw new Error(`FY column settings could not be read on ${where}`);
  const j = JSON.parse(raw) as { labels?: Record<string, string> | ({ id?: number; name?: string } | null)[] | null };
  const l = j?.labels;
  if (!l) return [];
  const list = Array.isArray(l)
    ? l.map((x) => ({ id: Number(x?.id), name: String(x?.name ?? '').trim() }))
    : Object.entries(l).map(([k, v]) => ({ id: Number(k), name: String(v ?? '').trim() }));
  return list.filter((o) => Number.isFinite(o.id) && o.name);
}

/**
 * Session 1-26 · MP Plan only. Load one year group as one filtered request per Team label instead of
 * paging it. `count` returns monday's own item count of the group; `cap` limits how many team
 * requests are in flight at once.
 */
export interface TeamSplit {
  col: string;
  count: (groupId: string) => Promise<number>;
  cap: number;
}

/** Every label of a dropdown column, active AND deactivated. null = settings could not be read. */
function parseAllLabels(raw: string | null | undefined): { id: number; name: string }[] | null {
  if (!raw) return null;
  try {
    type L = Record<string, string> | ({ id?: number; name?: string } | number | null)[] | null | undefined;
    const j = JSON.parse(raw) as { labels?: L; deactivated_labels?: L };
    const list = (l: L) =>
      !l
        ? []
        : Array.isArray(l)
          ? l.map((x) => (typeof x === 'number' ? { id: x, name: `#${x}` } : { id: Number(x?.id), name: String(x?.name ?? '') }))
          : Object.entries(l).map(([k, v]) => ({ id: Number(k), name: String(v ?? '') }));
    const all = [...list(j?.labels), ...list(j?.deactivated_labels)].filter((x) => Number.isFinite(x.id));
    const seen = new Set<number>();
    return all.filter((x) => (seen.has(x.id) ? false : (seen.add(x.id), true)));
  } catch {
    return null;
  }
}

/** Run `jobs` with at most `cap` in flight; results keep the jobs' order. */
async function capped<J, R>(jobs: J[], cap: number, run: (j: J) => Promise<R>): Promise<R[]> {
  const out = Array.from({ length: jobs.length }) as R[];
  let next = 0;
  const worker = async () => {
    while (next < jobs.length) {
      const i = next++;
      out[i] = await run(jobs[i]!);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(cap, jobs.length)) }, worker));
  return out;
}

/**
 * Session 1-26 · the year group, read team by team. Every request is limited to the group, so a row
 * that arrives belongs to it. Complete = no Item ID twice AND as many distinct rows as monday counts in
 * the group. Each team request pages itself through pageToEnd (a team over 500 rows does not undo the
 * split for the others). Anything unproven or failing returns null and the caller pages the group.
 */
async function readTeamSplit(
  boardId: string,
  g: { id: string; title: string },
  sel: string,
  label: string,
  calls: ReqLog[],
  split: TeamSplit,
  labels: { id: number; name: string }[] | null,
): Promise<GroupStart | null> {
  const t0 = Date.now();
  const back = (why: string) => {
    console.warn(`[SDD load] ${label} · group ${g.title} · team split incomplete · ${why} · paging the group`);
    return null;
  };
  if (!labels) return back('Team column settings could not be read');
  const col = JSON.stringify(split.col);
  const jobs = [
    ...labels.map((l) => ({ what: `team ${l.name}`, rule: `{ column_id: ${col}, compare_value: [${l.id}], operator: any_of }` })),
    { what: 'blank Team', rule: `{ column_id: ${col}, compare_value: [], operator: is_empty }` },
  ];
  type WireBoards = { boards?: ({ groups?: ({ id?: string; items_page?: Page | null } | null)[] | null } | null)[] | null };
  try {
    const countP = timed(label, `group ${g.title} · count`, calls, () => split.count(g.id), (n) => n);
    countP.catch(() => undefined); // observed below; never an unhandled rejection
    const parts = await capped(jobs, split.cap, async (j) => {
      const q = `query ($b: ID!, $g: [String]) {
        boards(ids: [$b]) { groups(ids: $g) { id items_page(limit: ${PAGE}, query_params: { rules: [${j.rule}] }) { cursor items ${sel} } } }
      }`;
      const out = await timed(label, `group ${g.title} · ${j.what} · page 1`, calls, async () => {
        const res = (await withRetry(() => executeGraphQL(q, { b: boardId, g: [g.id] }), label)) as WireBoards;
        const one = (res?.boards?.[0]?.groups ?? []).find((x) => String(x?.id ?? '') === g.id);
        return { items: merge(one?.items_page?.items), cursor: one?.items_page?.cursor ?? null };
      }, (r) => r.items.length);
      await pageToEnd(out, sel, label, (p) => `group ${g.title} · ${j.what} · page ${p}`, calls);
      return out.items;
    });
    const count = await countP;
    const items = parts.flat();
    const ids = new Set(items.map((it) => String(it.id)));
    if (ids.size !== items.length) return back(`${items.length - ids.size} Item ID(s) arrived twice`);
    if (!Number.isFinite(count) || ids.size !== count) return back(`got ${ids.size} of ${count}`);
    console.log(`[SDD load] ${label} · group ${g.title} · team split complete · ${ids.size} of ${count} · ${jobs.length} requests, ${split.cap} at a time · ${Date.now() - t0} ms`);
    return { id: g.id, title: g.title, items, cursor: null };
  } catch (e) {
    return back(`a request failed (${errText(e)})`);
  }
}

/** A group named like a fiscal year ("FY2026"). Every other group may hold rows of any year. */
const YEAR_GROUP = /^FY\d{4}$/;

/**
 * The rows of ONE fiscal year. Reads, all at the same moment, the group "FY{year}" and every group
 * that is NOT a fiscal-year group (New Group, Unmatched · รอยืนยัน, …) — the places a row lands when
 * it is saved without its FY group or moved by hand — then keeps a row only when its FY value is
 * the year, exactly as every screen does. Groups keep their API order, items their group order.
 * Later pages continue through next_items_page while `budgetMs` allows; any cursor left is
 * returned and its rows are kept by FY value on the client.
 *
 * Guard 1 · the year must exist as exactly one option on the FY column, looked up from the column
 *           settings on every call (same request as the group list). Otherwise → throws.
 * Guard 2 · no rows kept is checked, not trusted: if group "FY{year}" holds items yet none carries
 *           the year → throws. An empty FY group (prepared, nothing imported yet) or no FY group
 *           (unprepared) is an empty year.
 *
 * Note · the cost grows with the size of the non-year groups. A row of this year moved by hand into
 * ANOTHER year's group is not read.
 */
export async function readFyRows(
  boardId: string,
  cols: string[],
  label: string,
  o: SelOpts,
  fyCol: string,
  fy: string,
  budgetMs = Number.POSITIVE_INFINITY,
  side?: string[],
  split?: TeamSplit,
): Promise<{ groups: GroupStart[]; requests: number; calls: ReqLog[]; optionId: number; sideItems: RawItem[] }> {
  const t0 = Date.now();
  const calls: ReqLog[] = [];
  const FY = String(fy).trim();
  type Meta = {
    boards?: ({
      columns?: ({ id?: string; settings_str?: string | null } | null)[] | null;
      groups?: ({ id?: string; title?: string } | null)[] | null;
    } | null)[] | null;
  };
  // Session 1-26 · with a team split the same request also reads the Team column's settings (MP only).
  const metaCols = split ? [fyCol, split.col] : [fyCol];
  const metaQ = `query ($b: ID!) { boards(ids: [$b]) { columns(ids: ${JSON.stringify(metaCols)}) { id settings_str } groups { id title } } }`;
  const meta = await timed(label, 'fy options + group list', calls, async () => {
    const r = (await withRetry(() => executeGraphQL(metaQ, { b: boardId }), label)) as Meta;
    const bd = r?.boards?.[0];
    return {
      options: parseFyOptions(bd?.columns?.find((c) => c?.id === fyCol)?.settings_str, `${label} (${fyCol})`),
      teamLabels: split ? parseAllLabels(bd?.columns?.find((c) => c?.id === split.col)?.settings_str) : null,
      groups: (bd?.groups ?? []).filter((g): g is { id: string; title: string } => !!g?.id).map((g) => ({ id: String(g.id), title: String(g.title ?? '').trim() })),
    };
  }, (r) => r.groups.length);

  const hit = meta.options.filter((x) => x.name === FY);
  if (hit.length !== 1) {
    throw new Error(
      hit.length === 0
        ? `${label} · the FY column has no option "${FY}" — rows of this year cannot be read`
        : `${label} · the FY column has ${hit.length} options named "${FY}" — refusing to guess`,
    );
  }
  const optionId = hit[0]!.id;

  const targets = meta.groups.filter((g) => g.title === `FY${FY}` || !YEAR_GROUP.test(g.title));
  const sel = selection(cols, o);
  const pageQ = `query ($b: ID!, $g: [String]) {
    boards(ids: [$b]) { groups(ids: $g) { id items_page(limit: ${PAGE}) { cursor items ${sel} } } }
  }`;
  type WireBoards = { boards?: ({ groups?: ({ id?: string; items_page?: Page | null } | null)[] | null } | null)[] | null };
  // Session 1-23 · optional "side" columns of EVERY row of the board (Company Plan's company list).
  // The groups read above already carry them (taken before the FY filter); only the other-year
  // groups are read again, with the side columns alone, reusing the group list fetched above and
  // starting at the same moment as the year's own groups.
  const others = side ? meta.groups.filter((g) => !targets.some((t) => t.id === g.id)) : [];
  const sideSel = side ? selection(side) : '';
  const sideQ = `query ($b: ID!, $g: [String]) {
    boards(ids: [$b]) { groups(ids: $g) { id items_page(limit: ${PAGE}) { cursor items ${sideSel} } } }
  }`;
  const sideRead = Promise.all(
    others.map(async (g) => {
      const page = await timed(label, `group ${g.title} · page 1 · ${(side ?? []).join(',')} only`, calls, async () => {
        const res = (await withRetry(() => executeGraphQL(sideQ, { b: boardId, g: [g.id] }), label)) as WireBoards;
        const one = (res?.boards?.[0]?.groups ?? []).find((x) => String(x?.id ?? '') === g.id);
        return { items: merge(one?.items_page?.items), cursor: one?.items_page?.cursor ?? null };
      }, (r) => r.items.length);
      const out = { items: [...page.items], cursor: page.cursor };
      await pageToEnd(out, sideSel, label, (p) => `group ${g.title} · page ${p} · side`, calls);
      return out.items;
    }),
  );
  // if the year's own read fails first, the side read's later failure must not go unobserved
  sideRead.catch(() => undefined);
  const raw: GroupStart[] = await Promise.all(
    targets.map(async (g) => {
      // Session 1-26 · MP's own year group: one filtered request per Team label, proven complete by the
      // group's count. null = not proven → today's paging below (logged).
      if (split && g.title === `FY${FY}`) {
        const got = await readTeamSplit(boardId, g, sel, label, calls, split, meta.teamLabels);
        if (got) return got;
      }
      const page = await timed(label, `group ${g.title} · page 1`, calls, async () => {
        const res = (await withRetry(() => executeGraphQL(pageQ, { b: boardId, g: [g.id] }), label)) as WireBoards;
        const one = (res?.boards?.[0]?.groups ?? []).find((x) => String(x?.id ?? '') === g.id);
        return { items: merge(one?.items_page?.items), cursor: one?.items_page?.cursor ?? null };
      }, (r) => r.items.length);
      const out: GroupStart = { id: g.id, title: g.title, items: page.items, cursor: page.cursor };
      await pageToEnd(out, sel, label, (p) => `group ${g.title} · page ${p}`, calls, () => Date.now() - t0 < budgetMs);
      return out;
    }),
  );
  const sideOthers = await sideRead;
  const sideItems: RawItem[] = side ? [...raw.flatMap((g) => g.items), ...sideOthers.flat()] : [];
  const requests = calls.length;

  // keep by FY value — the first label, exactly as parse.dropdown() reads it for every screen
  const fyOf = (it: RawItem) => (cvMap(it)[fyCol]?.values?.[0]?.label ?? '').trim();
  const fyGroup = raw.find((g) => g.title === `FY${FY}`);
  const fyGroupRaw = fyGroup?.items.length ?? 0;
  const groups = raw.map((g) => ({ ...g, items: g.items.filter((it) => fyOf(it) === FY) }));

  const total = groups.reduce((n, g) => n + g.items.length, 0);
  const open = groups.some((g) => g.cursor);
  if (total === 0 && !open && fyGroupRaw > 0) {
    throw new Error(`${label} · group FY${FY} holds ${fyGroupRaw} rows but none carries FY ${FY} — not shown, to avoid wrong numbers`);
  }
  return { groups, requests, calls, optionId, sideItems };
}

/**
 * Session 1-25 · misplaced-row search. Rows whose FY value is `fy` but which sit in ANOTHER fiscal-year
 * group ("FY2025" while the year is 2026) — the only places the year's load does not read. Each
 * other-year group is asked, through monday's own filter on the FY column (option id from the column
 * settings, Guard 1), for its rows carrying the year; only id, name and the FY column come back. The
 * first FY label is then checked in memory, exactly as every screen reads it. Replaces the board-wide
 * scan; verified against it on boards 04 / 05 / 07 for every year before switching (same rows).
 */
export async function readYearRowsElsewhere(
  boardId: string,
  fyCol: string,
  fy: string,
  label: string,
): Promise<{ rows: { id: string; name: string; group: string }[]; returned: number; requests: number }> {
  const FY = String(fy).trim();
  type Meta = {
    boards?: ({
      columns?: ({ id?: string; settings_str?: string | null } | null)[] | null;
      groups?: ({ id?: string; title?: string } | null)[] | null;
    } | null)[] | null;
  };
  const metaQ = `query ($b: ID!) { boards(ids: [$b]) { columns(ids: ${JSON.stringify([fyCol])}) { id settings_str } groups { id title } } }`;
  const r = (await withRetry(() => executeGraphQL(metaQ, { b: boardId }), label)) as Meta;
  const bd = r?.boards?.[0];
  const options = parseFyOptions(bd?.columns?.find((c) => c?.id === fyCol)?.settings_str, `${label} (${fyCol})`);
  const hit = options.filter((x) => x.name === FY);
  if (hit.length !== 1) throw new Error(`${label} · FY column has ${hit.length} options named "${FY}"`);
  const optionId = hit[0]!.id;
  const others = (bd?.groups ?? [])
    .filter((g): g is { id: string; title: string } => !!g?.id)
    .map((g) => ({ id: String(g.id), title: String(g.title ?? '').trim() }))
    .filter((g) => YEAR_GROUP.test(g.title) && g.title !== `FY${FY}`);
  const sel = selection([fyCol]);
  const q = `query ($b: ID!, $g: [String]) {
    boards(ids: [$b]) { groups(ids: $g) { id items_page(limit: ${PAGE}, query_params: { rules: [{ column_id: ${JSON.stringify(fyCol)}, compare_value: [${optionId}], operator: any_of }] }) { cursor items ${sel} } } }
  }`;
  type WireBoards = { boards?: ({ groups?: ({ id?: string; items_page?: Page | null } | null)[] | null } | null)[] | null };
  const calls: ReqLog[] = [];
  const perGroup = await Promise.all(
    others.map(async (g) => {
      // the one difference from the main loader: the FIRST page carries the FY filter
      const first = await timed(label, `group ${g.title} · page 1 · FY ${FY} filter`, calls, async () => {
        const res = (await withRetry(() => executeGraphQL(q, { b: boardId, g: [g.id] }), label)) as WireBoards;
        const one = (res?.boards?.[0]?.groups ?? []).find((x) => String(x?.id ?? '') === g.id);
        return { items: merge(one?.items_page?.items), cursor: one?.items_page?.cursor ?? null };
      }, (r) => r.items.length);
      // later pages: the main loader's own loop (the cursor carries the filter)
      await pageToEnd(first, sel, label, (p) => `group ${g.title} · page ${p} · FY ${FY} filter`, calls);
      return { g, items: first.items };
    }),
  );
  const requests = 1 + calls.length;
  const fyOf = (it: RawItem) => (cvMap(it)[fyCol]?.values?.[0]?.label ?? '').trim();
  const rows = perGroup.flatMap(({ g, items }) =>
    items.filter((it) => fyOf(it) === FY).map((it) => ({ id: String(it.id), name: (it.name ?? '').trim(), group: g.title })),
  );
  return { rows, returned: perGroup.reduce((n, x) => n + x.items.length, 0), requests };
}

/** Session 1-17f · readFyRows paged to the end, flattened like readBoard (groups in API order). */
export async function readFyBoard(
  boardId: string,
  cols: string[],
  label: string,
  o: SelOpts,
  fyCol: string,
  fy: string,
  side?: string[],
): Promise<{ items: RawItem[]; stats: LoadStats; sideItems: RawItem[] }> {
  const t0 = Date.now();
  const r = await readFyRows(boardId, cols, label, o, fyCol, fy, Number.POSITIVE_INFINITY, side);
  const items = r.groups.flatMap((g) => g.items);
  const stats: LoadStats = {
    requests: r.requests,
    items: items.length,
    ms: Date.now() - t0,
    mode: 'grouped',
    groups: r.groups.length,
    calls: r.calls,
  };
  console.log(`[SDD load] ${label} · FY${fy} (option #${r.optionId}) · ${stats.requests} requests · ${stats.items} items · ${stats.ms} ms`);
  return { items, stats, sideItems: r.sideItems };
}

/** Raw settings_str per column (null on any failure — callers fall back exactly as for readLabelSets). */
export async function readColumnSettings(boardId: string, cols: string[]): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  try {
    const query = `query ($b: ID!) { boards(ids: [$b]) { columns(ids: ${JSON.stringify(cols)}) { id settings_str } } }`;
    const res = (await executeGraphQL(query, { b: boardId })) as {
      boards?: ({ columns?: ({ id?: string; settings_str?: string | null } | null)[] | null } | null)[] | null;
    };
    for (const c of res?.boards?.[0]?.columns ?? []) if (c?.id && c.settings_str) out[c.id] = c.settings_str;
  } catch (e) {
    console.error('readColumnSettings failed', boardId, e);
  }
  return out;
}

export async function readLabelSets(
  boardId: string,
  cols: string[],
): Promise<Record<string, string[]>> {
  const out: Record<string, string[]> = {};
  try {
    const query = `query ($b: ID!) {
      boards(ids: [$b]) { columns(ids: ${JSON.stringify(cols)}) { id settings_str } }
    }`;
    const res = (await executeGraphQL(query, { b: boardId })) as {
      boards?: ({ columns?: ({ id?: string; settings_str?: string | null } | null)[] | null } | null)[] | null;
    };
    for (const c of res?.boards?.[0]?.columns ?? []) {
      if (c?.id) out[c.id] = parseLabels(c.settings_str);
    }
  } catch (e) {
    console.error('readLabelSets failed', boardId, e);
  }
  return out;
}
