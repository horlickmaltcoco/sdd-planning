import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID, SUBITEM_BOARD_ID } from '@generated/config';
import { EMP_C, EMP_COLS, SUB_C, SUB_COLS } from '@generated/lib/cols';
import { cvMap, dateOf, dropdown, status, txt, ymCode } from '@generated/lib/parse';
import type { AssignRow, EmpRow } from '@generated/lib/types';
import { readBoard, readLabelSets } from '@generated/server/gql.server';

// B7 · Employee Master → D_EMP (14 slots per parent) and D_ASSIGN (7 slots per "ช่วงสังกัด").
export const getEmpData = createServerFn({ method: 'GET' })
  .validator(z.object({ legacy: z.boolean().optional() }).optional())
  .handler(async ({ data }) => {
    const boardId = BOARD_ID['Employee Master'];
    const [{ items, stats }, labels, subLabels] = await Promise.all([
      readBoard(boardId, EMP_COLS, '02 : SDD · Employee Master', {
        subCols: SUB_COLS,
        legacy: data?.legacy === true,
      }),
      readLabelSets(boardId, [EMP_C.sec, EMP_C.grp]),
      readLabelSets(SUBITEM_BOARD_ID, [SUB_C.team, SUB_C.grp]),
    ]);

    const emp: EmpRow[] = [];
    const assign: AssignRow[] = [];

    for (const it of items) {
      const cv = cvMap(it);
      const empId = txt(cv[EMP_C.emp]);
      emp.push([
        (it.name ?? '').trim(),
        empId,
        txt(cv[EMP_C.email]),
        dropdown(cv[EMP_C.grp]),
        dropdown(cv[EMP_C.sec]),
        dropdown(cv[EMP_C.pos]),
        dateOf(cv[EMP_C.begin]),
        dateOf(cv[EMP_C.end]),
        status(cv[EMP_C.status]),
        dropdown(cv[EMP_C.quota]),
        txt(cv[EMP_C.incharge]),
        txt(cv[EMP_C.mpname]),
        status(cv[EMP_C.plan]),
        '',
      ]);
      for (const sub of it.subitems ?? []) {
        const scv = cvMap(sub);
        assign.push([
          empId,
          dropdown(scv[SUB_C.team]),
          ymCode(dateOf(scv[SUB_C.from])),
          ymCode(dateOf(scv[SUB_C.to])),
          dropdown(scv[SUB_C.quota]),
          txt(scv[SUB_C.why]),
          dropdown(scv[SUB_C.grp]),
        ]);
      }
    }

    // Runtime count (read-only): parents and every subitem monday returned with them.
    const subCount = items.reduce((s, it) => s + (it.subitems?.length ?? 0), 0);
    console.log(`[SDD load] 02 Employee Master · ${items.length} items · ${subCount} subitems`);
    return {
      diag: { loaded: items.length, subitems: subCount },
      perf: stats,
      emp,
      assign,
      sections: labels[EMP_C.sec] ?? [],
      groups: labels[EMP_C.grp] ?? [],
      subSections: subLabels[SUB_C.team] ?? [],
      subGroups: subLabels[SUB_C.grp] ?? [],
    };
  });
