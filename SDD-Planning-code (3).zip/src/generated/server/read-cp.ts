import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID } from '@generated/config';
import { CP_C, CP_COLS } from '@generated/lib/cols';
import { cpRowOf } from '@generated/lib/cp-map';
import { readFyBoard } from '@generated/server/gql.server';

// 07 · Company Plan → CPLAN. Every item via items_page + cursor (readBoard pages each group).
export const getCpData = createServerFn({ method: 'GET' })
  .validator(z.object({ fy: z.string().min(1) }))
  .handler(async ({ data }) => {
    // Session 1-17f · the selected fiscal year only, by FY value. The company master list stays
    // built from the rows of EVERY year (import validation and add-company use it).
    // Session 1-23 · one pass over the board: the group list is read once, the year's own groups once
    // (their Company values reused), and only the OTHER year groups are read for the Company column
    // alone. Same rows, same company set as the former second board-wide read.
    const fyRead = await readFyBoard(
      BOARD_ID['Company Plan'],
      CP_COLS,
      '07 : SDD · Company Plan',
      { numCols: [CP_C.md] },
      CP_C.fy,
      data.fy,
      [CP_C.co],
    );
    const rows = fyRead.items.map(cpRowOf);
    const companies = fyRead.sideItems.map((it) => cpRowOf(it).co).filter(Boolean);
    return { rows, companies, count: rows.length, perf: fyRead.stats };
  });
