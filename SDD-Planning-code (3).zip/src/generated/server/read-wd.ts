import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID, MONTHS } from '@generated/config';
import { WD_C, WD_COLS } from '@generated/lib/cols';
import { cvMap, dropdown, month12, num, txt } from '@generated/lib/parse';
import type { MonthArr, RuleMap, RuleRow, WdMap } from '@generated/lib/types';
import { readBoard } from '@generated/server/gql.server';

// B3 · Working Day Master → D_WD, D_CAP, D_RULE
export const getWdData = createServerFn({ method: 'GET' })
  .validator(z.object({ legacy: z.boolean().optional() }).optional())
  .handler(async ({ data }) => {
    const { items, stats } = await readBoard(
      BOARD_ID['Working Day Master'],
      WD_COLS,
      '03 : SDD · Working Day Master',
      { legacy: data?.legacy === true },
    );
    const wd: WdMap = {};
    const cap: WdMap = {};
    const rule: RuleMap = {};
    const months = MONTHS as readonly string[];

    for (const it of items) {
      const cv = cvMap(it);
      const fy = dropdown(cv[WD_C.fy]);
      const mo = dropdown(cv[WD_C.month]);
      if (mo) {
        const mi = months.indexOf(mo);
        if (mi < 0 || !fy) continue;
        const wdRow: MonthArr = wd[fy] ?? month12<number | null>(null);
        const capRow: MonthArr = cap[fy] ?? month12<number | null>(null);
        wdRow[mi] = num(cv[WD_C.days]);
        capRow[mi] = num(cv[WD_C.cap]);
        wd[fy] = wdRow;
        cap[fy] = capRow;
      } else if (fy && !rule[fy]) {
        const r: RuleRow = {
          tol: num(cv[WD_C.tol]),
          minPer: dropdown(cv[WD_C.minPer]),
          maxPer: dropdown(cv[WD_C.maxPer]),
          bands: txt(cv[WD_C.bands]),
          redAt: num(cv[WD_C.redAt]),
          hpd: num(cv[WD_C.hpd]),
        };
        rule[fy] = r;
      }
    }
    return { wd, cap, rule, count: items.length, perf: stats };
  });
