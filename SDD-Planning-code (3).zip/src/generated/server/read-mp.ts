import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID } from '@generated/config';
import { MP_C, MP_COLS, MP_M } from '@generated/lib/cols';
import {
  cvMap,
  dropdown,
  itemId,
  lastUpdatedIso,
  num,
  parseLabels,
  status,
  txt,
} from '@generated/lib/parse';
import type { LoadStats, MpRow, RawItem } from '@generated/lib/types';
import { readColumnSettings, readFyRows, readNextPage, selection, type SelOpts, type TeamSplit } from '@generated/server/gql.server';
import { parseLabelSet } from '@generated/lib/mp-fields';
import { Board04SddMpPlanBoard } from '@api/BoardSDK';
import { diagNumbers } from '@generated/server/num-diag.server';

const LABEL = '04 : SDD · MP Plan';
// CHANGE 2 · the 12 month columns use the slim numbers-only selection.
const OPTS: SelOpts = { numCols: MP_M };
/**
 * Session 1-17b · a group's later pages are followed INSIDE this server call while it is younger
 * than this, so they skip the browser round trip. Anything left returns as a cursor and the
 * client continues it through getMpMore exactly as before.
 */
const IN_CALL_BUDGET_MS = 20_000;
/**
 * Session 1-26 · how many of MP's team requests are in flight at once. Raised from 6 to all at once
 * after two cold loads showed no rate limiting and the waves, not the data, set the time.
 * If a "rate limited" line appears on a true cold load, put this back to 6.
 */
const TEAM_CAP = Number.POSITIVE_INFINITY;

// B4 �� MP Plan → D_MPR. editedAt travels as ISO and is localised once, in the data hook.
function toMpRow(it: RawItem): MpRow {
  const cv = cvMap(it);
  return {
    id: itemId(it),
    title: (it.name ?? '').trim(),
    team: dropdown(cv[MP_C.team]),
    type: dropdown(cv[MP_C.type]),
    t1: txt(cv[MP_C.t1]),
    role: status(cv[MP_C.role]),
    detail: txt(cv[MP_C.detail]),
    system: dropdown(cv[MP_C.system]),
    task2: dropdown(cv[MP_C.task2]),
    name: txt(cv[MP_C.name]),
    empid: txt(cv[MP_C.empid]),
    sec: txt(cv[MP_C.sec]),
    ms: status(cv[MP_C.ms]),
    // an EMPTY MP month cell is read as 0
    m: MP_M.map((cid) => num(cv[cid]) ?? 0),
    fy: dropdown(cv[MP_C.fy]),
    batch: txt(cv[MP_C.batch]),
    src: status(cv[MP_C.src]),
    editedAt: lastUpdatedIso(cv[MP_C.edited]),
  };
}

// Diagnostics (read-only): the helper's result BEFORE the "?? 0" coercion of MP months.
function diagOf(items: RawItem[]) {
  const d = diagNumbers('04 MP Plan', items, MP_M);
  return { items: d.items, cells: d.cells, emptyNow: d.emptyNow, changedByFix: d.changedByFix };
}

/**
 * Session 1-17f · step 1 of the MP read, for ONE fiscal year (by FY value, see readFyRows). Later
 * pages are followed inside this call while it is younger than IN_CALL_BUDGET_MS; any cursor left
 * is continued by the client through getMpMore (the cursor keeps the FY filter).
 */
export const getMpStart = createServerFn({ method: 'GET' })
  .validator(z.object({ fy: z.string().min(1) }))
  .handler(async ({ data }) => {
    const t0 = Date.now();
    const boardId = BOARD_ID['MP Plan'];
    // Session 1-26 · the year group is read team by team and proven complete by monday's own count of
    // the group; anything unproven falls back to paging the group (see readTeamSplit).
    const split: TeamSplit = {
      col: MP_C.team,
      cap: TEAM_CAP,
      count: async (groupId) => {
        const r = await new Board04SddMpPlanBoard().aggregate().where({ group: groupId } as never).countItems('n').execute();
        const n = r?.[0]?.n;
        if (typeof n !== 'number') throw new Error('group count came back empty');
        return n;
      },
    };
    const [start, labels] = await Promise.all([
      readFyRows(boardId, MP_COLS, LABEL, OPTS, MP_C.fy, data.fy, IN_CALL_BUDGET_MS, undefined, split),
      readColumnSettings(boardId, [MP_C.type, MP_C.role, MP_C.system, MP_C.task2]),
    ]);
    const all = start.groups.flatMap((g) => g.items);
    const stats: LoadStats = {
      requests: start.requests,
      items: all.length,
      ms: Date.now() - t0,
      mode: 'grouped',
      groups: start.groups.length,
      calls: start.calls,
    };
    console.log(
      `[SDD load] ${LABEL} · FY${data.fy} (option #${start.optionId}) · start · ${stats.groups} group(s) · ` +
        `${stats.requests} requests · ${stats.items} items · ${stats.ms} ms`,
    );
    return {
      groups: start.groups.map((g) => ({ id: g.id, rows: g.items.map(toMpRow), cursor: g.cursor })),
      diag: diagOf(all),
      stats,
      types: parseLabels(labels[MP_C.type]),
      // Role / System pickers offer ACTIVE labels only; systemsAll also keeps deactivated ones.
      roles: parseLabelSet(labels[MP_C.role]).active,
      systems: parseLabelSet(labels[MP_C.system]).active,
      systemsAll: parseLabelSet(labels[MP_C.system]).all,
      task2s: parseLabelSet(labels[MP_C.task2]).active,
      task2sAll: parseLabelSet(labels[MP_C.task2]).all,
    };
  });

/** Performance pass · one next_items_page of ONE group chain (limit 500, same selection). */
export const getMpMore = createServerFn({ method: 'POST' })
  .validator(z.object({ cursor: z.string().min(1) }))
  .handler(async ({ data }) => {
    const t0 = Date.now();
    const page = await readNextPage(data.cursor, selection(MP_COLS, OPTS));
    return {
      rows: page.items.map(toMpRow),
      cursor: page.cursor,
      diag: diagOf(page.items),
      ms: Date.now() - t0,
    };
  });
