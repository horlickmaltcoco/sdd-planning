import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { BOARD_ID } from '@generated/config';
import { OT_C, OT_COLS, OT_M } from '@generated/lib/cols';
import { cvMap, dropdown, itemId, lastUpdatedIso, num, status, txt } from '@generated/lib/parse';
import type { OtRow } from '@generated/lib/types';
import { readFyBoard } from '@generated/server/gql.server';
import { diagNumbers } from '@generated/server/num-diag.server';

// B5 · OT Plan → D_OT. Empty month cell stays null ("not entered"), which is not 0.
// Performance pass: the 12 month columns use the slim numbers-only selection (CHANGE 2).
export const getOtData = createServerFn({ method: 'GET' })
  .validator(z.object({ fy: z.string().min(1) }))
  .handler(async ({ data }) => {
    // Session 1-17f · the selected fiscal year only, by FY value.
    const { items, stats } = await readFyBoard(BOARD_ID['OT Plan'], OT_COLS, '05 : SDD · OT Plan', { numCols: OT_M }, OT_C.fy, data.fy);
    const rows: OtRow[] = items.map((it) => {
      const cv = cvMap(it);
      return {
        id: itemId(it),
        name: (it.name ?? '').trim(),
        t: dropdown(cv[OT_C.t]),
        fy: dropdown(cv[OT_C.fy]),
        pl: status(cv[OT_C.pl]),
        m: OT_M.map((cid) => num(cv[cid])),
        batch: txt(cv[OT_C.batch]),
        src: status(cv[OT_C.src]),
        editedAt: lastUpdatedIso(cv[OT_C.edited]),
      };
    });
    // Diagnostics (read-only): how many empty month cells, and how many the empty-cell fix changed.
    const diag = { loaded: items.length, num: diagNumbers('05 OT Plan', items, OT_M) };
    return { rows, diag, perf: stats };
  });
