// Session 1-05 Part B — scope re-read for the import diff.
// Fetch BY ID (never by dropdown filter): monday's items_page query_params expects the label
// INDEX for dropdown/status columns, so compare_value:["SD1"] silently returns an empty list.
// items(ids:[...]) has no filter syntax to get wrong and touches only the rows the diff needs.
import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
// Raw GraphQL lives ONLY in gql.server.ts — importing '@api/api-methods' here would pull the
// server transport into the client bundle (this module is imported by ImportModal) where it has
// no monday token, and every call fails with 401 UNAUTHENTICATED.
import { readItemsByIds } from '@generated/server/gql.server';
import { CP_COLS, MP_C, MP_COLS, MP_M, OT_C, OT_COLS, OT_M } from '@generated/lib/cols';
import { cpRowOf } from '@generated/lib/cp-map';
import {
  cvMap,
  dropdown,
  itemId,
  lastUpdatedIso,
  num,
  status,
  txt,
} from '@generated/lib/parse';

/** Every id as a STRING, de-duped, empty values dropped. */
function idSet(...lists: (string | number)[][]): string[] {
  const seen = new Set<string>();
  for (const list of lists) {
    for (const raw of list) {
      const s = String(raw ?? '').trim();
      if (s) seen.add(s);
    }
  }
  return [...seen];
}

/** The side-by-side id/type dump asked for in the debug questions. */
function logIds(tag: string, fileIds: string[], scopeRows: { id: string }[]) {
  const rows = [0, 1, 2].map((i) => ({
    n: i,
    fileId: fileIds[i] ?? '(none)',
    fileType: typeof fileIds[i],
    scopeId: scopeRows[i]?.id ?? '(none)',
    scopeType: typeof scopeRows[i]?.id,
    equal: String(fileIds[i]) === String(scopeRows[i]?.id),
  }));
  console.log(`[${tag}] first 3 ids FILE vs SCOPE:`, JSON.stringify(rows, null, 2));
}

// ─── 04 · MP Plan — scope is team × FY ────────────────────────────────────────

export const readFreshMp = createServerFn({ method: 'POST' })
  .validator(z.object({ team: z.string(), fy: z.string(), ids: z.array(z.string()) }))
  .handler(async ({ data }) => {
    const team = String(data.team);
    const fy = String(data.fy);
    const ids = idSet(data.ids);

    console.log('[readFreshMp] scope:', { board: '5031548536', team, fy, idsRequested: ids.length });

    const items = await readItemsByIds(ids, MP_COLS, 'readFreshMp');

    // Every id monday returned exists on the board — whatever team or FY it belongs to.
    const allIds = items.map((it) => String(itemId(it)));

    const mapped = items.map((it) => {
      const cv = cvMap(it);
      return {
        id: String(itemId(it)),
        title: (it.name ?? '').trim(),
        team: dropdown(cv[MP_C.team]),
        type: dropdown(cv[MP_C.type]),
        t1: txt(cv[MP_C.t1]),
        role: status(cv[MP_C.role]),
        detail: txt(cv[MP_C.detail]),
        system: dropdown(cv[MP_C.system]),
        task2: dropdown(cv[MP_C.task2]),
        name: txt(cv[MP_C.name]),
        empid: txt(cv[MP_C.empid]),
        sec: txt(cv[MP_C.sec]),
        ms: status(cv[MP_C.ms]),
        m: MP_M.map((cid) => num(cv[cid]) ?? 0),
        fy: dropdown(cv[MP_C.fy]),
        batch: txt(cv[MP_C.batch]),
        src: status(cv[MP_C.src]),
        // Raw ISO (UTC, zoned). Localised on the VIEWER's machine, never here: this handler runs
        // on a server in UTC, where a "local" stamp is UTC wall-clock with no zone marker.
        editedAt: lastUpdatedIso(cv[MP_C.edited]),
        kind: 'MP' as const,
        isLeave: false,
      };
    });

    // In scope = same team AND same FY, both compared as strings.
    const rows = mapped.filter((r) => String(r.team) === team && String(r.fy) === fy);
    const out = mapped.filter((r) => !(String(r.team) === team && String(r.fy) === fy));

    console.log('[readFreshMp] RESULT rows in scope:', rows.length, '· returned but out of scope:', out.length);
    if (out.length) {
      console.log('[readFreshMp] out-of-scope sample:', out.slice(0, 3).map((r) => ({ id: r.id, team: r.team, fy: r.fy })));
    }
    logIds('readFreshMp', ids, rows);

    return { rows, allIds };
  });

// ─── 05 · OT Plan — scope is FY ───────────────────────────────────────────────

export const readFreshOt = createServerFn({ method: 'POST' })
  .validator(z.object({ fy: z.string(), ids: z.array(z.string()) }))
  .handler(async ({ data }) => {
    const fy = String(data.fy);
    const ids = idSet(data.ids);

    console.log('[readFreshOt] scope:', { board: '5031548533', fy, idsRequested: ids.length });

    const items = await readItemsByIds(ids, OT_COLS, 'readFreshOt');
    const allIds = items.map((it) => String(itemId(it)));

    const mapped = items.map((it) => {
      const cv = cvMap(it);
      return {
        id: String(itemId(it)),
        t: dropdown(cv[OT_C.t]),
        pl: status(cv[OT_C.pl]),
        m: OT_M.map((cid) => num(cv[cid])),
        fy: dropdown(cv[OT_C.fy]),
        batch: txt(cv[OT_C.batch]),
        src: status(cv[OT_C.src]),
        editedAt: lastUpdatedIso(cv[OT_C.edited]), // raw ISO · localised on the client
      };
    });

    const rows = mapped.filter((r) => String(r.fy) === fy);
    console.log('[readFreshOt] RESULT rows in scope:', rows.length, 'of', mapped.length, 'returned');
    logIds('readFreshOt', ids, rows);

    return { rows, allIds };
  });

// ─── 07 · Company Plan — scope is FY ──────────────────────────────────────────

export const readFreshCp = createServerFn({ method: 'POST' })
  .validator(z.object({ fy: z.string(), ids: z.array(z.string()) }))
  .handler(async ({ data }) => {
    const fy = String(data.fy);
    const ids = idSet(data.ids);

    const items = await readItemsByIds(ids, CP_COLS, 'readFreshCp');
    const allIds = items.map((it) => String(itemId(it)));
    // Same mapping as the page loader; Last updated stays raw ISO (UTC) · localised on the client.
    const mapped = items.map((it) => {
      const r = cpRowOf(it);
      return { ...r };
    });

    const rows = mapped.filter((r) => String(r.fy) === fy);
    console.log('[readFreshCp] RESULT rows in scope:', rows.length, 'of', mapped.length, 'returned');
    logIds('readFreshCp', ids, rows);

    return { rows, allIds };
  });
