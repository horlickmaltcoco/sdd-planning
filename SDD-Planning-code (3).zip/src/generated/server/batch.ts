// Session 1-05 Part C2 — batch runner server functions.
//
// Raw GraphQL lives ONLY in gql.server.ts. Importing '@api/api-methods' here would pull the
// server transport into the client bundle (import-run.ts, a client module, imports this file)
// where it has no monday token and every call fails with 401 UNAUTHENTICATED.
import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import {
  mutateCreateOne,
  mutateDeleteMany,
  mutateUpdateMany,
  readBoardGroupList,
} from '@generated/server/gql.server';

/** Request-size caps (C2). Updates and deletes batch; creates never do. */
export const BATCH = { update: 25, delete: 25 } as const;

/** Groups of a board, so a group can be looked up by title at runtime. Never hardcoded. */
export const readBoardGroups = createServerFn({ method: 'POST' })
  .validator(z.object({ boardId: z.string().min(1) }))
  .handler(async ({ data }) => {
    try {
      return { groups: await readBoardGroupList(data.boardId) };
    } catch (e) {
      console.error('readBoardGroups failed', data.boardId, e);
      return { groups: [] as { id: string; title: string }[] };
    }
  });

/** Up to 25 aliased change_multiple_column_values in ONE request. Absolute values only. */
export const batchUpdate = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      boardId: z.string().min(1),
      ops: z
        .array(
          z.object({
            itemId: z.string().min(1),
            columnValues: z.record(z.string(), z.any()),
          }),
        )
        .min(1)
        .max(BATCH.update),
    }),
  )
  .handler(async ({ data }) => {
    const n = await mutateUpdateMany(data.boardId, data.ops);
    return { done: n };
  });

/** ONE create_item per request — a timeout can never produce an id the app does not know. */
export const createOneItem = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      boardId: z.string().min(1),
      itemName: z.string().min(1),
      groupId: z.string().optional(),
      columnValues: z.record(z.string(), z.any()),
    }),
  )
  .handler(async ({ data }) => {
    const id = await mutateCreateOne(
      data.boardId,
      data.itemName,
      data.columnValues,
      data.groupId,
    );
    return { id };
  });

/** Up to 25 aliased delete_item per request. "not found" counts as done. */
export const batchDelete = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      itemIds: z.array(z.string().min(1)).min(1).max(BATCH.delete),
    }),
  )
  .handler(async ({ data }) => {
    const n = await mutateDeleteMany(data.itemIds);
    return { done: n };
  });
