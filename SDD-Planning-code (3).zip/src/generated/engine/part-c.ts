/**
 * Session 1-02 Part C — Validation engine (3-tier system)
 * Tier 1: each person each month vs capacity
 * Tier 2: each team each month vs quota + OT
 * Tier 3: each Group each month, sum of teams vs sum of quota + OT
 */

import { ALLMI } from '@generated/config';
import type { MpDerived, Person, Settings, Span, Win } from '@generated/model/types';
import { pctF, statusOf, ymOfFy } from './index';
import {
  grpLabel,
  grpOfM,
  headListOf,
  headOf,
  inEmployment,
  inQuotaOf,
  teamOfMonth,
  maskRow,
  personByName,
  personKeyOfRow,
  personOfRow,
  teamsOfRow,
  mustPlanOf,
  type MaskedRow,
} from './part-b';

// =============================================================================
// C1. TIER 1 JUDGE — the ONLY tier-1 decision in the whole app
// =============================================================================

export interface Tier1Judge {
  kind: 'under' | 'over' | 'ok';
  gap: number;
  bad: boolean;
}

export function tier1Judge(v: number, cap: number, S: Settings): Tier1Judge {
  // redAt null or "" → 100 (an empty value must never become 0)
  const raw: unknown = S ? S.redAt : null;
  const ra = raw == null || raw === '' ? 100 : Number(raw);
  
  if (v < cap - 0.001) {
    return {
      kind: 'under',
      gap: cap - v,
      bad: !!S.minPerPerson && pctF(v, cap) < ra,
    };
  }
  
  if (v > cap + 0.001) {
    return {
      kind: 'over',
      gap: v - cap,
      bad: !!S.maxPerPerson,
    };
  }
  
  return { kind: 'ok', gap: 0, bad: false };
}

// =============================================================================
// C1b. TIER 1 STATE — the ONLY per-person-month state (cell card, PersonDrill,
// TeamDrill). The five checks run in THIS order; do not reorder or merge them.
// =============================================================================

export type Tier1State =
  | { k: 'out' }
  | { k: 'other'; t: string }
  | { k: 'exempt' }
  | { k: 'nodata' }
  | { k: 'under'; gap: number; blank: boolean; bad: boolean }
  | { k: 'over'; gap: number; bad: boolean }
  | { k: 'ok' };

export interface Tier1Deps {
  EMPWIN: Record<string, Win>;
  ASSIGN: Span[];
  FYCODE?: Record<number, string[]>;
  PEOPLE_BY_EMP: Record<string, Person>;
  PEOPLE_BY_NAME: Record<string, Person>;
}

export function tier1State(
  team: string,
  pp: { m: number[]; emp: string; n: string },
  fy: string | number,
  mi: number,
  cap: number,
  S: Settings,
  d: Tier1Deps,
): Tier1State {
  const v = pp.m[mi] || 0;
  const emp = pp.emp;
  // 1. outside employment
  if (emp && !inEmployment(emp, ymOfFy(fy, mi), d.EMPWIN)) return { k: 'out' };
  // 2. belongs to another team this month
  const tm = emp ? teamOfMonth(emp, fy, mi, d.ASSIGN, d.FYCODE) : null;
  if (tm && tm !== team) return { k: 'other', t: tm };
  // 3. Needs MP Plan = "No"
  if (!mustPlanOf(pp, d.PEOPLE_BY_EMP, d.PEOPLE_BY_NAME)) return { k: 'exempt' };
  // 4. nothing planned and not in this team's quota
  if (v <= 0 && !(emp && inQuotaOf(team, emp, fy, mi, d.ASSIGN, d.FYCODE))) return { k: 'nodata' };
  // 5. the one tier-1 judge
  const j = tier1Judge(v, cap, S);
  if (j.kind === 'under') return { k: 'under', gap: j.gap, blank: v <= 0, bad: j.bad };
  if (j.kind === 'over') return { k: 'over', gap: j.gap, bad: j.bad };
  return { k: 'ok' };
}

// =============================================================================
// C2. STATUS AND PILL
// =============================================================================

export function pillOf(st: string): { cls: string; txt: string } {
  if (st === 'over') return { cls: 'pill ov', txt: 'เกิน' };
  if (st === 'under') return { cls: 'pill un', txt: 'ขาด' };
  return { cls: 'pill ok', txt: 'พอดี' };
}

// =============================================================================
// C3. PERSON SUMS
// =============================================================================

export interface PersonSum {
  n: string;
  key: string;
  role: string;
  roles: string[];
  emp: string;
  own: boolean[] | null;
  m: number[];
  mo: number[];
  lv: number[];
  noplan?: boolean;
}

export function personSums(
  rows: MaskedRow[],
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): PersonSum[] {
  const map = new Map<string, PersonSum>();
  const order: string[] = [];
  
  for (const r of rows) {
    const key = personKeyOfRow(r, PEOPLE_BY_EMP, PEOPLE_BY_NAME);
    const pr = personOfRow(r, PEOPLE_BY_EMP, PEOPLE_BY_NAME);
    
    if (!map.has(key)) {
      const entry: PersonSum = {
        n: pr ? pr.mpname || pr.name : r.name,
        key,
        roles: [],
        emp: (pr ? pr.emp : '') || r.empid || '',
        own: null,
        m: Array(12).fill(0),
        mo: Array(12).fill(0),
        lv: Array(12).fill(0),
        role: '',
      };
      map.set(key, entry);
      order.push(key);
    }
    
    const e = map.get(key)!;
    
    if (!e.emp && r.empid) e.emp = r.empid;
    if (r.role && !e.roles.includes(r.role)) e.roles.push(r.role);
    if ((r as any).own) e.own = (r as any).own;
    
    for (let i = 0; i < 12; i += 1) {
      e.m[i] += r.m[i] ?? 0;
      e.mo[i] += ((r as any).mo ?? r.m)[i] ?? 0;
      if (r.isLeave) e.lv[i] += r.m[i] ?? 0;
    }
  }
  
  // Round all arrays
  for (const e of map.values()) {
    e.m = e.m.map((x) => Math.round(x * 100) / 100);
    e.mo = e.mo.map((x) => Math.round(x * 100) / 100);
    e.lv = e.lv.map((x) => Math.round(x * 100) / 100);
    e.role = e.roles.join(' · ');
  }
  
  // Sort by display name, then key
  const sorted = order
    .map((k) => map.get(k)!)
    .sort((a, b) => {
      const cmp = a.n.localeCompare(b.n);
      return cmp !== 0 ? cmp : a.key.localeCompare(b.key);
    });
  
  return sorted;
}

// =============================================================================
// C4. BUILD PLAN
// =============================================================================

export interface Tier1Row {
  team: string;
  name: string;
  emp: string;
  key: string;
  role: string;
  mi: number;
  v: number;
  cap: number;
  gap: number;
  kind: 'under' | 'over' | 'ok';
  bad: boolean;
}

export interface Tier2Row {
  team: string;
  grp: string;
  mi: number;
  head: number;
  active: number;
  capPer: number;
  quota: number;
  otPlan: number | null;
  otMiss: boolean;
  otAvg: number | null;
  headFb: boolean;
  allow: number;
  planSum: number;
  leave: number;
  work: number;
  dif: number;
}

export interface Tier3Row {
  grp: string;
  mi: number;
  allow: number;
  planSum: number;
  leave: number;
  work: number;
  teams: string[];
  over: Array<{ t: string; h: number }>;
  dif: number;
  tol: number;
  st: string;
}

export interface TeamPlan {
  team: string;
  grp: string;
  people: PersonSum[];
  rows: Tier2Row[];
}

export interface Plan {
  WD: (number | null)[];
  teams: TeamPlan[];
  L1: Tier1Row[];
  L2: Tier2Row[];
  L3: Tier3Row[];
  groups: Record<string, Record<number, Omit<Tier3Row, 'dif' | 'tol' | 'st'>>>;
  head: Record<string, number>;
  headsM: Record<string, number[]>;
}

export function buildPlan(
  S: Settings,
  mpRows: MpDerived[],
  otData: Record<string, Record<string, any>>,
  deps: {
    SECTIONS: { c: string }[];
    PEOPLE_BY_EMP: Record<string, Person>;
    PEOPLE_BY_NAME: Record<string, Person>;
    PEOPLE: Person[];
    ASSIGN: Span[];
    D_OT_MAP: Record<string, Record<string, any>>;
    EMPWIN: Record<string, { from: string; to: string; open: boolean }>;
    FYCODE?: Record<number, string[]>;
    capPerOf: (fy: string | number, mi: number) => number;
    wdOfS: (s: Settings) => (number | null)[];
  },
): Plan {
  const fy = S.fy;
  const WD = deps.wdOfS(S);
  const OT = otData?.[String(fy)] ?? deps.D_OT_MAP[String(fy)] ?? {};
  
  // Filter rows by FY
  const rows = mpRows.filter((r) => String(r.fy) === String(fy));
  
  // Build byTeam (MaskedRow extends MpDerived with optional mo/own)
  const byTeam: Record<string, MaskedRow[]> = {};
  for (const r of rows) {
    const teams = teamsOfRow(r, fy, deps.ASSIGN, deps.FYCODE);
    for (const t of teams) {
      if (!byTeam[t]) byTeam[t] = [];
      byTeam[t].push(maskRow(r, t, fy, deps.ASSIGN, deps.EMPWIN, deps.FYCODE));
    }
  }
  
  // Add teams from register if headSource is employeeMaster
  let teams = Object.keys(byTeam);
  if (S.headSource === 'employeeMaster') {
    for (const s of deps.SECTIONS) {
      if (byTeam[s.c]) continue;
      for (let i = 0; i < 12; i += 1) {
        if (headOf(s.c, fy, i, deps.ASSIGN, deps.FYCODE) > 0) {
          byTeam[s.c] = [];
          break;
        }
      }
    }
    teams = Object.keys(byTeam);
  }
  teams.sort();
  
  const out: Plan = {
    WD,
    teams: [],
    L1: [],
    L2: [],
    L3: [],
    groups: {},
    head: {},
    headsM: {},
  };
  
  // Process each team
  for (const t of teams) {
    let people = personSums(byTeam[t] ?? [], deps.PEOPLE_BY_EMP, deps.PEOPLE_BY_NAME);
    
    const headsM: number[] = [];
    for (let mi = 0; mi < 12; mi += 1) {
      if (S.headSource === 'employeeMaster') {
        headsM[mi] = headOf(t, fy, mi, deps.ASSIGN, deps.FYCODE);
      } else {
        headsM[mi] = people.filter((p) => (p.m[mi] ?? 0) > 0).length;
      }
    }
    
    const headMax = Math.max(...headsM, 0);
    
    // Add no-plan people if employeeMaster
    if (S.headSource === 'employeeMaster') {
      const empSet = new Set(people.map((p) => p.emp).filter(Boolean));
      const added = new Set<string>();
      
      for (let mi = 0; mi < 12; mi += 1) {
        const heads = headListOf(t, fy, mi, deps.ASSIGN, deps.FYCODE);
        for (const id of heads) {
          if (empSet.has(id) || added.has(id)) continue;
          added.add(id);
          const pr = deps.PEOPLE_BY_EMP[id] || deps.PEOPLE.find((x) => x.emp === id);
          people.push({
            n: pr ? pr.mpname || pr.name : id,
            key: id,
            role: '',
            roles: [],
            emp: id,
            own: null,
            noplan: true,
            m: Array(12).fill(0),
            mo: Array(12).fill(0),
            lv: Array(12).fill(0),
          });
        }
      }
      
      people.sort((a, b) => {
        const cmp = a.n.localeCompare(b.n);
        return cmp !== 0 ? cmp : a.key.localeCompare(b.key);
      });
    }
    
    const teamRows: Tier2Row[] = [];
    
    // Build tier 2 rows for each month
    for (let mi = 0; mi < 12; mi += 1) {
      const active = people.filter((p) => (p.m[mi] ?? 0) > 0).length;
      let head =
        S.headSource === 'employeeMaster'
          ? headsM[mi]
          : S.headSource === 'maxYear'
            ? headMax
            : active;
      const headReg = head;
      if (!head) head = headMax || active;
      const headFb = S.headSource === 'employeeMaster' && !headReg && head > 0;
      
      const capPer = deps.capPerOf(fy, mi);
      const quota = capPer * head;
      
      const otRec = OT[t] ?? { plan: [] };
      const noOt = !!((S.noOtTeams ?? {})[String(fy)] ?? {})[t];
      const otPlan = noOt ? 0 : otRec.plan?.[mi] ?? null;
      const otMiss = !noOt && (otRec.plan?.[mi] ?? null) === null;
      const allow = quota + (otPlan ?? 0);
      
      const planSum = people.reduce<number>((sum, p) => sum + (p.m[mi] ?? 0), 0);
      const leave = people.reduce<number>((sum, p) => sum + (p.lv[mi] ?? 0), 0);
      const work = planSum - leave;
      const dif = planSum - allow;
      const otAvg = otPlan != null && head > 0 ? otPlan / head : null;
      
      const row: Tier2Row = {
        team: t,
        grp: grpOfM(t, fy, mi, deps.ASSIGN, {} as any, deps.FYCODE),
        mi,
        head,
        active,
        capPer,
        quota,
        otPlan,
        otMiss,
        otAvg,
        headFb,
        allow,
        planSum,
        leave,
        work,
        dif,
      };
      
      teamRows.push(row);
      
      // Tier 1 for this month
      for (const p of people) {
        const v = p.m[mi] ?? 0;
        if (v <= 0 && !inQuotaOf(t, p.emp, fy, mi, deps.ASSIGN, deps.FYCODE)) continue;
        if (!mustPlanOf(p, deps.PEOPLE_BY_EMP, deps.PEOPLE_BY_NAME)) continue;
        
        const j = tier1Judge(v, capPer, S);
        if (j.kind !== 'ok') {
          out.L1.push({
            team: t,
            name: p.n,
            emp: p.emp,
            key: p.key,
            role: p.role,
            mi,
            v,
            cap: capPer,
            gap: j.gap,
            kind: j.kind,
            bad: j.bad,
          });
        }
      }
    }
    
    out.head[t] = headMax;
    out.headsM[t] = headsM;
    out.teams.push({ team: t, grp: grpLabel(t, fy, deps.ASSIGN, {} as any, deps.FYCODE), people, rows: teamRows });
    out.L2.push(...teamRows);
  }
  
  // Tier 3 - group by grp and mi
  const byG: Record<string, Record<number, Omit<Tier3Row, 'dif' | 'tol' | 'st'>>> = {};
  
  for (const r of out.L2) {
    if (!byG[r.grp]) byG[r.grp] = {};
    if (!byG[r.grp][r.mi]) {
      byG[r.grp][r.mi] = {
        grp: r.grp,
        mi: r.mi,
        allow: 0,
        planSum: 0,
        leave: 0,
        work: 0,
        teams: [],
        over: [],
      };
    }
    
    const g = byG[r.grp][r.mi];
    g.allow += r.allow;
    g.planSum += r.planSum;
    g.leave += r.leave;
    g.work += r.work;
    g.teams.push(r.team);
    
    if (statusOf(r.dif, S.teamTolerance ?? 0) === 'over') {
      g.over.push({ t: r.team, h: r.dif });
    }
  }
  
  out.groups = byG;
  
  // Build L3
  for (const grp of Object.keys(byG)) {
    for (const mi of Object.keys(byG[grp]).map(Number)) {
      const g = byG[grp][mi];
      const dif = g.planSum - g.allow;
      const tol = (S.teamTolerance ?? 0) * g.teams.length;
      const st = statusOf(dif, tol);
      
      out.L3.push({
        ...g,
        dif,
        tol,
        st,
      });
    }
  }
  
  return out;
}
