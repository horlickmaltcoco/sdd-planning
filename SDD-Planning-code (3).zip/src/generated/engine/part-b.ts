/**
 * Session 1-02 Part B — Person lookup, employment, headcount, group, team ownership
 * 
 * Global rules:
 * - Identity is EMP ID (names are display only)
 * - Team and Group per month come ONLY from ASSIGN (subitems)
 * - Only exact "Yes" in Count in Quota counts toward quota
 */

import { ALLMI, MONTHS } from '@generated/config';
import { CACHE } from '@generated/model';
import type { MpDerived, Person, Span, VenDerived, Win } from '@generated/model/types';
import { nameKey } from '@generated/model/helpers';
import { fyCodeOf, refMiOf, todayISO, ymOfFy } from './index';

// =============================================================================
// B1. PERSON LOOKUP AND IDENTITY
// =============================================================================

export function personByName(
  n: string,
  PEOPLE_BY_NAME: Record<string, Person>,
): Person | null {
  return PEOPLE_BY_NAME[nameKey(n)] || null;
}

export function personOfRow(
  r: { empid: string; name: string },
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): Person | null {
  if (r.empid && PEOPLE_BY_EMP[r.empid]) return PEOPLE_BY_EMP[r.empid] as Person;
  return personByName(r.name, PEOPLE_BY_NAME);
}

export function personKeyOfRow(
  r: { empid: string; name: string },
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): string {
  const pr = personOfRow(r, PEOPLE_BY_EMP, PEOPLE_BY_NAME);
  return r.empid || (pr && pr.emp) || 'n:' + nameKey(r.name);
}

export function personKey(p: { emp?: string; n?: string; name?: string }): string {
  return p.emp || 'n:' + nameKey(p.n || p.name || '');
}

export function empName(id: string, PEOPLE_NOW: Person[]): string {
  const p = PEOPLE_NOW.find((x) => x.emp === id);
  return p ? p.name : id;
}

export interface UnknownPlanName {
  name: string;
  team: string;
  rows: number;
  hrs: number;
}

export function unknownPlanNames(
  rows: MpDerived[] | null | undefined,
  fy: string | number,
  MPROWS: MpDerived[],
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): UnknownPlanName[] {
  const list = rows ?? MPROWS;
  const fyStr = String(fy);
  const seen = new Map<string, UnknownPlanName>();
  for (const r of list) {
    if (String(r.fy) !== fyStr) continue;
    if (personOfRow(r, PEOPLE_BY_EMP, PEOPLE_BY_NAME)) continue;
    const nk = nameKey(r.name);
    if (!nk) continue;
    if (!seen.has(nk)) {
      seen.set(nk, { name: r.name, team: r.team, rows: 0, hrs: 0 });
    }
    const e = seen.get(nk)!;
    e.rows += 1;
    e.hrs += r.m.reduce<number>((a, v) => a + (v ?? 0), 0);
  }
  return Array.from(seen.values());
}

export function mustPlanOf(
  p: { emp?: string; n?: string; name?: string },
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): boolean {
  const pr =
    (p.emp && PEOPLE_BY_EMP[p.emp]) || personByName(p.n || p.name || '', PEOPLE_BY_NAME);
  return pr ? pr.plan !== 'No' : true;
}

export function mustPlan(
  name: string,
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE_BY_NAME: Record<string, Person>,
): boolean {
  return mustPlanOf({ n: name }, PEOPLE_BY_EMP, PEOPLE_BY_NAME);
}

// =============================================================================
// B2. EMPLOYMENT WINDOW
// =============================================================================

export function inEmployment(emp: string, ym: string, EMPWIN: Record<string, Win>): boolean {
  const w = EMPWIN[emp];
  if (!w) return true; // not in register
  if (w.from && w.from > ym) return false;
  if (w.to && w.to < ym) return false;
  return true;
}

export function hasLeft(p: Person): boolean {
  return !!p.end && String(p.end) < todayISO();
}

export function willLeave(p: Person): boolean {
  return !!p.end && String(p.end) >= todayISO();
}

export interface StatusDateMismatch {
  name: string;
  emp: string;
  sec: string;
  status: string;
  end: string;
  why: string;
}

export function statusDateMismatch(PEOPLE_NOW: Person[]): StatusDateMismatch[] {
  const result: StatusDateMismatch[] = [];
  for (const p of PEOPLE_NOW) {
    const st = p.status || 'Active';
    if (hasLeft(p) && st === 'Active') {
      result.push({
        name: p.name,
        emp: p.emp,
        sec: p.sec,
        status: st,
        end: p.end,
        why: 'มีวันสิ้นสุดที่ผ่านมาแล้ว แต่สถานะยังเป็น Active',
      });
    } else if (!p.end && st === 'Resigned') {
      result.push({
        name: p.name,
        emp: p.emp,
        sec: p.sec,
        status: st,
        end: '',
        why: 'สถานะเป็น Resigned แต่ไม่มีวันสิ้นสุด · ระบบจึงยังนับเป็นหัวโควตาต่อไป',
      });
    }
  }
  return result;
}

// =============================================================================
// B3. HEADCOUNT (quota membership)
// =============================================================================

export function headListOf(
  team: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string[] {
  const ym = fyCodeOf(fy, mi, FYCODE);
  const taken = new Set<string>();
  const list: string[] = [];
  for (const a of ASSIGN) {
    if (a.team !== team) continue;
    if (a.quota !== 'Yes') continue;
    if (a.from && a.from > ym) continue;
    if (a.to && a.to < ym) continue;
    if (taken.has(a.emp)) continue;
    taken.add(a.emp);
    list.push(a.emp);
  }
  return list;
}

export function headOf(
  team: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): number {
  return headListOf(team, fy, mi, ASSIGN, FYCODE).length;
}

export function headNames(
  team: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  PEOPLE_NOW: Person[],
  FYCODE?: Record<number, string[]>,
): string[] {
  return headListOf(team, fy, mi, ASSIGN, FYCODE).map((id) => empName(id, PEOPLE_NOW));
}

export function headMaxOf(
  team: string,
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): number {
  let max = 0;
  for (let i = 0; i < 12; i += 1) {
    const h = headOf(team, fy, i, ASSIGN, FYCODE);
    if (h > max) max = h;
  }
  return max;
}

export function inQuotaOf(
  team: string,
  emp: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): boolean {
  return !!emp && headListOf(team, fy, mi, ASSIGN, FYCODE).includes(emp);
}

export function headRangeTxt(
  teams: string[],
  fy: string | number,
  MI: number[] | null | undefined,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string {
  const mis = MI ?? ALLMI;
  const a: number[] = [];
  for (const i of mis) {
    const sum = teams.reduce<number>((acc, t) => acc + headOf(t, fy, i, ASSIGN, FYCODE), 0);
    a.push(sum);
  }
  if (a.length === 0) return '0';
  const lo = Math.min(...a);
  const hi = Math.max(...a);
  return lo === hi ? String(hi) : `${lo}–${hi}`;
}

export function headNowOf(
  teams: string[],
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): number {
  const mi = refMiOf(fy, FYCODE);
  return teams.reduce<number>((acc, t) => acc + headOf(t, fy, mi, ASSIGN, FYCODE), 0);
}

export function headMonthsTip(
  teams: string[],
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string {
  const a: number[] = [];
  for (let i = 0; i < 12; i += 1) {
    a[i] = teams.reduce<number>((acc, t) => acc + headOf(t, fy, i, ASSIGN, FYCODE), 0);
  }
  const runs: { s: number; e: number; v: number }[] = [];
  let s = 0;
  while (s < 12) {
    const v = a[s]!;
    let e = s;
    while (e + 1 < 12 && a[e + 1] === v) e += 1;
    runs.push({ s, e, v });
    s = e + 1;
  }
  return runs
    .map((r) =>
      r.s === r.e ? `${MONTHS[r.s]} ${r.v}` : `${MONTHS[r.s]}–${MONTHS[r.e]} ${r.v}`,
    )
    .join(' · ');
}

export interface NoPlanPerson {
  emp: string;
  name: string;
}

export function noPlanPeople(
  team: string,
  fy: string | number,
  mis: number[] | null | undefined,
  plannedEmps: Set<string>,
  ASSIGN: Span[],
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE: Person[],
  FYCODE?: Record<number, string[]>,
): NoPlanPerson[] {
  const miList = mis ?? ALLMI;
  const seen = new Set<string>();
  const result: NoPlanPerson[] = [];
  for (const mi of miList) {
    const heads = headListOf(team, fy, mi, ASSIGN, FYCODE);
    for (const id of heads) {
      if (plannedEmps.has(id)) continue;
      if (seen.has(id)) continue;
      seen.add(id);
      const p = PEOPLE_BY_EMP[id] || PEOPLE.find((x) => x.emp === id);
      result.push({ emp: id, name: p?.mpname || p?.name || id });
    }
  }
  return result.sort((a, b) => a.name.localeCompare(b.name));
}

export function noPlanNames(
  team: string,
  fy: string | number,
  mis: number[] | null | undefined,
  plannedEmps: Set<string>,
  ASSIGN: Span[],
  PEOPLE_BY_EMP: Record<string, Person>,
  PEOPLE: Person[],
  FYCODE?: Record<number, string[]>,
): string[] {
  return noPlanPeople(team, fy, mis, plannedEmps, ASSIGN, PEOPLE_BY_EMP, PEOPLE, FYCODE).map(
    (x) => x.name,
  );
}

export function teamInRegister(t: string, ASSIGN: Span[]): boolean {
  return ASSIGN.some((a) => a.team === t);
}

// =============================================================================
// B4. GROUP PER MONTH
// =============================================================================

export function grpOfM(
  team: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  grpOf: Record<string, string>,
  FYCODE?: Record<number, string[]>,
): string {
  const key = `${team}|${fy}|${mi}`;
  if (CACHE[key]) return CACHE[key] as string;
  
  const ym = fyCodeOf(fy, mi, FYCODE);
  for (const a of ASSIGN) {
    if (a.team !== team) continue;
    if (!a.grp) continue;
    if (a.from && a.from > ym) continue;
    if (a.to && a.to < ym) continue;
    CACHE[key] = a.grp;
    return a.grp;
  }
  const fallback = grpOf[team] || '—';
  CACHE[key] = fallback;
  return fallback;
}

export function grpsOfFy(
  team: string,
  fy: string | number,
  ASSIGN: Span[],
  grpOf: Record<string, string>,
  FYCODE?: Record<number, string[]>,
): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (let i = 0; i < 12; i += 1) {
    const g = grpOfM(team, fy, i, ASSIGN, grpOf, FYCODE);
    if (!seen.has(g)) {
      seen.add(g);
      result.push(g);
    }
  }
  return result;
}

export function inGrpFy(
  team: string,
  fg: string | null | undefined,
  fy: string | number,
  ASSIGN: Span[],
  grpOf: Record<string, string>,
  FYCODE?: Record<number, string[]>,
): boolean {
  if (!fg || fg === 'ALL') return true;
  return grpsOfFy(team, fy, ASSIGN, grpOf, FYCODE).includes(fg);
}

export function grpLabel(
  team: string,
  fy: string | number,
  ASSIGN: Span[],
  grpOf: Record<string, string>,
  FYCODE?: Record<number, string[]>,
): string {
  return grpsOfFy(team, fy, ASSIGN, grpOf, FYCODE).join(' → ');
}

export function grpOf(t: string, grpOfMap: Record<string, string>): string {
  return grpOfMap[t] || '—';
}

export function knownGroupsFy(fy: string | number, ASSIGN: Span[], GROUPS: string[], FYCODE?: Record<number, string[]>): string[] {
  const a = fyCodeOf(fy, 0, FYCODE);
  const b = fyCodeOf(fy, 11, FYCODE);
  const set = new Set<string>();
  for (const x of ASSIGN) {
    if (!x.grp) continue;
    if (x.from && x.from > b) continue;
    if (x.to && x.to < a) continue;
    set.add(x.grp);
  }
  return set.size > 0 ? Array.from(set) : GROUPS;
}

export interface VendorGroupBad {
  grp: string;
  co: string;
  n: number;
  mh: number;
}

export function vendorGroupBad(
  rows: VenDerived[],
  fy: string | number,
  ASSIGN: Span[],
  GROUPS: string[],
  FYCODE?: Record<number, string[]>,
): VendorGroupBad[] {
  const known = new Set(knownGroupsFy(fy, ASSIGN, GROUPS, FYCODE));
  const map = new Map<string, VendorGroupBad>();
  for (const r of rows) {
    if (String(r.fy) !== String(fy)) continue;
    if (known.has(r.grp)) continue;
    const key = `${r.grp || ''}|${r.co || ''}`;
    if (!map.has(key)) {
      map.set(key, { grp: r.grp, co: r.co, n: 0, mh: 0 });
    }
    const e = map.get(key)!;
    e.n += 1;
    e.mh += r.mh ?? 0;
  }
  return Array.from(map.values()).sort((a, b) => {
    const ka = `${a.grp}|${a.co}`;
    const kb = `${b.grp}|${b.co}`;
    return ka.localeCompare(kb);
  });
}

export interface TeamGroupClash {
  team: string;
  mi: number;
  grps: string[];
}

export function teamGroupClash(
  fy: string | number,
  SECTIONS: { c: string; g: string }[],
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): TeamGroupClash[] {
  const result: TeamGroupClash[] = [];
  for (const s of SECTIONS) {
    for (let mi = 0; mi < 12; mi += 1) {
      const ym = fyCodeOf(fy, mi, FYCODE);
      const grps = new Set<string>();
      for (const a of ASSIGN) {
        if (a.team !== s.c) continue;
        if (!a.grp) continue;
        if (a.from && a.from > ym) continue;
        if (a.to && a.to < ym) continue;
        grps.add(a.grp);
      }
      if (grps.size > 1) {
        result.push({ team: s.c, mi, grps: Array.from(grps) });
      }
    }
  }
  return result;
}

export interface TeamNotInRegister {
  t: string;
  mp: number;
  ot: number;
}

export function teamsNotInRegister(
  fy: string | number,
  MPROWS: MpDerived[],
  D_OT: Array<{ fy: string; t: string }>,
  SECTIONS: { c: string }[],
): TeamNotInRegister[] {
  const sectionSet = new Set(SECTIONS.map((s) => s.c));
  const map = new Map<string, TeamNotInRegister>();
  
  for (const r of MPROWS) {
    if (String(r.fy) !== String(fy)) continue;
    if (sectionSet.has(r.team)) continue;
    if (!map.has(r.team)) {
      map.set(r.team, { t: r.team, mp: 0, ot: 0 });
    }
    map.get(r.team)!.mp += 1;
  }
  
  for (const r of D_OT) {
    if (String(r.fy) !== String(fy)) continue;
    if (sectionSet.has(r.t)) continue;
    if (!map.has(r.t)) {
      map.set(r.t, { t: r.t, mp: 0, ot: 0 });
    }
    map.get(r.t)!.ot += 1;
  }
  
  return Array.from(map.values()).sort((a, b) => a.t.localeCompare(b.t));
}

export interface AssignClash {
  emp: string;
  name: string;
  mi: number;
  teams: string[];
}

export function assignClash(
  fy: string | number,
  ASSIGN: Span[],
  PEOPLE_NOW: Person[],
  FYCODE?: Record<number, string[]>,
): AssignClash[] {
  const result: AssignClash[] = [];
  for (let mi = 0; mi < 12; mi += 1) {
    const ym = fyCodeOf(fy, mi, FYCODE);
    const empTeams = new Map<string, Set<string>>();
    
    for (const a of ASSIGN) {
      if (a.quota !== 'Yes') continue;
      if (a.from && a.from > ym) continue;
      if (a.to && a.to < ym) continue;
      
      if (!empTeams.has(a.emp)) {
        empTeams.set(a.emp, new Set());
      }
      empTeams.get(a.emp)!.add(a.team);
    }
    
    for (const [emp, teams] of empTeams) {
      if (teams.size > 1) {
        result.push({
          emp,
          name: empName(emp, PEOPLE_NOW),
          mi,
          teams: Array.from(teams),
        });
      }
    }
  }
  return result;
}

// =============================================================================
// B5. TEAM OWNERSHIP OF MONTHS
// =============================================================================

export function teamOfMonth(
  emp: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string | null {
  if (!emp) return null;
  const ym = fyCodeOf(fy, mi, FYCODE);
  for (const a of ASSIGN) {
    if (a.emp !== emp) continue;
    if (a.from && a.from > ym) continue;
    if (a.to && a.to < ym) continue;
    return a.team;
  }
  return null;
}

export function spanAt(emp: string, ym: string, ASSIGN: Span[]): Span | null {
  for (const a of ASSIGN) {
    if (a.emp !== emp) continue;
    if (a.from && a.from > ym) continue;
    if (a.to && a.to < ym) continue;
    return a;
  }
  return null;
}

export function ownsMonth(
  team: string,
  emp: string,
  fy: string | number,
  mi: number,
  ASSIGN: Span[],
  EMPWIN: Record<string, Win>,
  FYCODE?: Record<number, string[]>,
): boolean {
  if (!emp) return true;
  const ym = fyCodeOf(fy, mi, FYCODE);
  if (!inEmployment(emp, ym, EMPWIN)) return false;
  const t = teamOfMonth(emp, fy, mi, ASSIGN, FYCODE);
  return t == null ? true : t === team;
}

export function ownMask(
  team: string,
  emp: string,
  fy: string | number,
  ASSIGN: Span[],
  EMPWIN: Record<string, Win>,
  FYCODE?: Record<number, string[]>,
): boolean[] {
  const result: boolean[] = [];
  for (let i = 0; i < 12; i += 1) {
    result.push(ownsMonth(team, emp, fy, i, ASSIGN, EMPWIN, FYCODE));
  }
  return result;
}

export function spansOfEmp(emp: string, ASSIGN: Span[]): Span[] {
  return ASSIGN.filter((a) => a.emp === emp).sort((a, b) =>
    String(a.from || '').localeCompare(String(b.from || '')),
  );
}

export function ymDash(v: string): string {
  if (v.length === 6 && /^\d{6}$/.test(v)) {
    return `${v.slice(0, 4)}-${v.slice(4, 6)}`;
  }
  return v || '—';
}

export function assignSpans(
  emp: string,
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): Array<{ team: string; a: number; b: number }> {
  const runs: Array<{ team: string; a: number; b: number }> = [];
  let current: { team: string; a: number; b: number } | null = null;
  
  for (let i = 0; i < 12; i += 1) {
    const t = teamOfMonth(emp, fy, i, ASSIGN, FYCODE);
    if (t == null) break;
    
    if (!current || current.team !== t) {
      if (current) runs.push(current);
      current = { team: t, a: i, b: i };
    } else {
      current.b = i;
    }
  }
  
  if (current) runs.push(current);
  return runs;
}

export function spanTxt(
  emp: string,
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string {
  const runs = assignSpans(emp, fy, ASSIGN, FYCODE);
  if (runs.length < 2) return '';
  return runs
    .map((x) =>
      x.a === x.b
        ? `${x.team} ${MONTHS[x.a]}`
        : `${x.team} ${MONTHS[x.a]}–${MONTHS[x.b]}`,
    )
    .join(' · ');
}

export function movedInFy(
  emp: string,
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): boolean {
  return assignSpans(emp, fy, ASSIGN, FYCODE).length > 1;
}

export function teamsOfRow(
  r: MpDerived,
  fy: string | number,
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): string[] {
  if (!r.empid) return [r.team];
  
  const set = new Set<string>();
  for (let i = 0; i < 12; i += 1) {
    if ((r.m[i] ?? 0) <= 0) continue;
    const t = teamOfMonth(r.empid, fy, i, ASSIGN, FYCODE) || r.team;
    set.add(t);
  }
  
  return set.size > 0 ? Array.from(set) : [r.team];
}

export interface MaskedRow extends MpDerived {
  mo?: (number | null)[];
  own?: boolean[];
}

export function maskRow(
  r: MpDerived,
  team: string,
  fy: string | number,
  ASSIGN: Span[],
  EMPWIN: Record<string, Win>,
  FYCODE?: Record<number, string[]>,
): MaskedRow {
  if (!r.empid) return r;
  
  const msk = ownMask(team, r.empid, fy, ASSIGN, EMPWIN, FYCODE);
  let needsMask = false;
  for (let i = 0; i < 12; i += 1) {
    if (!msk[i] && (r.m[i] ?? 0) > 0) {
      needsMask = true;
      break;
    }
  }
  
  if (!needsMask) return r;
  
  const m = r.m.map((v, i) => (msk[i] ? v : 0));
  return { ...r, m, mo: r.m, own: msk };
}

export function rowsOfTeam(
  rows: MpDerived[],
  team: string,
  fy: string | number,
  ASSIGN: Span[],
  EMPWIN: Record<string, Win>,
  FYCODE?: Record<number, string[]>,
): MaskedRow[] {
  const fyStr = String(fy);
  return rows
    .filter((r) => {
      if (String(r.fy) !== fyStr) return false;
      return teamsOfRow(r, fy, ASSIGN, FYCODE).includes(team);
    })
    .map((r) => maskRow(r, team, fy, ASSIGN, EMPWIN, FYCODE));
}

// =============================================================================
// B6. REGISTER MISMATCH CHECKS
// =============================================================================

export interface AssignMismatchRow {
  emp: string;
  name: string;
  mi: number;
  fileTeam: string;
  regTeam: string;
  hrs: number;
  id: string;
}

export function assignMismatch(
  rows: MpDerived[] | null | undefined,
  fy: string | number,
  MPROWS: MpDerived[],
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): AssignMismatchRow[] {
  const list = rows ?? MPROWS;
  const fyStr = String(fy);
  const result: AssignMismatchRow[] = [];
  
  for (const r of list) {
    if (String(r.fy) !== fyStr) continue;
    if (!r.empid) continue;
    
    const spans = assignSpans(r.empid, fy, ASSIGN, FYCODE);
    if (spans.length > 1) continue; // move recorded correctly
    
    for (let i = 0; i < 12; i += 1) {
      if ((r.m[i] ?? 0) <= 0) continue;
      const t = teamOfMonth(r.empid, fy, i, ASSIGN, FYCODE);
      if (t && t !== r.team) {
        result.push({
          emp: r.empid,
          name: r.name,
          mi: i,
          fileTeam: r.team,
          regTeam: t,
          hrs: r.m[i] ?? 0,
          id: r.id,
        });
      }
    }
  }
  
  return result;
}

export interface AssignMismatchPeople {
  emp: string;
  name: string;
  fileTeam: string;
  regTeam: string;
  mis: number[];
  hrs: number;
  rows: number;
}

export function assignMismatchPeople(
  rows: MpDerived[] | null | undefined,
  fy: string | number,
  MPROWS: MpDerived[],
  ASSIGN: Span[],
  FYCODE?: Record<number, string[]>,
): AssignMismatchPeople[] {
  const mismatches = assignMismatch(rows, fy, MPROWS, ASSIGN, FYCODE);
  const map = new Map<string, AssignMismatchPeople>();
  
  for (const m of mismatches) {
    const key = `${m.emp}|${m.fileTeam}|${m.regTeam}`;
    if (!map.has(key)) {
      map.set(key, {
        emp: m.emp,
        name: m.name,
        fileTeam: m.fileTeam,
        regTeam: m.regTeam,
        mis: [],
        hrs: 0,
        rows: 0,
      });
    }
    const e = map.get(key)!;
    if (!e.mis.includes(m.mi)) e.mis.push(m.mi);
    e.hrs += m.hrs;
    e.rows += 1;
  }
  
  for (const e of map.values()) {
    e.mis.sort((a, b) => a - b);
  }
  
  return Array.from(map.values());
}

export interface SectionDrift {
  emp: string;
  name: string;
  sec: string;
  teams: string[];
  txt: string;
}

export function sectionDrift(
  fy: string | number,
  PEOPLE_NOW: Person[],
  ASSIGN: Span[],
  ASSIGN_FROM_BOARD: boolean,
  FYCODE?: Record<number, string[]>,
): SectionDrift[] {
  if (!ASSIGN_FROM_BOARD) return [];
  
  const result: SectionDrift[] = [];
  
  for (const p of PEOPLE_NOW) {
    if (!p.emp || !p.sec) continue;
    
    const sp = spansOfEmp(p.emp, ASSIGN);
    if (sp.length === 0) continue;
    
    const teams = Array.from(new Set(sp.map((s) => s.team)));
    if (teams.includes(p.sec)) continue;
    
    // Build txt
    const txt = spanTxt(p.emp, fy, ASSIGN, FYCODE);
    let finalTxt = txt;
    
    if (!txt) {
      // Find first and last month with a team
      let a = -1;
      let b = -1;
      let t0 = '';
      for (let i = 0; i < 12; i += 1) {
        const t = teamOfMonth(p.emp, fy, i, ASSIGN, FYCODE);
        if (t) {
          if (a < 0) a = i;
          b = i;
          t0 = t;
        }
      }
      finalTxt = a >= 0 ? `${t0} ${MONTHS[a]}–${MONTHS[b]}` : teams.join(' · ');
    }
    
    result.push({
      emp: p.emp,
      name: p.name,
      sec: p.sec,
      teams,
      txt: finalTxt,
    });
  }
  
  return result;
}
