/**
 * Session 1-09 Part B/C — Overview-page-only aggregation helpers.
 * Pure functions; no board access. Read-only page — never write from here.
 */
import type { MpDerived, Span, Win } from '@generated/model/types';
import type { Plan, Tier2Row } from './part-c';
import { ymOfFy, z12 } from './index';
import { grpOfM, inEmployment, teamOfMonth } from './part-b';

export interface ScopedMpRow extends MpDerived {
  mteam: (string | null)[];
}

/**
 * Raw plan rows restricted to the FY + Group + team scope, month by month.
 * Months outside employment belong to no team; the team of each month comes from the
 * assignment subitems (teamOfMonth), not from the row's own Team cell.
 */
export function mpScope(
  rows: MpDerived[],
  fy: string | number,
  fg: string,
  ft: string,
  ASSIGN: Span[],
  EMPWIN: Record<string, Win>,
  grpOfMap: Record<string, string>,
  FYCODE?: Record<number, string[]>,
): ScopedMpRow[] {
  const out: ScopedMpRow[] = [];
  for (const r of rows) {
    if (String(r.fy) !== String(fy)) continue;
    const mteam: (string | null)[] = Array.from({ length: 12 }, () => null);
    const m: number[] = Array.from({ length: 12 }, () => 0);
    let any = false;
    for (let i = 0; i < 12; i += 1) {
      let t: string | null = r.team;
      if (r.empid) {
        const ym = ymOfFy(fy, i);
        t = inEmployment(r.empid, ym, EMPWIN)
          ? teamOfMonth(r.empid, fy, i, ASSIGN, FYCODE) || r.team
          : null;
      }
      const ok =
        t != null &&
        (ft && ft !== 'ALL'
          ? t === ft
          : !fg || fg === 'ALL' || grpOfM(t, fy, i, ASSIGN, grpOfMap, FYCODE) === fg);
      mteam[i] = t;
      m[i] = ok ? r.m[i] || 0 : 0;
      if (ok) any = true;
    }
    if (!any) continue;
    out.push({ ...r, m, mteam });
  }
  return out;
}

export interface TypeAggRow {
  ty: string;
  m: number[];
}

/** Group scoped rows by Type, sum the 12-month array. Sorted by type name. */
export function typeAgg(rows: Array<{ type: string; m: number[] }>): TypeAggRow[] {
  const map = new Map<string, number[]>();
  for (const r of rows) {
    if (!map.has(r.type)) map.set(r.type, z12());
    const arr = map.get(r.type) as number[];
    for (let i = 0; i < 12; i += 1) arr[i] += r.m[i] ?? 0;
  }
  return Array.from(map.entries())
    .map(([ty, m]) => ({ ty, m }))
    .sort((a, b) => a.ty.localeCompare(b.ty));
}

/** {team: 12-month array of Σ L2.allow} */
export function capBySec(P: Plan): Record<string, number[]> {
  const out: Record<string, number[]> = {};
  for (const r of P.L2) {
    if (!out[r.team]) out[r.team] = z12();
    (out[r.team] as number[])[r.mi] += r.allow;
  }
  return out;
}

/** {grp: 12-month array of Σ L3.allow} */
export function capByGrp(P: Plan): Record<string, number[]> {
  const out: Record<string, number[]> = {};
  for (const r of P.L3) {
    if (!out[r.grp]) out[r.grp] = z12();
    (out[r.grp] as number[])[r.mi] += r.allow;
  }
  return out;
}

/** Month sums of quota/allow/planSum over a (already scoped) set of Tier2Row. */
export function monthSums(rows: Tier2Row[]): { q: number[]; a: number[]; s: number[] } {
  const q = z12();
  const a = z12();
  const s = z12();
  for (const r of rows) {
    q[r.mi] += r.quota;
    a[r.mi] += r.allow;
    s[r.mi] += r.planSum;
  }
  return { q, a, s };
}
