/**
 * Session 1-02 Engine — the single source for all business rules.
 * Pages must never re-implement these; they call these functions.
 * All raw values are HOURS. Units are converted only at display time.
 */

import { ALLMI, BAND_DEFAULT, MONTHS } from '@generated/config';
import { TT } from '@generated/i18n';
import { ymCode } from '@generated/lib/parse';
import type { MonthArr } from '@generated/lib/types';
import { CACHE } from '@generated/model';
import { HPD } from '@generated/model/rules';
import type { MpDerived, OtMap, Person, Settings, Span, VenDerived, Win } from '@generated/model/types';

// Re-export model helpers that are part of the engine API
export { ymCode, lastWorkYm, nameKey, monthYearOf, yesNo, n0 } from '@generated/model/helpers';
export { HPD } from '@generated/model/rules';

// Import for internal use (already re-exported above)
import { n0, nameKey } from '@generated/model/helpers';

// Internal ymOfFy that pages should not use directly
import { ymOfFy as _ymOfFy } from '@generated/model/helpers';

/** Public ymOfFy that pages can use */
export function ymOfFy(fy: string | number, mi: number): string {
  return _ymOfFy(fy, mi);
}

// =============================================================================
// A1. MONTH / FY HELPERS
// =============================================================================

/** FY 2026 mi=0 → "202604" (Apr 2026), mi=11 → "202703" (Mar 2027) */
export function fyCodeOf(fy: string | number, mi: number, FYCODE?: Record<number, string[]>): string {
  if (FYCODE) {
    const codes = FYCODE[Number(fy)];
    if (codes?.[mi]) return codes[mi] as string;
  }
  // fallback formula
  const y = Number.parseInt(String(fy), 10);
  const m = ((mi + 3) % 12) + 1;
  const year = m >= 4 ? y : y + 1;
  return `${year}${String(m).padStart(2, '0')}`;
}

/** Calendar year of fy month mi. (2026, 9) → 2027 (Jan). */
export function fyYearOf(fy: string | number, mi: number): number {
  const m = ((mi + 3) % 12) + 1;
  return m >= 4 ? Number.parseInt(String(fy), 10) : Number.parseInt(String(fy), 10) + 1;
}

/** "Jan 2027" for (2026, 9) */
export function fyMonthLabel(fy: string | number, mi: number): string {
  return `${MONTHS[mi]} ${fyYearOf(fy, mi)}`;
}

/** "Apr 2026 – Mar 2027" with spaces around en dash */
export function fySpanTxt(fy: string | number): string {
  return `${MONTHS[0]} ${fyYearOf(fy, 0)} – ${MONTHS[11]} ${fyYearOf(fy, 11)}`;
}

/** Current month as "YYYYMM" in local time */
export function ymToday(): string {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** True when fy month mi is before the current month (current month is NOT past) */
export function isPastMonth(fy: string | number, mi: number, FYCODE?: Record<number, string[]>): boolean {
  return fyCodeOf(fy, mi, FYCODE) < ymToday();
}

/** Count of months in MI that are past */
export function pastCount(fy: string | number, MI?: number[], FYCODE?: Record<number, string[]>): number {
  const mis = MI ?? ALLMI;
  return mis.filter((i) => isPastMonth(fy, i, FYCODE)).length;
}

/** Parse month filter: "ALL" → [0..11], else [parseInt(fM)] */
export function miOf(fM: string): number[] {
  if (fM === 'ALL') return ALLMI;
  const mi = Number.parseInt(fM, 10);
  return Number.isNaN(mi) ? ALLMI : [mi];
}

/** Array of 12 zeros (fiscal order Apr..Mar) */
export function z12(): number[] {
  return Array(12).fill(0);
}

/** Reference month index for FY: the current month if in range, else 0 or 11 */
export function refMiOf(fy: string | number, FYCODE?: Record<number, string[]>): number {
  const now = ymToday();
  const first = fyCodeOf(fy, 0, FYCODE);
  const last = fyCodeOf(fy, 11, FYCODE);
  if (now < first) return 0;
  if (now > last) return 11;
  for (let i = 0; i < 12; i += 1) {
    if (fyCodeOf(fy, i, FYCODE) === now) return i;
  }
  return 0;
}

/** Today in UTC as "YYYY-MM-DD" */
export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

/** Today in local time as "YYYY-MM-DD" */
export function TODAY(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** Now in local time as "YYYY-MM-DD HH:MM:SS" */
export function NOW(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  const s = String(d.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${day} ${h}:${min}:${s}`;
}

// =============================================================================
// A2. CAPACITY, HOURS PER DAY, RULES
// =============================================================================
// Most of these exist in model/rules.ts and are called through the RuleApi.
// The engine re-exports them for convenience.

/** Check bands: null = ok, string = error message */
export function bandsCheck(a: ReadonlyArray<number | null> | null | undefined): string | null {
  if (!a || a.length !== 5) return 'ต้องระบุครบ 5 ค่า';
  for (const v of a) {
    if (v == null || !Number.isFinite(v)) return 'ทุกค่าต้องเป็นตัวเลข';
  }
  for (let i = 1; i < 5; i += 1) {
    if (!((a[i] as number) > (a[i - 1] as number))) return 'ต้องเรียงจากน้อยไปมากและห้ามซ้ำกัน';
  }
  if ((a[0] as number) < 1) return 'ค่าแรกต้องมากกว่า 0';
  return null;
}

/** Detect hours-per-day drift between board and calculated */
export function hpdDrift(
  fy: string | number,
  D_WD: Record<string, MonthArr>,
  capPerOf: (fy: string | number, mi: number) => number,
  hpd: number,
): { onBoard: number; calc: number; mi: number } | null {
  const w = D_WD[String(fy)];
  if (!w) return null;
  if (hpd <= 0) return null;
  for (const i of ALLMI) {
    const wd = w[i];
    const cap = capPerOf(fy, i);
    if (wd != null && wd > 0 && cap > 0) {
      const calc = Math.round((cap / wd) * 1000) / 1000;
      if (Math.abs(calc - hpd) < 0.005) return null;
      return { onBoard: hpd, calc, mi: i };
    }
  }
  return null;
}

/** OT map for a single FY (never borrows another FY) */
export function otOfFy(all: OtMap | null | undefined, fy: string | number): Record<string, any> {
  return (all ?? {})[String(fy)] ?? {};
}

/** OT rows with bad labels (not "Yes" or "No") */
export function otLabelBad(
  D_OT: Array<{ fy: string; t: string; pl: string }>,
  fy: string | number,
): Array<{ t: string; pl: string }> {
  return D_OT.filter((r) => String(r.fy) === String(fy) && r.pl !== 'Yes' && r.pl !== 'No').map((r) => ({
    t: r.t,
    pl: r.pl || '',
  }));
}

/** Status based on difference vs tolerance: over/under/ok */
export function statusOf(dif: number, tol: number): 'over' | 'under' | 'ok' {
  if (dif > tol) return 'over';
  if (dif < -tol) return 'under';
  return 'ok';
}

// =============================================================================
// A3. NUMBER FORMATTING
// =============================================================================

/** Round to 1 decimal, with thousands separators: 12 → "12", 1234567.25 → "1,234,567.3" (decimal shown only when present) */
export function n1(v: number): string {
  const x = Math.round(v * 10) / 10;
  const neg = x < 0;
  const a = Math.abs(x);
  const isWhole = a === Math.floor(a);
  const s = isWhole
    ? a.toLocaleString('en-US')
    : a.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  return (neg ? '-' : '') + s;
}

/** Round to 2 decimals, no separators: "12.00" */
export function n2(v: number): string {
  return (Math.round(v * 100) / 100).toFixed(2);
}

/** Round to integer with thousands separators: 1234567 → "1,234,567" */
// already exported from model/helpers

/** Round to 2 decimals, return number */
export function nn(v: number): number {
  return Math.round(v * 100) / 100;
}

/** Sum an array, treating null as 0 */
export function sum(a: (number | null)[]): number {
  return a.reduce<number>((x, y) => x + (y ?? 0), 0);
}

/** Round to 2 decimals, half-up away from zero (guards float error) */
export function round2(v: number): number {
  const s = v < 0 ? -1 : 1;
  return (s * Math.round(Math.abs(v) * 100 + 1e-7)) / 100;
}

/** Percentage as a number, rounded: pctF(52366, 60336) → 86.79 */
export function pctF(a: number, b: number): number {
  return b ? round2((a / b) * 100) : 0;
}

/** Percentage as a string: "86.79" */
export function pct(a: number, b: number): string {
  return pctF(a, b).toFixed(2);
}

/** Percentage text with <0.01 / >-0.01 for tiny values */
export function pctTxt(a: number, b: number): string {
  if (!b) return '0';
  const v = (a / b) * 100;
  if (v > 0 && v < 0.005) return '<0.01';
  if (v < 0 && v > -0.005) return '>-0.01';
  return pct(a, b);
}

/** Signed number with "+" prefix for positive: "+12.5" */
export function sign(v: number): string {
  return (v > 0 ? '+' : '') + n1(v);
}

/** Convert hours to unit: "MD" → h/HPD, "%" → h/cap*100, else h */
export function toU(h: number, cap: number, u: string): number {
  if (u === 'MD') return h / HPD;
  if (u === '%') return cap > 0 ? (h / cap) * 100 : 0;
  return h;
}

/** Convert from unit to hours */
export function fromU(x: number, cap: number, u: string): number {
  if (u === 'MD') return x * HPD;
  if (u === '%') return cap > 0 ? (x / 100) * cap : 0;
  return x;
}

/** True when unit is editable (% mode is read-only) */
export function editableU(u: string): boolean {
  return u !== '%';
}

/** Format hours with unit: hours use n1, MD uses n1, % shows 2 decimals */
export function fmt(
  h: number,
  cap: number,
  u: string,
  opt?: { sign?: boolean },
): string {
  if (u === '%') {
    if (!cap) return '–';
    const v = pctF(h, cap);
    return ((opt?.sign && v > 0 ? '+' : '') + v.toFixed(2)) + '%';
  }
  const x = u === 'MD' ? h / HPD : h;
  const t = n1(x);
  return (opt?.sign && x > 0 ? '+' : '') + t;
}

/** Unit label with divisor description */
export function uLabel(u: string, den?: string): string {
  if (u === 'MD') return `MD (${HPD}${TT(' ชม. = 1 MD)')}`;
  if (u !== '%') return TT('ชั่วโมง');
  return TT('% ของ ') + (den ?? TT('โควตา+OT'));
}

/** Unit suffix appended after a formatted number ("ชม." / "MD" / "" for %) */
export function uSuf(u: string): string {
  if (u === 'MD') return 'MD';
  if (u === '%') return '';
  return TT('ชม.');
}

/** Band class: "b0" to "b6" based on % and bands */
export function band(h: number, cap: number, bands?: number[]): string {
  if (h <= 0) return 'b0';
  const p = pctF(h, cap);
  const b = bands ?? BAND_DEFAULT;
  if (p < b[0]!) return 'b1';
  if (p < b[1]!) return 'b2';
  if (p < b[2]!) return 'b3';
  if (p <= b[3]!) return 'b4';
  if (p <= b[4]!) return 'b5';
  return 'b6';
}

/** Band labels for legend: [["b1","<50"], ["b2","50–74"], ...] */
export function bandLabels(bands?: number[]): Array<[string, string]> {
  const b = bands ?? BAND_DEFAULT;
  return [
    ['b1', `<${b[0]}`],
    ['b2', `${b[0]}–${b[1]! - 1}`],
    ['b3', `${b[1]}–${b[2]! - 1}`],
    ['b4', `${b[2]}–${b[3]}`],
    ['b5', `${b[3]! + 1}–${b[4]}`],
    ['b6', `>${b[4]}`],
  ];
}

/** Band colors: background / text */
export const BAND_COLORS: Record<string, { bg: string; text: string }> = {
  b0: { bg: '#F9FAFB', text: '#D0D5DD' },
  b1: { bg: '#F2F4F7', text: '#98A2B3' },
  b2: { bg: '#E0F2FE', text: '#0369A1' },
  b3: { bg: '#B9E6FE', text: '#026AA2' },
  b4: { bg: '#D1FADF', text: '#027A48' },
  b5: { bg: '#FEF0C7', text: '#B54708' },
  b6: { bg: '#FECDCA', text: '#B42318' },
};

/** Type color palette */
export const TYPE_PALETTE = [
  '#2E75B6',
  '#1F3864',
  '#ED7D31',
  '#7030A0',
  '#C00000',
  '#9DC3E6',
  '#B4A7D6',
  '#70AD47',
  '#FFC000',
  '#1B7A6E',
  '#FF6B6B',
  '#548235',
  '#4DD0E1',
  '#F4B183',
  '#8497B0',
];

/** Color for a type string (stable hash) */
export function typeColor(ty: string, TYPES: string[]): string {
  let i = TYPES.indexOf(ty);
  if (i < 0) {
    let h = 0;
    for (let j = 0; j < ty.length; j += 1) h = ((h * 31 + ty.charCodeAt(j)) >>> 0);
    i = h;
  }
  return TYPE_PALETTE[i % TYPE_PALETTE.length] as string;
}

// =============================================================================
// A4. SHARED FILTER OPTION BUILDERS
// =============================================================================

export interface FilterOpt {
  v: string;
  t: string;
}

/** FY options: "ปีงบ 2026 (Apr 2026 – Mar 2027)" */
export function optFY(fyList: string[]): FilterOpt[] {
  return fyList.map((y) => ({ v: y, t: `${TT('ปีงบ')} ${y} (${fySpanTxt(y)})` }));
}

/** Month options: "ทุกเดือน" + Apr..Mar */
export function optMonths(): FilterOpt[] {
  return [{ v: 'ALL', t: TT('ทุกเดือน') }, ...MONTHS.map((m, i) => ({ v: String(i), t: m }))];
}

/** Group options: "ทุก Group" + actual groups */
export function optGroups(GROUPS: string[]): FilterOpt[] {
  return [{ v: 'ALL', t: TT('ทุก Group') }, ...GROUPS.map((g) => ({ v: g, t: g }))];
}

/** Search helper: every word of q must be in the joined parts */
export function hit(q: string, parts: (string | null | undefined)[]): boolean {
  if (!q.trim()) return true;
  const hay = parts
    .filter((p) => p)
    .join(' ')
    .toLowerCase();
  const words = q
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w);
  return words.every((w) => hay.includes(w));
}

/** Unique types from rows, sorted */
export function typeOptsOf(rows: MpDerived[]): string[] {
  const set = new Set<string>();
  for (const r of rows) {
    if (r.type) set.add(r.type);
  }
  return Array.from(set).sort();
}

/** Unique Task1 values for a given type, sorted */
export function t1OptsOf(rows: MpDerived[], ty: string): string[] {
  const set = new Set<string>();
  for (const r of rows) {
    if (r.type === ty && r.t1) set.add(r.t1);
  }
  return Array.from(set).sort();
}

// =============================================================================
// PART B — Person lookup, employment, headcount, group, team ownership
// =============================================================================

export * from './part-b';

// =============================================================================
// PART C — Validation engine (3-tier system)
// =============================================================================

export * from './part-c';

// =============================================================================
// PART D — Overview page aggregation helpers (Session 1-09 Part B/C)
// =============================================================================

export * from './part-d';
