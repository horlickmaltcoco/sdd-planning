# Engine Module

Session 1-02 Engine — the single source for all business rules.

## Important Rules

1. **Pages must never re-implement these functions** — they call the engine
2. **All raw values are HOURS** — units convert only at display time
3. **Month index mi 0..11** = Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Jan, Feb, Mar
4. **FY keys are strings** ("2026", not 2026)
5. **ym format is "YYYYMM"** — string comparison is chronological

## Module Organization

### A1. Month / FY Helpers
- `ymOfFy`, `fyCodeOf`, `fyYearOf`, `fyMonthLabel`, `fySpanTxt`
- `ymCode`, `lastWorkYm`, `ymToday`, `isPastMonth`, `pastCount`, `refMiOf`
- `todayISO`, `TODAY`, `NOW`
- `monthYearOf`

### A2. Capacity, Hours per Day, Rules
- `bandsCheck`, `hpdDrift`, `otOfFy`, `otLabelBad`
- Most capacity/rule functions are in `model/rules.ts` and accessed via `RuleApi`

### A3. Number Formatting
- `n1`, `n2`, `n0`, `nn` — number formatting with separators
- `sum`, `round2`, `pctF`, `pct`, `pctTxt` — calculations
- `sign` — signed display
- `toU`, `fromU`, `editableU` — unit conversions
- `fmt`, `uLabel` — formatted display with units
- `band`, `bandLabels`, `BAND_COLORS` — color bands
- `TYPE_PALETTE`, `typeColor` — type colors

### A4. Filter Option Builders
- `optFY`, `optMonths`, `optGroups` — dropdown options
- `hit` — search matching
- `typeOptsOf`, `t1OptsOf` — unique values

### B1. Person Lookup and Identity
- `personByName`, `personOfRow`, `personKeyOfRow`, `personKey`
- `empName` — EMP ID → display name
- `unknownPlanNames` — misspelled names in plan rows
- `mustPlanOf`, `mustPlan` — check if person needs MP plan

### B2. Employment Window
- `inEmployment` — check if person employed in a month
- `hasLeft`, `willLeave` — resignation date checks
- `statusDateMismatch` — find Status vs. End Date disagreements

### B3. Headcount (Quota Membership)
- `headListOf`, `headOf`, `headNames` — quota members per team/month
- `headMaxOf`, `inQuotaOf` — quota queries
- `headRangeTxt`, `headNowOf`, `headMonthsTip` — display helpers
- `noPlanPeople`, `noPlanNames` — find quota members without plans
- `teamInRegister` — check if team exists in ASSIGN

### B4. Group Per Month
- `grpOfM`, `grpsOfFy`, `inGrpFy`, `grpLabel`, `grpOf` — group lookups
- `knownGroupsFy` — groups active in a fiscal year
- `vendorGroupBad`, `teamGroupClash` — validation checks
- `teamsNotInRegister`, `assignClash` — mismatch detection

### B5. Team Ownership of Months
- `teamOfMonth`, `spanAt`, `ownsMonth`, `ownMask` — ownership checks
- `spansOfEmp`, `ymDash`, `assignSpans`, `spanTxt`, `movedInFy` — span display
- `teamsOfRow`, `maskRow`, `rowsOfTeam` — row filtering and masking

### B6. Register Mismatch Checks
- `assignMismatch`, `assignMismatchPeople` — file team vs. register team
- `sectionDrift` — parent Section vs. subitem teams

## Examples

```typescript
import * as E from '@generated/engine';

// Format hours — a whole number of 1,000 or more drops the decimal
E.fmt(2294.5, 0, 'Hrs'); // "2,294.5"
E.fmt(117552, 0, 'Hrs'); // "117,552"
E.fmt(560, 0, 'Hrs');    // "560.0"

// Calculate percentage
E.pctF(52366, 60336); // 86.79
E.pct(52366, 60336);  // "86.79"

// Get band class
E.band(86.79, 100); // "b3" with default bands

// Format with unit
E.fmt(80, 0, 'MD');    // "10.0" (80 hours / 8 HPD)
E.fmt(50, 200, '%');   // "25.00%"

// Month helpers
E.fyMonthLabel(2026, 9);  // "Jan 2027"
E.fySpanTxt(2026);        // "Apr 2026 – Mar 2027"
E.isPastMonth(2026, 5);   // true if before Sep 2026
```

## Migration from Session 1-01

Functions that existed in `model/helpers.ts` or `model/rules.ts` are now re-exported
from the engine for convenience. Pages should import from `@generated/engine` instead
of reaching into the model internals.
