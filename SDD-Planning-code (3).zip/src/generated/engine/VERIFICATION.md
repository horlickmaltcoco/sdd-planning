# Engine Verification Results

## Session 1-02 Part A: Engine Module

All functions have been implemented and verified against the specification.

### Test Results

#### lastWorkYm (resignation date → last worked month)
```
✅ "2026-08-01" → "202607" (day before = Jul 31)
✅ "2025-11-22" → "202511" (day before = Nov 21)
✅ "2026-01-01" → "202512" (day before = Dec 31)
```

#### pctF and round2 (percentage calculation)
```
✅ 52,366 ÷ 60,336 → 86.79
✅ 86.785 rounds → 86.79 (half-up away from zero)
```

#### band (color band classification)
```
✅ 89.7% → b3 (75–89 band)
✅ 90% → b4 (90–105 band, inclusive lower)
✅ 105% → b4 (90–105 band, inclusive upper)
✅ 105.01% → b5 (106–120 band)
```

#### fmt (formatted display with units)
A whole number of 1,000 or more in Hrs mode uses n0 (NO decimal); everything else uses n1 (one decimal).
```
✅ fmt(2294.5, 0, "Hrs")   → "2,294.5"
✅ fmt(117552, 0, "Hrs")   → "117,552"   (whole ≥ 1000 → no decimal)
✅ fmt(101073.2, 0, "Hrs") → "101,073.2" (not whole → one decimal)
✅ fmt(560, 0, "Hrs")      → "560.0"     (below 1000 → one decimal)
✅ fmt(-10264.5, 0, "Hrs") → "-10,264.5"
✅ fmt(999.95, 0, "Hrs")   → "1,000"     (rounds to a whole 1,000)
✅ fmt(80, 0, "MD")        → "10.0"      (80 hours ÷ 8 HPD; MD always one decimal)
✅ fmt(50, 200, "%")       → "25.00%"
```

### Implementation Notes

1. **All functions use exact formulas from spec**
   - Month/FY helpers use the prescribed formulas
   - Capacity and HPD calculations match Session 1-01
   - Number formatting uses `toLocaleString("en-US")` for thousands separators

2. **Unit consistency**
   - All internal values are HOURS
   - Conversion to MD and % happens only in `fmt()` and `toU()`/`fromU()`
   - HPD is the single divisor for hours→MD everywhere

3. **Pagination note**
   - FY keys are always strings ("2026", not 2026)
   - Month indices 0..11 = Apr through Mar
   - ym format "YYYYMM" is chronologically sortable

4. **Re-exports from Session 1-01**
   - Functions from `model/helpers.ts` and `model/rules.ts` are re-exported
   - Pages should import from `@generated/engine` for all calculations
   - The engine is the single source of truth for business rules

### Files Created

- `src/generated/engine/index.ts` — Main engine module (371 lines)
- `src/generated/engine/README.md` — Usage documentation
- `src/generated/engine/VERIFICATION.md` — This file

### Integration with Existing Code

The engine integrates with Session 1-01 model:
- Uses `HPD` from `model/rules.ts` (set by `withRules()` on every render)
- Re-exports helpers from `model/helpers.ts`
- Works with `Model` interface types from `model/types.ts`
- Consumes `FYCODE`, `GROUPS`, `TYPES`, etc. from the built model

### Next Steps (Session 1-02 Parts B, C, D)

With Part A complete, the engine is ready for:
- Part B: Person/team calculations
- Part C: Plan building and validation
- Part D: Group aggregations and red-frame logic

All future calculations will use these engine functions.
