import type { MonthArr, WdMap } from '@generated/lib/types';

export interface Person {
  name: string;
  emp: string;
  email: string;
  grp: string;
  sec: string;
  pos: string;
  begin: string;
  end: string;
  status: string;
  quota: string;
  incharge: string;
  mpname: string;
  plan: string;
  lvl: string;
}

export interface Win {
  from: string;
  to: string;
  open: boolean;
}

export interface Span {
  emp: string;
  team: string;
  from: string;
  to: string;
  quota: string;
  why: string;
  grp: string;
}

export interface MpDerived {
  id: string;
  title: string;
  team: string;
  type: string;
  t1: string;
  role: string;
  detail: string;
  system: string;
  task2: string;
  name: string;
  m: number[];
  empid: string;
  sec: string;
  ms: string;
  fy: string;
  kind: 'PJ' | 'MP';
  isLeave: boolean;
  src: string;
  editedAt: string;
  batch: string;
}

export interface OtCell {
  plan: (number | null)[];
  pl: string;
  id: string;
  src: string;
  editedAt: string;
}

export type OtMap = Record<string, Record<string, OtCell>>;

export interface VenDerived {
  id: string;
  grp: string;
  co: string;
  my: string;
  mo: string;
  fy: string;
  mh: number | null;
  src: string;
  editedAt: string;
}

export interface RuleView {
  tol: number;
  minPer: boolean;
  maxPer: boolean;
  bands: number[];
  redAt: number;
}

export interface Settings {
  fy: number;
  hoursPerDay: number;
  bandsEdit: Record<string, { bands: number[]; redAt: number | null }> | null;
  minPerPerson: boolean;
  maxPerPerson: boolean;
  teamOverWarn: boolean;
  teamUnderWarn: boolean;
  teamTolerance: number;
  headSource: string;
  wdFix: WdMap | null;
  noOtTeams: Record<string, Record<string, boolean>>;
  showWorkOnlyUtil: boolean;
  otMdDivisor: number; // NOT used: OT is never converted to MD
  hoursPerOtDay: number; // unused
  blockImport: boolean;
  bands?: number[];
  redAt?: number;
  bandsDirty?: boolean;
  bandsBoard?: number[];
  redAtBoard?: number;
}

export interface RuleApi {
  capPerOf: (fy: string | number, mi: number) => number;
  capSumOf: (fy: string | number, mis: number[]) => number;
  hpdOf: (fy: string | number) => number;
  bandsOf: (fy: string | number) => number[];
  ruleOf: (fy: string | number) => RuleView | null;
  wdOf: (fy: string | number) => MonthArr;
  wdOfS: (s: Settings) => MonthArr;
  fyList: () => string[];
  defaultFy: () => number;
  withRules: (s: Settings) => Settings;
}
