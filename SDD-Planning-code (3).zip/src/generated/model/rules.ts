// C1/C3/C4 · per-FY rules, FY list, default FY and the settings object.
import { ALLMI, BAND_DEFAULT, HPD_FALLBACK } from '@generated/config';
import { loadBandsEdit } from '@generated/lib/bands';
import type { MonthArr, RuleMap, WdMap } from '@generated/lib/types';
import { yesNo } from '@generated/model/helpers';
import type { OtMap, RuleApi, RuleView, Settings } from '@generated/model/types';

// The ONLY hours → MD divisor in the app. Reassigned by withRules on every render.
export let HPD: number = HPD_FALLBACK;
export function setHPD(v: number): void {
  HPD = Number.isFinite(v) && v > 0 ? v : HPD_FALLBACK;
}

function zeros(): MonthArr {
  return ALLMI.map(() => 0);
}

export function makeRules(wd: WdMap, cap: WdMap, rule: RuleMap): RuleApi {
  const capPerOf = (fy: string | number, mi: number): number => {
    const c = cap[String(fy)];
    const cv = c ? c[mi] : null;
    if (cv != null && cv > 0) return cv;
    const w = (wd[String(fy)] ?? [])[mi];
    return (w != null ? w : 0) * HPD_FALLBACK;
  };

  const capSumOf = (fy: string | number, mis: number[]): number =>
    mis.reduce<number>((a, i) => a + capPerOf(fy, i), 0);

  const hpdOf = (fy: string | number): number => {
    const r = rule[String(fy)];
    if (r && r.hpd != null && r.hpd > 0) return r.hpd;
    const w = wd[String(fy)] ?? [];
    for (const i of ALLMI) {
      const d = w[i];
      const c = capPerOf(fy, i);
      if (d != null && d > 0 && c > 0) return Math.round((c / d) * 1000) / 1000;
    }
    return HPD_FALLBACK;
  };

  const bandsOf = (fy: string | number): number[] => {
    const raw = rule[String(fy)]?.bands ?? '';
    if (!raw.trim()) return [...BAND_DEFAULT];
    const list = raw
      .trim()
      .split(/[,\s]+/)
      .map((x) => Number.parseFloat(x))
      .filter((x) => Number.isFinite(x));
    if (list.length !== 5) return [...BAND_DEFAULT];
    for (let i = 1; i < list.length; i += 1) {
      if (!((list[i] as number) > (list[i - 1] as number))) return [...BAND_DEFAULT];
    }
    return list;
  };

  const ruleOf = (fy: string | number): RuleView | null => {
    const r = rule[String(fy)];
    if (!r) return null;
    return {
      tol: r.tol == null ? 0 : Number(r.tol),
      minPer: yesNo(r.minPer, true),
      maxPer: yesNo(r.maxPer, false),
      bands: bandsOf(fy),
      redAt: r.redAt == null ? 100 : Number(r.redAt),
    };
  };

  // C1 · a FY that board 03 does not have = 12 zeros. Never borrow another FY's days.
  const wdOf = (fy: string | number): MonthArr => wd[String(fy)] ?? zeros();

  const wdOfS = (s: Settings): MonthArr => s.wdFix?.[String(s.fy)] ?? wdOf(s.fy);

  const fyToday = (): number => {
    const d = new Date();
    return d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
  };

  // C1 · FY options come from board 03; an empty board 03 leaves the single FY of today.
  const fyList = (): string[] => {
    const keys = Object.keys(wd).sort((a, b) => b.localeCompare(a));
    return keys.length ? keys : [String(fyToday())];
  };

  const defaultFy = (): number => {
    const cur = fyToday();
    const have = Object.keys(wd)
      .map((k) => Number.parseInt(k, 10))
      .filter((n) => Number.isFinite(n))
      .sort((a, b) => a - b);
    if (!have.length) return cur;
    if (have.includes(cur)) return cur;
    const le = have.filter((n) => n <= cur);
    return le.length ? (le[le.length - 1] as number) : (have[0] as number);
  };

  const withRules = (s: Settings): Settings => {
    setHPD(hpdOf(s.fy)); // side effect on every render
    const r = ruleOf(s.fy);
    if (!r) return s;
    const out: Settings = {
      ...s,
      teamTolerance: r.tol,
      minPerPerson: r.minPer,
      maxPerPerson: r.maxPer,
      hoursPerDay: hpdOf(s.fy),
      bands: r.bands,
      redAt: r.redAt,
    };
    const e = (s.bandsEdit ?? {})[String(s.fy)];
    if (e?.bands) out.bands = e.bands;
    if (e && e.redAt != null) out.redAt = e.redAt;
    out.bandsDirty = !!e;
    out.bandsBoard = r.bands;
    out.redAtBoard = r.redAt;
    return out;
  };

  return { capPerOf, capSumOf, hpdOf, bandsOf, ruleOf, wdOf, wdOfS, fyList, defaultFy, withRules };
}

// C4 · DEFAULT_SETTINGS. Built after the data is loaded (reads localStorage → call from an effect).
export function defaultSettings(fy: number, hoursPerDay: number, ot: OtMap): Settings {
  const noOtTeams: Record<string, Record<string, boolean>> = {};
  for (const fyKey of Object.keys(ot)) {
    const teams = ot[fyKey] ?? {};
    const box: Record<string, boolean> = {};
    for (const t of Object.keys(teams)) box[t] = String(teams[t]?.pl || '') === 'No';
    noOtTeams[fyKey] = box;
  }
  return {
    fy,
    hoursPerDay,
    bandsEdit: loadBandsEdit(),
    minPerPerson: true,
    maxPerPerson: false,
    teamOverWarn: true,
    teamUnderWarn: true,
    teamTolerance: 0,
    headSource: 'employeeMaster',
    wdFix: null,
    noOtTeams,
    showWorkOnlyUtil: true,
    otMdDivisor: HPD_FALLBACK,
    hoursPerOtDay: 9,
    blockImport: false,
  };
}
