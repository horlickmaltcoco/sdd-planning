// C1 · helpers needed by the derived structures. Pure, no board access.
import { MONTHS } from '@generated/config';
import { ymCode } from '@generated/lib/parse';

export { ymCode };

// End Date is the first day NOT worked, so the last worked month is the month of the day before.
export function lastWorkYm(end: string): string {
  if (!end) return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(end);
  if (!m) return ymCode(end);
  const t = Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) - 86400000;
  const d = new Date(t);
  return `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
}

export function ymOfFy(fy: string | number, mi: number): string {
  const y = Number.parseInt(String(fy), 10);
  const m = ((mi + 3) % 12) + 1;
  const year = m >= 4 ? y : y + 1;
  return `${year}${String(m).padStart(2, '0')}`;
}

export function nameKey(s: string | null | undefined): string {
  return String(s || '')
    .trim()
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

export function monthYearOf(mo: string, fy: string): string {
  const i = (MONTHS as readonly string[]).indexOf(mo);
  if (i < 0 || !fy) return '';
  const y = Number.parseInt(fy, 10);
  return mo + String(i <= 8 ? y : y + 1);
}

export function yesNo(v: string | null | undefined, dflt: boolean): boolean {
  if (v === 'Yes') return true;
  if (v === 'No') return false;
  return dflt;
}

export function n0(v: number): string {
  return Math.round(v).toLocaleString('en-US');
}
