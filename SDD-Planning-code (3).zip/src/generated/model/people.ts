// C2 · people, employment windows and team spans.
import { A, E, type AssignRow, type EmpRow } from '@generated/lib/types';
import { lastWorkYm, nameKey, ymCode } from '@generated/model/helpers';
import type { Person, Span, Win } from '@generated/model/types';

export function buildPeople(emp: EmpRow[]): Person[] {
  return emp.map((r) => ({
    name: r[E.name] ?? '',
    emp: r[E.emp] ?? '',
    email: r[E.email] ?? '',
    grp: r[E.grp] ?? '',
    sec: r[E.sec] ?? '',
    pos: r[E.pos] ?? '',
    begin: r[E.begin] ?? '',
    end: r[E.end] ?? '',
    status: r[E.status] ?? '',
    quota: r[E.quota] ?? '',
    incharge: r[E.incharge] ?? '',
    mpname: r[E.mpname] ?? '',
    plan: r[E.plan] ?? '',
    lvl: r[E.lvl] ?? '',
  }));
}

// One entry per EMP ID: an open row beats a closed one, otherwise the later start wins.
// The kept entry stays at the position of the first occurrence.
export function buildPeopleNow(people: Person[]): Person[] {
  const at = new Map<string, number>();
  const out: Person[] = [];
  for (const c of people) {
    const i = at.get(c.emp);
    if (i === undefined) {
      at.set(c.emp, out.length);
      out.push(c);
      continue;
    }
    const p = out[i] as Person;
    const beats =
      (!c.end && !!p.end) ||
      (!c.end === !p.end && String(c.begin || '') > String(p.begin || ''));
    if (beats) out[i] = c;
  }
  return out;
}

export function buildGrpOf(peopleNow: Person[]): Record<string, string> {
  const grpOf: Record<string, string> = {};
  for (const p of peopleNow) {
    if (p.sec && p.grp && !grpOf[p.sec]) grpOf[p.sec] = p.grp;
  }
  return grpOf;
}

// Employment window per EMP ID, merged over ALL rows of that person.
export function buildEmpWin(people: Person[]): Record<string, Win> {
  const win: Record<string, Win> = {};
  for (const p of people) {
    const f = ymCode(p.begin);
    const t = lastWorkYm(p.end);
    const cur = win[p.emp];
    if (!cur) {
      win[p.emp] = { from: f, to: t, open: !t };
      continue;
    }
    if (f && (!cur.from || f < cur.from)) cur.from = f;
    if (!t) cur.open = true;
    else if (!cur.open && (!cur.to || t > cur.to)) cur.to = t;
  }
  for (const k of Object.keys(win)) {
    const w = win[k] as Win;
    if (w.open) w.to = '';
  }
  return win;
}

export function clipSpan(a: Span, win: Record<string, Win>): Span | null {
  const w = win[a.emp];
  if (!w) return a;
  const from = w.from && (!a.from || w.from > a.from) ? w.from : a.from;
  const to = w.to && (!a.to || w.to < a.to) ? w.to : a.to;
  if (from && to && from > to) return null;
  return { emp: a.emp, team: a.team, from, to, quota: a.quota, why: a.why, grp: a.grp };
}

export function buildAssign(
  dAssign: AssignRow[],
  people: Person[],
  win: Record<string, Win>,
): Span[] {
  const base: Span[] = dAssign.length
    ? dAssign.map((r) => ({
        emp: r[A.emp] ?? '',
        team: r[A.team] ?? '',
        from: r[A.from] ?? '',
        to: r[A.to] ?? '',
        quota: r[A.quota] ?? '',
        why: r[A.why] || '',
        grp: r[A.grp] || '',
      }))
    : people.map((p) => ({
        emp: p.emp,
        team: p.sec,
        from: ymCode(p.begin),
        to: lastWorkYm(p.end),
        quota: p.quota,
        why: 'ตั้งต้นจากทะเบียนพนักงาน',
        grp: p.grp || '',
      }));
  const out: Span[] = [];
  for (const s of base) {
    const c = clipSpan(s, win);
    if (c) out.push(c);
  }
  return out;
}

export function byEmp(peopleNow: Person[]): Record<string, Person> {
  const map: Record<string, Person> = {};
  for (const p of peopleNow) {
    if (p.emp) map[p.emp] = p;
  }
  return map;
}

// The FIRST person to claim a key keeps it. Names are labels only — never an identity.
export function byName(peopleNow: Person[]): Record<string, Person> {
  const map: Record<string, Person> = {};
  for (const p of peopleNow) {
    for (const k of [nameKey(p.mpname), nameKey(p.name)]) {
      if (k && !map[k]) map[k] = p;
    }
  }
  return map;
}
