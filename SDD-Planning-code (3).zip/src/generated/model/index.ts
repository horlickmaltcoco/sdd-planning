// C2 · every derived structure, rebuilt after each (re)load. Pages never re-implement these.
import { ALLMI, HPD_FALLBACK } from '@generated/config';
import type { SddCore } from '@generated/hooks/use-sdd-data';
import type { CpRow } from '@generated/lib/types';
import { monthYearOf, ymOfFy } from '@generated/model/helpers';
import {
  buildAssign,
  buildEmpWin,
  buildGrpOf,
  buildPeople,
  buildPeopleNow,
  byEmp,
  byName,
} from '@generated/model/people';
import { makeRules, setHPD } from '@generated/model/rules';
import type {
  MpDerived,
  OtMap,
  Person,
  RuleApi,
  Span,
  VenDerived,
  Win,
} from '@generated/model/types';

// Engine caches (Session 1-02 adds "_grpM"); cleared on every rebuild.
export const CACHE: Record<string, unknown> = {};

export interface Model extends RuleApi {
  FYCODE: Record<number, string[]>;
  SECTIONS: { c: string; g: string }[];
  GROUPS: string[];
  TYPES: string[];
  ROLES: string[];
  /** MP Plan System labels: active (pickers) and all (display / mapping). */
  SYSTEMS: string[];
  SYSTEMS_ALL: string[];
  /** MP Plan Task2 labels: active (pickers) and all. */
  TASK2S: string[];
  TASK2S_ALL: string[];
  COMPANIES: string[];
  grpOf: Record<string, string>;
  PEOPLE: Person[];
  PEOPLE_NOW: Person[];
  EMPWIN: Record<string, Win>;
  ASSIGN: Span[];
  ASSIGN_FROM_BOARD: boolean;
  HOLIDAYS: string[];
  MPROWS: MpDerived[];
  PEOPLE_BY_EMP: Record<string, Person>;
  PEOPLE_BY_NAME: Record<string, Person>;
  D_OT_MAP: OtMap;
  /** 07 Company Plan · CPLAN rows, all FYs (B1). Pages scope them to S.fy themselves. */
  CPLAN: CpRow[];
}

export function buildModel(d: SddCore): Model {
  for (const k of Object.keys(CACHE)) delete CACHE[k];

  const rules = makeRules(d.D_WD, d.D_CAP, d.D_RULE);

  const fyKeys = Object.keys(d.D_WD).sort();
  const latest = fyKeys[fyKeys.length - 1];
  setHPD(latest ? rules.hpdOf(latest) : HPD_FALLBACK);

  const FYCODE: Record<number, string[]> = {};
  for (const fy of fyKeys) {
    FYCODE[Number.parseInt(fy, 10)] = ALLMI.map((i) => ymOfFy(fy, i));
  }

  const PEOPLE = buildPeople(d.D_EMP);
  const PEOPLE_NOW = buildPeopleNow(PEOPLE);
  const grpOf = buildGrpOf(PEOPLE_NOW);
  const SECTIONS = d.D_BD.sections.map((c) => ({ c, g: grpOf[c] || '—' }));
  const EMPWIN = buildEmpWin(PEOPLE);
  const ASSIGN = buildAssign(d.D_ASSIGN, PEOPLE, EMPWIN);

  const MPROWS: MpDerived[] = d.D_MPR.map((r) => {
    const typeStr = String(r.type || '').replace(' ', '');
    return {
      id: r.id,
      title: r.title,
      team: r.team,
      type: r.type,
      t1: r.t1,
      role: r.role,
      detail: r.detail,
      system: r.system,
      task2: r.task2,
      name: r.name,
      m: r.m,
      empid: r.empid,
      sec: r.sec,
      ms: r.ms,
      fy: r.fy,
      kind: typeStr === '01.Project' ? 'PJ' : 'MP',
      isLeave: typeStr === '11.Leave',
      src: r.src,
      editedAt: r.editedAt,
      batch: r.batch,
    };
  });

  const D_OT_MAP: OtMap = {};
  for (const r of d.D_OT) {
    if (!r.fy || !r.t) continue;
    const box = D_OT_MAP[r.fy] ?? {};
    box[r.t] = { plan: r.m, pl: r.pl, id: r.id, src: r.src, editedAt: r.editedAt };
    D_OT_MAP[r.fy] = box;
  }

  return {
    ...rules,
    FYCODE,
    SECTIONS,
    GROUPS: d.D_BD.groups,
    TYPES: d.D_BD.types,
    ROLES: d.D_BD.roles,
    SYSTEMS: d.D_BD.systems,
    SYSTEMS_ALL: d.D_BD.systemsAll,
    TASK2S: d.D_BD.task2s,
    TASK2S_ALL: d.D_BD.task2sAll,
    COMPANIES: d.D_BD.companies,
    grpOf,
    PEOPLE,
    PEOPLE_NOW,
    EMPWIN,
    ASSIGN,
    ASSIGN_FROM_BOARD: d.D_ASSIGN.length > 0,
    HOLIDAYS: [],
    MPROWS,
    PEOPLE_BY_EMP: byEmp(PEOPLE_NOW),
    PEOPLE_BY_NAME: byName(PEOPLE_NOW),
    D_OT_MAP,
    CPLAN: d.D_CP,
  };
}
